#define GENERAL_1_G

#include <stdio.h>
#include <p2c/p2c.h>
#include <p2c/general_1.h>

void set_timeout(sc, sec)
int sc;
double sec;
{
}
