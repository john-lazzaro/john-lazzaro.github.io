#define LOADER_G

#include <p2c/p2c.h>

#ifndef LOADER_H
#include <p2c/loader.h>
#endif



void markuser()
{
}

