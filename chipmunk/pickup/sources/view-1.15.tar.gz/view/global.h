#include <stdlib.h>
#define HAS_STDLIB
#include <p2c/p2c.h>

#define TEXT_IN_WINDOW
#define USE_MARK_RELEASE


#include <p2c/newcrt.h>
#include <unistd.h>
