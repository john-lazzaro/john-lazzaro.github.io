#define HPIB_2_G

#include <stdio.h>
#include <p2c/p2c.h>
#include <p2c/hpib_2.h>


void abort_hpib(sc)
int sc;
{
}

