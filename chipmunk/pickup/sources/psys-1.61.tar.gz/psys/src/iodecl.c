#define IODECLARATIONS_G

#include <stdio.h>
#include <p2c/p2c.h>
#include <p2c/iodecl.h>
