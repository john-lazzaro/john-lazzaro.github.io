#define GENERAL_2_G

#include <stdio.h>
#include <p2c/p2c.h>
#include <p2c/general_2.h>

void P_readstring(sc, s)
long sc;
Char *s;
{
}

void P_writestring(sc, s)
long sc;
Char *s;
{
}

void P_writestringln(sc, s)
long sc;
Char *s;
{
}

