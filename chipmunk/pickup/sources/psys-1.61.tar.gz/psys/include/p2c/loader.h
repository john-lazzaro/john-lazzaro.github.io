#ifndef LOADER_H
#define LOADER_H
#include <X11/Xlib.h>


#ifdef LOADER_G
# define vextern
#else
# define vextern extern
#endif



extern void markuser(void);



#endif /* LOADER_H */
