
#define help_init
#define help_index
#define help_do
#define help_show
#define help_setus
