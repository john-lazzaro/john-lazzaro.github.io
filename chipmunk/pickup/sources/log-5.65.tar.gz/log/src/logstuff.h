

struct ext_proc {
  char *name;
  Void (*proc)();
};

