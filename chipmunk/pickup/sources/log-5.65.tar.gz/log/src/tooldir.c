#include <p2c/p2c.h>
#include "logstuff.h"

/* Do not modify this file.  It is created automatically by "munch". */

extern Void Log_0_proc();
extern Void Log_16_7seg();
extern Void Log_16_break();
extern Void Log_16_clock();
extern Void Log_16_digh();
extern Void Log_16_inst();
extern Void Log_16_keypad();
extern Void Log_16_ledgate();
extern Void Log_16_ledgate2();
extern Void Log_16_proc();
extern Void Log_16_pulse();
extern Void Log_16_scope();
extern Void Log_16_switch();
extern Void Log_17_proc();
extern Void Log_1_proc();
extern Void Log_2_proc();
extern Void Log_32_proc();
extern Void Log_33_proc();
extern Void Log_7_ginst();
extern Void Log_7_proc();
extern Void Log_7_time();
extern Void Log_DEVTECHN_initlib_32();
extern Void Log_DEVTECHP_initlib_32();
extern Void Log_Diode1_INITLIB_32();
extern Void Log_NFET5_INITLIB_32();
extern Void Log_NFET7F_INITLIB_32();
extern Void Log_NFET7T_INITLIB_32();
extern Void Log_NPN1_INITLIB_32();
extern Void Log_NPN2_INITLIB_32();
extern Void Log_NSPC1_INITLIB_32();
extern Void Log_PFET5_INITLIB_32();
extern Void Log_PFET6_INITLIB_32();
extern Void Log_PFET7F_INITLIB_32();
extern Void Log_PFET7T_INITLIB_32();
extern Void Log_PHYSICAL_initlib_32();
extern Void Log_PNP1_INITLIB_32();
extern Void Log_PNP2_INITLIB_32();
extern Void Log_PSPC1_INITLIB_32();
extern Void Log_PWL_INITLIB_32();
extern Void Log_RUNSPEC_initlib_32();
extern Void Log_THERMAL_initlib_32();
extern Void Log_capfloat_initlib_32();
extern Void Log_dig_inst();
extern Void Log_fwr_initlib_32();
extern Void Log_ganglion_initlib_32();
extern Void Log_hres_initlib_32();
extern Void Log_hwr_initlib_32();
extern Void Log_idiff_initlib_32();
extern Void Log_iscope_initlib_32();
extern Void Log_iswitch1_initlib_32();
extern Void Log_iswitch2_initlib_32();
extern Void Log_logntk_proc();
extern Void Log_logspc_proc();
extern Void Log_lplot_proc();
extern Void Log_mmeter_initlib_32();
extern Void Log_moscap_initlib_32();
extern Void Log_mygates_ascdisp();
extern Void Log_mygates_asckbd();
extern Void Log_mygates_sram8k();
extern Void Log_nfet4_initlib_32();
extern Void Log_numbers_initlib_32();
extern Void Log_opamp_initlib_32();
extern Void Log_pfet4_initlib_32();
extern Void Log_resfloat_initlib_32();
extern Void Log_rtd_initlib_32();
extern Void Log_stairs_initlib_32();
extern Void Log_vdiff_initlib_32();
extern Void Log_vswitch_initlib_32();
extern Void Log_wramp_initlib_32();

struct ext_proc ext_proc_table[] = {
  "Log_0_proc", Log_0_proc,
  "Log_16_7seg", Log_16_7seg,
  "Log_16_break", Log_16_break,
  "Log_16_clock", Log_16_clock,
  "Log_16_digh", Log_16_digh,
  "Log_16_inst", Log_16_inst,
  "Log_16_keypad", Log_16_keypad,
  "Log_16_ledgate", Log_16_ledgate,
  "Log_16_ledgate2", Log_16_ledgate2,
  "Log_16_proc", Log_16_proc,
  "Log_16_pulse", Log_16_pulse,
  "Log_16_scope", Log_16_scope,
  "Log_16_switch", Log_16_switch,
  "Log_17_proc", Log_17_proc,
  "Log_1_proc", Log_1_proc,
  "Log_2_proc", Log_2_proc,
  "Log_32_proc", Log_32_proc,
  "Log_33_proc", Log_33_proc,
  "Log_7_ginst", Log_7_ginst,
  "Log_7_proc", Log_7_proc,
  "Log_7_time", Log_7_time,
  "Log_DEVTECHN_initlib_32", Log_DEVTECHN_initlib_32,
  "Log_DEVTECHP_initlib_32", Log_DEVTECHP_initlib_32,
  "Log_Diode1_INITLIB_32", Log_Diode1_INITLIB_32,
  "Log_NFET5_INITLIB_32", Log_NFET5_INITLIB_32,
  "Log_NFET7F_INITLIB_32", Log_NFET7F_INITLIB_32,
  "Log_NFET7T_INITLIB_32", Log_NFET7T_INITLIB_32,
  "Log_NPN1_INITLIB_32", Log_NPN1_INITLIB_32,
  "Log_NPN2_INITLIB_32", Log_NPN2_INITLIB_32,
  "Log_NSPC1_INITLIB_32", Log_NSPC1_INITLIB_32,
  "Log_PFET5_INITLIB_32", Log_PFET5_INITLIB_32,
  "Log_PFET6_INITLIB_32", Log_PFET6_INITLIB_32,
  "Log_PFET7F_INITLIB_32", Log_PFET7F_INITLIB_32,
  "Log_PFET7T_INITLIB_32", Log_PFET7T_INITLIB_32,
  "Log_PHYSICAL_initlib_32", Log_PHYSICAL_initlib_32,
  "Log_PNP1_INITLIB_32", Log_PNP1_INITLIB_32,
  "Log_PNP2_INITLIB_32", Log_PNP2_INITLIB_32,
  "Log_PSPC1_INITLIB_32", Log_PSPC1_INITLIB_32,
  "Log_PWL_INITLIB_32", Log_PWL_INITLIB_32,
  "Log_RUNSPEC_initlib_32", Log_RUNSPEC_initlib_32,
  "Log_THERMAL_initlib_32", Log_THERMAL_initlib_32,
  "Log_capfloat_initlib_32", Log_capfloat_initlib_32,
  "Log_dig_inst", Log_dig_inst,
  "Log_fwr_initlib_32", Log_fwr_initlib_32,
  "Log_ganglion_initlib_32", Log_ganglion_initlib_32,
  "Log_hres_initlib_32", Log_hres_initlib_32,
  "Log_hwr_initlib_32", Log_hwr_initlib_32,
  "Log_idiff_initlib_32", Log_idiff_initlib_32,
  "Log_iscope_initlib_32", Log_iscope_initlib_32,
  "Log_iswitch1_initlib_32", Log_iswitch1_initlib_32,
  "Log_iswitch2_initlib_32", Log_iswitch2_initlib_32,
  "Log_logntk_proc", Log_logntk_proc,
  "Log_logspc_proc", Log_logspc_proc,
  "Log_lplot_proc", Log_lplot_proc,
  "Log_mmeter_initlib_32", Log_mmeter_initlib_32,
  "Log_moscap_initlib_32", Log_moscap_initlib_32,
  "Log_mygates_ascdisp", Log_mygates_ascdisp,
  "Log_mygates_asckbd", Log_mygates_asckbd,
  "Log_mygates_sram8k", Log_mygates_sram8k,
  "Log_nfet4_initlib_32", Log_nfet4_initlib_32,
  "Log_numbers_initlib_32", Log_numbers_initlib_32,
  "Log_opamp_initlib_32", Log_opamp_initlib_32,
  "Log_pfet4_initlib_32", Log_pfet4_initlib_32,
  "Log_resfloat_initlib_32", Log_resfloat_initlib_32,
  "Log_rtd_initlib_32", Log_rtd_initlib_32,
  "Log_stairs_initlib_32", Log_stairs_initlib_32,
  "Log_vdiff_initlib_32", Log_vdiff_initlib_32,
  "Log_vswitch_initlib_32", Log_vswitch_initlib_32,
  "Log_wramp_initlib_32", Log_wramp_initlib_32,
  NULL, NULL
};

