
#define help_init(x, y)
#define help_index(x, y)
#define help_do(x)
#define help_show(x, y) 
#define help_setus
