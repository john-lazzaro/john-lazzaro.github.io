
#ifndef TABLET_STUFF_H
#define TABLET_STUFF_H

#ifndef CRT_STUFF_H
#include "crt_stuff.h"
#endif

#ifndef MAT_STUFF_H
#include "mat_stuff.h"
#endif

#ifndef SYSGLOBALS_H
#include <p2c/sysglobals.h>
#endif


typedef struct mypen {
  long x, y;   /* position in grid space */
  long rx, ry;   /* position before grid space */
  short sx, sy;   /* position on graphics screen */
  short ax, ay;   /* alpha position */
  boolean didRef;   /* Refreshed during tablet read? */
  boolean depressed, near_, dn, up, moving;  /* position in grid space moving? */
  boolean amoving;   /* position in alpha space moving? */
} mypen;


extern mypen curPen;
extern short grid_mul, grid_rnd;
extern boolean grid_hex;
extern void *updateProc;
extern short boopTime, boopFreq;


extern void boop(void);
extern void update_tablet0(void);
extern void update_tablet(void);
extern void update_tablet_all(void);

#endif  /* TABLET_STUFF_H */
