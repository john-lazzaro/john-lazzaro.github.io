
#ifndef NAME_STUFF_H
#define NAME_STUFF_H


#ifndef MYLIB_H
#include <p2c/mylib.h>
#endif

#ifndef SYSGLOBALS_H
#include <p2c/sysglobals.h>
#endif

#ifndef ASM_H
#include <p2c/asm.h>
#endif

#ifndef SYSDEVS_H
#include <p2c/sysdevs.h>
#endif

#ifndef NEWCI_H
#include <p2c/newci.h>
#endif

#ifndef NEWASM_H
#include <p2c/newasm.h>
#endif

#ifndef NEWKBD_H
#include <p2c/newkbd.h>
#endif

#ifndef CITINFOMOD_H
#include <p2c/citinfomod.h>
#endif

#ifndef LUNIX_PAS_H
#include <p2c/lunix_pas.h>
#endif

#ifndef TABLET_STUFF_H
#include "tablet_stuff.h"
#endif

#ifndef GR_STUFF_H
#include "gr_stuff.h"
#endif

#ifndef MAT_STUFF_H
#include "mat_stuff.h"
#endif

#ifndef CRT_STUFF_H
#include "crt_stuff.h"
#endif

#ifndef BB_STUFF_H
#include "bb_stuff.h"
#endif

#ifndef DATA_TYPES_H
#include "data_types.h"
#endif

#ifndef FFMAN_H
#include "ffman.h"
#endif

#ifndef PRIM_STUFF_H
#include "prim_stuff.h"
#endif

#ifndef MENU_STUFF_H
#include "menu_stuff.h"
#endif

#ifndef MENU_H
#include "menu.h"
#endif


extern boolean prompt_filename;


extern Char *getFigure(Char *Result);
extern Char *getfname(Char *Result, Char *start);
extern Char *getfilename(Char *Result, Char *prompt, Char *default_);

extern boolean yes_no_quest(Char *pmpt);


#endif /*NAME_STUFF_H*/
