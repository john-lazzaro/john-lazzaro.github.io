
#ifndef BB_STUFF_H
#define BB_STUFF_H

typedef struct bbrec {
  long xh, yh, xl, yl;
} bbrec;

extern bbrec bbbb;              /* Box-type pen-position */
extern long bbx, bby;           /* pen-position */
extern long bbrx, bbry, bbrxy;  /* radius in X, radius in Y, radius^2 in XY */

extern void makebb(long x, long y, long rx, long ry);
extern void newbb(bbrec *bb, long lx, long ly, long hx, long hy);
extern void emptybb(bbrec *bb);
extern void addbb(bbrec *bb, bbrec *bb2);
extern void addbbpnt(bbrec *bb, long x, long y);
extern boolean bbcheck(bbrec *bb);
extern boolean pntcheck(long x, long y);
extern boolean linecheck(long x1, long y1, long x2, long y2);
extern boolean bbrcheck(bbrec *bb);
extern boolean bbincheck(bbrec *bb);
extern boolean bbxcheck(long xl, long yl, long xh, long yh);
extern boolean bbxrcheck(long xl, long yl, long xh, long yh);

#endif /*BB_STUFF_H*/
