/* Output from p2c, the Pascal-to-C translator */
/* From input file "hcsuga4.text" */


/*Caged_Process='com $B$M$B$M$B$Mq$Mwol $B$M'*/



#include <p2c/p2c.h>

#ifndef WOLCOMPLIB_H
#include <wolcomp.h>
#endif


#define plotter         705

/*lambda   =150;*/
/*number of cif units in one lambda*/

#define tinypadlib  "/sashimi/tools/vlsi/src/chipmunk/example/tinypadlib/"
#define row1dir  "/sashimi/tools/vlsi/src/chipmunk/example/row1/"

#define sugadir ""
#define number          8


/******************************************/
/*********** main program ***********/

main(argc, argv)
int argc;
Char *argv[];
{  /*main program*/
  long i, j;   /* global scratch registers */
  long x2, y2, x3, y3, x4, y4, x5, y5, x6, x7, x8, x9, y6, numberofstages,
       innervate;
  Char STR1[24];
  Char STR2[26];
  Char STR3[28];
  Char STR4[38];
  Char STR5[36];
  Char STR6[40];
  Char STR7[30];
  Char STR8[32];
  Char STR9[34];

  PASCAL_MAIN(argc, argv);
  set_up();   /* initialize program state */


  lambda = 100;

  sprintf(STR1, "%sknobpad", tinypadlib);
  /*load in pad library*/

  /*all pads same height, width, and orientation*/

  getfile(STR1);   /*diode connected nfet input pad*/
  sprintf(STR2, "%spknobpad", tinypadlib);
  getfile(STR2);   /*diode connected pfet input pad*/
  sprintf(STR2, "%spleakpad", tinypadlib);
  getfile(STR2);   /*leak connected pfet input pad*/
  sprintf(STR1, "%stwinpad", tinypadlib);
  getfile(STR1);   /*diode connected nfet pad w/pfet input*/
  sprintf(STR2, "%sknobcpad", tinypadlib);
  getfile(STR2);   /*diode connected nfet input corner pad*/
  sprintf(STR1, "%sfollpad", tinypadlib);
  getfile(STR1);   /*voltage follower output pad*/
  sprintf(STR1, "%sinvpad", tinypadlib);
  getfile(STR1);   /*inverter output pad*/
  sprintf(STR2, "%spfollpad", tinypadlib);
  getfile(STR2);   /*voltage follower output pad*/
  sprintf(STR2, "%sisetfpad", tinypadlib);
  getfile(STR2);   /*input pad for Iset of pad followers*/
  sprintf(STR3, "%sisetverpad", tinypadlib);
  getfile(STR3);   /*input pad for Iset of pad followers*/
  sprintf(STR1, "%svinpad", tinypadlib);
  getfile(STR1);   /*protected voltage input/output pad*/
  sprintf(STR1, "%svddpad", tinypadlib);
  getfile(STR1);   /*vdd corner pad input */
  sprintf(STR1, "%sgndpad", tinypadlib);
  getfile(STR1);   /*ground corner pad input */
  sprintf(STR1, "%scoregnd", tinypadlib);
  getfile(STR1);   /*gnd to chip core*/
  sprintf(STR1, "%scorevdd", tinypadlib);
  getfile(STR1);   /*vdd to chip core */
  sprintf(STR1, "%spinvpad", tinypadlib);
  getfile(STR1);   /*inverter pad ?? */
  sprintf(STR1, "%svincpad", tinypadlib);
  getfile(STR1);   /*corner vin pad */
  sprintf(STR2, "%snleakpad", tinypadlib);
  getfile(STR2);   /*nfet leak pad */
  sprintf(STR2, "%sshortvdd", tinypadlib);
  getfile(STR2);   /*shorts core and pad vdd */
  sprintf(STR2, "%sshortgnd", tinypadlib);
  getfile(STR2);   /*shorts pad and core gnd */
  sprintf(STR3, "%snleakverpad", tinypadlib);
  getfile(STR3);   /*nfet leak pad */
  sprintf(STR2, "%sinvverpad", tinypadlib);
  getfile(STR2);   /*vertical end inverter pad */
  sprintf(STR2, "%svinverpad", tinypadlib);
  getfile(STR2);   /*vertical end vin pad */
  sprintf(STR3, "%svinver2pad", tinypadlib);
  getfile(STR3);   /*vertical end vin pad */
  sprintf(STR2, "%svinhorpad", tinypadlib);
  getfile(STR2);   /*horizontal end vin pad */
  sprintf(STR3, "%sfollverpad", tinypadlib);
  getfile(STR3);   /*vertical end follower pad  */
  sprintf(STR3, "%sfollhorpad", tinypadlib);
  getfile(STR3);   /*horizontal end follower */

  sprintf(STR4, "%ssinglescan", sugadir);
  /*these spacers same height, and orientation, incremental size*/

  getfile(STR4);   /*CSRL scanner element*/
  sprintf(STR5, "%ssscanbot", sugadir);
  getfile(STR5);   /*CSRL scanner element*/
  sprintf(STR5, "%ssscantop", sugadir);
  getfile(STR5);   /*CSRL scanner element*/
  sprintf(STR6, "%ssingscanamp", sugadir);
  getfile(STR6);   /*CSRL scanner element*/
  sprintf(STR5, "%ssamptop", sugadir);
  getfile(STR5);   /*CSRL scanner element*/
  sprintf(STR5, "%ssampbot", sugadir);
  getfile(STR5);   /*CSRL scanner element*/

  sprintf(STR7, "%sord2odd", row1dir);
  getfile(STR7);   /*second-order section block*/
  sprintf(STR8, "%sord2even", row1dir);
  getfile(STR8);   /*second-order section block*/
  sprintf(STR7, "%sord2sp", row1dir);
  getfile(STR7);   /*wiring for second-order section block*/
  sprintf(STR5, "%sord2top", sugadir);
  getfile(STR5);   /*top cap for SOC array*/
  sprintf(STR5, "%sord2bot", sugadir);
  getfile(STR5);   /*bottom cap for SOC array*/
  sprintf(STR8, "%sord2left", row1dir);
  getfile(STR8);   /*left cap for SOC array*/
  sprintf(STR7, "%sord2ro", row1dir);
  getfile(STR7);   /*right cap for SOC array*/
  sprintf(STR7, "%sord2re", row1dir);
  getfile(STR7);   /*right cap for SOC array*/

  sprintf(STR7, "%shysdiff", row1dir);
  getfile(STR7);   /*hysteretic differentiator array*/
  sprintf(STR7, "%sspgang", row1dir);
  getfile(STR7);   /*half-wave rectifier array*/
  sprintf(STR9, "%sspsyn", sugadir);
  getfile(STR9);   /*half-wave rectifier array*/
  sprintf(STR9, "%sspcell", sugadir);
  getfile(STR9);   /*half-wave rectifier array*/
  sprintf(STR9, "%ssswta", sugadir);
  getfile(STR9);   /*half-wave rectifier array*/
  sprintf(STR9, "%swtathr", sugadir);
  getfile(STR9);   /*half-wave rectifier array*/
  sprintf(STR9, "%shctop", sugadir);
  getfile(STR9);   /*hc top spacer*/
  sprintf(STR9, "%shcbot", sugadir);
  getfile(STR9);   /*hc bottom spacer*/
  sprintf(STR5, "%spayload", sugadir);
  getfile(STR5);   /*free top spacer*/
  sprintf(STR5, "%sautosect", sugadir);
  getfile(STR5);   /*free top spacer*/
  sprintf(STR9, "%sjoin1", sugadir);
  getfile(STR9);   /*free top spacer*/
  sprintf(STR9, "%spaytop", sugadir);
  getfile(STR9);   /*free top spacer*/
  sprintf(STR9, "%spaybot", sugadir);
  getfile(STR9);   /*free bottom spacer*/

  sprintf(STR9, "%ssideroute1", row1dir);
  getfile(STR9);   /*side pad router*/
  sprintf(STR9, "%ssideroute2", row1dir);
  getfile(STR9);   /*side pad router*/
  sprintf(STR9, "%ssideroute3", row1dir);
  getfile(STR9);   /*side pad router*/
  sprintf(STR9, "%ssideroute4", row1dir);
  getfile(STR9);   /*side pad router*/
  sprintf(STR4, "%soutspace", row1dir);
  getfile(STR4);   /*side pad router*/
  sprintf(STR7, "%sdummyhc", row1dir);
  getfile(STR7);   /*side pad spacer*/
  sprintf(STR6, "%scorfollspace", sugadir);
  getfile(STR6);   /*spacers for empty frame*/
  sprintf(STR6, "%scorbotspace", sugadir);
  getfile(STR6);   /*spacers for empty frame*/




  /* Your Design Here */

  /* getfile(''); */
  /*load in each cell*/

  /* a vertical row of things*/

  /*define('a new cell');
    draw(cell('an old cell')); y0:=y1;*/
  /*drawx(cell('an old cell'),1); y0:=y1;*/
  /*CCW 90 degrees*/
  /*drawx(cell('an old cell'),2); y0:=y1;*/
  /*CCW 180 degrees*/
  /*drawx(cell('an old cell'),3); y0:=y1;*/
  /*CCW 270 degrees*/
  /*drawx(cell('an old cell'),4); y0:=y1;*/
  /*mirror x*/
  /*drawx(cell('an old cell'),5); y0:=y1;*/
  /*mirror x + CCW 90*/
  /*drawx(cell('an old cell'),6); y0:=y1;*/
  /*mirror x + CCW 180*/
  /*drawx(cell('an old cell'),7); y0:=y1;*/
  /*mirror x + CCW 270*/
  /*endef;*/

  define("rotate1");
  draw(cell("follpad"));
  y0 = y1;
  drawx(cell("follpad"), 1L);
  y0 = y1;   /*CCW 90 degrees*/
  drawx(cell("follpad"), 2L);
  y0 = y1;   /*CCW 180 degrees*/
  drawx(cell("follpad"), 3L);
  y0 = y1;   /*CCW 270 degrees*/
  drawx(cell("follpad"), 4L);
  y0 = y1;   /*mirror x*/
  drawx(cell("follpad"), 5L);
  y0 = y1;   /*mirror x + CCW 90*/
  drawx(cell("follpad"), 6L);
  y0 = y1;   /*mirror x + CCW 180*/
  drawx(cell("follpad"), 7L);
  y0 = y1;   /*mirror x + CCW 270*/
  endef();

  define("rotate2");
  draw(cell("vddpad"));
  y0 = y1;
  drawx(cell("vddpad"), 1L);
  y0 = y1;   /*CCW 90 degrees*/
  drawx(cell("vddpad"), 2L);
  y0 = y1;   /*CCW 180 degrees*/
  drawx(cell("vddpad"), 3L);
  y0 = y1;   /*CCW 270 degrees*/
  drawx(cell("vddpad"), 4L);
  y0 = y1;   /*mirror x*/
  drawx(cell("vddpad"), 5L);
  y0 = y1;   /*mirror x + CCW 90*/
  drawx(cell("vddpad"), 6L);
  y0 = y1;   /*mirror x + CCW 180*/
  drawx(cell("vddpad"), 7L);
  y0 = y1;   /*mirror x + CCW 270*/
  endef();

  /* a horizontal row of things: can also set x0, y0 to 0*/

  /*define('a new cell');
    draw(cell('an old cell')); x0:=x1;
    drawx(cell('an old cell'),2); x0:=x1;
    drawx(cell('an old cell'),4); x0:=x1;
    drawx(cell('an old cell'),6); x0:=x1;
   endef;*/

  define("scanblock");
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  endef();

  define("scantopcap");
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  endef();

  define("scanbotcap");
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  drawx(cell("singlescan"), 1L);
  y0 = y1;
  endef();

  define("scampblock");
  drawx(cell("singscanamp"), 0L);
  y0 = y1;
  drawx(cell("singscanamp"), 6L);
  y0 = y1;
  drawx(cell("singscanamp"), 0L);
  y0 = y1;
  drawx(cell("singscanamp"), 6L);
  y0 = y1;
  endef();

  define("scamptopcap");
  drawx(cell("singscanamp"), 0L);
  y0 = y1;
  drawx(cell("singscanamp"), 6L);
  y0 = y1;
  endef();

  define("scampbotcap");
  drawx(cell("singscanamp"), 0L);
  y0 = y1;
  drawx(cell("singscanamp"), 6L);
  y0 = y1;
  endef();

  define("ord2block");
  drawx(cell("ord2left"), 0L);
  x0 = x1;
  drawx(cell("ord2odd"), 0L);
  x0 = x1;
  drawx(cell("ord2ro"), 4L);
  x0 = 0;
  y0 = y1;
  drawx(cell("ord2sp"), 0L);
  y0 = y1;
  drawx(cell("ord2left"), 6L);
  x0 = x1;
  drawx(cell("ord2even"), 2L);
  x0 = x1;
  drawx(cell("ord2re"), 2L);
  x0 = 0;
  y0 = y1;

  drawx(cell("ord2left"), 0L);
  x0 = x1;
  drawx(cell("ord2odd"), 0L);
  x0 = x1;
  drawx(cell("ord2ro"), 4L);
  x0 = 0;
  y0 = y1;
  drawx(cell("ord2sp"), 0L);
  y0 = y1;
  drawx(cell("ord2left"), 6L);
  x0 = x1;
  drawx(cell("ord2even"), 2L);
  x0 = x1;
  drawx(cell("ord2re"), 2L);
  x0 = 0;
  y0 = y1;
  endef();


  define("ord2botcap");
  drawx(cell("ord2left"), 0L);
  x0 = x1;
  drawx(cell("ord2odd"), 0L);
  x0 = x1;
  drawx(cell("ord2ro"), 4L);
  x0 = 0;
  y0 = y1;
  drawx(cell("ord2sp"), 0L);
  y0 = y1;
  drawx(cell("ord2left"), 6L);
  x0 = x1;
  drawx(cell("ord2even"), 2L);
  x0 = x1;
  drawx(cell("ord2re"), 2L);
  x0 = 0;
  y0 = y1;
  endef();

  define("ord2topcap");
  drawx(cell("ord2left"), 0L);
  x0 = x1;
  drawx(cell("ord2odd"), 0L);
  x0 = x1;
  drawx(cell("ord2ro"), 4L);
  x0 = 0;
  y0 = y1;
  drawx(cell("ord2sp"), 0L);
  y0 = y1;
  drawx(cell("ord2left"), 6L);
  x0 = x1;
  drawx(cell("ord2even"), 2L);
  x0 = x1;
  drawx(cell("ord2re"), 2L);
  x0 = 0;
  endef();

  define("hcunit");
  drawx(cell("hysdiff"), 0L);
  x0 = x1;
  drawx(cell("spsyn"), 0L);
  x0 = x1;
  for (innervate = 1; innervate <= 11; innervate++) {
    drawx(cell("spcell"), 0L);
    x0 = x1;
  }
  endef();

  define("hcblock");
  drawx(cell("hcunit"), 6L);
  y0 = y1;
  drawx(cell("hcunit"), 0L);
  y0 = y1;
  drawx(cell("hcunit"), 6L);
  y0 = y1;
  drawx(cell("hcunit"), 0L);
  y0 = y1;
  endef();

  define("hctopcap");
  drawx(cell("hcunit"), 6L);
  y0 = y1;
  drawx(cell("hcunit"), 0L);
  y0 = y1;
  endef();

  define("hcbotcap");
  drawx(cell("hcunit"), 6L);
  y0 = y1;
  drawx(cell("hcunit"), 0L);
  y0 = y1;
  endef();

  define("payunit");
  drawx(cell("join1"), 0L);
  x0 = x1;
  drawx(cell("autosect"), 0L);
  x0 = x1;
  drawx(cell("sswta"), 0L);
  endef();

  define("paythr");
  drawx(cell("join1"), 0L);
  x0 = x1;
  drawx(cell("autosect"), 0L);
  x0 = x1;
  drawx(cell("wtathr"), 0L);
  endef();

  define("payblock");
  drawx(cell("payunit"), 6L);
  y0 = y1;
  drawx(cell("payunit"), 0L);
  y0 = y1;
  drawx(cell("payunit"), 6L);
  y0 = y1;
  drawx(cell("payunit"), 0L);
  y0 = y1;
  endef();

  define("payblockthr");
  drawx(cell("paythr"), 6L);
  y0 = y1;
  drawx(cell("paythr"), 0L);
  y0 = y1;
  drawx(cell("paythr"), 6L);
  y0 = y1;
  drawx(cell("paythr"), 0L);
  y0 = y1;
  endef();

  define("paytopcap");
  drawx(cell("payunit"), 6L);
  y0 = y1;
  drawx(cell("payunit"), 0L);
  y0 = y1;
  endef();

  define("paybotcap");
  drawx(cell("payunit"), 6L);
  y0 = y1;
  drawx(cell("payunit"), 0L);
  y0 = y1;
  endef();

  define("basout");
  draw(cell("outspace"));
  x0 = x1;
  draw(cell("sideroute3"));
  x0 = x1;
  draw(cell("sideroute4"));
  y0 = y1;
  draw(cell("dummyhc"));
  y0 = y1;
  draw(cell("sideroute2"));
  y0 = 0;
  x0 = x1;
  draw(cell("sideroute1"));
  x0 = x1;
  endef();

  define("hcout");
  draw(cell("outspace"));
  x0 = x1;
  draw(cell("sideroute3"));
  x0 = x1;
  draw(cell("sideroute4"));
  y0 = y1;
  drawx(cell("spgang"), 3L);
  y0 = y1;
  drawx(cell("hysdiff"), 3L);
  y0 = y1;
  draw(cell("sideroute2"));
  y0 = 0;
  x0 = x1;
  draw(cell("sideroute1"));
  x0 = x1;
  endef();


  define("bottom");
  drawx(cell("vincpad"), 5L);
  x0 = x1;   /*Q*/
  drawx(cell("vinhorpad"), 6L);
  x0 = x1;   /*Lin*/
  drawx(cell("vinpad"), 6L);
  x0 = x1;   /*Vin*/
  drawx(cell("vinpad"), 2L);
  x0 = x1;   /*Htau*/
  drawx(cell("vinpad"), 6L);
  x0 = x1;   /*PW2*/
  drawx(cell("corevdd"), 2L);
  x0 = x1;   /*Vdd*/
  drawx(cell("vinpad"), 2L);
  x0 = x1;   /*Weight*/
  drawx(cell("vinpad"), 2L);
  x0 = x1;   /*Lastin*/
  drawx(cell("vinpad"), 6L);
  x0 = x1;   /*PW*/
  drawx(cell("vinhorpad"), 2L);
  x0 = x1;   /*Clk*/
  drawx(cell("vddpad"), 3L);
  x0 = x1;   /*Vdd*/
  endef();

  define("botend");
  drawx(cell("vinverpad"), 1L);
  x0 = x1;   /*Tau*/
  drawx(cell("corbotspace"), 0L);
  x0 = x1;
  x2 = x1;
  drawx(cell("ord2bot"), 0L);
  x0 = x1;
  drawx(cell("hcbot"), 0L);
  x0 = x1;
  drawx(cell("paybot"), 0L);
  x0 = x1;
  drawx(cell("sampbot"), 0L);
  x0 = x1;
  drawx(cell("sscanbot"), 0L);
  y0 = y1;
  x0 = x2;
  drawx(cell("ord2botcap"), 0L);
  x0 = x1;
  drawx(cell("hcbotcap"), 0L);
  x0 = x1;
  drawx(cell("paybotcap"), 0L);
  x0 = x1;
  drawx(cell("scampbotcap"), 0L);
  x0 = x1;
  drawx(cell("scanbotcap"), 0L);
  x0 = x1;
  y0 = 0;
  drawx(cell("invverpad"), 7L);
  x0 = x1;   /*Sync*/
  endef();

  define("regbas");
  drawx(cell("follpad"), 1L);
  x0 = x1;
  drawx(cell("basout"), 0L);
  x0 = x1;
  drawx(cell("ord2block"), 0L);
  x0 = x1;
  drawx(cell("hcblock"), 0L);
  x0 = x1;
  drawx(cell("payblock"), 0L);
  x0 = x1;
  drawx(cell("scampblock"), 0L);
  x0 = x1;
  drawx(cell("scanblock"), 0L);
  x0 = x1;
  drawx(cell("invpad"), 7L);
  x0 = x1;
  endef();

  define("regbasthr");
  drawx(cell("follpad"), 1L);
  x0 = x1;
  drawx(cell("basout"), 0L);
  x0 = x1;
  drawx(cell("ord2block"), 0L);
  x0 = x1;
  drawx(cell("hcblock"), 0L);
  x0 = x1;
  drawx(cell("payblockthr"), 0L);
  x0 = x1;
  drawx(cell("scampblock"), 0L);
  x0 = x1;
  drawx(cell("scanblock"), 0L);
  x0 = x1;
  drawx(cell("invpad"), 7L);
  x0 = x1;
  endef();

  define("reghc");
  drawx(cell("invpad"), 5L);
  x0 = x1;
  drawx(cell("hcout"), 0L);
  x0 = x1;
  drawx(cell("ord2block"), 0L);
  x0 = x1;
  drawx(cell("hcblock"), 0L);
  x0 = x1;
  drawx(cell("payblock"), 0L);
  x0 = x1;
  drawx(cell("scampblock"), 0L);
  x0 = x1;
  drawx(cell("scanblock"), 0L);
  x0 = x1;
  drawx(cell("invpad"), 7L);
  x0 = x1;
  endef();

  define("topend");
  drawx(cell("vinverpad"), 5L);
  x0 = x1;   /*Tau*/
  drawx(cell("corfollspace"), 6L);
  x0 = x1;
  x2 = x1;
  drawx(cell("ord2topcap"), 0L);
  x0 = x1;
  drawx(cell("hctopcap"), 0L);
  x0 = x1;
  drawx(cell("paytopcap"), 0L);
  x0 = x1;
  drawx(cell("scamptopcap"), 0L);
  x0 = x1;
  drawx(cell("scantopcap"), 0L);
  y0 = y1;
  x0 = x2;
  drawx(cell("ord2top"), 0L);
  x0 = x1;
  drawx(cell("hctop"), 0L);
  x0 = x1;
  drawx(cell("paytop"), 0L);
  x0 = x1;
  drawx(cell("samptop"), 0L);
  x0 = x1;
  drawx(cell("sscantop"), 0L);
  x0 = x1;
  y0 = 0;
  drawx(cell("vinver2pad"), 3L);
  x0 = x1;   /*PWOut*/
  endef();

  define("top");
  drawx(cell("vincpad"), 1L);
  x0 = x1;   /*Q*/
  drawx(cell("vinhorpad"), 0L);
  x0 = x1;   /*Lin*/
  drawx(cell("vinpad"), 0L);
  x0 = x1;   /*PW*/
  drawx(cell("vinpad"), 4L);
  x0 = x1;   /*Spont*/
  drawx(cell("vinpad"), 0L);
  x0 = x1;   /*PW2*/
  drawx(cell("coregnd"), 0L);
  x0 = x1;   /*Gnd*/
  drawx(cell("nleakpad"), 0L);
  x0 = x1;   /*Vcntrl*/
  drawx(cell("vinpad"), 0L);
  x0 = x1;   /*Weight*/
  drawx(cell("isetfpad"), 0L);
  x0 = x1;   /*Scanamp and Isetfpad*/
  drawx(cell("follhorpad"), 0L);
  x0 = x1;   /*Vout*/
  drawx(cell("gndpad"), 0L);
  x0 = x1;   /*Gnd*/
  endef();

  define("chip");
  draw(cell("bottom"));
  y0 = y1;
  draw(cell("botend"));
  y0 = y1;
  draw(cell("reghc"));
  y0 = y1;
  draw(cell("regbas"));
  y0 = y1;
  draw(cell("reghc"));
  y0 = y1;
  draw(cell("regbasthr"));
  y0 = y1;
  draw(cell("reghc"));
  y0 = y1;
  draw(cell("regbas"));
  y0 = y1;
  draw(cell("reghc"));
  y0 = y1;
  draw(cell("topend"));
  y0 = y1;
  draw(cell("top"));
  y0 = y1;
  endef();

  /*final command*/

  x0 = 0;
  y0 = 0;
  draw(cell("chip"));

  shut_down();   /* close output file */
  exit(0);
}



/* End. */
