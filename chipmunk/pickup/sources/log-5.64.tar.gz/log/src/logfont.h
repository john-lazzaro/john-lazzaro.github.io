
#define logfont_lfont NULL

