
#include <stdio.h>
#include <ctype.h>
#include <p2c/p2c.h>

typedef union swap2 {
        short ival;
        unsigned char c[2];
} swap2;

typedef union swap4 {
        long ival;
        unsigned char c[4];
} swap4;

short shortsw(sh)
short getshortsw(c)
long getintsw(c)
long intsw(ii)
short reverse(s)










