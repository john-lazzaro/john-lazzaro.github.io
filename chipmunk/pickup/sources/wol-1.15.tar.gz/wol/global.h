#ifdef sun4
#include <sys/types.h>
#endif
#include <p2c/p2c.h>

#define TEXT_IN_WINDOW
#define USE_MARK_RELEASE


#include <p2c/newcrt.h>

#ifdef Const
#undef Const
#endif
#define Const

#ifdef const
#undef const
#endif
#define const
#define asm_newbytes(p, n) *(p) = malloc(n)
#ifdef sun4
#define labs abs
#endif
