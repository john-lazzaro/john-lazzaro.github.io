/*
 * hash.h
 *
 */

#define	HASH_TABLE_SIZE	255

struct Symbol
{
  char                  *name;
  char                  **namePtr;
  char                  *label;
  struct Bucket         *ports;
  char			*remainder;
  struct Bucket         *instances;
};

struct Bucket
{
  struct Symbol *symbol;
  struct Bucket *prev;
  struct Bucket *next;
};

extern void             InitHashTable ();
extern struct Symbol    *GetSymbol ();
extern void		NullSymbol ();
extern void             FirstBucket ();
extern void             LastBucket ();
extern void             AddBucket ();
extern struct Symbol    *InBucket ();

