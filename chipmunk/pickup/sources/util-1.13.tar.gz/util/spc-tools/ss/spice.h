/*
 * spice.h
 *
 */

extern void	GetSpiceWord ();
extern int	GetLastSpiceWord ();

