/* "boxify", is a simple filter for cleaning up quite general CIF
             and make it readable for "WOL"
   Copyright (C) 1990 Tor Sverre Lande
   Author's address: bassen@ifi.uio.no

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (any version).

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

struct polygon
{
	int a,b;
};

typedef struct polygon Polygon;

extern int gentrapes(Edge *l, Edge *r, double a,
		     int resa, int resb,long Xoffset, long Yoffset);

extern int mergeedges(Edge_Head * e1, Edge_Head * e2);

extern int makeedges(Edge_Head * eh);

extern int updateactive(Edge_Head * ah, Edge_Head * eh, double alt);

extern int mates(Edge_Head * ah, double cy, double alt,
		 int resa, int resb, long Xoffset, long Yoffset);

extern int delete_under(Edge_Head * ah, double alt);

extern int trapes(Polygon * pl, int resa, int resb,
		  long Xoffset, long Yoffset);
