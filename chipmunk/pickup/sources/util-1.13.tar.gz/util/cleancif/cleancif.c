/* Output from p2c, the Pascal-to-C translator */
/* From input file "plusds.text" */

#include <stdio.h>

int main(int argc, char *argv[])

{

int input,ready,dump,semicolon;
int c;

ready=1; dump = 0; semicolon = 0;
while ((c=getchar()) != EOF)
  if (c == '\n'){
    if (dump==0)  { 
                    /* if normal mode pass cif through as always */
      putchar(c);
      ready=1;      /* next character could signal a comment */
    }
    else 
      if (semicolon==1) { 
	                /* if no semicolon just keep dumping */
	dump = 0;       /* get out of dump mode */
	semicolon = 0;  /* reset semicolon flag */
	ready=1;        /* next character could signal a comment */
      }   
  }
  else{
    if (ready==1)    /* first character of a new line */
      if (c == '9')  /* a comment that needs dumping */
	dump = 1;    /* set dumping flag */
    ready = 0;       /* 9 no longer indicates a comment */
    if (dump==0)     /* if not in dump mode put out normally */
      putchar(c);
    else             /* if we're in dump mode check for ; to terminate */
      if (c == ';')
	semicolon = 1;
  }
      
}
/* End. */
