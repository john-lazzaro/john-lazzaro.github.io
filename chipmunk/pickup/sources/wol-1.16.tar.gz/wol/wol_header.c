
/* "WOL", an integrated circuit layout tool,
   Copyright (C) 1983, 1990 California Institute of Technology.
   Author: Massimo Sivilotti
   Thanks to: Glenn Gribble, Marty Sirkin, Sylvie Rychebusch
	      Maryann Mayer, Carver Mead, Rick Koshi, Torre Lande
   Maintainer: John Lazzaro
   Maintainers's address: lazzaro@hobiecat.cs.caltech.edu;
                          CB 425/ CU Boulder/Boulder CO 91125. 
			  Send questions, bug fixes, to this address.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (Version 1, 1989).

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

/* Output from p2c, the Pascal-to-C translator */
/* p2c: wolopt.text, line 9: Note: Range checking is OFF [216] */
/* p2c: wolopt.text, line 10: Note: Stack checking is OFF [217] */
/* p2c: wolopt.text, line 16: Note: Range checking is ON [216] */
/* From input file "wol_header.text" */


/* Change these for testing */



#include "global.h"


#define WOL_HEADER_G
#include "wol_header.h"


const xformarray xf = {
  { 0, 1, 2, 3, 4, 5, 6, 7 },
  { 1, 2, 3, 0, 7, 4, 5, 6 },
  { 2, 3, 0, 1, 6, 7, 4, 5 },
  { 3, 0, 1, 2, 5, 6, 7, 4 },
  { 4, 5, 6, 7, 0, 1, 2, 3 },
  { 5, 6, 7, 4, 3, 0, 1, 2 },
  { 6, 7, 4, 5, 2, 3, 0, 1 },
  { 7, 4, 5, 6, 1, 2, 3, 0 }
};




/* End. */
