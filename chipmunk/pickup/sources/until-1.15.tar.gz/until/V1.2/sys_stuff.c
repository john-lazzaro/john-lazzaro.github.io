
/* "UNTIL", a graphics editor,
   Copyright (C) 1985, 1990 California Institute of Technology.
   Original authors: Glenn Gribble, port by Steve DeWeerth
   Unix Port Maintainer: John Lazzaro
   Maintainers's address: lazzaro@hobiecat.cs.caltech.edu;
                          CB 425 CU Boulder/Boulder CO 91125. 

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (Version 1, 1989).

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to the
Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
USA. */


/*******************************************************************************/
/*                                                                             */ 
/*  file contains stuff that used to be in /usr/cs10/src/p-system/*.c          */
/*                                                                             */ 
/*  created by steve - 12 May 1990                                             */
/*                                                                             */ 
/*******************************************************************************/

#include <p2c/p2c.h>

#include "sys_stuff.h"

char *strupper(char *r, char *s)
{
  char *d = r;

  if (s == NULL)
    r = NULL;
  else {
    while (*s != '\000')
      *d++ = toupper(*s++);
    *d = '\000';
  }

  return r;
}





