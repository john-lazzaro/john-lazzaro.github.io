
#ifndef FFMAN_H
#define FFMAN_H

#ifndef SYSGLOBALS_H
#include <p2c/sysglobals.h>
#endif

#ifndef GR_STUFF_H
#include "gr_stuff.h"
#endif

#ifndef MAT_STUFF_H
#include "mat_stuff.h"
#endif

#ifndef CRT_STUFF_H
#include "crt_stuff.h"
#endif

#ifndef BB_STUFF_H
#include "bb_stuff.h"
#endif

#ifndef DATA_TYPES_H
#include "data_types.h"
#endif


#define def_center_type  TLL

#define def_font        13
#define def_font_scale  12   /* In Point */


extern fileSpec *read_in_a_file(Char *s);

extern void write_out_the_File(fileSpec *fs);


#endif /*FFMAN_H*/
