
#ifndef CRT_STUFF_H
#define CRT_STUFF_H


#ifndef SYSGLOBALS_H
#include <p2c/sysglobals.h>
#endif


extern void crt_write_str(short x, short y, Char *s, short field, short high);
extern void crt_center_str(Char *s, short y, short high);
extern void crt_write_int(short x, short y, long i, short field, short high);
extern void acursor(short x, short y);
extern void acursoroff(void);


#endif /*CRT_STUFF_H*/
