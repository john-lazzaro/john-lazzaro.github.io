
#ifndef DATAWALK_H
#define DATAWALK_H


typedef enum {
  d_obj, d_fig, d_file, d_pnt, d_pHead, d_path, d_gbl
} d_kinds;


extern void startWalk(d_kinds kind, void *p);

#endif /*DATAWALK_H*/
