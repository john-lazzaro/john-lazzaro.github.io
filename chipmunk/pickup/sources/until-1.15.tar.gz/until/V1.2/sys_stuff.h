
extern char *strupper(char *r, char *s);

