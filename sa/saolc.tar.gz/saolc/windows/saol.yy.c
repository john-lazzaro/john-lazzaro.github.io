/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

# include "stdio.h"
# define U(x) ((unsigned char)(x))
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 2048
# define output(c) (void)putc(c,yyout)
#if defined(__cplusplus) || defined(__STDC__)

#ifdef __cplusplus
extern "C" {
#endif
	extern int yylex(void);
	extern int yyback(int *, int);
	extern int yyinput(void);
	extern int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);
#ifndef yyless
	void yyless(long int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#ifdef __cplusplus
}
#endif

#endif

# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO (void)fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

# line 2 "saol.lex"
/* $Id: saol.lex,v 1.6 1998/05/06 21:43:03 eds Exp eds $ */

# line 3 "saol.lex"
/* $Log: saol.lex,v $
# Revision 1.6  1998/05/06  21:43:03  eds
# FCD version.
#
# Revision 1.5  1997/11/20  16:34:50  eds
# Changed 'sfsynth' to 'sbsynth'.
#
# Revision 1.4  1997/11/05  20:11:55  eds
# Added tablemaps.
#
# Revision 1.3  1997/10/03  15:10:35  eds
# Added SFSYNTH keyword.
#
# Revision 1.2  1997/09/17  14:10:06  eds
# Added spatialize keyword.
# */

# line 19 "saol.lex"
/*********************************************************************

ISO_HEADER_START

This software module was originally developed by

  Eric Scheirer (MIT Media Laboratory)

in the course of development of the MPEG-4 standard.
This software module is an implementation of a part of one or more
MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
of the MPEG-4 standard free license to this software module or
modifications thereof for use in hardware or software products
claiming conformance to MPEG-4.  Those intending to use this software
module in hardware or software products are advised that its use may
infringe existing patents.  The original developer of this software
module and his/her company, the subsequent editors and their
companies, and ISO/IEC have no liability for use of this software
module or modifications thereof in an implementation.  Copyright is
not released for non MPEG-4 conforming products. The MIT Media
Laboratory retains full right to use the code for its own purpose,
assign or donate the code to a third party and to inhibit third
parties from using the code for non MPEG-4 conforming products.  This
copyright notice must be included in all copies or derivative
works. Copyright (c) 1998.

ISO_HEADER_END

***********************************************************************/

# line 54 "saol.lex"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
  
void count(void),comment(void),dumpline(int i);
int yyline=1,yycol=0;
char thisline[1000],**all_lines = NULL;
#ifdef _WIN32
#define gettxt(s,s2) puts(s2)
#endif
# define YYNEWLINE 10
yylex(void){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

# line 69 "saol.lex"
	{ comment(); }
break;
case 2:

# line 70 "saol.lex"
{ count(); return(AOPCODE) ; }
break;
case 3:

# line 71 "saol.lex"
	{ count(); return(ASIG) ; }
break;
case 4:

# line 72 "saol.lex"
         { count(); return(ELSE) ; }
break;
case 5:

# line 73 "saol.lex"
      { count(); return(EXPORTS) ; }
break;
case 6:

# line 74 "saol.lex"
       { count(); return(EXTEND) ; }
break;
case 7:

# line 75 "saol.lex"
       { count(); return(GLOBAL) ; }
break;
case 8:

# line 76 "saol.lex"
           { count(); return(IF) ; }
break;
case 9:

# line 77 "saol.lex"
      { count(); return(IMPORTS); }
break;
case 10:

# line 78 "saol.lex"
   { count(); return(INCHANNELS) ; }
break;
case 11:

# line 79 "saol.lex"
        { count(); return(INSTR); }
break;
case 12:

# line 80 "saol.lex"
       { count(); return(INTERP); }
break;
case 13:

# line 81 "saol.lex"
{ count(); return(IOPCODE); }
break;
case 14:

# line 82 "saol.lex"
	{ count(); return(IVAR) ; }
break;
case 15:

# line 83 "saol.lex"
{ count(); return(KOPCODE); }
break;
case 16:

# line 84 "saol.lex"
        { count(); return(KRATE) ; }
break;
case 17:

# line 85 "saol.lex"
	{ count(); return(KSIG) ; }
break;
case 18:

# line 86 "saol.lex"
        { count(); return(MAP) ; }
break;
case 19:

# line 87 "saol.lex"
      { count(); return(OPARRAY) ; }
break;
case 20:

# line 88 "saol.lex"
{ count(); return(OPCODE) ; }
break;
case 21:

# line 89 "saol.lex"
{ count(); return(OUTBUS) ; }
break;
case 22:

# line 90 "saol.lex"
  { count(); return(OUTCHANNELS) ; }
break;
case 23:

# line 91 "saol.lex"
{ count(); return(OUTPUT) ; }
break;
case 24:

# line 92 "saol.lex"
       { count(); return(PRESET) ; }
break;
case 25:

# line 93 "saol.lex"
{ count(); return(RETURN) ; }
break;
case 26:

# line 94 "saol.lex"
        { count(); return(ROUTE) ; }
break;
case 27:

# line 95 "saol.lex"
         { count(); return(SEND) ; }
break;
case 28:

# line 96 "saol.lex"
     { count(); return(SEQUENCE) ; }
break;
case 29:

# line 97 "saol.lex"
        { count(); return(SASBF) ; }
break;
case 30:

# line 98 "saol.lex"
   { count(); return(SPATIALIZE) ; }
break;
case 31:

# line 99 "saol.lex"
	{ count(); return(SRATE); }
break;
case 32:

# line 100 "saol.lex"
	{ count(); return(TABLE); }
break;
case 33:

# line 101 "saol.lex"
     { count(); return(TABLEMAP); }
break;
case 34:

# line 102 "saol.lex"
{ count(); return(TEMPLATE); }
break;
case 35:

# line 103 "saol.lex"
      { count(); return(TURNOFF); }
break;
case 36:

# line 104 "saol.lex"
	{ count(); return(WHILE); }
break;
case 37:

# line 105 "saol.lex"
         { count(); return(WITH); }
break;
case 38:

# line 106 "saol.lex"
	{ count(); return(XSIG) ; }
break;
case 39:

# line 107 "saol.lex"
	{ count(); return(AND); }
break;
case 40:

# line 108 "saol.lex"
	{ count(); return(OR); }
break;
case 41:

# line 109 "saol.lex"
	{ count(); return(GEQ); }
break;
case 42:

# line 110 "saol.lex"
	{ count(); return(LEQ); }
break;
case 43:

# line 111 "saol.lex"
	{ count(); return(NEQ); }
break;
case 44:

# line 112 "saol.lex"
	{ count(); return(EQEQ); }
break;
case 45:

# line 113 "saol.lex"
	{ count(); return(MINUS); }
break;
case 46:

# line 114 "saol.lex"
	{ count(); return(STAR); }
break;
case 47:

# line 115 "saol.lex"
	{ count(); return(SLASH); }
break;
case 48:

# line 116 "saol.lex"
	{ count(); return(PLUS); }
break;
case 49:

# line 117 "saol.lex"
	{ count(); return(GT); }
break;
case 50:

# line 118 "saol.lex"
	{ count(); return(LT); }
break;
case 51:

# line 119 "saol.lex"
	{ count(); return(Q); }
break;
case 52:

# line 120 "saol.lex"
	{ count(); return(COL); }
break;
case 53:

# line 121 "saol.lex"
	{ count(); return(LP); }
break;
case 54:

# line 122 "saol.lex"
	{ count(); return(RP); }
break;
case 55:

# line 123 "saol.lex"
	{ count(); return(LC); }
break;
case 56:

# line 124 "saol.lex"
	{ count(); return(RC); }
break;
case 57:

# line 125 "saol.lex"
	{ count(); return(LB); }
break;
case 58:

# line 126 "saol.lex"
	{ count(); return(RB); }
break;
case 59:

# line 127 "saol.lex"
	{ count(); return(SEM); }
break;
case 60:

# line 128 "saol.lex"
	{ count(); return(COM); }
break;
case 61:

# line 129 "saol.lex"
	{ count(); return(EQ); }
break;
case 62:

# line 130 "saol.lex"
            { count(); return(NOT); }
break;
case 63:

# line 132 "saol.lex"
{ count(); yytext[strlen(yytext)-1] = 0; /* strip quotes */
                           yylval = add_ptr_index(strdup(&yytext[1]));
                           return(STRCONST); }
break;
case 64:

# line 135 "saol.lex"
	{ count(); yylval = add_ptr_index(strdup(yytext));
                           return(IDENT) ; }
break;
case 65:

# line 137 "saol.lex"
	{ count(); yylval = add_ptr_index(strdup(yytext));
                           return(INTGR) ; }
break;
case 66:

# line 139 "saol.lex"
{ count(); yylval = add_ptr_index(strdup(yytext));
                           return(NUMBER) ; }
break;
case 67:

# line 141 "saol.lex"
	{ count(); }
break;
case 68:

# line 142 "saol.lex"
	{ count();
                  printf("Line %d: Unknown character: '%s'\n",yyline,yytext); }
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */

# line 146 "saol.lex"

void comment() {
  char c;

  while ((c = input()) != '\n'); /* skip */
  yyline++;
  thisline[0] = 0;
  yycol = 0;
  }
              

void count() {
  char *nl;
  
  if (strcmp(yytext,"\n")) {
    yycol += strlen(yytext);
    strcat(thisline,yytext);
    }
  else {
    int i=0;

    while (thisline[i] == ' ' || thisline[i] == '\t') i++;
    nl = strdup(&thisline[i]);
   
    yycol = 0;
    if (all_lines)
      all_lines = (char **)realloc(all_lines,(yyline +2) * sizeof(char *));
    else
      all_lines = (char **)malloc((yyline+2) * sizeof(char *));
    all_lines[yyline-1] = nl; /* since yyline starts from 1 */
    yyline++;
    thisline[0] = 0;
    all_lines[yyline-1] = thisline;
    }
  }

void dumpline(int i) {
 
  printf("%s\n",all_lines[i]);
}
int yyvstop[] = {
0,

68,
0,

67,
68,
0,

67,
0,

62,
68,
0,

68,
0,

68,
0,

53,
68,
0,

54,
68,
0,

46,
68,
0,

48,
68,
0,

60,
68,
0,

45,
68,
0,

66,
68,
0,

47,
68,
0,

65,
66,
68,
0,

52,
68,
0,

59,
68,
0,

50,
68,
0,

61,
68,
0,

49,
68,
0,

51,
68,
0,

64,
68,
0,

57,
68,
0,

58,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

64,
68,
0,

55,
68,
0,

68,
0,

56,
68,
0,

43,
0,

63,
0,

39,
0,

66,
0,

1,
0,

66,
0,

65,
66,
0,

42,
0,

44,
0,

41,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

8,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

40,
0,

66,
0,

66,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

18,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

3,
64,
0,

4,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

14,
64,
0,

64,
0,

64,
0,

17,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

27,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

37,
64,
0,

38,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

11,
64,
0,

64,
0,

64,
0,

64,
0,

16,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

26,
64,
0,

29,
64,
0,

64,
0,

64,
0,

31,
64,
0,

32,
64,
0,

64,
0,

64,
0,

36,
64,
0,

64,
0,

64,
0,

6,
64,
0,

7,
64,
0,

64,
0,

64,
0,

12,
64,
0,

64,
0,

64,
0,

64,
0,

20,
64,
0,

21,
64,
0,

64,
0,

23,
64,
0,

24,
64,
0,

25,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

2,
64,
0,

5,
64,
0,

9,
64,
0,

64,
0,

13,
64,
0,

15,
64,
0,

19,
64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

64,
0,

35,
64,
0,

64,
0,

64,
0,

28,
64,
0,

64,
0,

33,
64,
0,

34,
64,
0,

64,
0,

64,
0,

64,
0,

10,
64,
0,

64,
0,

30,
64,
0,

22,
64,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,6,	1,7,	
0,0,	0,0,	0,0,	1,8,	
8,47,	1,9,	1,10,	1,11,	
1,12,	1,13,	1,14,	1,15,	
1,16,	1,17,	14,48,	16,50,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	1,18,	
1,19,	1,20,	1,21,	1,22,	
1,23,	6,43,	1,24,	20,54,	
21,55,	22,56,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
7,44,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
7,44,	7,44,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
1,25,	1,3,	1,26,	0,0,	
0,0,	0,0,	1,27,	0,0,	
0,0,	0,0,	1,28,	44,46,	
1,29,	0,0,	1,30,	32,71,	
1,31,	7,45,	1,32,	67,102,	
1,33,	1,34,	69,104,	1,35,	
1,36,	1,37,	7,44,	29,62,	
1,38,	1,39,	2,6,	7,44,	
1,40,	1,41,	1,42,	2,8,	
27,58,	2,9,	2,10,	2,11,	
27,59,	2,13,	2,14,	2,15,	
2,16,	34,74,	31,68,	33,72,	
7,44,	31,69,	31,70,	39,86,	
33,73,	38,84,	38,85,	2,18,	
2,19,	2,20,	2,21,	2,22,	
2,23,	15,48,	15,48,	15,48,	
15,48,	15,48,	15,48,	15,48,	
15,48,	15,48,	15,48,	41,87,	
58,91,	59,92,	17,51,	7,46,	
17,52,	17,52,	17,52,	17,52,	
17,52,	17,52,	17,52,	17,52,	
17,52,	17,52,	35,75,	28,60,	
2,25,	2,3,	2,26,	60,93,	
62,96,	61,94,	2,27,	64,97,	
35,76,	61,95,	2,28,	28,61,	
2,29,	66,101,	2,30,	37,81,	
2,31,	68,103,	2,32,	37,82,	
2,33,	2,34,	65,98,	2,35,	
2,36,	2,37,	15,49,	70,105,	
2,38,	2,39,	71,106,	73,109,	
2,40,	2,41,	2,42,	37,83,	
74,110,	75,111,	65,99,	65,100,	
76,112,	17,53,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
72,107,	77,113,	72,108,	78,114,	
79,116,	80,117,	78,115,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	81,118,	82,119,	83,120,	
84,121,	24,57,	85,122,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	24,57,	24,57,	24,57,	
24,57,	30,63,	86,123,	36,77,	
46,44,	91,124,	92,125,	36,78,	
30,64,	30,65,	30,66,	93,126,	
46,44,	46,0,	94,127,	95,128,	
96,129,	30,67,	36,79,	49,49,	
36,80,	97,130,	49,88,	49,88,	
49,88,	49,88,	49,88,	49,88,	
49,88,	49,88,	49,88,	49,88,	
98,131,	99,132,	100,133,	101,134,	
102,135,	46,44,	103,136,	104,137,	
105,138,	107,139,	108,140,	110,144,	
111,145,	112,146,	46,44,	113,147,	
109,141,	109,142,	114,148,	46,44,	
51,51,	51,51,	51,51,	51,51,	
51,51,	51,51,	51,51,	51,51,	
51,51,	51,51,	109,143,	115,149,	
53,89,	116,150,	53,89,	117,151,	
46,44,	53,90,	53,90,	53,90,	
53,90,	53,90,	53,90,	53,90,	
53,90,	53,90,	53,90,	88,88,	
88,88,	88,88,	88,88,	88,88,	
88,88,	88,88,	88,88,	88,88,	
88,88,	89,90,	89,90,	89,90,	
89,90,	89,90,	89,90,	89,90,	
89,90,	89,90,	89,90,	118,152,	
119,153,	120,154,	121,155,	122,156,	
123,157,	51,53,	124,158,	127,159,	
128,160,	129,161,	130,162,	131,163,	
132,164,	133,165,	134,166,	136,167,	
137,168,	139,169,	140,170,	141,171,	
142,172,	143,173,	144,174,	145,175,	
146,176,	147,177,	149,178,	150,179,	
151,180,	152,181,	153,182,	154,183,	
155,184,	158,185,	159,186,	160,187,	
161,188,	162,189,	163,190,	165,191,	
166,192,	167,193,	169,194,	170,195,	
171,196,	172,197,	173,198,	174,199,	
175,200,	178,201,	179,202,	181,203,	
182,204,	183,205,	185,206,	186,207,	
189,208,	190,209,	192,210,	193,211,	
194,212,	197,213,	201,214,	202,215,	
203,216,	204,217,	205,218,	209,219,	
213,220,	214,221,	215,222,	216,223,	
217,224,	219,225,	220,226,	222,227,	
225,228,	226,229,	227,230,	229,231,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-89,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+6,
yycrank+4,	0,		yyvstop+8,
yycrank+-75,	0,		yyvstop+11,
yycrank+2,	0,		yyvstop+13,
yycrank+0,	0,		yyvstop+15,
yycrank+0,	0,		yyvstop+18,
yycrank+0,	0,		yyvstop+21,
yycrank+0,	0,		yyvstop+24,
yycrank+0,	0,		yyvstop+27,
yycrank+4,	0,		yyvstop+30,
yycrank+105,	0,		yyvstop+33,
yycrank+4,	0,		yyvstop+36,
yycrank+120,	0,		yyvstop+39,
yycrank+0,	0,		yyvstop+43,
yycrank+0,	0,		yyvstop+46,
yycrank+6,	0,		yyvstop+49,
yycrank+7,	0,		yyvstop+52,
yycrank+8,	0,		yyvstop+55,
yycrank+0,	0,		yyvstop+58,
yycrank+174,	0,		yyvstop+61,
yycrank+0,	0,		yyvstop+64,
yycrank+0,	0,		yyvstop+67,
yycrank+17,	yysvec+24,	yyvstop+70,
yycrank+71,	yysvec+24,	yyvstop+73,
yycrank+11,	yysvec+24,	yyvstop+76,
yycrank+195,	yysvec+24,	yyvstop+79,
yycrank+27,	yysvec+24,	yyvstop+82,
yycrank+10,	yysvec+24,	yyvstop+85,
yycrank+27,	yysvec+24,	yyvstop+88,
yycrank+23,	yysvec+24,	yyvstop+91,
yycrank+77,	yysvec+24,	yyvstop+94,
yycrank+202,	yysvec+24,	yyvstop+97,
yycrank+98,	yysvec+24,	yyvstop+100,
yycrank+41,	yysvec+24,	yyvstop+103,
yycrank+28,	yysvec+24,	yyvstop+106,
yycrank+0,	0,		yyvstop+109,
yycrank+39,	0,		yyvstop+112,
yycrank+0,	0,		yyvstop+114,
yycrank+0,	0,		yyvstop+117,
yycrank+-11,	yysvec+7,	0,	
yycrank+0,	0,		yyvstop+119,
yycrank+-299,	0,		0,	
yycrank+0,	0,		yyvstop+121,
yycrank+0,	yysvec+15,	yyvstop+123,
yycrank+270,	0,		0,	
yycrank+0,	0,		yyvstop+125,
yycrank+300,	0,		yyvstop+127,
yycrank+0,	yysvec+17,	yyvstop+129,
yycrank+317,	0,		0,	
yycrank+0,	0,		yyvstop+132,
yycrank+0,	0,		yyvstop+134,
yycrank+0,	0,		yyvstop+136,
yycrank+0,	yysvec+24,	yyvstop+138,
yycrank+52,	yysvec+24,	yyvstop+140,
yycrank+60,	yysvec+24,	yyvstop+142,
yycrank+68,	yysvec+24,	yyvstop+144,
yycrank+73,	yysvec+24,	yyvstop+146,
yycrank+73,	yysvec+24,	yyvstop+148,
yycrank+0,	yysvec+24,	yyvstop+150,
yycrank+75,	yysvec+24,	yyvstop+153,
yycrank+103,	yysvec+24,	yyvstop+155,
yycrank+81,	yysvec+24,	yyvstop+157,
yycrank+14,	yysvec+24,	yyvstop+159,
yycrank+85,	yysvec+24,	yyvstop+161,
yycrank+17,	yysvec+24,	yyvstop+163,
yycrank+102,	yysvec+24,	yyvstop+165,
yycrank+98,	yysvec+24,	yyvstop+167,
yycrank+135,	yysvec+24,	yyvstop+169,
yycrank+95,	yysvec+24,	yyvstop+171,
yycrank+115,	yysvec+24,	yyvstop+173,
yycrank+101,	yysvec+24,	yyvstop+175,
yycrank+103,	yysvec+24,	yyvstop+177,
yycrank+118,	yysvec+24,	yyvstop+179,
yycrank+125,	yysvec+24,	yyvstop+181,
yycrank+139,	yysvec+24,	yyvstop+183,
yycrank+140,	yysvec+24,	yyvstop+185,
yycrank+167,	yysvec+24,	yyvstop+187,
yycrank+157,	yysvec+24,	yyvstop+189,
yycrank+153,	yysvec+24,	yyvstop+191,
yycrank+163,	yysvec+24,	yyvstop+193,
yycrank+154,	yysvec+24,	yyvstop+195,
yycrank+193,	yysvec+24,	yyvstop+197,
yycrank+0,	0,		yyvstop+199,
yycrank+327,	0,		yyvstop+201,
yycrank+337,	0,		0,	
yycrank+0,	yysvec+89,	yyvstop+203,
yycrank+202,	yysvec+24,	yyvstop+205,
yycrank+199,	yysvec+24,	yyvstop+207,
yycrank+206,	yysvec+24,	yyvstop+209,
yycrank+199,	yysvec+24,	yyvstop+211,
yycrank+210,	yysvec+24,	yyvstop+213,
yycrank+214,	yysvec+24,	yyvstop+215,
yycrank+206,	yysvec+24,	yyvstop+217,
yycrank+224,	yysvec+24,	yyvstop+219,
yycrank+213,	yysvec+24,	yyvstop+221,
yycrank+229,	yysvec+24,	yyvstop+223,
yycrank+232,	yysvec+24,	yyvstop+225,
yycrank+218,	yysvec+24,	yyvstop+227,
yycrank+235,	yysvec+24,	yyvstop+229,
yycrank+219,	yysvec+24,	yyvstop+231,
yycrank+233,	yysvec+24,	yyvstop+233,
yycrank+0,	yysvec+24,	yyvstop+235,
yycrank+223,	yysvec+24,	yyvstop+238,
yycrank+227,	yysvec+24,	yyvstop+240,
yycrank+246,	yysvec+24,	yyvstop+242,
yycrank+224,	yysvec+24,	yyvstop+244,
yycrank+223,	yysvec+24,	yyvstop+246,
yycrank+225,	yysvec+24,	yyvstop+248,
yycrank+245,	yysvec+24,	yyvstop+250,
yycrank+246,	yysvec+24,	yyvstop+252,
yycrank+242,	yysvec+24,	yyvstop+254,
yycrank+245,	yysvec+24,	yyvstop+256,
yycrank+247,	yysvec+24,	yyvstop+258,
yycrank+287,	yysvec+24,	yyvstop+260,
yycrank+284,	yysvec+24,	yyvstop+262,
yycrank+287,	yysvec+24,	yyvstop+264,
yycrank+290,	yysvec+24,	yyvstop+266,
yycrank+295,	yysvec+24,	yyvstop+268,
yycrank+297,	yysvec+24,	yyvstop+270,
yycrank+291,	yysvec+24,	yyvstop+272,
yycrank+0,	yysvec+24,	yyvstop+274,
yycrank+0,	yysvec+24,	yyvstop+277,
yycrank+289,	yysvec+24,	yyvstop+280,
yycrank+294,	yysvec+24,	yyvstop+282,
yycrank+308,	yysvec+24,	yyvstop+284,
yycrank+292,	yysvec+24,	yyvstop+286,
yycrank+310,	yysvec+24,	yyvstop+288,
yycrank+294,	yysvec+24,	yyvstop+290,
yycrank+295,	yysvec+24,	yyvstop+292,
yycrank+299,	yysvec+24,	yyvstop+294,
yycrank+0,	yysvec+24,	yyvstop+296,
yycrank+300,	yysvec+24,	yyvstop+299,
yycrank+311,	yysvec+24,	yyvstop+301,
yycrank+0,	yysvec+24,	yyvstop+303,
yycrank+299,	yysvec+24,	yyvstop+306,
yycrank+314,	yysvec+24,	yyvstop+308,
yycrank+298,	yysvec+24,	yyvstop+310,
yycrank+312,	yysvec+24,	yyvstop+312,
yycrank+300,	yysvec+24,	yyvstop+314,
yycrank+317,	yysvec+24,	yyvstop+316,
yycrank+305,	yysvec+24,	yyvstop+318,
yycrank+319,	yysvec+24,	yyvstop+320,
yycrank+319,	yysvec+24,	yyvstop+322,
yycrank+0,	yysvec+24,	yyvstop+324,
yycrank+321,	yysvec+24,	yyvstop+327,
yycrank+318,	yysvec+24,	yyvstop+329,
yycrank+323,	yysvec+24,	yyvstop+331,
yycrank+324,	yysvec+24,	yyvstop+333,
yycrank+318,	yysvec+24,	yyvstop+335,
yycrank+316,	yysvec+24,	yyvstop+337,
yycrank+327,	yysvec+24,	yyvstop+339,
yycrank+0,	yysvec+24,	yyvstop+341,
yycrank+0,	yysvec+24,	yyvstop+344,
yycrank+329,	yysvec+24,	yyvstop+347,
yycrank+314,	yysvec+24,	yyvstop+349,
yycrank+331,	yysvec+24,	yyvstop+351,
yycrank+324,	yysvec+24,	yyvstop+353,
yycrank+317,	yysvec+24,	yyvstop+355,
yycrank+324,	yysvec+24,	yyvstop+357,
yycrank+0,	yysvec+24,	yyvstop+359,
yycrank+323,	yysvec+24,	yyvstop+362,
yycrank+336,	yysvec+24,	yyvstop+364,
yycrank+337,	yysvec+24,	yyvstop+366,
yycrank+0,	yysvec+24,	yyvstop+368,
yycrank+341,	yysvec+24,	yyvstop+371,
yycrank+338,	yysvec+24,	yyvstop+373,
yycrank+325,	yysvec+24,	yyvstop+375,
yycrank+344,	yysvec+24,	yyvstop+377,
yycrank+326,	yysvec+24,	yyvstop+379,
yycrank+327,	yysvec+24,	yyvstop+381,
yycrank+334,	yysvec+24,	yyvstop+383,
yycrank+0,	yysvec+24,	yyvstop+385,
yycrank+0,	yysvec+24,	yyvstop+388,
yycrank+335,	yysvec+24,	yyvstop+391,
yycrank+349,	yysvec+24,	yyvstop+393,
yycrank+0,	yysvec+24,	yyvstop+395,
yycrank+338,	yysvec+24,	yyvstop+398,
yycrank+351,	yysvec+24,	yyvstop+401,
yycrank+347,	yysvec+24,	yyvstop+403,
yycrank+0,	yysvec+24,	yyvstop+405,
yycrank+349,	yysvec+24,	yyvstop+408,
yycrank+336,	yysvec+24,	yyvstop+410,
yycrank+0,	yysvec+24,	yyvstop+412,
yycrank+0,	yysvec+24,	yyvstop+415,
yycrank+337,	yysvec+24,	yyvstop+418,
yycrank+343,	yysvec+24,	yyvstop+420,
yycrank+0,	yysvec+24,	yyvstop+422,
yycrank+353,	yysvec+24,	yyvstop+425,
yycrank+354,	yysvec+24,	yyvstop+427,
yycrank+335,	yysvec+24,	yyvstop+429,
yycrank+0,	yysvec+24,	yyvstop+431,
yycrank+0,	yysvec+24,	yyvstop+434,
yycrank+347,	yysvec+24,	yyvstop+437,
yycrank+0,	yysvec+24,	yyvstop+439,
yycrank+0,	yysvec+24,	yyvstop+442,
yycrank+0,	yysvec+24,	yyvstop+445,
yycrank+359,	yysvec+24,	yyvstop+448,
yycrank+351,	yysvec+24,	yyvstop+450,
yycrank+363,	yysvec+24,	yyvstop+452,
yycrank+345,	yysvec+24,	yyvstop+454,
yycrank+360,	yysvec+24,	yyvstop+456,
yycrank+0,	yysvec+24,	yyvstop+458,
yycrank+0,	yysvec+24,	yyvstop+461,
yycrank+0,	yysvec+24,	yyvstop+464,
yycrank+362,	yysvec+24,	yyvstop+467,
yycrank+0,	yysvec+24,	yyvstop+469,
yycrank+0,	yysvec+24,	yyvstop+472,
yycrank+0,	yysvec+24,	yyvstop+475,
yycrank+354,	yysvec+24,	yyvstop+478,
yycrank+364,	yysvec+24,	yyvstop+480,
yycrank+361,	yysvec+24,	yyvstop+482,
yycrank+355,	yysvec+24,	yyvstop+484,
yycrank+367,	yysvec+24,	yyvstop+486,
yycrank+0,	yysvec+24,	yyvstop+488,
yycrank+361,	yysvec+24,	yyvstop+491,
yycrank+369,	yysvec+24,	yyvstop+493,
yycrank+0,	yysvec+24,	yyvstop+495,
yycrank+349,	yysvec+24,	yyvstop+498,
yycrank+0,	yysvec+24,	yyvstop+500,
yycrank+0,	yysvec+24,	yyvstop+503,
yycrank+357,	yysvec+24,	yyvstop+506,
yycrank+365,	yysvec+24,	yyvstop+508,
yycrank+373,	yysvec+24,	yyvstop+510,
yycrank+0,	yysvec+24,	yyvstop+512,
yycrank+360,	yysvec+24,	yyvstop+515,
yycrank+0,	yysvec+24,	yyvstop+517,
yycrank+0,	yysvec+24,	yyvstop+520,
0,	0,	0};
struct yywork *yytop = yycrank+475;
struct yysvf *yybgin = yysvec+1;
unsigned char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,011 ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,'"' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,'+' ,01  ,'+' ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,'"' ,01  ,01  ,'A' ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ident	"$Revision: 1.9 $"

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
#ifndef LONGLINES
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
#endif
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (void *)yyt > (void *)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
#ifndef LONGLINES
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
#endif
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((void *)yyt < (void *)yycrank) {	/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
#ifndef LONGLINES
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
#endif
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
#ifndef LONGLINES
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
#endif
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = (int)(yylastch-yytext+1);
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
	return(input());
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
	output(c);
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
