/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#include "saol_interp.h"
#include "fft.h"

struct core_opcode_struct *is_core_opcode(char *name);
#ifdef _MPEGPROFILER
  int core_opcode_index(char *name);
#endif

typedef struct core_opcode_struct {
  char *name;
  long oprate;  /* rate of the opcode */
  long p1type, p2type, p3type, p4type, p5type, p6type, p7type;
  /* rates of the arguments */
  long varargs; /* rate of the terminal vararg sequence */
  long storage; /* local storage needed for each instance of the opcode */
  sa_real (*code)(sa_decoder *sa, opval *,actparam *, int, long rate);
    /* function pointer to the code needed */
} core_opcode;

#define PROT_MAL_CO(op_storage) \
if (!(op->local = (void *)malloc(sizeof(op_storage)))) \
  interror("Couldn't allocate space in co_opcode");

void add_sym_table_core_opcodes(symtable *t);
int opcode_is_varargs(char *name);
table_storage *co_param_table(actparam *pf, int which);
sa_real co_param(actparam *pf, int which);

typedef struct int_storage_struct { int shold; } int_storage;
sa_real co_int(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct frac_storage_struct { int shold; } frac_storage;
sa_real co_frac(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct dbamp_storage_struct { int shold; } dbamp_storage;
sa_real co_dbamp(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct ampdb_storage_struct { int shold; } ampdb_storage;
sa_real co_ampdb(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct abs_storage_struct { int shold; } abs_storage;
sa_real co_abs(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct sgn_storage_struct { int shold; } sgn_storage;
sa_real co_sgn(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct exp_storage_struct { int shold; } exp_storage;
sa_real co_exp(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct log_storage_struct { int shold; } log_storage;
sa_real co_log(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct sqrt_storage_struct { int shold; } sqrt_storage;
sa_real co_sqrt(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct sin_storage_struct { int shold; } sin_storage;
sa_real co_sin(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct cos_storage_struct { int shold; } cos_storage;
sa_real co_cos(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct atan_storage_struct { int shold; } atan_storage;
sa_real co_atan(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct pow_storage_struct { int shold; } pow_storage;
sa_real co_pow(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct log10_storage_struct { int shold; } log10_storage;
sa_real co_log10(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct asin_storage_struct { int shold; } asin_storage;
sa_real co_asin(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct acos_storage_struct { int shold; } acos_storage;
sa_real co_acos(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct floor_storage_struct { int shold; } floor_storage;
sa_real co_floor(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct ceil_storage_struct { int shold; } ceil_storage;
sa_real co_ceil(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct min_storage_struct { int shold; } min_storage;
sa_real co_min(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct max_storage_struct { int shold; } max_storage;
sa_real co_max(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_gettune(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_settune(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct octpch_storage_struct { int shold; } octpch_storage;
sa_real co_octpch(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct pchoct_storage_struct { int shold; } pchoct_storage;
sa_real co_pchoct(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct cpspch_storage_struct { int shold; } cpspch_storage;
sa_real co_cpspch(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct pchcps_storage_struct { int shold; } pchcps_storage;
sa_real co_pchcps(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct cpsoct_storage_struct { int shold; } cpsoct_storage;
sa_real co_cpsoct(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct octcps_storage_struct { int shold; } octcps_storage;
sa_real co_octcps(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct pchmidi_storage_struct { int shold; } pchmidi_storage;
sa_real co_pchmidi(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct midipch_storage_struct { int shold; } midipch_storage;
sa_real co_midipch(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct octmidi_storage_struct { int shold; } octmidi_storage;
sa_real co_octmidi(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct midioct_storage_struct { int shold; } midioct_storage;
sa_real co_midioct(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct cpsmidi_storage_struct { int shold; } cpsmidi_storage;
sa_real co_cpsmidi(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct midicps_storage_struct { int shold; } midicps_storage;
sa_real co_midicps(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct ftlen_storage_struct { int shold; } ftlen_storage;
sa_real co_ftlen(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct ftloop_storage_struct { int shold; } ftloop_storage;
sa_real co_ftloop(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct ftloopend_storage_struct { int shold; } ftloopend_storage;
sa_real co_ftloopend(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct ftsr_storage_struct { int shold; } ftsr_storage;
sa_real co_ftsr(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_ftsetloop(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_ftsetend(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_ftsetbase(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_ftsetsr(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_ftbasecps(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct tableread_storage_struct { int shold; } tableread_storage;
sa_real co_tableread(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct tablewrite_storage_struct { int shold; } tablewrite_storage;
sa_real co_tablewrite(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct oscil_storage_struct {
  sa_real ph;
  int loops;
} oscil_storage;

sa_real co_oscil(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct koscil_storage_struct {
  sa_real ph;
  int loops;
} koscil_storage;

sa_real co_koscil(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct loscil_storage_struct {
  sa_real idx;
} loscil_storage;

sa_real co_loscil(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct doscil_storage_struct {
  sa_real idx;
} doscil_storage;

sa_real co_doscil(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct kline_storage_struct {
  sa_real left,right,dur,durtime;
  int done,varargs_pos;
} kline_storage;
sa_real co_kline(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct aline_storage_struct {
  sa_real left,right,dur,durtime;
  int done,varargs_pos;
} aline_storage;
sa_real co_aline(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct kexpon_storage_struct {
  sa_real left,right,dur,durtime;
  int done,varargs_pos;
 } kexpon_storage;
sa_real co_kexpon(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct aexpon_storage_struct {
  sa_real left,right,dur,durtime;
  int done,varargs_pos;
} aexpon_storage;

sa_real co_aexpon(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct kphasor_storage_struct { sa_real ph; } kphasor_storage;
sa_real co_kphasor(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct aphasor_storage_struct { sa_real ph; } aphasor_storage;
sa_real co_aphasor(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct pluck_storage_struct {
  sa_real *buf, *newbuf;
  sa_real ph,ct;
} pluck_storage;

sa_real co_pluck(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct buzz_storage_struct {
  sa_real ph;
} buzz_storage;
sa_real co_buzz(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct grain_storage_struct {
  int numg, glength;
  sa_real dens_time;
  sa_real new_grain_time;
} grain_storage;

sa_real co_grain(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct irand_storage_struct { int shold; } irand_storage;
sa_real co_irand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct krand_storage_struct { int shold; } krand_storage;
sa_real co_krand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct arand_storage_struct { int shold; } arand_storage;
sa_real co_arand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct ilinrand_storage_struct { int shold; } ilinrand_storage;
sa_real co_ilinrand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct klinrand_storage_struct { int shold; } klinrand_storage;
sa_real co_klinrand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct alinrand_storage_struct { int shold; } alinrand_storage;
sa_real co_alinrand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct iexprand_storage_struct { int shold; } iexprand_storage;
sa_real co_iexprand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct kexprand_storage_struct { int shold; } kexprand_storage;
sa_real co_kexprand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct aexprand_storage_struct { int shold; } aexprand_storage;
sa_real co_aexprand(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct kpoissonrand_storage_struct {
  int wait;
} kpoissonrand_storage;

sa_real co_kpoissonrand(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct apoissonrand_storage_struct {
  int wait;
} apoissonrand_storage;

sa_real co_apoissonrand(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct igaussrand_storage_struct { int shold; } igaussrand_storage;
sa_real co_igaussrand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct kgaussrand_storage_struct { int shold; } kgaussrand_storage;
sa_real co_kgaussrand(sa_decoder *, opval *,actparam *, int, long rate); 
typedef struct agaussrand_storage_struct { int shold; } agaussrand_storage;
sa_real co_agaussrand(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct port_storage_struct {
  real old,cur,newx,time;
} port_storage;

sa_real co_port(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct hipass_storage_struct {
  real oldcut, a1,a2,a0,b1,b2,b0,d1,d2;
} hipass_storage;

sa_real co_hipass(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct lopass_storage_struct {
  real oldcut, a1,a2,a0,b1,b2,b0,d1,d2;
} lopass_storage;

sa_real co_lopass(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct bandpass_storage_struct {
  real oldcf, oldbw, a1, a2, a0, b1, b2, b0, d1, d2;
} bandpass_storage;

sa_real co_bandpass(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct bandstop_storage_struct {
  real oldcf, oldbw, a1, a2, a0, b1, b2, b0, d1, d2;
} bandstop_storage;

sa_real co_bandstop(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct fft_storage_struct {
  complex *basis;
  real *buf,*inbuf;
  int pt,framept,framect;
  int p2,ready;
} fft_storage;

sa_real co_fft(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct ifft_storage_struct {
  complex *basis;
  real *buf;
  int pt,ct,p2;
} ifft_storage;
sa_real co_ifft(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct rms_storage_struct { 
	sa_real *buf;
	sa_real last;
	int pt;
} rms_storage;
sa_real co_rms(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct gain_storage_struct {
	sa_real *buf;
	sa_real rms;
	int pt;
} gain_storage;

sa_real co_gain(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct balance_storage_struct {
	sa_real *inbuf, *refbuf;
	sa_real inrms, refrms;
	int pt;
 } balance_storage;

sa_real co_balance(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct compressor_storage_struct {
  sa_real *xdly, *compdly;
  int xdly_pt, compdly_pt;
  sa_real gain, change, env;
} compressor_storage;

sa_real co_compressor(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct sblock_storage_struct {
  int pt;
  sa_real *buf;
} sblock_storage;

sa_real co_sblock(sa_decoder *, opval *, actparam *, int, long rate);

typedef struct decimate_storage_struct { sa_real last; } decimate_storage;
sa_real co_decimate(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct upsamp_storage_struct { 
	sa_real last;
	int ct;
} upsamp_storage;
sa_real co_upsamp(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct downsamp_storage_struct { 
	sa_real *buf;
	int pt;
 } downsamp_storage;
sa_real co_downsamp(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct samphold_storage_struct {
	sa_real hold;
	sa_real gate;
 } samphold_storage;
sa_real co_samphold(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct delay_storage_struct {
  sa_real *dline;
  int pt;
} delay_storage;

sa_real co_delay(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct delay1_storage_struct { sa_real last; } delay1_storage;

sa_real co_delay1(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct biquad_storage_struct { 
	sa_real d1,d2;
} biquad_storage;

sa_real co_biquad(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct firt_storage_struct {
  sa_real *dline;
  int pt;
} firt_storage;

sa_real co_firt(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct fir_storage_struct {
  sa_real *dline;
  int pt;
} fir_storage;

sa_real co_fir(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct iir_storage_struct {
  sa_real *dline;
  int pt;
} iir_storage;

sa_real co_iir(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct iirt_storage_struct {
  sa_real *dline;
  int pt;
} iirt_storage;

sa_real co_iirt(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct fdelay_storage_struct {
  sa_real *dline;
  int pt;
  int len;
} fdelay_storage;

sa_real co_fdelay(sa_decoder *, opval *,actparam *, int, long rate); 

typedef struct comb_storage_struct {
  sa_real *dline;
  int pt;
} comb_storage;

sa_real co_comb(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct allpass_storage_struct {
  sa_real *dline;
  int pt;
} allpass_storage;

sa_real co_allpass(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_gettempo(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_settempo(sa_decoder *, opval *,actparam *, int, long rate);

typedef struct kdump_storage_struct { int shold; } kdump_storage;
sa_real co_kdump(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct idump_storage_struct { int shold; } idump_storage;
sa_real co_idump(sa_decoder *, opval *,actparam *, int, long rate);
typedef struct adump_storage_struct { int shold; } adump_storage;
sa_real co_adump(sa_decoder *, opval *,actparam *, int, long rate);
sa_real co_midicc(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate);

/* ISO_ONLY_CODE */
typedef struct fx_speedc_storage_struct {
  sa_real scf;
  int min_pitch;
  int max_pitch;
  int pitch;
  int start_point;
  int inend_point;
  int outend_point;
  int target_point;
  int output_point;
  int write_point;
  int inbuf_frame;
  int len_inbuf;
  int outbuf_frame;
  int len_outbuf;
  sa_real frac;
  int num_in_samples;
  sa_real *inbuf;
  int num_out_samples;
  sa_real *outbuf;
  int init;
} fx_speedc_storage;

/* END_ISO_ONLY_CODE */

/* PUBLIC_ONLY_CODE */
#ifdef PUBLIC_SOURCE
typedef struct fx_speedc_storage_struct {
	int shold; 
} fx_speedc_storage;
#endif
/* END_PUBLIC_ONLY_CODE */

sa_real co_fx_speedc(sa_decoder *, opval *,actparam *, int, long rate);


