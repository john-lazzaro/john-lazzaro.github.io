// dls_wrapper.cpp
#include <stdlib.h>
#include <string.h>
#include "sfe_datatype.h"
#include "dlsparse.h"
#include "dls_wrapper.h"


PInstrMgr CreateInstrMgr(){
	return new InstManager;
}

void DestroyInstrMgr(PInstrMgr pInstr){
	delete pInstr;
}

HRESULT	DownloadCollection(dls_bank *bank){
  HRESULT res;
  
  printf("Loading DLS Patches: ");
  InstManager * pIM = (InstManager *) bank->instrument;
  res = pIM->DownloadCollection(bank->gpData, bank->gdwDataSize, &(bank->hCollection));
  printf("\n");
  return res;
}

HRESULT UnloadCollection(dls_bank *bank){
	InstManager * pIM = (InstManager *) bank->instrument;
	return pIM->UnloadCollection(&bank->hCollection);
}

HRESULT	GetSynthParams(dls_bank *bank, DWORD dwPatch, DWORD dwNote, DWORD dwVel, sfData *pParams, DWORD dwLayer){
	InstManager * pIM = (InstManager *) bank->instrument;
	return pIM->GetSynthParams(dwPatch, dwNote, dwVel, pParams, dwLayer);
}

#ifdef _WIN32

//		From Todor Fay's main.cpp
//      Copyright (c) Microsoft Corporation 1996, 1998
//
void CloseCollectionFile(dls_bank *bank)
{
	if (bank->gpData != NULL)
	{
		UnmapViewOfFile(bank->gpData);
		bank->gpData = NULL;
	}
    if (bank->ghMapFile)
    {
        CloseHandle(bank->ghMapFile);
        bank->ghMapFile = NULL;
    }
    if (bank->ghFile != NULL)
    {
        if (bank->ghFile != INVALID_HANDLE_VALUE)
        {
            CloseHandle(bank->ghFile);
        }
        bank->ghFile = NULL;
    }
}


HRESULT OpenCollectionFile(dls_bank *bank, char *filename)
{
	bank->ghFile = CreateFile(filename,
							  GENERIC_READ,
							  FILE_SHARE_READ,
							  NULL,
							  OPEN_EXISTING,
							  FILE_ATTRIBUTE_NORMAL,
							  NULL);
	if (bank->ghFile == INVALID_HANDLE_VALUE) {
		LONG lResult = GetLastError();
		return HRESULT_FROM_WIN32(lResult);
	}

	bank->ghMapFile = CreateFileMapping(bank->ghFile,NULL,
		PAGE_READONLY,0,0,NULL);
	if (bank->ghMapFile == NULL)
	{
		CloseCollectionFile(bank);
		return E_FAIL;
	}

	bank->gpData = (BYTE *) MapViewOfFile(bank->ghMapFile,
		FILE_MAP_READ,0,0,0 );

	if (bank->gpData == NULL)
	{
		CloseCollectionFile(bank);
		return GetLastError();
	}

    bank->gdwDataSize = GetFileSize(bank->ghFile, NULL);

	return S_OK;
}
#else

void CloseCollectionFile (dls_bank *bank) {
  if (bank->gpData != NULL) {
    free(bank->gpData);
    bank->gpData = NULL;
  }
  if (bank->ghMapFile) {
    fclose((FILE *)bank->ghMapFile);
    bank->ghMapFile = NULL;
  }
  if (bank->ghFile) {
    fclose((FILE *)bank->ghFile);
    bank->ghFile = NULL;
  }
}

HRESULT OpenCollectionFile(dls_bank *bank, char *filename) {
  size_t ct, tot;
  char buf[1024];
  
  bank->ghFile = (void *)fopen(filename,"r");
  if (!bank->ghFile)
    return -1;

  tot = 0; bank->gpData = NULL;
  /* don't need MapFile here */
  while (ct = fread(buf,1,1024,(FILE *)bank->ghFile)) {
    tot += ct;
    bank->gpData = (unsigned char *)realloc(bank->gpData,tot);
    memcpy(&bank->gpData[tot-ct],buf,ct);
  }

  bank->gdwDataSize = tot;
}
#endif

/*int WINAPI WinMain( HINSTANCE hInstance, 
	HINSTANCE hPrevInstance, 

	LPSTR lpCmdLine, 
	int nCmdShow 
)

{
	InstManager Inst;
	if (SUCCEEDED(OpenCollectionFile("test.dls")))
	{
		HANDLE hCollection;
		if (SUCCEEDED(Inst.DownloadCollection(gpData,gdwDataSize,&hCollection)))
		{
			sfData Params;
			Inst.GetSynthParams(0x00010005,64,&Params);
			Inst.UnloadCollection(hCollection);
		}
		CloseCollectionFile();
	}
	return 0;
} */
 

