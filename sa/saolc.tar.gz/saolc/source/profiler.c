/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
  Giorgio Zoia (Signal Processing Institute - EPFL)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The EPFL
  retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1999.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* profiler.c */
/* This file contains the counter increments to profile the execution */
/* like described in the Conformance standard 14496-4, Annex B        */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "profiler.h"
#include "saol.tab.h"
#include "saol.h"
#include "saol_interp.h"

int allocated_mem;
pointer *ptable;
int pointer_num;
int tables_mem;

counter my_counter;

int factor[COUNTMAX], cs_factor[COUNTMAX];
int interp_vector[COUNTMAX] = {0, 3, 1, 0, 1, 0, 0, 0, 0, 0, 0};
co_table co_op_table;   /* store here the file opcodes.map for profiling */

int prof_co; /* profile or not the opcodes */
int seconds=0, kprof=0;
int opt_mem=0, first_ka;  
/* optional memory that can be associated to each opcode: (MEM+1)th column  */

int done_interp=0, quality;
int abs_cs2=0, sgn_cs2=0, oscil_cs2=0, loscil_cs2=0;
int koscil_cs2=0, line_cs2=0;
int expon_cs2=0, phasor_cs2=0;
int pluck_cs2=0, pluck_cs3=0, buzz_cs2=0, port_cs2=0, port_cs3=0;
int fdelay_m2=0, fdelay_m3=0, fdelay_m4=0, fdelay_m5=0;
int rms_cs2=0, gain_cs2=0, balance_cs2=0;
int upsamp_cs2=0, downsamp_cs2=0, poiss_cs2=0;
int grain_cs2=0, grain_cs3=0, grain_cs4=0, grain_cs5=0;
int grain_cs6=0, grain_cs7=0, grain_cs5a=0, grain_cs7a=0;

int grain_factor, grain_afactor;

FILE *kout;  /* the file where kout are stored */
static FILE *ipsout;  /* the file where IPS are stored (not avoidable if prof) */

extern char *getline(FILE *fp);
extern int split(char *s, char ***words);
void calc_factor(int opcode, actparam *pf, int pf_ct, sa_decoder *sa);

void increment_counter(int par, int amount, int rate) {

  int i;

  if(rate==SCHEDP) {
    switch(par) {
    case IF:
    case ELSE:
    case WHILE:
      my_counter.s_counter[TEST_IND] += amount;   /* conditional operations = test*/
      break;
    case SPATIALIZE:
      my_counter.s_counter[EFF_IND] += amount;   /* more or less an effect */
      break;
    case ARRAYREF:
      my_counter.s_counter[FLOP_IND] += amount;  /* add an offset */
      break;
    case UMINUS:
    case NOT:
      my_counter.s_counter[FLOP_IND] += amount;
      break;
    case Q:
      my_counter.s_counter[TEST_IND] += amount;  /* 1 test */
      break;
    case LT:
    case GT:
    case NEQ:
    case EQEQ:
    case GEQ:
    case LEQ:
    case OR:
    case AND:
      my_counter.s_counter[FLOP_IND] += amount;
      break;
    case PLUS:
    case MINUS:
      my_counter.s_counter[FLOP_IND] += amount;
      break;
    case STAR:
      my_counter.s_counter[MULT_IND] += amount;
      break;
    case SLASH:
      my_counter.s_counter[MATH_IND] += amount;
      break;
    case CO_PLUS:
      my_counter.s_counter[FLOP_IND] += amount;
      break;
    case OPCALL:
      /* here amount is which opcode */
      if(prof_co) { 
	my_counter.s_counter[0] += co_op_table[amount][0];   /* opcode call */
	factor[INTERP_IND]=done_interp;
	for(i=1; i<COUNTLEN; i++) 
	  my_counter.s_counter[i] += (co_op_table[amount][i]*factor[i]);
	evaluate_cases(amount);
	if(first_ka)
	  opt_mem += co_op_table[amount][MEM_IND];
      }	
      break;
    default:
      break;
    }
  } else if(rate==TIMEP) {
    /* increment the time profiler and reset the kcycle profiler */
    for(i=0; i<par; i++) {
      my_counter.t_counter[i] += my_counter.s_counter[i];
      my_counter.s_counter[i] = 0;
    }
    
  } else {  /* globalp assumed, reset the time profiler */
    for(i=0; i<par-1; i++) {
      my_counter.g_counter[i] += my_counter.t_counter[i];
      my_counter.t_counter[i] = 0;
    }
    seconds++;
  }
}


/* for some particular opcodes a special scale factor is needed **
** which depends on the parameters passed to the opcode itself  */

void calc_factor(int opcode, actparam *pf, int pf_ct, sa_decoder *sa) {

  int i, temp;

  for(i=0; i<COUNTMAX; i++) {
    factor[i]=1;
    cs_factor[i]=1;
  }
  switch(opcode) {
  case 18:
  case 19:   /* min, max */
    factor[FLOP_IND]=factor[TEST_IND]=2*(pf_ct-1);  /* Flops and Test */
    break;
  case 56:  /* pluck: buffer length for case 2 */
    cs_factor[FLOP_IND]=cs_factor[MULT_IND]=cs_factor[MATH_IND]=(int)(pf[1].val + 0.5);
    break;
  case 57:  /* buzz: operations times NHARM; not really a case */
    cs_factor[FLOP_IND]=cs_factor[MULT_IND]=cs_factor[MATH_IND]=(int)pf[1].val;
    break;
  case 78:  /* fft */
    if (pf_ct < 4)
      temp = sa->ksmps;
    else
      temp=(int)floor(pf[3].val + 0.5);
    factor[MACC_IND]=temp * (int)floor(log10(temp)/log10(2) + 0.5); /* Nlog2(N) */
    break;
  case 79:  /* ifft */
    if (pf_ct < 3)
      temp = sa->ksmps;
    else
      temp=(int)floor(pf[2].val + 0.5);
    factor[MACC_IND]=temp * (int)floor(log10(temp)/log10(2) + 0.5); /* Nlog2(N) */
    break;
  case 80:  /* rms */
    if (pf_ct > 1)
      cs_factor[MACC_IND] = (int)floor(pf[1].val + 0.5);
    if (cs_factor[MACC_IND]==1)
      cs_factor[MACC_IND] = (int)floor(sa->all->g->srate/sa->all->g->krate);
    break;
  case 81:  /* gain */
    if (pf_ct > 2)
      cs_factor[MACC_IND] = (int)floor(pf[2].val + 0.5);
    if (cs_factor[MACC_IND]==1)
      cs_factor[MACC_IND] = (int)floor(sa->all->g->srate / sa->all->g->krate + 0.1);
    break;
  case 82:  /* balance */
    if (pf_ct > 2) 
      cs_factor[MACC_IND] = 2*(int)(floor(pf[2].val + 0.5));
    if (cs_factor[MACC_IND]==1)
      cs_factor[MACC_IND] = 2*(int)floor(sa->all->g->srate / sa->all->g->krate + 0.1);
    break;
  case 86:  /* upsamp */
    /* implementation doesn't correspond ?? */
    cs_factor[MACC_IND] = sa->ksmps;
    break;
  case 87:  /* downsamp */
    cs_factor[MACC_IND] = (int)floor(sa->all->g->srate / sa->all->g->krate + 0.1);
    break;
  case 92:  /* fir */
    factor[MACC_IND]=pf_ct-1;  /* multiply and add */
    break;
  case 93:  /* firt */
    factor[MACC_IND]=(int)pf[2].val; /* co_param(pf,3) */
    break;
  case 94:  /* iir */
    factor[MACC_IND]=pf_ct;
    break;
  case 95:  /* iirt */
    factor[MACC_IND]=2*(int)(floor(pf[3].val));
    break;
  case 96:  /* fracdelay: return the method number */
    factor[COUNTMAX]=(int)(pf[0].val+0.5); /* co_param(pf,1) */
    break;
  default:
    factor[0]=1;
    break;
  }

}


void evaluate_cases(int opc) {

    int i;

    switch(opc) {
    case 4:   /* abs */
	if(abs_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[ABS2][i]);
	abs_cs2=0;
        }
	break;
    case 5:   /* sgn */
	if(sgn_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[SGN2][i]);
	sgn_cs2=0;
        }
	break;
    case 46:   /* oscil */
	if(oscil_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[OSCIL2][i]);
	oscil_cs2=0;
        }
	break;
    case 47:  /* loscil */
	if(loscil_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[LOSCIL2][i]);
	loscil_cs2=0;
        }
	break;
    case 49:  /* koscil */
	if(koscil_cs2) {
	for(i=1; i<COUNTLEN; i++) 
	  my_counter.s_counter[i] += (co_op_table[KOSCIL2][i]);
	koscil_cs2=0;
        }
	break;
    case 50:  /* kline */
    case 51:  /* aline */
	if(line_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[LINE2][i]);
	line_cs2=0;
        }
        break;
    case 52:  /* kexpon */
    case 53:  /* aexpon */
	if(expon_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[EXPON2][i]);
	expon_cs2=0;
        }
        break;
    case 54:  /* kphasor */
    case 55:  /* aphasor */
        if(phasor_cs2) {
	for(i=1; i<COUNTLEN; i++) 
	  my_counter.s_counter[i] += (co_op_table[PHASOR2][i]);
	phasor_cs2=0;
        }
        break;
    case 56:  /* pluck */
	if(pluck_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[PLUCK2][i]*cs_factor[i]);
	pluck_cs2=0;
        }
	if(pluck_cs3) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[PLUCK3][i]);
	pluck_cs3=0;
        }
	break;
    case 57:  /* buzz */
	if(buzz_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[BUZZ2][i]);
	buzz_cs2=0;
        }
	for(i=1; i<COUNTLEN; i++)   /* always verified: it is not a real case */
	  my_counter.s_counter[i] += (co_op_table[BUZZNH][i]*cs_factor[i]);
   break;
    case 58:  /* grain */
	if(grain_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN2][i]);
	grain_cs2=0;
        }
	if(grain_cs3) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN3][i]);
	grain_cs3=0;
        }
	if(grain_cs4) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN4][i]);
	grain_cs4=0;
        }
	if(grain_cs5) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN5][i]*grain_factor);
	grain_cs5=0;
        }
	if(grain_cs6) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN6][i]*grain_factor);
	grain_cs6=0;
        }
	if(grain_cs7) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN7][i]*grain_factor);
	grain_cs7=0;
	}
	if(grain_cs5a) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN5A][i]*grain_afactor);
	grain_cs5a=0;
        }
	if(grain_cs7a) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GRAIN7A][i]*grain_afactor);
	grain_cs7a=0;
        }
    break;
    case 68:
    case 69:  /* poisson noise generators */
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[POISS2][i]);
	poiss_cs2=0;
    break;
    case 73:  /* port */
   if(port_cs3) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[PORT3][i]);
	port_cs3=0;
        }
	break;
    case 80:  /* rms */
	if(rms_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[RMS2][i]*cs_factor[i]);
	rms_cs2=0;
        }
	break;
    case 81:  /* gain */
	if(gain_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[GAIN2][i]*cs_factor[i]);
	gain_cs2=0;
        }
	break;
    case 82:  /* balance */
	if(balance_cs2) {
	for(i=1; i<COUNTLEN; i++) 
	  my_counter.s_counter[i] += (co_op_table[BALANCE2][i]*cs_factor[i]);
	balance_cs2=0;
        }
	break;
    case 86:  /* upsamp */
	if(upsamp_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[UPSAMP2][i]*cs_factor[i]);
	upsamp_cs2=0;
        }
	break;
    case 87:  /* downsamp */
	if(downsamp_cs2) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[DOWNSAMP2][i]*cs_factor[i]);
	downsamp_cs2=0;
        }
	break;
    case 96:  /* fracdelay */
	if(fdelay_m2) {
	cs_factor[INTERP_IND]=done_interp;
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[FDELAY2][i]*cs_factor[i]);
	fdelay_m2=0;
        }
	if(fdelay_m3) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[FDELAY3][i]);
	fdelay_m3=0;
        }
	if(fdelay_m4) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[FDELAY4][i]);
	fdelay_m4=0;
        }
	if(fdelay_m5) {
	for(i=1; i<COUNTLEN; i++)
	  my_counter.s_counter[i] += (co_op_table[FDELAY5][i]);
	fdelay_m5=0;
        }
	break;
    default:
	opc++;
    }
}


/* print profiler information and convert interpolation to operations if linear */

void prof_print(int par, int factor) {

  FILE *fp;
  int i;

  if(par==0 && kprof) {
    fp = kout;
    if(quality == 0) {   /* linear interpolation */
	for(i=0; i<COUNTLEN; i++)
		my_counter.s_counter[i] += (interp_vector[i]*my_counter.s_counter[INTERP_IND]);
	my_counter.s_counter[INTERP_IND] = 0;
    }
    fprintf(fp, "%d", my_counter.s_counter[0]*factor);
    fprintf(fp, "\n%d", my_counter.s_counter[1]*factor);
    fprintf(fp, "\n%d", my_counter.s_counter[2]*factor);
    fprintf(fp, "\n%d\n", my_counter.s_counter[3]*factor);
    fprintf(fp, "%d", my_counter.s_counter[4]*factor);
    fprintf(fp, "\n%d", my_counter.s_counter[5]*factor);
    fprintf(fp, "\n%d", my_counter.s_counter[6]*factor);
    fprintf(fp, "\n%d", my_counter.s_counter[7]*factor);
    fprintf(fp, "\n%d", my_counter.s_counter[8]*factor);
    fprintf(fp, "\n%d", my_counter.s_counter[9]*factor);
    fprintf(fp, "\n%d\n", allocated_mem + opt_mem + tables_mem);
  } else if(par==1) {
    if(quality == 0) {   /* linear interpolation */
	for(i=0; i<COUNTLEN; i++)
		my_counter.t_counter[i] += (interp_vector[i]*my_counter.t_counter[INTERP_IND]);
	my_counter.t_counter[INTERP_IND] = 0;
    }
    fprintf(ipsout, "%d", my_counter.t_counter[0]);
    fprintf(ipsout, "\n%d", my_counter.t_counter[1]);
    fprintf(ipsout, "\n%d", my_counter.t_counter[2]);
    fprintf(ipsout, "\n%d\n", my_counter.t_counter[3]);
    fprintf(ipsout, "%d", my_counter.t_counter[4]);
    fprintf(ipsout, "\n%d", my_counter.t_counter[5]);
    fprintf(ipsout, "\n%d", my_counter.t_counter[6]);
    fprintf(ipsout, "\n%d", my_counter.t_counter[7]);
    fprintf(ipsout, "\n%d", my_counter.t_counter[8]);
    fprintf(ipsout, "\n%d", my_counter.t_counter[9]);
    fprintf(ipsout, "\n%d\n", allocated_mem+opt_mem+tables_mem);

    fprintf(stdout, "\nIt's now t=%d seconds", seconds+1);
    fprintf(stdout, "\nOpcode calls: %d", my_counter.t_counter[0]);
    fprintf(stdout, "\nFloat operations: %d", my_counter.t_counter[1]);
    fprintf(stdout, "\nMultiplications: %d", my_counter.t_counter[2]);
    fprintf(stdout, "\nTests: %d", my_counter.t_counter[3]);
    fprintf(stdout, "\nMath methods: %d\n", my_counter.t_counter[4]);
    fprintf(stdout, "Noise generators: %d\n", my_counter.t_counter[5]);
    fprintf(stdout, "Interpolations: %d", my_counter.t_counter[6]);
    fprintf(stdout, "\nMultiply-and-Accumulate: %d", my_counter.t_counter[7]);
    fprintf(stdout, "\nFilters: %d", my_counter.t_counter[8]);
    fprintf(stdout, "\nEffects: %d", my_counter.t_counter[9]);
    fprintf(stdout, "\nAllocated memory: %d\n", allocated_mem+opt_mem+tables_mem);
  } else if(par!=0) {
    if(quality == 0) {   /* linear interpolation */
	for(i=0; i<COUNTLEN; i++)
		my_counter.g_counter[i] += (interp_vector[i]*my_counter.g_counter[INTERP_IND]);
	my_counter.g_counter[INTERP_IND] = 0;
    }
    fprintf(stdout, "\nThe end of the performance: global values\n");
    fprintf(stdout, "\nOpcode calls: %d", my_counter.g_counter[0]);
    fprintf(stdout, "\nFloat operations: %d", my_counter.g_counter[1]);
    fprintf(stdout, "\nMultiplications: %d", my_counter.g_counter[2]);
    fprintf(stdout, "\nTests: %d", my_counter.g_counter[3]);
    fprintf(stdout, "\nMath methods: %d\n", my_counter.g_counter[4]);
    fprintf(stdout, "Noise generators: %d\n", my_counter.g_counter[5]);
    fprintf(stdout, "Interpolations: %d", my_counter.g_counter[6]);
    fprintf(stdout, "\nMultiply-and-Accumulate: %d", my_counter.g_counter[7]);
    fprintf(stdout, "\nFilters: %d", my_counter.g_counter[8]);
    fprintf(stdout, "\nEffects: %d", my_counter.g_counter[9]);
    fprintf(stdout, "\nAllocated memory: %d\n", allocated_mem+opt_mem+tables_mem);
  }
}

/* parse the file opcodes.map and build the table for coefficients */
int prof_setup(char *ips, char *fl) {

  FILE *fp;
  int i, j, prof_op, num;
  char *line, **acoeffs;

  ipsout=fopen(ips, "w");

  if((fp=fopen("opcodes.map", "r"))==NULL) {
    fprintf(stderr, "Can't find file 'opcodes.map', opcodes will not be profiled...\n");
    prof_op = 0;
  } else {
    for(i=0; i<CO_NUM; i++) {
      line = getline(fp);
      num = split(line, &acoeffs);
      for(j=0; j<COUNTMAX; j++)
	co_op_table[i][j] = atoi(acoeffs[j]);
    }
    allocated_mem = 0;
    tables_mem = 0;
    pointer_num = 0;
    ptable = NULL;
    prof_op = 1;
    for(j=0; j<COUNTMAX; j++)
	my_counter.s_counter[i] = 0;
    
    map_kout(fl);  /* measurements at the k-rate, if any */
  }
  return(prof_op);
}

/* decide if and where the kcycle profiling must be saved */
void map_kout(char *fl) {

  if(fl) {
    kout=fopen(fl, "w");
    kprof=1;
  }
  else
    kprof=0;
}


/* the following function adds an entry to the pointer table **
** and increments the allocated_mem variable                 */
 
int add_pointer(void *pnt, int bytes) {

  ptable=(pointer *)realloc(ptable, (pointer_num+1)*sizeof(pointer));

  ptable[pointer_num].pnt=pnt;
  ptable[pointer_num].bytes=bytes;
  allocated_mem += bytes;
  return(++pointer_num);

}


/* the following function eliminates an entry from the pointer **
** table and decreases the allocated_mem variable              */

int remove_pointer(void *pnt) {

  int i;

  i=0;
  while((ptable[i].pnt != pnt) && (i!=pointer_num))
    i++;
  /* now verify if the pointer was found and proceed */
  if(ptable[i].pnt == pnt) {
    allocated_mem -= ptable[i].bytes;
    pointer_num--;
    if(i<pointer_num)
      do {
        ptable[i].pnt=ptable[i+1].pnt;
        ptable[i].bytes=ptable[i+1].bytes;
        i++;
      } while(i!=pointer_num);

    ptable=(pointer *)realloc(ptable, pointer_num*sizeof(pointer));
  }
  return(pointer_num);
}



int *prof_malloc(int size) {

  int *buf;

  buf=(int *)malloc(size+sizeof(double));
  *buf = size/2;
  allocated_mem += *buf;   /* the standard format */
  return(++buf);
}


void prof_free(int *block) {

  block--;
  allocated_mem -= *block;
  free(block);
}


int *prof_calloc(int items, int size) {

  int *buf;

  buf=(int *)malloc((size*items)+sizeof(double));
  *buf = size*items/2;
  allocated_mem += *buf;   /* the standard format */
  return(++buf);
}



