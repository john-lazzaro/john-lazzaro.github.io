/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#include <stdio.h>
#ifdef _WIN32
#include <string.h>
#else
#include <strings.h>
#endif
#include <stdlib.h>
#include "saol.h"

void walk_block_replace_tvar(block *, char *, terminal *);
void walk_expr_replace_tvar(expr *, char *, terminal *);
void walk_exprlist_replace_tvar(exprlist *, char *, terminal *);
void walk_statement_replace_tvar(statement *, char *, terminal *);

void deal_with_template(sa_decoder *sa, template_decl *t) {
  /* we need to make an instrument for each of the template names.

     this involves
       making space for the instrument,
       moving the names over,
       putting the preset lists in (if any),
       making deep copies of
          the parameter list,
	  the local variable list,
	  and the code,
       checking each template variable map for correct type,
       replacing the template variables in the code with their maps,
          (those not actually used by this instrument) */

  namelist *name,*tvar,*newparams;
  terminal_list *value,*new_pre;
  mapblock *map,*pre;
  char *newname;
  vardecl_list *newlocalvars;
  block *newcode;
  instr_decl *id;
    

  
  if (!sa->all->il) sa->all->il = new_instr_list();

  pre = t->preset;
  for (name = t->names, map=t->mapping;
       name;
       name=name->next, map=map->next) {
    if (!map) {
      parse_error("Not enough mapwith blocks for template.");
      return;
    }

    if (t->preset)
      new_pre = pre->tl;  /* don't need a deep copy */
    else
      new_pre = NULL;
      

    newname = strdup(name->n->name);
    newparams = copy_namelist(t->params);
    newlocalvars = copy_vardecl_list(t->localvars);
    newcode = copy_block(t->code);

    for (tvar = t->tvars, value = map->tl;
	 tvar;
	 tvar = tvar->next, value = value->next) {
      if (!value) {
	parse_error("Not enough mapwidth values in block.");
	return;
      }
      walk_block_replace_tvar(newcode,tvar->n->name,value->t);
    }

    
    id = new_instr_decl(newname,newparams,newlocalvars,newcode,new_pre);
    add_instr_list(sa->all->il,id);
    if (sa->verbose) {
      printf("Made instrument '%s' from template:\n",name->n->name);
      print_block(newcode);
    }
    if (t->preset) {
      pre = pre->next;
      if (!pre && tvar && tvar->next)
	parse_error("Not enough preset blocks for template.");
    }
   
  }
}

void walk_block_replace_tvar(block *b,char *orig,terminal *repl) {
  if (!b) return;
  walk_statement_replace_tvar(b->st,orig,repl);
  walk_block_replace_tvar(b->next,orig,repl);
}

void walk_statement_replace_tvar(statement *st, char *orig, terminal *repl) {
  if (!st) return;
  walk_block_replace_tvar(st->b,orig,repl);
  walk_block_replace_tvar(st->elseb,orig,repl);
  walk_expr_replace_tvar(st->expr,orig,repl);
  walk_expr_replace_tvar(st->lvalue,orig,repl);
  walk_exprlist_replace_tvar(st->params,orig,repl);
}

void walk_expr_replace_tvar(expr *e, char *orig, terminal *repl) {
  if (!e) return;
  if (e->d && e->d->iname && !strcmp(e->d->iname,orig)) {
    free(e->d);
    e->op = repl->type;  /* might have changed from an expr to a const */
    e->d = copy_terminal(repl);
  }
  walk_expr_replace_tvar(e->left,orig,repl);
  walk_expr_replace_tvar(e->right,orig,repl);
  walk_expr_replace_tvar(e->extra,orig,repl);
  walk_exprlist_replace_tvar(e->params,orig,repl);
}


void walk_exprlist_replace_tvar(exprlist *el, char *orig, terminal *repl) {
  if (!el) return;
  walk_expr_replace_tvar(el->p,orig,repl);
  walk_exprlist_replace_tvar(el->next,orig,repl);
}
