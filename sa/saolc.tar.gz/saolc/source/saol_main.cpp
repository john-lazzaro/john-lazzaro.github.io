/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_main.cpp : The main function of saolc. */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#ifdef _WIN32
#include <string.h>
void srand48(long x) {
  srand((int)x);
}
#else
#include <strings.h>
#endif

#include <time.h>

extern "C" {
#include "saol_prec.h"
#include "saol.h"
#include "bifs_nodes.h"

#ifdef _AC
#include "ac.h"
#endif

#ifdef _SASBF
#include "sf_wave_def.h"
#endif

#include "saol.tab.h"
#include "saol_interp.h"
#include "saol_sched.h"

#include "aifif.h"
#include <malloc.h>
extern int yyparse(void);
extern void open_inputs(sa_decoder *sa, struct cmdinfo *cmd);

#ifdef _MPEGPROFILER
  extern int prof_setup(char *ips, char *fl);
  extern void prof_print(int par, int factor);
#endif

int yywrap(void) {
  return 1;
}
  /* struct cmdinfo cmd; */
extern int yydebug;  
extern FILE *yyin;
#ifdef _MPEGPROFILER
  extern int prof_co;
  extern int quality;
#endif

sa_decoder *cur_sa; /* only needed at startup for yyparse() and MIDIfiles */
extern void parse_midi(sa_decoder *,char *);
}


void help(void);
void saol_startup(sa_decoder *,struct cmdinfo *);
void help(void);
void get_cmd_line(cmdinfo *, int, char *argv[]);
extern void process_header(sa_decoder *,struct cmdinfo *);
#ifndef _AC

main(int argc, char *argv[]) {
  sa_decoder *sa;
  struct cmdinfo cmd;
  int text = 0;

#ifdef _WIN32
  _fmode = O_BINARY;  // set binary mode when reading/writing files 
#endif 
  
  get_cmd_line(&cmd,argc,argv); // process the command line arguments
  
  // make the decoder
  sa = (sa_decoder *)malloc(sizeof(sa_decoder));
  if (!sa) {
    printf("Fatal: couldn't create SA decoder.\n");
    exit(1);
  }

  // if there's not enough stuff to do
  if ((!cmd.orc && (!cmd.midi || !cmd.sco)) && !cmd.bit)
    help(); // print some information to help the user figure it out

  // configure the decoder
  saol_startup(sa,&cmd);
#ifdef _MPEGPROFILER
  if(sa->all->g->interp) quality = 1; else quality = 0;
#endif

  // run the decoder until its done
  while (sa->sched->running) {
    sched_run_kcycle(sa,NULL);
  }

  // flush the output
  finish_output(sa);

#ifdef _MPEGPROFILER
  if(sa->prof)
    prof_print(2, 1);
#endif

  printf("\n");
  return(0);
}
#endif

void get_cmd_line(cmdinfo *cmd, int argc, char *argv[]) {
	// suck in all the command line arguments and fill up the command structure

	// first initialize
	cmd->sco = cmd->orc = cmd->out = cmd->bit = NULL;
	cmd->temp = ".";
	cmd->text = 0;
	cmd->verbose = 0;
#ifdef _MPEGPROFILER
	cmd->prof = 0;
	cmd->kprof = NULL;
#endif
	cmd->inct = 0;
	cmd->midi = 0;
	cmd->sfbank0 = 0;
	cmd->sfbank1 = 0;
	cmd->interp = 0;
	cmd->southpark = 0;
	cmd->segfault = 0;
	cmd->decoder = NULL;
    cmd->has_midi = cmd->has_sco = cmd->has_sbf = 0;

	// go through all the command line arguments
	while (++argv,--argc) {
		if (!strncmp(*argv,"-bit",4)) {cmd->bit = *(++argv); argc--;}
		else if (!strncmp(*argv,"-verb",4)) {cmd->verbose = 1;}
		else if (!strcmp(*argv,"-temp")) {cmd->temp = *(++argv); argc--;}
#ifdef _MPEGPROFILER
    	else if (!strcmp(*argv,"-prof")) {cmd->prof = 1; cmd->ips = *(++argv); argc--;}
    	else if (!strncmp(*argv,"-kprof", 4)) {cmd->kprof = *(++argv); argc--;}
#endif
		else if (!strncmp(*argv,"-sc",3)) {cmd->sco = *(++argv); argc--;}
		else if (!strncmp(*argv,"-or",3)) {cmd->orc = *(++argv); argc--;}
		else if (!strncmp(*argv,"-out",4)) {cmd->out = *(++argv); argc--; }
		else if (!strcmp(*argv,"-midi")) {cmd->midi = *(++argv); argc--; }
		else if (!strncmp(*argv,"-in",3)) {
			cmd->in[cmd->inct] = *(++argv); argc--;
			cmd->delay[cmd->inct++] = 0; /* atof(*(++argv)); argc--; */
		}
		else if (!strncmp(*argv,"-help",5)) help();
		else if (!strncmp(*argv,"-text",5)) { cmd->text = 1;}
		else if (!strcmp(*argv,"-sbank0")) { cmd->sfbank0 = *(++argv); argc--; }
		else if (!strcmp(*argv,"-sbank1")) { cmd->sfbank1 = *(++argv); argc--; }
		else if (!strcmp(*argv,"-iq")) { cmd->interp = atoi(*(++argv)); argc--; }
		else if (!strcmp(*argv,"-southpark")) { cmd->southpark = 1; }
		else if (!strcmp(*argv,"-segfault")) { cmd->segfault = 1; }
		else if (!strcmp(*argv,"-v")) { 
			printf("saolc version 1.0.1 (15 Aug 1999)\n");
		}
		else { printf("Unknown option '%s'.\n",*argv); exit(1); }
	}
}
	
  	
void saol_startup(sa_decoder *sa,struct cmdinfo *cmd) {
	// startup the decoder 
  FILE *fp;
  char s[800];
  int i,j;

  // initialize the decoder status
  sa->audioout = 0; sa->cmd = cmd; sa->textout = cmd->text; 
  sa->audioout = 0; sa->synerror = 0; sa->verbose = cmd->verbose;
#ifdef _MPEGPROFILER
  sa->prof = cmd->prof;
#endif
  sa->audioout = 0; sa->global_cx = NULL; sa->ksmps = 0;
  sa->outfile = cmd->out; sa->all_ptrs = NULL; sa->bufsize = 0;
  sa->replace_count = 0; sa->sched = NULL; sa->outbuf = NULL; 
#ifdef _32BITOUT
  sa->pcmout = NULL;
#else
  sa->aifout = NULL;
#endif
  sa->outbuf_ct = 0; sa->ended = 0;
  sa->all = NULL; sa->inct = cmd->inct; sa->is_outputbus = 0;
  sa->sound = 0; sa->southpark = cmd->southpark; sa->segfault = cmd->segfault;
  sa->tuning = 440.; sa->cached_au = NULL; sa->in_bitstream = NULL;
  sa->inbuf = NULL; sa->inbus = NULL; sa->inchan = 0;
  sa->MIDICCINIT = 0; sa->interp_q = cmd->interp ? cmd->interp : 3;
  sa->d = cmd->decoder;
  
  // seed the random number generator
  srand48((long)time(NULL));
  
  // if there's input files 
  if (cmd->inct) {
	  // make space to keep track of them
    sa->in = (inputfile *)calloc(cmd->inct,sizeof(inputfile));
  } else sa->in = NULL;

  // initialize the input-file data structures
  for (i=0;i!=sa->inct;i++) {
    if (cmd->in[i]) {
      sa->in[i].fn = strdup(cmd->in[i]); // filename
      sa->in[i].delay = cmd->delay[i];   // not currently used
      sa->in[i].aif_in = NULL;           // file pointer
    }
    else {
      sa->in[i].fn = NULL;
      sa->in[i].delay = 0;
      sa->in[i].nchan = 1;
    }
  }
  
  /* initialize global speed control stuff */
#ifdef _FX_SPEEDC
  sa->fx_speedc = 0;
  sa->num_spc_samples = 0;
  sa->spc_buf = NULL;
#endif
  
  /* initialize all the MIDI controllers */
  for (i = 0; i < NUM_MIDI_CHANS; i++)
    {
      sa->channels[i] = NULL;
      for (j=0;j!=NUM_MIDI_CC;j++)
	sa->midicc[i][j] = 0;
      /* Contiuous Controller Initializations go here (XXX) */
      sa->midicc[i][128] = 8192;	/* Pitch bend set to none */
      sa->midicc[i][7] = 64;
      sa->midicc[i][11] = 127;
      sa->midicc[i][10] = 64;		/* Pan set to center */
    }/* LSD midiCC add: for now PitchBend is CC#128 */
  
  if (cmd->bit) { // we're doing bitstream processing
    /* make filenames of temp files */
    sprintf(s,"%s%ctemp.sao",cmd->temp,DIRSEP);
    cmd->orc = strdup(s);
    sprintf(s,"%s%ctemp.sas",cmd->temp,DIRSEP);
    cmd->sco = strdup(s);
    sprintf(s,"%s%ctemp.mid",cmd->temp,DIRSEP);
    cmd->midi = strdup(s);

	// deal with the decoder configuration header (sa_decode.cpp)
    process_header(sa,cmd);

	// figure out what's actually here
    if (!cmd->has_sco) {
      free(cmd->sco);
      cmd->sco = NULL;
    }
    if (!cmd->has_midi) {
      free(cmd->midi);
      cmd->midi = NULL;
    }
    if (cmd->has_sbf) {
      sprintf(s,"%s%ctemp.sbf",cmd->temp,DIRSEP);
      cmd->sfbank0 = strdup(s);
    }
    
  }
  else { // not bitstream processing
    char *cpp;
    /* preprocess orc file with preprocessor (not normative) */
    if (cpp = getenv("SAOL_CPP")) {
      sprintf(s,cpp,cmd->orc);
      sprintf(s,"%s > %s%ctemp.sao",s,cmd->temp,DIRSEP);
      if (cmd->verbose) printf("Preprocessing: %s\n",s);
      system(s);
      sprintf(s,"%s%ctemp.sao",cmd->temp,DIRSEP);
      cmd->orc = strdup(s);
    }
  }
  
  // there's a SASBF bank on the command line
  if (cmd->sfbank0)
    
#ifdef _SASBF
    {
      printf("Loading DLS bank...\n");
      sf_bank_load(sa, cmd->sfbank0, 0); // load the bank (XXX) 
      printf("sfbank0 loaded\n");
      sa->dlsbankflag[0] = 1; // mark that it exists
    }
  else sa->dlsbankflag[0] = 0;
#else
  {
    printf("No SASBF support in this executable.\n");
  }
#endif

  // there's another SASBF bank on the command line
  if (cmd->sfbank1)
#ifdef _SASBF
    {
      sf_bank_load(sa, cmd->sfbank1, 1); // load the bank (XXX)
      printf("sfbank1 loaded\n");
      sa->dlsbankflag[1] = 1;
    }
  else sa->dlsbankflag[1] = 0;
#else
  {
    printf("No SASBF support in this executable.\n");
  }
#endif

#ifdef _MPEGPROFILER
  if(cmd->prof) 
    prof_co = prof_setup(cmd->ips, cmd->kprof);  // parse the core opcodes file, set the weights
#endif

  // open the orchestra file
  if (!(fp = fopen(cmd->orc,"r"))) {
    printf("Fatal: couldn't open orchestra file '%s'.\n",cmd->orc);
    exit(1);
  }
  
  // the YYIN variable is used by the lex code (saol.yy.c) to read data
  yyin = fp;
  
  // make a new orchestra structure
  sa->all = new_orc();

  // hold the decoder globally so that yacc can deal with it
  cur_sa = sa;
  // open all the input files
  open_inputs(sa,cmd); /* do first so get #input channels */

  // read and parse the saol code (saol.yacc / saol.tab.c)
  yyparse();

  /* if there wasn't a global block in the SAOL file, make a default one */
  if (!sa->all->g)
    sa->all->g = new_orc_global();

  /* build the symbol tables */
  build_sym_table(sa);
  /* rate check the orchestra */
  rate_checking(sa);
  /* macro expand the orchestra */
  macro_expand(sa);
  /* exit if syntax errors */
  if (sa->synerror) exit(1);

  /* make the global storage space */
  make_global_context(sa);
  /* startup the scheduler */
  start_scheduler(sa);
  /* deal with the score and MIDI file if there is one */
  if (cmd->sco) parse_score(sa,cmd->sco);
  if (cmd->midi) parse_midi(sa,cmd->midi);
  
  /* set up the global speed control buffers if they exist */
#ifdef _FX_SPEEDC
  if(!sa->spc_buf) {
    if (sa->inchan)
      sa->spc_buf = (sa_real **)calloc(sizeof(sa_real *), sa->inchan);
    else
      sa->inchan = NULL;
    
    for(i=0;i<sa->inchan;i++) {
      sa->spc_buf[i] = (sa_real *)calloc(sizeof(sa_real), sa->ksmps*2);
    }
  }
#endif

}

void runtime(sa_decoder *sa,char *s) {
	// what to do on a runtime error 
  printf("Runtime error: %s\n",s);
  if (sa && sa->segfault) {
    if (sa->southpark)
      printf("Oh my god!  You killed Kenny!  You bastard!\n");
    *(int *)0 = 1;		/* dump core */
  }
	  
  exit(1);
}

void help() {
  printf("Usage: saolc -orc [orcfile] [options]\n");
  printf("          -or-\n");
  printf("       saolc -bitstream [bitfile] [options]\n");
  printf("\n");
  printf("Options:\n");
  printf("   -sco         : score file in SASL format\n");
  printf("   -midi        : format 0/1 MIDI file\n");
  printf("   -sbank0     : SA sample bank file #0 \n");
  printf("   -sbank1     : SA sample bank file #1 \n");
  printf("   -text        : dump text sample values to stdout.                    \n");
  printf("   -temp        : directory for temp files for bitstream processing [.] \n");
  printf("   -in [fn]     : input sound file.\n");
#ifdef _32BITOUT
  printf("   -out [file]  : write output as raw 32-bit file.\n");
#else
  printf("   -out [file]  : write output as AIFF file.\n");
#endif
  printf("   -verbose     : dump out orch info and de-macroized orchestra.\n");
#ifdef _MPEGPROFILER
  printf("   -prof [file] : activate the built-in ips profiler.\n");
  printf("   -kprof [file]: activate the krate profiler printout. \n");
#endif
  printf("   -iq          : 'high' interpolation quality [3].\n");
  printf("   -v           : print version number.\n");
  printf("\nAt least one of -sco, -midi, -bitstream must be specified.\n");
  printf("\nIf the environment variable SAOL_CPP is set, the orchestra will be run\n");
  printf(" through the preprocessor before compilation.\n");
  printf("\n");
  exit(1);
}

