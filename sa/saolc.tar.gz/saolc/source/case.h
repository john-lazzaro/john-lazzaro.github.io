/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
  Giorgio Zoia (Signal Processing Institute - EPFL)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The EPFL
  retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1999.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* case.h */

extern int done_interp;
extern int done_interp2;
extern int abs_cs2;
extern int sgn_cs2;
extern int oscil_cs2;
extern int loscil_cs2;
extern int koscil_cs2;
extern int line_cs2;
extern int expon_cs2;
extern int phasor_cs2;
extern int pluck_cs2;
extern int pluck_cs3;
extern int buzz_cs2;
extern int port_cs2;
extern int port_cs3;
extern int fdelay_m2;
extern int fdelay_m3;
extern int fdelay_m4;
extern int fdelay_m5;
extern int rms_cs2;
extern int gain_cs2;
extern int balance_cs2;
extern int grain_cs2;
extern int grain_cs3;
extern int grain_cs4;
extern int grain_cs5;
extern int grain_cs6;
extern int grain_cs7;
extern int grain_cs5a;
extern int grain_cs7a;
extern int upsamp_cs2;
extern int downsamp_cs2;
extern int poiss_cs2;
