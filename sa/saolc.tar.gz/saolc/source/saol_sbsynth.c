
/* ISO_HEADER_START */

/*********************************************************************


This software module was originally developed by

  Luke Dahl (Joint E-Mu/Creative Tech Center)
  Eric D. Scheirer (MIT Media Laboratory) 

in the course of development of the MPEG-4 standard.
This software module is an implementation of a part of one or more
MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
of the MPEG-4 standard free license to this software module or
modifications thereof for use in hardware or software products
claiming conformance to MPEG-4.  Those intending to use this software
module in hardware or software products are advised that its use may
infringe existing patents.  The original developer of this software
module and his/her company, the subsequent editors and their
companies, and ISO/IEC have no liability for use of this software
module or modifications thereof in an implementation.  Copyright is
not released for non MPEG-4 conforming products. The MIT Media
Laboratory retains full right to use the code for its own purpose,
assign or donate the code to a third party and to inhibit third
parties from using the code for non MPEG-4 conforming products.  This
copyright notice must be included in all copies or derivative
works. Copyright (c) 1998.

***********************************************************************/

/* ISO_HEADER_END */

#include <stdio.h>
#ifdef _SASBF
#include "sf_wave_def.h"
#endif
#include "saol_prec.h"
#include "saol_sched.h"
#include "saol.tab.h"



int sasbf_width(sa_decoder *sa) {
  /* returns the number of channels of SASBF synthesis */
  return 2;
}

void sfsynth(context *cx, int offset, long rate, sa_real note, sa_real vel,
	     sa_real preset, sa_real bank, sa_real *val, int len) {
  sa_real x1, x2;
  int i;
  
  /* synthesizes one note using the SASBF synthesizer.
     Using channel CHAN, bank BANK, return successive samples
     of the note on pitch NOTE, velocity VEL in the VAL array.

     If SASBF is mono and LEN is bigger than 1, put the same value in
     each of VAL[0]..VAL[LEN-1].

     If SASBF is N channels and LEN is bigger than N, then
       VAL[0] = SASBF[0]
       ...
       VAL[N] = SASBF[N]
       VAL[N+1] = 0;
       ...
       VAL[LEN] = 0;

     If SASBF is N channels and N is bigger or equal to LEN, then
       VAL[0] = SASBF[0]
       ...
       VAL[LEN] = SASBF[LEN]

     If the easiest way to keep track of "which note is this?" is
     to generate a tag on the first call per note and then index
     it on subsequent calls, feel free to add a (void **)tag
     parameter; I'm not attached to this prototype.
       */

#ifdef _SASBF
  sf_synth_top(cx,offset,&x1,&x2,&x3,&x4,rate,0,cx->channel,bank,preset,note,vel);
#else	
  x1 = x2 = 0;
#endif

  val[0] = x1;
  if (len == 2)
    val[1] = x2;

  if (len > 2)
    for (i=2;i<len;i++) val[i] = 0;
  
}
