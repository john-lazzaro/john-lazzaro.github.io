/* $Id: audio.h,v 1.3 1998/05/06 21:13:33 eds Exp $ */
/* $Log: audio.h,v $
 * Revision 1.3  1998/05/06  21:13:33  eds
 * FCD version.
 * */
/*
   audio.h -- Definitions for generic real time audio I/O
   language: C
   author  : Paris Smaragdis
   copyright: (c) 1996 MIT Media Lab, All Rights Reserved
*/
/*********************************************************************
ISO_HEADER_START

This software module was originally developed by

  Paris Smaragdis (MIT Media Laboratory)

in the course of development of the MPEG-4 standard.
This software module is an implementation of a part of one or more
MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
of the MPEG-4 standard free license to this software module or
modifications thereof for use in hardware or software products
claiming conformance to MPEG-4.  Those intending to use this software
module in hardware or software products are advised that its use may
infringe existing patents.  The original developer of this software
module and his/her company, the subsequent editors and their
companies, and ISO/IEC have no liability for use of this software
module or modifications thereof in an implementation.  Copyright is
not released for non MPEG-4 conforming products. The MIT Media
Laboratory retains full right to use the code for its own purpose,
assign or donate the code to a third party and to inhibit third
parties from using the code for non MPEG-4 conforming products.  This
copyright notice must be included in all copies or derivative
works. Copyright (c) 1998.

ISO_HEADER_END
***********************************************************************/

#include <stdio.h>

#ifdef __alpha
#include <signal.h>
#include <mme/mme_api.h>

/* Interrupt function */
void soundInterrupt( int);

/* Buffer structure */
typedef struct {
  void *lpData;
  BOOL available;
} buffer_t;

#endif

#ifdef __sgi
#include <audio.h>
typedef int BOOL;
#endif

/* Sound output functions */
int soundOutOpen( int, int, int);
int soundOutClose( int);
int soundOutQueue( short *);

/* Sound input functions */
int soundInOpen( int, int, int);
int soundInClose( int);
