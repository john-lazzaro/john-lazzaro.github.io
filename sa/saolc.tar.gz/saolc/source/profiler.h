/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
  Giorgio Zoia (Signal Processing Institute - EPFL)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The EPFL
  retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1999.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* profiler.h */


#define COUNTLEN 19
#define COUNTMAX 20

#define SCHEDP 0
#define TIMEP 1
#define GLOBALP 2
#define CO_NUM 133     /* total number of lines in opcodes.map */

#define ABS2 102       /* extra cases for branches */
#define SGN2 103
#define OSCIL2 104
#define LOSCIL2 105
#define KOSCIL2 106
#define LINE2 107
#define EXPON2 108
#define PHASOR2 109
#define PLUCK2 110
#define PLUCK3 111
#define BUZZ2 112
#define GRAIN2 113
#define GRAIN3 114
#define GRAIN4 115
#define GRAIN5 116
#define GRAIN6 117
#define GRAIN7 118
#define GRAIN5A 119
#define GRAIN7A 120
#define PORT3 121
#define FDELAY2 122
#define FDELAY3 123
#define FDELAY4 124
#define FDELAY5 125
#define RMS2 126
#define GAIN2 127
#define BALANCE2 128
#define UPSAMP2 129
#define DOWNSAMP2 130
#define POISS2 131
#define BUZZNH 132

#define CO_PLUS 401

#define OPCALL_IND 0
#define FLOP_IND   1
#define MULT_IND   2
#define TEST_IND   3
#define MATH_IND   4
#define NOISE_IND  5
#define INTERP_IND 6
#define MACC_IND   7
#define FILT_IND   8
#define EFF_IND    9
#define MEM_IND   10

typedef struct {
  int s_counter[COUNTLEN];  /* the counter at scheduler rate */
  int t_counter[COUNTLEN];  /* the counter at time rate (seconds) */
  int g_counter[COUNTLEN];  /* the global counter */
} counter;

typedef int co_table[CO_NUM][COUNTMAX];

typedef struct {
  void *pnt;
  int bytes;
} pointer;

void increment_counter(int par, int amount, int rate);

void prof_print(int par, int factor);

int prof_setup(char *ips, char *fl);

void map_kout(char *fl);

void evaluate_cases(int opc);

int add_pointer(void *pnt, int bytes);
int remove_pointer(void *pnt);

int *prof_malloc(int size);
int *prof_calloc(int items, int size);

void prof_free(int *block);

