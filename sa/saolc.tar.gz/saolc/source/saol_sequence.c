/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_sequence.c : figure out a legal sequence for all the instruments,
according to the rules in Subclause 5.8.5.6.  

  The syntax-checker calls make_sequence(), which gives each instrument a
number according to its place in the sequence */

#include "saol.h"

typedef struct {
	int **d;
	int size;
} seqdata;

void before(sa_decoder *sa,seqdata *seq,char *x,char *y);
int isbefore(sa_decoder *sa,seqdata *seq,char *x,char *y);
int inum(sa_decoder *sa,char *name);
void new_seqdata(sa_decoder *sa,seqdata **seq);
void free_seqdata(seqdata *seq);
void transclose(seqdata *seq);
int isroutedto(sa_decoder *sa,char *from, char *to);
int seqloop(seqdata *seq);
void put_sequence(sa_decoder *sa,seqdata *seq);
int has_out_pred(seqdata *seq, int *out, int which);

void make_sequence(sa_decoder *sa) {
/* figure out a legal order for the instruments.  We do this by using assertion
rules to prohibit orders, in order to rule out all the illegal ones.  Then
	   we choose one of the not-ruled-out sequences as the one to use */
	send_list *sl;
	sequence_list *seql;
	instr_list *il;
	seqdata *seq;
	namelist *nl;
	
	/* make a structure to hold the assertion data */
	new_seqdata(sa, &seq);
	
	/* do explicit "sequences" first -- go through each sequence() instruction */
	for (seql = sa->all->g->seqs; seql && seql->s; seql = seql->next) {
	/* for each name in the sequence list, that instrument must be
		executed before its successor */
		for (nl = seql->s->seqlist; nl && nl->n; nl = nl->next) { /* go thru instrs */
			/* if the current namae isn't the last one */
			if (nl->next && nl->next->n)
				/* then add an assertion that the current one precedes the next one */
				before(sa,seq,nl->n->name,nl->next->n->name);
		}
	}
	
	transclose(seq); /* calculate the transitive closure of the sequence instructions */

	/* test if the 'sequence' statements have made a loop -- it's a parse 
	   error if so (XXX) */
	if (seqloop(seq))
		parse_error("Explicit loop in 'sequence' instructions.");
		
	/* now add 'startup' to the earliest place it can go. */
		
	/* if there's a 'startup' instrument */
	if (get_instr_decl(sa->all->g->sym,"startup")) {
		/* go through all the other instruments */
		for (il = sa->all->il; il && il->i; il = il->next) {
			/* if the current instrument isn't explicitly before "startup" */
			if (!isbefore(sa,seq,il->i->name,"startup")) {
				/* then startup is before the current instrument */
				before(sa,seq,"startup",il->i->name);
				/* and every instrument the current instrument is before */
				transclose(seq); 
			}
		}
	}

	/* now sends -- for each "send", find instruments that route onto the bus
	   defined by the send.  for each send-instrument - route-instrument pair,
	   if the send-instrument isn't explicitly before the route-instrument,
	   then the route-instrument is first */
				
	/* go through all the sends */
	for (sl = sa->all->g->sends; sl && sl->s; sl = sl->next) {
		/* go through all the instruments */
		for (il= sa->all->il; il && il->i; il = il->next) {
			/* if the current instrument is routed to the send instrument */
			if (isroutedto(sa,il->i->name,sl->s->instr) &&
				/* and it's not explicitly after */
				!isbefore(sa,seq,sl->s->instr,il->i->name)) {
				/* then it's before the send instrument */
				before(sa,seq,il->i->name,sl->s->instr);
				/* and before every instrument the send instrument is before */
				transclose(seq);
			}
		}
	}
	
	put_sequence(sa,seq); /* find a legal sequence and put the numbers in the instruments */
						
	free_seqdata(seq); /* clear out temporary data */
}

/* we use a precedence matrix to figure out the sequence; at every time, seq->d[i][j] == 1
   if we already know that instrument i has to come before instrument j (where instrument
   numbers i,j are according to syntactic order, not sequence order */

void before(sa_decoder *sa,seqdata *seq,char *x,char *y) {
	/* assert that instrument X has to come before instrument Y */
	int i1 = inum(sa,x); /* get the number of each instrument */
	int i2 = inum(sa,y);
	
	if (i1 != i2) /* if the instruments are different */
		seq->d[i1][i2] = 1; /* put the assertion in the matrix */
}

int isbefore(sa_decoder *sa,seqdata *seq,char *x,char *y) {
	/* test if instrument X is known to be before instrument Y */
	int i1 = inum(sa,x);
	int i2 = inum(sa,y);
	
	return(seq->d[i1][i2]);
}

int inum(sa_decoder *sa,char *name) {
	/* get the syntactic number of an instrument -- the instrument first in
	    the orchestra is 0, second is 1, and so on, just based on the SAOL
		code 
	
	   NAME assumed to be a legal instrument name */
	int i=0;
	instr_list *il;
	
	for (i=0,il=sa->all->il;strcmp(il->i->name,name);i++,il=il->next) ;
	return(i);
}

void new_seqdata(sa_decoder *sa,seqdata **seq) {
	/* make a new array to hold the assertion data */
	int ct,i=0,j=0;
	instr_list *il;
	
	/* count up the instruments */
	for (ct=0,il=sa->all->il;il && il->i;ct++,il=il->next) ;
	
	/* make a CT-by-CT matrix set all to zeros */
	*seq = (seqdata *)malloc(sizeof(seqdata));
	(*seq)->size = ct;
	(*seq)->d = (int **)calloc(ct,sizeof(int *));
	for (i=0;i!=ct;i++) {
		(*seq)->d[i] = (int *)calloc(ct,sizeof(int));
		for (j=0;j!=ct;j++) {
			(*seq)->d[i][j] = 0;
		}
	}
}

void free_seqdata(seqdata *seq) {
	/* release the assertion data */
	int i;
	
	for (i=0;i!=seq->size;i++)
		free(seq->d[i]);
	free(seq->d);
	free(seq);
}

void transclose(seqdata *seq) {
	/* calculate the transitive closure of the precedence matrix.  One transitive
	   step means that if D[i,j] == 1 and D[j,k] == 1, we want to set D[i,k] = 1 for 
	   all i,j,k.  The transitive closure is the matrix that results if we do 
	   transitive steps over and over again until the matrix converges (never more than
	   CT steps for a CT-by-CT matrix.
	
	   What this gives us is the "deductions" of all the instruments we know to be
	   before others.  For example
	
	      sequence(a,b,c);
	      sequence(b,d);
	      sequence(c,e,f);
	  
	   tells us explicitly that A is before B, B is before C, B is before D, and so forth,
	   but we can also deduce that A is before C, A is before D, A is before F, and so on.
	   The transitive closure performs these deductions and makes them explicit in the 
	   matrix.
	
	   This algorithm is O(N^4), which is fine unless there's more than 200 instruments
	   or so.  There's faster algorithms for doing this -- see an algorithms textbook.
	*/
	int i,j,k,l;
	
	/* do enough times */
	for (i=0;i!=seq->size;i++)
		/* implement the transitive-step rule */
		for (j=0;j!=seq->size;j++)
			for (k=0;k!=seq->size;k++)
				for (l=0;l!=seq->size;l++)
					if (seq->d[j][l] && seq->d[l][k])
						seq->d[j][k] =1;
}

int isroutedto(sa_decoder *sa,char *from, char *to) {
	/* return 1 if instrument FROM is routed onto a bus that is sent to TO */
	route_list *rl;
	send_list *sl;
	namelist *nl,*nl2;
	
	/* go through all the route instructions */
	for (rl=sa->all->g->routes;rl && rl->r;rl = rl->next)
		/* go through each instrument in the route */
		for (nl = rl->r->instrs;nl && nl->n;nl = nl->next)
			/* if the instrument is the FROM instrument */
			if (!strcmp(from,nl->n->name))
				/* go through all the send instructions */
				for (sl=sa->all->g->sends;sl && sl->s;sl=sl->next)
					/* if the send instrument is the TO instrument */
					if (!strcmp(sl->s->instr,to))
						/* go the all the busses for the send */
						for (nl2 = sl->s->busses;nl2 && nl2->n;nl2=nl2->next)
							/* if the bus in the route is a bus in the send */
							if (!strcmp(rl->r->bus,nl2->n->name))
								/* then the desired routing is found */
								return 1;
							
	/* o/w, not found */
	return 0;
}

int seqloop(seqdata *seq) {
	/* return 1 iff the sequence matrix contains a loop */
	int i;
	
	transclose(seq); /* calculate transitive closure */

	/* loop is easy to find -- if an instrument is before itself, there's a loop */
	for (i=0;i!=seq->size;i++)
		if (seq->d[i][i])
			return 1;
		
		return 0;
}

void put_sequence(sa_decoder *sa,seqdata *seq) {
	/* given the completed precedence matrix SEQ, figure out a legal order */
	int *out,*inv;
	int i,ct=0,outct,j;
	instr_list *il;
	
	/* make space */
	/* SA->SEQ[i] is the sequence order of instrument i */
	sa->seq = (int *)calloc(seq->size,sizeof(int));
	/* OUT is a list of instruments we still have to place in order */
	out = (int *)calloc(seq->size,sizeof(int));
	/* INV[i] is the the instrument sequenced as #i (the inverse function of SA->SEQ) */
	inv = (int *)calloc(seq->size,sizeof(int));
	
	/* initialize */
	for (i=0;i!=seq->size;i++) {
		sa->seq[i] = 0; out[i] = 1; /* still have to place all the instruments */
	}
	
	outct = seq->size;
	
	/* while there's still instruments we haven't dealt with */
	while (outct) {
		/* there has to be at least one instrument without predecessors that we
		   haven't yet placed */
		i=0; while (!out[i] || has_out_pred(seq,out,i)) i++;
		/* I is the next instrument in the sequence */
		out[i] = 0; /* we don't have to place it anyone */
		sa->seq[i] = ct++; /* it goes as #ct in the sequence */
		inv[ct-1] = i; /* the #ct instrument is I */
		outct--; /* one less to deal with */
	}
	
	/* dump out report if desired */
	if (sa->verbose) {
		printf("Sequence of instruments:\n  ");
		for (i=0;i!=seq->size;i++) {
			for (j=0,il=sa->all->il;j!=inv[i];j++,il=il->next) ;
			printf("%s ",il->i->name);
		}
		printf("\n\n");
	}
	
}

int has_out_pred(seqdata *seq, int *out, int which) {
	/* return 1 if instrument #WHICH has predecessors that we haven't yet
	   placed, according to OUT */
	int i;
	
	/* go through all the instruments */
	for (i=0;i!=seq->size;i++)
		/* if instrument I isn't dealt width, and it precedes WHICH, then
		   return true */
		if (out[i] && seq->d[i][which]) return 1;
		
	return 0; /* no such predecessor */
}

void dump_seq(seqdata *seq) {
	/* dump out the sequence matrix, for debugging only */
	int i,j;
	
	for (i=0;i!=seq->size;i++) {
		for (j=0;j!=seq->size;j++)
			printf("%d ",seq->d[i][j]);
		printf("\n");
	}
}
