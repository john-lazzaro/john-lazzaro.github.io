/* ISO_HEADER_START */

/*

 This software module was originally developed by

 Naoya Tanaka (Matsushita Communication Industrial Co., Ltd.)

 in the course of development of the MPEG-4 Audio standard (ISO/IEC 14496-3).
 This software module is an implementation of a part of one or more
 MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio
 standard (ISO/IEC 14496-3).
 ISO/IEC gives users of the MPEG-4 Audio standards (ISO/IEC 14496-3)
 free license to this software module or modifications thereof for use
 in hardware or software products claiming conformance to the MPEG-4
 Audio standards (ISO/IEC 14496-3).
 Those intending to use this software module in hardware or software
 products are advised that this use may infringe existing patents.
 The original developer of this software module and his/her company,
 the subsequent editors and their companies, and ISO/IEC have no
 liability for use of this software module or modifications thereof in
 an implementation.
 Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3)
 conforming products. The original developer retains full right to use
 the code for his/her own purpose, assign or donate the code to a third
 party and to inhibit third party from using the code for non MPEG-4
 Audio (ISO/IEC 14496-3) conforming products.
 This copyright notice must be included in all copies or derivative works.

 Copyright (c)1997.

*/

/* ISO_HEADER_END */

/* fx_picola.c : implementation of the PICOLA speed-change tool */

/* ISO_ONLY_CODE */

/* constants */
#define PAN_MAX_SPEED 5.
#define PAN_MIN_SPEED .5

#include <stdio.h>
#include <stdlib.h>
#include "saol_prec.h"
#include "fx_picola.h"


/* -------------- */
/* PICOLA modules */
/* -------------- */

void fx_picola(
    sa_real *inputSignal,
    sa_real *outputSignal,
    fx_speedc_storage *local
)
{

	int	i;
	int offset, num;
	sa_real coef, targ;


    if((sa_real)1. == local->scf){
		if(local->init) {

			for(i=0;i<local->num_out_samples;i++) {
				coef = i/(sa_real)local->num_out_samples;
                outputSignal[i] = coef*inputSignal[i];
			}
            local->init = 0;
        }else {
	        for(i=0;i<local->num_out_samples;i++) 
                outputSignal[i] = inputSignal[i];
		}

		return;
    }else {

/* for SA: begin ***************************************************/
/* startup */
	    if(local->init) {
            if(local->scf>(sa_real)1.) {
                if(local->len_inbuf
				    >(local->inend_point+local->num_in_samples)) {

                    if(0==local->inend_point) {
						for(i=0;i<local->num_in_samples;i++) {
			                coef = i/(sa_real)local->num_in_samples;
                            local->inbuf[local->inend_point+i] 
					            = coef*inputSignal[i];
					    }
                        local->inend_point += local->num_in_samples;

				    }else {

        			    for(i=0;i<local->num_in_samples;i++) {
		                    local->inbuf[local->inend_point+i] = inputSignal[i];
					    }
			            local->inend_point += local->num_in_samples;
				
                    }

			        for(i=0;i<local->num_out_samples;i++) 
                        outputSignal[i] = 0.;
#ifdef PICOLA_VFL
					local->num_out_samples = 0;
#endif

	                return;

			    }else {
			        local->init = 0;

    			    local->output_point = 0;

                    local->target_point = local->start_point
                        + (int)(local->scf/(local->scf-(sa_real)1.)*local->max_pitch);

                    for(i=0;i<local->num_in_samples;i++) {
                        local->inbuf[local->inend_point+i] = inputSignal[i];
			        }
                    local->inend_point += local->num_in_samples;

                }

            }else { /* local->scf<(sa_real)1. */

    			offset = (local->inbuf_frame/2)*local->num_in_samples;

                if(local->len_inbuf
				    >(local->inend_point+local->num_in_samples)) {

                    if(0==local->inend_point) {
						for(i=0;i<local->num_in_samples;i++) {
			                coef = i/(sa_real)local->num_in_samples;
                            local->inbuf[local->inend_point+i] 
					            = coef*inputSignal[i];
					    }
                        local->inend_point += local->num_in_samples;

				    }else {

        			    for(i=0;i<local->num_in_samples;i++) {
		                    local->inbuf[local->inend_point+i] = inputSignal[i];
					    }
			            local->inend_point += local->num_in_samples;
				
                    }

			        for(i=0;i<local->num_out_samples;i++) 
                        outputSignal[i] = 0.;
#ifdef PICOLA_VFL
					local->num_out_samples = 0;
#endif

	                return;

			    }else {
			        local->init = 0;
					local->output_point = 0;

                    num = (local->max_pitch+local->num_out_samples-1)
						/(local->num_in_samples);
					for(i=0;i<(num-1)*local->num_in_samples;i++)
					    local->outbuf[local->outend_point++] 
						    = local->inbuf[local->output_point++];


					local->target_point = offset-local->max_pitch
                            + (int)((sa_real)1./((sa_real)1.-local->scf)*local->max_pitch);

                    for(i=0;i<local->num_in_samples;i++) {
                        local->inbuf[local->inend_point+i] = inputSignal[i];
			        }
                    local->inend_point += local->num_in_samples;

				}

            }

        }else if(local->num_in_samples>0) {
            for(i=0;i<local->num_in_samples;i++) {
                local->inbuf[local->inend_point+i] = inputSignal[i];
	        }
            local->inend_point += local->num_in_samples;

		}else {
			return;
		}

/**************/
/* quick play */
/**************/

        if((local->scf>(sa_real)1.)&&(local->scf<=PAN_MAX_SPEED)) {
            if(local->target_point<local->num_in_samples) {
/* PICOLA processing */
				if(0!=local->output_point) {

					while(local->output_point<local->target_point) {
						local->outbuf[local->outend_point++]
							= local->inbuf[local->output_point++];
					}
				}else {
 
                    for(i=0;i<local->target_point;i++)
	    				local->outbuf[local->outend_point++] 
		    			    = local->inbuf[local->output_point++];
				}

				while(local->target_point<local->num_in_samples) {
    				local->start_point = local->target_point;
                    local->pitch = pit_sel_forward(local->inbuf+local->start_point,
		    		    local->min_pitch, local->max_pitch); 
  
                    if(0!=local->pitch) {
                        for(i=0;i<local->pitch;i++){
                            coef = (i+1)/(sa_real)(local->pitch+1);
                            local->inbuf[local->start_point+local->pitch+i] 
                                = ((sa_real)1.-coef)*local->inbuf[local->start_point+i]
                                     + coef*local->inbuf[local->start_point+local->pitch+i];
						}
                        local->output_point = local->start_point+local->pitch;
						targ = local->scf/(local->scf-(sa_real)1.)*local->pitch;
                        local->frac += targ;
                        local->frac -= (int)(targ);
                        local->target_point = local->start_point+(int)targ;
                        if(local->frac>(sa_real)1.) {
							local->frac -= (sa_real)1.;
							local->target_point += 1;
						}else if(local->frac<-(sa_real)1.) {
							local->frac += (sa_real)1.;
							local->target_point -= 1;
						}

                        if(local->target_point<local->num_in_samples) {
/* write outbuf */
							while(local->output_point<local->target_point) {
                                local->outbuf[local->outend_point++] 
                                    = local->inbuf[local->output_point++];
                            }

						}else if(local->output_point<local->num_in_samples) {
                            
							while(local->output_point<local->num_in_samples) {
                                local->outbuf[local->outend_point++] 
                                    = local->inbuf[local->output_point++];
							}

						}else {
							;
						}

					}else {
printf("\n pitch estimation is failed\n");
exit(3);
					}
/* end of while loop */
                }

/* shift the input samples */
                for(i=0;i<(local->len_inbuf - local->num_in_samples);i++) 
                    local->inbuf[i] = local->inbuf[local->num_in_samples+i];
                local->target_point -= local->num_in_samples;
                local->start_point -= local->num_in_samples;
                local->output_point -= local->num_in_samples;
                local->inend_point -= local->num_in_samples;

            }else {
/* target point is not in the first input frame */
/* write outbuf */
				if(local->output_point>local->num_in_samples) {
					;
				}else if(0!=local->output_point) {
					while(local->output_point<local->num_in_samples) {
                        local->outbuf[local->outend_point++] 
                            = local->inbuf[local->output_point++];
					}

				}else {
                    for(i=0;i<local->num_in_samples;i++) 
                        local->outbuf[local->outend_point++] 
                            = local->inbuf[local->output_point++];
				}

/* shift the input signal */
                for(i=0;i<(local->inend_point - local->num_in_samples);i++) 
                    local->inbuf[i] = local->inbuf[local->num_in_samples+i];
                local->target_point -= local->num_in_samples;
                local->start_point -= local->num_in_samples;
                local->output_point -= local->num_in_samples;
                local->inend_point -= local->num_in_samples;

            }

/* speed changed signal output */
            for(i=0;i<local->num_out_samples;i++)
                outputSignal[i] = local->outbuf[local->write_point++];

/* shift the output signal */
            for(i=0;i<(local->outend_point - local->num_out_samples);i++)
                local->outbuf[i] 
                    = local->outbuf[local->num_out_samples+i];

			local->outend_point -= local->num_out_samples;
            local->write_point -= local->num_out_samples;

/*************/
/* slow play */
/*************/

        }else if((local->scf<(sa_real)1.)&&(local->scf>=PAN_MIN_SPEED)) {

			offset = (local->inbuf_frame/2)*local->num_in_samples;
			/* for TEST */
			if(local->target_point-local->max_pitch<0) {
				printf("\n tp error (slow)\n");
				exit(3);
			}

            if((local->target_point-offset)<local->num_in_samples) {
/* PICOLA processing */
				if(0!=local->output_point-offset) {

					while(local->output_point<local->target_point) {
						local->outbuf[local->outend_point++]
							= local->inbuf[local->output_point++];
					}
				}else {
 
                    for(i=0;i<local->target_point-offset;i++)
	    				local->outbuf[local->outend_point++] 
		    			    = local->inbuf[local->output_point++];
				}

				while(local->target_point-offset<local->num_in_samples) {
    				local->start_point = local->target_point;
                    local->pitch = 
						pit_sel_backward(local->inbuf+local->start_point,
		    		    local->min_pitch, local->max_pitch); 
  
                    if(0!=local->pitch) {
						local->start_point -= local->pitch;
                        for(i=0;i<local->pitch;i++){
                            coef = (i+1)/(sa_real)(local->pitch+1);
                            local->inbuf[local->start_point+i] 
                                = coef*local->inbuf[local->start_point+i]
                                     + ((sa_real)1.-coef)*local->inbuf[local->start_point+local->pitch+i];
						}
                        local->output_point = local->start_point;
						targ = (sa_real)1./((sa_real)1.-local->scf)*local->pitch;
                        local->frac += targ;
                        local->frac -= (int)(targ);
                        local->target_point = local->start_point+(int)targ;
                        if(local->frac>(sa_real)1.) {
							local->frac -= (sa_real)1.;
							local->target_point += 1;
						}else if(local->frac<-(sa_real)1.) {
							local->frac += (sa_real)1.;
							local->target_point -= 1;
						}

/* write outbuf */
						for(i=0;i<local->pitch;i++) {
							local->outbuf[local->outend_point++]
								= local->inbuf[local->output_point++];
						}

                        if(local->target_point-offset<local->num_in_samples) {
							while(local->output_point<local->target_point) {
                                local->outbuf[local->outend_point++] 
                                    = local->inbuf[local->output_point++];
                            }

						}else if(local->output_point-offset<local->num_in_samples) {
                            
							while(local->output_point-offset<local->num_in_samples) {
                                local->outbuf[local->outend_point++] 
                                    = local->inbuf[local->output_point++];
							}

						}else {
							;
						}

					}else {
printf("\n pitch estimation is failed\n");
exit(3);
					}
/* end of while loop */
                }

/* shift the input samples */
                for(i=0;i<(local->len_inbuf - local->num_in_samples);i++) 
                    local->inbuf[i] = local->inbuf[local->num_in_samples+i];
                local->target_point -= local->num_in_samples;
                local->start_point -= local->num_in_samples;
                local->output_point -= local->num_in_samples;
                local->inend_point -= local->num_in_samples;

            }else {
/* target point is not in the first input frame */
/* write outbuf */
				if(local->output_point-offset>local->num_in_samples) {
					;
				}else if(0!=local->output_point-offset) {
					while(local->output_point-offset<local->num_in_samples) {
                        local->outbuf[local->outend_point++] 
                            = local->inbuf[local->output_point++];
					}

				}else {
                    for(i=0;i<local->num_in_samples;i++) 
                        local->outbuf[local->outend_point++] 
                            = local->inbuf[local->output_point++];
				}

/* shift the input signal */
                for(i=0;i<(local->len_inbuf - local->num_in_samples);i++) 
                    local->inbuf[i] = local->inbuf[local->num_in_samples+i];
                local->target_point -= local->num_in_samples;
                local->start_point -= local->num_in_samples;
                local->output_point -= local->num_in_samples;
                local->inend_point -= local->num_in_samples;

            }

/* speed changed signal output */
            for(i=0;i<local->num_out_samples;i++)
                outputSignal[i] = local->outbuf[local->write_point++];
        
/* shift the output signal */
            for(i=0;i<(local->outend_point - local->num_out_samples);i++)
                local->outbuf[i] 
                    = local->outbuf[local->num_out_samples+i];
            local->outend_point -= local->num_out_samples;
            local->write_point -= local->num_out_samples;

/* over range */
        }else {
            printf("\n speed control factor %f is not supported\n", local->scf);
            exit(1);
        }

/* for SA: end   ***************************************************/
		
		
	}

}


int pit_sel_backward(
    sa_real *Signal,
	int MinPitch,
	int MaxPitch
)
{
    int i, j;
    int Pitch;
    sa_real MinError;
    sa_real Error;
    sa_real CrossCorrelation;
    sa_real PastSignalEnergy;
    sa_real CurrentSignalEnergy;

    Pitch = MinPitch-1;
    MinError = (sa_real)1.0e20;

    PastSignalEnergy = 0.;
    CurrentSignalEnergy = 0.;
    for(i=1;i<MinPitch;i++) {
        PastSignalEnergy += (*(Signal-i))*(*(Signal-i));
        CurrentSignalEnergy += (*(Signal+i-1))*(*(Signal+i-1));
    }

    for(j=MinPitch;j<=MaxPitch;j++) {
        PastSignalEnergy += (*(Signal-j))*(*(Signal-j));
        CurrentSignalEnergy += (*(Signal+j-1))*(*(Signal+j-1));
	    CrossCorrelation = 0.;
	    for(i=0;i<j;i++) 
                CrossCorrelation += (*(Signal-j+i))*(*(Signal+i));

        Error = (PastSignalEnergy + CurrentSignalEnergy - 2*CrossCorrelation)
                    /(float)j;
        if((MinError>Error) && (CrossCorrelation>0.)) {
            MinError = Error;
            Pitch = j;
        }
    }

    if(0==Pitch) {
        if((PastSignalEnergy<(sa_real)1.) || (CurrentSignalEnergy<(sa_real)1.)) {
            Pitch = MaxPitch;
        }
    }

    return(Pitch);
}

int pit_sel_forward(
    sa_real  *Signal,
    int MinPitch,
	int MaxPitch
)
{
    int i, j;
    int Pitch;
    sa_real MinError;
    sa_real Error;
    sa_real CrossCorrelation;
    sa_real FirstHalfEnergy;
    sa_real SecondHalfEnergy;

    FirstHalfEnergy = 0.;
    SecondHalfEnergy = 0.;
    for(i=0;i<MinPitch-1;i++) {
        FirstHalfEnergy += (*(Signal+i))*(*(Signal+i));
        SecondHalfEnergy 
            += (*(Signal+i+MinPitch-1))*(*(Signal+i+MinPitch-1));
    }

    Pitch = MinPitch-1;
    MinError = (sa_real)1.0e20;

    for(j=MinPitch;j<=MaxPitch;j++) {
        FirstHalfEnergy += (*(Signal+j-1))*(*(Signal+j-1));
        SecondHalfEnergy += ((*(Signal+j*2-1))-(*(Signal+j-1)))
                                *((*(Signal+j*2-1))+(*(Signal+j-1)));
        SecondHalfEnergy += (*(Signal+j*2-2))*(*(Signal+j*2-2));

        CrossCorrelation = 0.;
        for(i=0;i<j;i++) 
            CrossCorrelation += (*(Signal+j+i))*(*(Signal+i));

        Error = (FirstHalfEnergy + SecondHalfEnergy - 2*CrossCorrelation)
                    /(float)j;
        if((MinError>Error) && (CrossCorrelation>0.)) {
            MinError = Error;
            Pitch =j;
        }

    }

    if(0==Pitch) {
        if((FirstHalfEnergy<(sa_real)1.) || (SecondHalfEnergy<(sa_real)1.)) {
            Pitch = MaxPitch;
        }
    }

    return(Pitch);
}

/* END_ISO_ONLY_CODE */


