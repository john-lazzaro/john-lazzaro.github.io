
/*

Instr.cpp

This software module was developed by Todor Fay (Microsoft Corp)
in the course of development of the MPEG-4 Audio (ISO/IEC 14496-3) standard. 
This software module is an implementation of a part of one or more 
MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio 
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC 14496-3) 
free license to this software module or modifications thereof for use 
in hardware or software products claiming conformance to the MPEG-4 Audio 
(ISO/IEC 14496-3). Those intending to use this software module in hardware 
or software products are advised that its use may infringe existing patents. 
The original developer of this software module and his/her company, the 
subsequent editors and their companies, and ISO/IEC have no liability for 
use of this software module or modifications thereof in an implementation. 
Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming 
products. Microsoft retains full right to use the code for its own 
purpose, assign or donate the code to a third party and to inhibit third 
parties from using the code for non MPEG-4 Audio (ISO/IEC 14496-3) 
conforming products. This copyright notice must be included in all copies 
or derivative works. 

Copyright (c) Microsoft Corporation 1996, 1998
*/

#ifndef _WIN32
#include <stdio.h>
#include <string.h>
#include "sfe_datatype.h"
#endif

#include "dlsparse.h"

void SourceLFO::Init()

{
	m_prFilterScale = 0;
    m_prPitchScale = 0;
    m_vrVolumeScale = 0;
    m_trDelay = -32768;
    m_trFrequency = 0;
	m_prMWFilterScale = 0;
    m_prMWPitchScale = 0;
    m_vrMWVolumeScale = 0;
	m_prCPFilterScale = 0;
    m_prCPPitchScale = 0;
    m_vrCPVolumeScale = 0;
}

SourceLFO::SourceLFO()

{
    Init();
}

void SourceLFO::Verify()

{
    FORCEBOUNDS(m_vrVolumeScale,-120,120);
    FORCEBOUNDS(m_vrMWVolumeScale,-120,120);
    FORCEBOUNDS(m_vrCPVolumeScale,-120,120);
    FORCEBOUNDS(m_prPitchScale,-1200,1200);
    FORCEBOUNDS(m_prMWPitchScale,-1200,1200);
    FORCEBOUNDS(m_prCPPitchScale,-1200,1200);
    FORCEBOUNDS(m_prFilterScale,0,13508);
    FORCEBOUNDS(m_prMWFilterScale,0,13508);
    FORCEBOUNDS(m_prCPFilterScale,0,13508);
}

void SourceEG::Init()

{
    m_pcSustain = 1000;
	m_prFilterScale = 0;
    m_prPitchScale = 0;
    m_trAttack = -32768;
    m_trDecay = -32768;
	m_trDelay = -32768;
	m_trHold = -32768;
    m_trKeyDecayScale = 0;
    m_trRelease = -32768;
    m_trVelAttackScale = 0;
}

SourceEG::SourceEG()

{
    Init();
}

void SourceEG::Verify()

{
//    FORCEBOUNDS(m_stAttack,0,1764000);
//    FORCEBOUNDS(m_stDecay,0,1764000);
    FORCEBOUNDS(m_pcSustain,0,1000);
//    FORCEBOUNDS(m_stRelease,0,1764000);
    FORCEBOUNDS(m_prPitchScale,-1200,1200);
	FORCEBOUNDS(m_prFilterScale,-12000,12000);
    FORCEBOUNDS(m_trKeyDecayScale,-12000,12000);
    FORCEBOUNDS(m_trVelAttackScale,-12000,12000);
}

void SourceArticulation::Init()

{
    m_ModEG.Init();
    m_ModLFO.Init();
	m_pcCC10ToPan = 500;
	m_pcCC91ToChorus = 0;
	m_pcCC93ToReverb = 400;
	m_pcChorusSend = 0;
    m_pcDefaultPan = 0;
	m_pcReverbSend = 0;
	m_prFilterC = 13508;
	m_prKeyNumberToPitch = 12800;
    m_prTune = 0;
    m_prVelToFilterScale = 0;
    m_VibratoLFO.Init();
    m_VolumeEG.Init();
	m_vrFilterQ = 0;
    m_vrVelToVolScale = -960;
}

SourceArticulation::SourceArticulation()

{
    m_wUsageCount = 0;
    Init();
}


void SourceArticulation::Verify()

{
	FORCEBOUNDS(m_pcDefaultPan,-500,500);
    FORCEBOUNDS(m_vrVelToVolScale,-2000,2000);
    FORCEBOUNDS(m_prVelToFilterScale,0,13508);
	FORCEBOUNDS(m_prKeyNumberToPitch,0,12800);
   	FORCEBOUNDS(m_prTune,-1200,1200);
	FORCEBOUNDS(m_prFilterC,1549,13508);
	FORCEBOUNDS(m_vrFilterQ,0,300);
	FORCEBOUNDS(m_pcChorusSend,0,1000);
	FORCEBOUNDS(m_pcCC91ToChorus,0,1000);
	FORCEBOUNDS(m_pcReverbSend,0,1000);
	FORCEBOUNDS(m_pcCC93ToReverb,0,1000);
	FORCEBOUNDS(m_pcCC10ToPan,0,500);
    m_ModLFO.Verify();
    m_ModEG.Verify();
    m_VolumeEG.Verify();
}

void SourceArticulation::AddRef()

{
    m_wUsageCount++;
}

void SourceArticulation::Release()

{
    m_wUsageCount--;
    if (m_wUsageCount == 0)
    {
        delete this;
    }
}

SourceSample::SourceSample()

{
    m_pWave = NULL;
    m_dwLoopStart = 0;
    m_dwLoopEnd = 1;
    m_dwSampleLength = 0;
    m_prFineTune = 0;
    m_dwSampleRate = 22050;
    m_bMIDIRootKey = 60;
    m_bOneShot = TRUE;
    m_bSampleType = 0;
    m_bWSMPLoaded = FALSE;
}

SourceSample::~SourceSample()

{ 
	if (m_pWave != NULL)
	{
		m_pWave->Release();
	}
}

void SourceSample::Verify()

{
    if (m_pWave != NULL)
    {
        if (m_pWave->m_wLockCount)
        {
            FORCEBOUNDS(m_dwSampleLength,0,m_pWave->m_dwSampleLength);
            FORCEBOUNDS(m_dwLoopEnd,1,m_dwSampleLength);
            FORCEBOUNDS(m_dwLoopStart,0,m_dwLoopEnd);
            if ((m_dwLoopEnd - m_dwLoopStart) < 1) 
            {
                m_bOneShot = TRUE;
            }
        }
    }
    FORCEBOUNDS(m_dwSampleRate,100,1000000);
    FORCEBOUNDS(m_bMIDIRootKey,0,127);
    FORCEBOUNDS(m_prFineTune,-1200,1200);
}

BOOL SourceSample::CopyFromWave()

{
	if (m_pWave == NULL)
	{
		return FALSE;
	}
	m_dwSampleLength = m_pWave->m_dwSampleLength;
	m_dwSampleRate = m_pWave->m_dwSampleRate;
	if (m_pWave->m_bWSMPLoaded && !m_bWSMPLoaded)
	{
		m_dwLoopEnd = m_pWave->m_dwLoopEnd;
		m_dwLoopStart = m_pWave->m_dwLoopStart;
		m_bOneShot = m_pWave->m_bOneShot;
		m_prFineTune = m_pWave->m_prFineTune;
		m_bMIDIRootKey = m_pWave->m_bMIDIRootKey;
	}
	if (m_bOneShot)
	{
		m_dwSampleLength--;
		m_pWave->m_pfWave[m_dwSampleLength] = 0;
	}
	else 
	{
		if (m_dwLoopStart >= m_dwSampleLength)
		{
			m_dwLoopStart = 0;
		}
		m_pWave->m_pfWave[m_dwSampleLength-1] =
			m_pWave->m_pfWave[m_dwLoopStart];
	}
	Verify();
	return (TRUE);
}

BOOL SourceSample::Lock(BOOL fLoadNow)

{
    if (m_pWave == NULL)
    {   // error, no wave structure!
        return (FALSE);
    }
    if (fLoadNow)
    {
        if (m_pWave->Lock())
        {
			if (m_pWave->m_pfWave == NULL)
			{
				m_pWave->UnLock();
				return (FALSE);
			}
			return CopyFromWave();
        }
    }
    else
    {
        return (m_pWave->m_ulOffset != 0);
    }
    return (FALSE);
}

BOOL SourceSample::UnLock()

{
    if (m_pWave != NULL)
    {
        m_pWave->UnLock();
        return (TRUE);
    }
    return (FALSE);
}

Wave::Wave()
{
    m_pfWave = NULL;
    m_dwSampleRate = 22050;
    m_dwSampleLength = 0;
    m_wUsageCount = 0;
    m_wLockCount = 0;
    m_ulOffset = 0;
    m_wID = 0;
	m_bOneShot = FALSE;
	m_wPlayCount = 0;
}

Wave::~Wave()

{
    if (m_pfWave != NULL)
    {
        delete m_pfWave;
        m_pfWave = NULL;
    }
}

void Wave::Verify()

{
    if (m_wLockCount > 0)
    {
        if (m_pfWave == NULL)
        {
            m_dwSampleLength = 0;
        }
    }
    FORCEBOUNDS(m_dwLoopEnd,1,m_dwSampleLength);
    FORCEBOUNDS(m_dwLoopStart,0,m_dwLoopEnd);
    FORCEBOUNDS(m_bMIDIRootKey,0,127);
    FORCEBOUNDS(m_prFineTune,-1200,1200);
    FORCEBOUNDS(m_vrAttenuation,-1000,0);
}

void Wave::AddRef()

{
    m_wUsageCount++;
}

void Wave::Release()

{
    m_wUsageCount--;
    if (m_wUsageCount == 0)
    {
        delete this;
    }
}

#ifdef __BYTE_INCOHERENT

static void _inline Swap2(unsigned short * punShort)
{
    unsigned char ucTemp;
    unsigned char *pucBuff;
    pucBuff = (unsigned char *) punShort;
    ucTemp = pucBuff[0];
    pucBuff[0] = pucBuff[1];
    pucBuff[1] = ucTemp;
}

static void _inline Swap4(unsigned long *pulLong)
{
    unsigned short unTemp;
    unsigned short *punBuff;
    punBuff = (unsigned short *) pulLong;
    unTemp = punBuff[0];
    punBuff[0] = punBuff[1];
    punBuff[1] = unTemp;
    Swap2(&punBuff[0]);
    Swap2(&punBuff[1]);
}

static void _inline SwapRIFFLIST(RIFFLIST *pRIFFLIST)

{
    Swap4(&pRIFFLIST->ckid);
    Swap4(&pRIFFLIST->cksize);
    Swap4(&pRIFFLIST->fccType);
}

#else
static void SwapRIFFLIST(RIFFLIST *pRIFFLIST) { }
#endif

BOOL Wave::Lock()

{
    if (m_wLockCount == 0)
    {
        if (m_ulOffset != 0)
        {
            RIFFLIST ck, *pck = &ck;
	    memcpy(&ck,(void *)m_ulOffset,sizeof(ck));
	    SwapRIFFLIST(pck);
	    
            if ((pck->ckid == LIST_TAG) && 
                (pck->fccType == MAKEFOURCC('w','a','v','e')))
            {
                HRESULT hr;
                BYTE *p = (BYTE *) m_ulOffset;
                hr = Load(p + sizeof(RIFFLIST),
                    p + sizeof(RIFF) + pck->cksize);
                if (hr < 0)
                {
                    return (FALSE);
                }   
            }
            else return (FALSE);
        }
        else return (FALSE);
    }
    m_wLockCount++;
    return (TRUE);
}

BOOL Wave::UnLock()

{
    m_wLockCount--;
    if (m_wLockCount == 0)
    {
        if (m_pfWave != NULL)
        {
            delete m_pfWave;
            m_pfWave = NULL;
        }
    }
    return (TRUE);
}

SourceRegion::SourceRegion()
{
    m_pArticulation = NULL;
    m_vrAttenuation = 0;
    m_bKeyHigh = 127;
    m_bKeyLow = 0;
    m_bVelHigh = 127;
    m_bVelLow = 0;
    m_bGroup = 0;
    m_bAllowOverlap = FALSE;
}

SourceRegion::~SourceRegion()
{
	m_Sample.UnLock();
    if (m_pArticulation)
    {
        m_pArticulation->Release();
    }
}

void SourceRegion::Verify()

{
    FORCEBOUNDS(m_bKeyHigh,0,127);
    FORCEBOUNDS(m_bKeyLow,0,127);
    FORCEBOUNDS(m_bVelHigh,0,127);
    FORCEBOUNDS(m_bVelLow,0,127);
    FORCEBOUNDS(m_vrAttenuation,-1200,0);
    m_Sample.Verify();
    if (m_pArticulation != NULL)
    {
        m_pArticulation->Verify();
    }
}

Instrument::Instrument()
{
    m_dwProgram = 0;
	m_pCollection = NULL;
}

Instrument::~Instrument()
{
	while (!m_RegionList.IsEmpty())
	{
        SourceRegion *pRegion = m_RegionList.RemoveHead();
        delete pRegion;
	}
}

void Instrument::Verify()

{
    SourceRegion *pRegion = m_RegionList.GetHead();
    SourceArticulation *pArticulation;
    for (;pRegion != NULL;pRegion = pRegion->GetNext())
    {
        if (pRegion->m_pArticulation != NULL)
        {
            pArticulation = pRegion->m_pArticulation;
        }
        pRegion->Verify();
    }
    pRegion = m_RegionList.GetHead();
    for (;pRegion != NULL;pRegion = pRegion->GetNext())
    {
        if (pRegion->m_pArticulation == NULL)
        {
            pRegion->m_pArticulation = pArticulation;
            pArticulation->AddRef();
        }
    }
}

SourceRegion * Instrument::ScanForRegion(DWORD dwNoteValue, DWORD dwNoteVelocity, DWORD dwLayerIndex)

{
    SourceRegion *pRegion = m_RegionList.GetHead();
    for (;pRegion;pRegion = pRegion->GetNext())
    {
        if (dwNoteValue >= pRegion->m_bKeyLow &&
            dwNoteValue <= pRegion->m_bKeyHigh &&
            dwNoteVelocity >= pRegion->m_bVelLow &&
            dwNoteVelocity <= pRegion->m_bVelHigh)
        {
            if (dwLayerIndex == 0) break ;
            dwLayerIndex--;
        }
    }
    return pRegion;
}

Collection::Collection()

{
    m_dwLockCount = 0;
    m_dwOpenCount = 0;
    m_pData = NULL;
    m_ulWavePool = 0;
	m_wWavePoolSize = 0;
}

Collection::~Collection()

{
	while (!m_InstrumentList.IsEmpty())
	{
        Instrument *pInstrument = m_InstrumentList.RemoveHead();
        delete pInstrument;
	}
	while (!m_WavePool.IsEmpty()) 
	{
        Wave *pWave = m_WavePool.RemoveHead();
        pWave->Release();
	}
}

void Collection::Verify()

{
    Wave *pWave = m_WavePool.GetHead();
    for (;pWave != NULL; pWave = pWave->GetNext())
    {
        pWave->Verify();
    }
    Instrument *pInstrument = m_InstrumentList.GetHead();
    for (;pInstrument != NULL;pInstrument = pInstrument->GetNext())
    {
        pInstrument->Verify();
    }
}

void Collection::AddInstrument(Instrument *pInstrument)

{
    if (pInstrument != NULL)
    {
        SourceRegion *pRegion = pInstrument->m_RegionList.GetHead();
        for (;pRegion;pRegion = pRegion->GetNext())
        {
            Wave *pWave = pRegion->m_Sample.m_pWave;
            if (pWave != NULL)
            {
                m_WavePool.AddTail(pWave);
				pWave->AddRef();
            }
        }
        m_InstrumentList.AddTail(pInstrument);
    }
}

Instrument * Collection::GetInstrument(DWORD dwProgram)

{
    Instrument *pInstrument = m_InstrumentList.GetHead();
    for (;pInstrument != NULL; pInstrument = pInstrument->GetNext())
    {
        if (pInstrument->m_dwProgram == dwProgram) 
        {
            break;
        }
    }
    return (pInstrument);
}


void Collection::RemoveDuplicateInstrument(DWORD dwProgram)

{
    Instrument *pInstrument = m_InstrumentList.GetHead();
    for (;pInstrument != NULL; pInstrument = pInstrument->GetNext())
    {
        if (pInstrument->m_dwProgram == dwProgram) 
        {
			m_InstrumentList.Remove(pInstrument);
			delete pInstrument;
			break;
        }
    }
}

InstManager::InstManager()

{
}

InstManager::~InstManager()

{
	while (!m_CollectionList.IsEmpty())
	{
        Collection *pCollection = m_CollectionList.RemoveHead();
        delete pCollection;
	}
}

void InstManager::Verify()

{
    Collection *pCollection = m_CollectionList.GetHead();
    for (;pCollection != NULL;pCollection = pCollection->GetNext())
    {
        pCollection->Verify();
    }
}

Instrument * InstManager::GetInstrument(DWORD dwProgram)

{
    Collection *pCollection;
    Instrument *pInstrument = NULL;
    pCollection = m_CollectionList.GetHead();
    for (;pCollection != NULL; pCollection = pCollection->GetNext())
    {
        pInstrument = pCollection->GetInstrument(dwProgram);
        if (pInstrument != NULL)
        {
            break;
        }
    }
    return (pInstrument);
}

HRESULT InstManager::GetSynthParams(DWORD dwPatch, DWORD dwNote, DWORD dwVelocity, sfData *pData, DWORD dwLayerIndex)

{
  char s[80];
	Instrument *pInstrument = GetInstrument(dwPatch);
	if (pInstrument)
	{
		SourceRegion * pRegion = 
			pInstrument->ScanForRegion(dwNote,dwVelocity, dwLayerIndex);
		if (pRegion && pData && pRegion->m_pArticulation)
		{
			SourceArticulation *pArticulation = pRegion->m_pArticulation;
			pData->dwStart = 0;
			pData->dwEnd = pRegion->m_Sample.m_dwSampleLength;
			pData->dwStartloop = pRegion->m_Sample.m_dwLoopStart;
			pData->dwEndloop = pRegion->m_Sample.m_dwLoopEnd;
			pData->dwSampleRate = pRegion->m_Sample.m_dwSampleRate;
			pData->shOrigKeyAndCorr = pRegion->m_Sample.m_bMIDIRootKey << 8;
			pData->shSampleModes = pRegion->m_Sample.m_bOneShot ? 0 : 1;
			pData->pfWave = pRegion->m_Sample.m_pWave->m_pfWave;
			pData->shCoarseTune = 0; // Coarse and fine tune are built into m_prFineTune.
			pData->shFineTune = pRegion->m_Sample.m_prFineTune + pArticulation->m_prTune;
			pData->shScaleTuning = pArticulation->m_prKeyNumberToPitch / 128;
			pData->shModLfoToPitch = pArticulation->m_ModLFO.m_prPitchScale;
			pData->shModWheelModLfoToPitch = pArticulation->m_ModLFO.m_prMWPitchScale;
			pData->shVibLfoToPitch = pArticulation->m_VibratoLFO.m_prPitchScale;
			pData->shModEnvToPitch = pArticulation->m_ModEG.m_prPitchScale;
			pData->shInitialFilterFc = pArticulation->m_prFilterC;
			pData->shInitialFilterQ = pArticulation->m_vrFilterQ;
			pData->shModLfoToFilterFc = pArticulation->m_ModLFO.m_prFilterScale;
			pData->shModEnvToFilterFc = pArticulation->m_ModEG.m_prFilterScale;
			pData->shInstVol = pRegion->m_vrAttenuation;                
			pData->shModLfoToVolume = pArticulation->m_ModLFO.m_vrVolumeScale;           
			pData->shModWheelModLfoToVolume = pArticulation->m_ModLFO.m_vrMWVolumeScale;   			
			pData->shChorusEffectsSend = pArticulation->m_pcChorusSend;
			pData->shReverbEffectsSend = pArticulation->m_pcReverbSend;
			pData->shPanEffectsSend = pArticulation->m_pcDefaultPan;
			pData->shDelayModLfo = pArticulation->m_ModLFO.m_trDelay;
			pData->shFreqModLfo = pArticulation->m_ModLFO.m_trFrequency;
			pData->shDelayVibLfo = pArticulation->m_VibratoLFO.m_trDelay;
			pData->shFreqVibLfo = pArticulation->m_VibratoLFO.m_trFrequency;
			pData->shDelayModEnv = pArticulation->m_ModEG.m_trDelay;
			pData->shAttackScaleModEnv = pArticulation->m_ModEG.m_trVelAttackScale;
			pData->shAttackModEnv = pArticulation->m_ModEG.m_trAttack;
			pData->shHoldModEnv = pArticulation->m_ModEG.m_trHold;
			pData->shDecayModEnv = pArticulation->m_ModEG.m_trDecay;
			pData->shSustainModEnv = pArticulation->m_ModEG.m_pcSustain;
			pData->shReleaseModEnv = pArticulation->m_ModEG.m_trRelease;
			pData->shAutoHoldModEnv = -32768; // LSD Mod!!! No DLS1 support
			pData->shAutoDecayModEnv = pArticulation->m_ModEG.m_trKeyDecayScale;
			pData->shDelayVolEnv = pArticulation->m_VolumeEG.m_trDelay;
			pData->shAttackScaleVolEnv = pArticulation->m_VolumeEG.m_trVelAttackScale;
			pData->shAttackVolEnv = pArticulation->m_VolumeEG.m_trAttack;
			pData->shHoldVolEnv = pArticulation->m_VolumeEG.m_trHold;
			pData->shDecayVolEnv = pArticulation->m_VolumeEG.m_trDecay;
			pData->shSustainVolEnv = pArticulation->m_VolumeEG.m_pcSustain;
			pData->shReleaseVolEnv = pArticulation->m_VolumeEG.m_trRelease;
			pData->shAutoHoldVolEnv = -32768; // LSD Mod!!! No DLS1 support
			pData->shAutoDecayVolEnv = pArticulation->m_VolumeEG.m_trKeyDecayScale;
			pData->shKeyExclusiveClass = pRegion->m_bGroup;
			pData->shKeynum = 0;			// LSD overide DEBUG!!!        
			pData->shVelocity = 0;		// LSD overide DEBUG!!!	 
			pData->shOverridingRootKey = -1;
			return S_OK;
		}
	}
	/*	sprintf(s,"No DLS instrument with patch #%d.",dwPatch);
	runtime(NULL,s); */
	return E_FAIL;
}

