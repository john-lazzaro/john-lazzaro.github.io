/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#include "bifs_types.h"

#define TRUE 1
#define FALSE 0

typedef struct mpeg4_node_struct {
  long id, type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
} mpeg4_node;

struct Reused_node {
  long id, node_type;
  mpeg4_node *node;
};

mpeg4_node *parse_node();

struct AudioDelay {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  long num_children;
  mpeg4_node **children;
  mpeg4_time delay;
  mpeg4_int32 numChan;
  long num_phaseGroup;
  mpeg4_int32 *phaseGroup;
  sa_real ***inbuf_last, **delbuf;
}; 

struct AudioMix {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  long num_children;
  mpeg4_node **children;
  mpeg4_int32 numInputs;
  long num_matrix;
  mpeg4_float *matrix;
  mpeg4_int32 numChan;
  long num_phaseGroup;
  mpeg4_int32 *phaseGroup;
  sa_real ***inbuf_last;
}; 

struct AudioSource {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  long num_url;
  mpeg4_url *url;
  mpeg4_float pitch;
  mpeg4_time startTime;
  mpeg4_time stopTime;
  mpeg4_int32 numChan;
  long num_phaseGroup;
  mpeg4_int32 *phaseGroup;
  struct decoder_struct *decoder;
}; 

struct AudioFX {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  long num_children;
  mpeg4_node **children;
  mpeg4_string orch;
  mpeg4_string score;
  long num_params;
  mpeg4_float *params;
  mpeg4_int32 numChan;
  long num_phaseGroup;
  mpeg4_int32 *phaseGroup;
  struct decoder_struct *decoder;
  sa_real ***inbuf_last, **fxinbuf, **fxoutbuf;
  int fxinpt,fxoutpt;
}; 

struct AudioSwitch {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  long num_children;
  mpeg4_node **children;
  long num_whichChoice;
  mpeg4_int32 *whichChoice;
  mpeg4_int32 numChan;
  long num_phaseGroup;
  mpeg4_int32 *phaseGroup;
}; 

struct AudioClip {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  mpeg4_bool loop;
  mpeg4_float pitch;
  mpeg4_time startTime;
  mpeg4_time stopTime;
  long num_url;
  mpeg4_url *url;
  mpeg4_time duration_changed;
  mpeg4_bool isActive;
};

struct Sound {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  mpeg4_vec3f direction;
  mpeg4_float intensity;
  mpeg4_vec3f location;
  mpeg4_float maxBack;
  mpeg4_float maxFront;
  mpeg4_float minBack;
  mpeg4_float minFront;
  mpeg4_float priority;
  mpeg4_node *source;
  mpeg4_bool spatialize;
}; 

struct Group2D {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  long num_addChildren;
  mpeg4_node **addChildren;
  long num_removeChildren;
  mpeg4_node **removeChildren;
  long num_children;
  mpeg4_node **children;
  mpeg4_vec2f bboxCenter;
  mpeg4_vec2f bboxSize;
  sa_real ***inbuf_last;
}; 

struct Sound2D {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  long inchan, outchan, srate;
  sa_real **inbuf, **outbuf;
  mpeg4_vec2f location;
  mpeg4_float intensity;
  mpeg4_node *sound;
  mpeg4_bool spatialize;
  sa_real ***inbuf_last;
}; 

struct ListeningPoint {
  /*
    //}}AFX_private
    // Gentle user: place private declarations here
    //{{AFX_private
  */
  long id, node_type;
  mpeg4_bool set_bind;
  mpeg4_bool jump;
  mpeg4_rotation orientation;
  mpeg4_vec3f position;
  mpeg4_string description;
  mpeg4_time bindTime;
  mpeg4_bool isBound;
}; 
