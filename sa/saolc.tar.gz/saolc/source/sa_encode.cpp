/* $Id: sa_encode.cpp,v 1.4 1998/05/06 21:30:43 eds Exp eds $ */
/* $Log: sa_encode.cpp,v $
// Revision 1.4  1998/05/06  21:30:43  eds
// FCD version.
//
// Revision 1.3  1997/11/20  18:32:14  eds
// Added SASBF block.
// Changed many direct actual parameters to pointer-passing.
// Bug fixes.
//
 * Revision 1.2  1997/11/15 00:43:01  luked
 * This is the result of the manual merge from the vendor branch for the
 * release tagged Fribourg_after_integration. I (brian) have probably lost
 * some history, but oh well.
 *
 * This contains the integration work by Eric Scheirer (MIT).
 *
// Revision 1.1  1997/11/10  22:55:37  eds
// Initial revision
// */

/*********************************************************************
ISO_HEADER_START

This software module was originally developed by

  Eric Scheirer (MIT Media Laboratory)

in the course of development of the MPEG-4 standard.
This software module is an implementation of a part of one or more
MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
of the MPEG-4 standard free license to this software module or
modifications thereof for use in hardware or software products
claiming conformance to MPEG-4.  Those intending to use this software
module in hardware or software products are advised that its use may
infringe existing patents.  The original developer of this software
module and his/her company, the subsequent editors and their
companies, and ISO/IEC have no liability for use of this software
module or modifications thereof in an implementation.  Copyright is
not released for non MPEG-4 conforming products. The MIT Media
Laboratory retains full right to use the code for its own purpose,
assign or donate the code to a third party and to inhibit third
parties from using the code for non MPEG-4 conforming products.  This
copyright notice must be included in all copies or derivative
works. Copyright (c) 1998.

ISO_HEADER_END

***********************************************************************/
#ifdef WIN32
#include <vector>
#include <queue>
#else
#include <queue>
#include <errno.h>
using namespace std;
#endif

extern "C"
{
#include "aifif.h"
#include "saol.h"
extern char *getline(FILE *fp);
extern int split(char *s, char ***words);
extern FILE *yyin;
int yylex(void); 
extern char yytext[];
extern midi_msg *get_next_event(FILE *fp,char *fn);
}
#include "bitstream.h"
#include "sa_bitstream.h"
#include "saol.tab.h"
#include "saol_tok_table.h"


orc_file *parse_saol(Bitstream *);
sa_symtable symtab;
sa_symbol doSample(char *,Bitstream *,sample **);
void doScore(char *,Bitstream *,float,float,float);
void dostreamScore(char *, Bitstream *, float, float, float);
void dostreamMIDI(char *, Bitstream *, float, float, float);
midi_msg *get_next_event(FILE *,char *);
void doMIDI(char *,Bitstream *);
int get_score_line(score_line *,FILE *,sample **);
struct cmdinfo cmd;
void doDataBlocks(char *,float, float);
priority_queue<SA_access_unit> au_list;

void main(int argc, char *argv[]) {
  int done = 0,type;
  FILE *fp;
  Bitstream *out;
  char s[100];
  orc_file *orc;
  sbf *SBF;
  float st,en,sh;

  if (argc < 2) {
    printf("Usage: encoder [file]\n");
    exit(1);
  }

  out = new Bitstream(argv[1],BS_OUTPUT);
  
  printf("Adding chunks to decoder configuration header...\n\n");
  while (!done) {
	  printf("Chunk types: 1=SAOL 2=SASL 3=sample 4=MIDI 5=SASBF (0=done)\n");
	  printf("Type, name: ");
	  scanf("%d",&type);
	  
	  switch (type) {
	  case 0:
		  done = 1;
		  break;
	  case 1: /* SAOL */
		  scanf("%s",s);
		  if (!(fp = fopen(s,"r"))) {
			  printf("Couldn't open file.\n");
		  } else {
			  yyin = fp;
			  orc = parse_saol(out);
			  out->putbits(1,1);  /* more_data */
			  out->putbits(0,3); /* orc_file */
			  orc->put(*out);
		  }
		  break;
	  case 2: /* SASL */
		  scanf("%s",s);
		  printf("start end shift: ");
		  scanf("%f %f %f",&st,&en,&sh);
		  doScore(s,out,st,en,sh);
		  break;
	  case 3: /* sample */
		  scanf("%s",s);
		  doSample(s,out,NULL);
		  break;
		  
	  case 4: /* SMF */
		  scanf("%s",s);
		  doMIDI(s,out);
		  break;
		  
	  case 5: /* SASBF */
		  scanf("%s",s);
		  if (!(fp = fopen(s,"r"))) {
			  printf("Couldn't open file.\n");
		  } else {
			  out->putbits(1,1);
			  out->putbits(4,3);
			  SBF = new sbf;
			  while (!feof(fp))
				  SBF->data.push_back(getc(fp));
			  fclose(fp);
			  SBF->length = SBF->data.size();
			  printf("Read %d bytes.\n",SBF->length);
			  SBF->put(*out);
		  }
		  break;
	  default:
		  printf("Not done yet.\n");
    }
  }
  printf("Include sa_symbol table? ");
  scanf("%s",s);
  if (s[0] == 'y') {
    out->putbits(1,1);
    out->putbits(5,3);
    symtab.put(*out);
  }
  out->putbits(0,1); /* no more bits */

  printf("\nBuilding streaming data...\n\n");
  done = 0;
  while (!done) {
	  printf("Chunk types: 2=SASL 3=sample 4=MIDI 6=data blocks (0=done)\n");
      printf("Type, name: ");
	  scanf("%d",&type);

	  switch (type) {
	  case 0:
		  done = 1;
		  break;
	  case 2: /* SASL */
		  scanf("%s",s);
		  printf("start end shift: ");
		  scanf("%f %f %f",&st,&en,&sh);
		  dostreamScore(s,out,st,en,sh);
		  break; 
	  case 4: /* MIDI */
		  scanf("%s",s);
		  printf("start end shift: ");
		  scanf("%f %f %f",&st,&en,&sh);
		  dostreamMIDI(s,out,st,en,sh);
		  break;
	  case 6: /* blocks of data */
		  scanf("%s",s);
		  printf("Offset blockrate: ");
		  scanf("%f %f",&st,&sh);
		  doDataBlocks(s,st,sh);
		  break;
	  default:
		  printf("Not supported.\n");
		  break;
	  }
  }

  while (!au_list.empty()) { // put() all elements
		SA_access_unit first;

		first = au_list.top();
		first.put(*out);
	  //au_list.top().put(*out);	
	  au_list.pop();
  }
  
  out->flushbits();

}

void flerror(char *s) {
  printf(s);
  exit(1);
}

double bufval(char *buf, int nchan, int nbits, int frame, int chan) {
  /* get the value of frame #frame, chan #chan, from the buffer, which
     corresponds to input #input of the current decode process */
  
  if (nbits == 16)
    return((double)*(short *)&buf[frame * nchan * 2 + chan * 2]);
  
  if (nbits == 32)
    return((double)*(int *)&buf[frame * nchan * 2 + chan * 2]);
  
  if (nbits == 8)
    return((double)*(char *)&buf[frame * nchan *2 + chan * 2]);

  return 0;
}

orc_file *parse_saol(Bitstream *out) {
  int lexel;
  orch_token t;
  int i;
  orc_file *o;
  char s[20];

  o = new orc_file;
  
  while (lexel = yylex()) {
    if (lexel > STRCONST)
      t.token = lexel_map(lexel);
    if (lexel == IDENT) {
      if (is_builtin(yytext) != -1)
	t.token = is_builtin(yytext);
      else { /* sa_symbol */
	t.token = TOK_SYMBOL;
	t.sym = symtab.add(yytext);
	/*	printf("Sa_Symbol '%s' = %d.\n",yytext,t.sym.sym); */
      }
    }
    if (lexel == NUMBER) {
      t.token = TOK_NUMBER;
      t.val = atof(yytext);
    }
    if (lexel == INTGR) {
      i = atoi(yytext);
      if (i >=0 && i <= 255)
	t.token = TOK_BYTE;
      else
	t.token = TOK_INT;
      t.ival = atoi(yytext);
    }
    if (lexel == STRCONST) {
      /* Must be a sound file */
      printf("Incorporate sound file '%s'? ",&yytext[1]);
      scanf("%s",s);
      if (s[0] == 'y') {
	t.token = TOK_SYMBOL;
	t.sym = doSample(&yytext[1],out,NULL);
      }
    }

    o->add(t);
  }

  return o;
}

void doScore(char *name, Bitstream *out, float start, float en, float shift) {
  FILE *fp;
  score_file *sf;
  score_line *sl;
  sample *samp;
  
  sf = new score_file;
  
  if (!(fp = fopen(name,"r")))
	  printf("Couldn't open file.\n");
  else {
	  while (!feof(fp)) {
		  sl = new score_line;
		  
		  if (!get_score_line(sl,fp,&samp)) break;
		  if (samp) {
			  out->putbits(1,1);  /* more bits */
			  out->putbits(3,3); /* sample */
			  samp->put(*out);
		  }
		  /* segment and time-shift */
		  if (sl->time >= start && (en <= start || sl->time < en)) {
			  sl->time += shift;
			  sf->add(sl);
			  sl->has_time = 1;
		  }
	  }
  }
  out->putbits(1,1);  /* more bits */
  out->putbits(1,3);  /* score file */
  sf->put(*out);
}

void dostreamScore(char *name, Bitstream *out, float start, float en, float shift) {
  FILE *fp;
  score_line *sl;
  SA_access_unit *au;
  au_event *event;
  sample *samp;
  
  
  if (!(fp = fopen(name,"r")))
	  printf("Couldn't open file.\n");
  else {
	  while (!feof(fp)) {
		  event = new au_event;

		  event->event_type = 0;

		  sl = &event->score_ev;
		  if (!get_score_line(&event->score_ev,fp,&samp)) break;
		
		  /* segment and time-shift */
		  if (sl->time >= start && (en <= start || sl->time < en)) {
			  sl->time += shift;

			  sl->has_time = 0;
		  }
		  
		  /* add to general "sorted object list" */
		  au = new SA_access_unit;

		  au->num_events = 1;
		  au->dts = sl->time;

		  au->events.push_back(event);
		  
		  if (samp) {
			  au_event *sev = new au_event;
			  au->num_events = 2;

			  sev->event_type = 2; /* sample */
			  sev->samp = *samp;
			  au->events.push_back(sev);
		  }

		  au_list.push(*au);
		  
	  }
  }
}

sa_symbol doSample(char *yytext,Bitstream *out,sample **passback) {
  AIF_STRUCT *aif;
  char buf[65536];
  float fdata[4][1024],scale;
  short data[4][1024];
  long pvb[16];
  long nchan, nbits, srate;
  sample *s;
  char name[20];
  int usechan,ct,tot=0,done=0,i,j;
  static int count = 0;
  
  aif = aifNew();
  
  if (aifOpenRead(aif,yytext))
    printf("Couldn't open file.\n");
  else {
    s = new sample;
    sprintf(name,"_sym_samp_%d",count++);
    s->sample_name_sym = symtab.add(name);
    pvb[0] = AIF_P_CHANNELS;
    pvb[2] = AIF_P_SAMPSIZE;
    pvb[4] = AIF_P_SAMPRATE;
    aifGetParams(aif,pvb,6);
    nchan = pvb[1]; nbits = pvb[3]; srate = (int)*(float *)&pvb[5];
    s->has_srate = 1;
    if (nchan > 1) {
      printf("Sample has %d channels; use which channel (0 = mean)? ",nchan);
      scanf("%d",&usechan);
    } else usechan = 1;
    s->srate = srate;
    s->has_loop = 0;
    s->has_base = 0;
    
     while (!done) {
      ct = aifReadFrames(aif,buf,1024);
      if (ct < 1024) done = 1;
      if (nbits == 32) {
	scale = (double)(2 << (nbits-2));
	 
	s->float_sample = 1;
	for (i=0;i!=nchan;i++)
	  for (j=0;j!=ct;j++)
	    fdata[i][j] = (float)bufval(buf,nchan,nbits,j,i) / scale;

	s->fs_data.reserve(tot+ct);

	for (j=0;j!=ct;j++)
	  if (!usechan) {
	    s->fs_data.push_back(0);
	    for (i=0;i!=nchan;i++)
	      s->fs_data[tot+j] += fdata[i][j];
	    s->fs_data[tot+j] /= nchan;
	  }
	  else s->fs_data.push_back(fdata[usechan-1][j]);
      } else {
	double val;
	
	s->float_sample = 0;
	for (i=0;i!=nchan;i++)
	  for (j=0;j!=ct;j++) {
	    data[i][j] = (short)bufval(buf,nchan,nbits,j,i);
	  }
	s->s_data.reserve(tot+ct);

	for (j=0;j!=ct;j++) {
	  if (!usechan) {
	    val = 0;
	    for (i=0;i!=nchan;i++)
	      val += data[i][j];
	    s->s_data.push_back((short)(val / nchan));
	  }
	  else s->s_data.push_back(data[usechan-1][j]);
	}
      }
      tot += ct;
    }
    s->length = tot;
    printf("Read %d samples.\n",tot); 
  } 
  if (out) {
	  out->putbits(1,1);  /* more bits */
	  out->putbits(3,3); /* sample */
	  s->put(*out);
  }
  else 
	  if (passback) *passback = s;
  return s->sample_name_sym;
}

void doMIDI(char *s, Bitstream *out) {
  FILE *fp;
  midi_file *smf;
  unsigned char c;

  if (!(fp = fopen(s,"rb"))) printf("Couldn't open file.\n");
  else {
    smf = new midi_file;
    
    while (!feof(fp)) {
      c = fgetc(fp);
      if (!feof(fp)) smf->data.push_back(c);
    }

    smf->length = smf->data.size();
    printf("Read %d bytes.\n",smf->data.size());
    out->putbits(1,1);
    out->putbits(2,3);
    smf->put(*out);
  }
}
    
void dostreamMIDI(char *s, Bitstream *out, float start, float en, float offset) {
	FILE *fp;
	midi_msg *m;
	SA_access_unit *au;
	au_event *ev;
	midi_event *midi;
	int i,ct=0;

	if (!(fp = fopen(s,"rb"))) printf("Couldn't open file.\n");
	else {
		while (1) {
			au = new SA_access_unit;
			ev = new au_event;
			midi = &ev->midi_ev;

			m = get_next_event(fp,s);
			if (!m) break;
			
			if (m->t >= start && (en <= start || m->t < en)) {
				au->dts = m->t + offset;
				au->num_events = 1;
				midi->length = m->length;
				for (i=0;i!=m->length;i++)
					midi->data.push_back(m->event[i]);
				free(m);
				ev->event_type = 0x01;
				au->events.push_back(ev);
				
				au_list.push(*au);
				ct++;
			}
		}
	}
	printf("Added %d MIDI events to stream.\n",ct);
}
			



int get_score_line (score_line *sl,FILE *fp, sample **samp) {
	char *s,**words;
	int num,i;
	
	s = getline(fp);
	*samp = NULL;
	num = split(s,&words);
	if (!num) { /* no data */
		return 0;
	}
	sl->priority = 0;
	sl->use_if_late = 0;

	if (num > 2 && (!strcmp(words[1],"control") || !strcmp(words[2],"control"))) {
		control_event *ctrl = new control_event;
		sl->type = 1;
		sl->time = atof(words[0]);
		
		if (!strcmp(words[2],"control")) {
			ctrl->has_label = 1;
			ctrl->label = symtab.add(words[1]);
			ctrl->varsym = symtab.add(words[3]);
			ctrl->value = atof(words[4]);
		}
		else {
			ctrl->has_label = 0;
			ctrl->varsym = symtab.add(words[2]);
			ctrl->value = atof(words[3]);
		}
		sl->control = *ctrl;
	}
	else if (!strcmp(words[1],"tempo")) {
		sl->type = 5;

		tempo_event *tempo = new tempo_event;
		sl->time = atof(words[0]);
		tempo->tempo = atof(words[2]);
		sl->tempo = *tempo;
	}
	else if (!strcmp(words[1],"table")) {
		char *end;
		/* still need to get samples in */
		table_event *table = new table_event;
		sl->type = 2;
		sl->time = atof(words[0]);
		table->tgen = is_builtin(words[3]);
		table->tname = symtab.add(words[2]);
		table->num_pf = num-4;
		table->refers_to_sample = 0;
		table->destroy = 0;
		table->pf = (sa_real *)calloc(sizeof(sa_real),num-4);
		for (i=4;i!=num;i++) {
			table->pf[i-4] = strtod(words[i],&end);
			if (end == words[i]) { /* couldn't get value */
				if (i != 5) 
					printf("Bad numeric value '%s' in score line.\n",words[i]);
				else { /* must be a sample */
					table->refers_to_sample = 1;
					printf("Adding sample '%s'... ",words[i]);
					table->table_sym = doSample(words[i],NULL,samp);
				}
			}
		}

		sl->table = *table;
	}
	else if (!strcmp(words[1],"end")) {
		sl->type = 4;
		sl->time = atof(words[0]);
		end_event *end = new end_event;
		sl->end = *end;
	}
	else { /* must be an instrument event */
		instr_event *instr = new instr_event;
		sl->type = 0;
		
		if (words[0][strlen(words[0])-1] == ':') { /* label */
			instr->has_label = 1;
			words[0][strlen(words[0])-1] = '\0';
			instr->label = symtab.add(words[0]);
			sl->time = atof(words[1]);
			instr->iname_sym = symtab.add(words[2]);
			instr->dur = atof(words[3]);
			instr->num_pf =  num-4;
			for (i=4;i!=num;i++)
				instr->pf[i-4] = atof(words[i]);

		} else {
			instr->has_label = 0;
			sl->time = atof(words[0]);
			instr->iname_sym = symtab.add(words[1]);
			instr->dur = atof(words[2]);
			instr->num_pf =  num-3;
			for (i=3;i!=num;i++)
				instr->pf[i-3] = atof(words[i]);
			
		}
		sl->inst = *instr;
	}
	return 1;
}
	
void doDataBlocks(char *stem, float start, float block_rate) {

		// we want to stream data into the table STEM
		// there should be datafiles called STEM0.DAT, STEM1.DAT, ...
		// for each of these, we make a sample block and a table to contain the
		// sample.

	char fn[40];
	FILE *fp;
	SA_access_unit *au;
	score_line *sl;
	sample *samp;
	au_event *event;
	table_event *t;
	short data[32768], length;
	int ct = 0,fct=0,dct,i;

	sa_symbol sym;

	sym = symtab.add(stem);

	while (1) {  // breaks out using the return statement 4 lines below

		sprintf(fn,"%s%d.dat",stem,fct);

		errno = -1;
		if (!(fp = fopen(fn,"rb"))) { // stop when no more files
				printf("\nRead %d block(s).\n",ct);
				return;
		}


		while (!feof(fp)) {
			if (!fread((void *)&length,1,sizeof(short),fp)) break;

#ifdef __BYTE_COHERENT 
			length = ((length & 0xFF00) >> 8) + ((length & 0x00FF) << 8);
#endif
			// printf("%d ",length);
			
			dct = 0;	
			while (dct < length) { // read data from file #CT
				if (!fread((void *)&(data[dct]),1,sizeof(short),fp)) break;
#ifdef __BYTE_COHERENT
				data[dct] = ((data[dct] & 0xFF00) >> 8) +
											((data[dct] & 0x00FF) << 8);
#endif
				dct++;

			}

			event = new au_event;
			event->event_type = 2;  // sample event
			
			samp = &event->samp;
			samp->sample_name_sym = sym;
			samp->length = length;
			samp->has_srate = 0;
			samp->srate = 0;
			samp->has_loop = 0;
			samp->loopstart = 0;
			samp->loopend = 0;
			samp->has_base = 0;
			samp->basecps = 0;
			samp->float_sample = 0;
			for (i=0;i!=length;i++)
				samp->s_data.push_back(data[i]);
			
			au = new SA_access_unit;  // make a new AU
			au->num_events = 2;  /* the data block, and the table line */
			au->dts = start + ct / block_rate - 1e-3;
			if (au->dts < 0) au->dts = 0;
			au->events.push_back(event);  // put the sample event in the AU
			
			event = new au_event;
			event->event_type = 0; // score line event
			
			sl = &(event->score_ev);
			sl->has_time = 1;
			sl->use_if_late = 0;
			sl->time = au->dts;
			sl->priority = 0;
			sl->type = 2; // table event
			
			t = &sl->table;
			t->tname = sym;
			t->destroy = 0;
			t->tgen = is_builtin("sample");  // use the "sample" ctg
			t->refers_to_sample = 1;
			t->table_sym = sym;
			t->num_pf = 2;
			t->pf = new float [2];
			t->pf[0] = length;  // length
			t->pf[1] = sym.num();  // which
			
			au->events.push_back(event); // and put the score line event in the AU
			
			au_list.push(*au);
			ct++;
		}

		fclose(fp); fct++;
	}
}
		

extern "C" {
	void runtime(char *s) {
		printf(s);
		exit(1);
	}
	
	void schedule_event() { }
}
