/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */
			     
#define AAC 1
#define SA 2
#define CELP 3

typedef char stream_info_header;
typedef char au;

typedef struct au_list_struct {
  struct au_struct *au;
  struct au_list_struct *next;
} au_list;

typedef struct decoder_struct {
  int type;
  int outchan;
  int srate;
  sa_real frame;
  sa_real time;
  int done;
  void (*startup)(struct decoder_struct *,mpeg4_url);
  struct comp_buffer_struct *(*run_frame)(struct decoder_struct *,au_list *);
  void *priv;
  struct decoder_struct *next;
  mpeg4_node *node;
} decoder;

void startup_ac(mpeg4_node *);
void ac_run(mpeg4_node *);
int get_decoder_type (mpeg4_url);
stream_info_header *get_streaminfo(mpeg4_url);
decoder *new_decoder(int);
sa_real **buffer(int, int);
void ac_traverse(mpeg4_node *);
au_list *get_au(decoder *d);

typedef struct comp_buffer_struct {
  sa_real time;
  int length;
  sa_real **buf;
  decoder *d;
  struct comp_buffer_struct *next;
} comp_buffer;

comp_buffer *add_samples_cb(sa_real **buf,decoder *d,sa_real time,int length);
void get_decoder_samples(decoder *d,sa_real **buf,sa_real time);
void free_buf(sa_real **buf, int numchan);
void shift_buf(sa_real **x, int *len, int ct, int numchan);
void add_buf(sa_real **x, sa_real **target, int length, int *start, int numchan);

