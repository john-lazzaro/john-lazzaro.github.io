
/* ISO_HEADER_START */

/*********************************************************************


This software module was originally developed by

  DAniel P.W. Ellis (MIT Media Laboratory)

in the course of development of the MPEG-4 standard.
This software module is an implementation of a part of one or more
MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
of the MPEG-4 standard free license to this software module or
modifications thereof for use in hardware or software products
claiming conformance to MPEG-4.  Those intending to use this software
module in hardware or software products are advised that its use may
infringe existing patents.  The original developer of this software
module and his/her company, the subsequent editors and their
companies, and ISO/IEC have no liability for use of this software
module or modifications thereof in an implementation.  Copyright is
not released for non MPEG-4 conforming products. The MIT Media
Laboratory retains full right to use the code for its own purpose,
assign or donate the code to a third party and to inhibit third
parties from using the code for non MPEG-4 conforming products.  This
copyright notice must be included in all copies or derivative
works. Copyright (c) 1998.

***********************************************************************/

/* ISO_HEADER_END */

/***************************************************************\
*   IEEE80.h							*
*   Convert between "double" and IEEE 80 bit format  		*
*   in machine independent manner.				*
*   Assumes array of char is a continuous region of 8 bit frames*
*   Assumes (unsigned long) has 32 useable bits			*
*   billg, dpwe @media.mit.edu					*
*   01aug91							*
*   19aug91  aldel/dpwe  workaround top bit problem in Ultrix   *
*                        cc's double->ulong cast		*
*   05feb92  dpwe/billg  workaround top bit problem in 		*
*                        THINKC4 + 68881 casting		*
\***************************************************************/

double ieee_80_to_double PARG((unsigned char *p));
void   double_to_ieee_80 PARG((double val, unsigned char *p));
