/* $Log: saol_co_imp.c,v $
 *
 * Revision 1.1 1999/09/15  19:30:00  gzoia
 * Included profiling tool flags
 *
/*********************************************************************
ISO_HEADER_START

This software module was originally developed by

  Eric Scheirer (MIT Media Laboratory)

in the course of development of the MPEG-4 standard.
This software module is an implementation of a part of one or more
MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
of the MPEG-4 standard free license to this software module or
modifications thereof for use in hardware or software products
claiming conformance to MPEG-4.  Those intending to use this software
module in hardware or software products are advised that its use may
infringe existing patents.  The original developer of this software
module and his/her company, the subsequent editors and their
companies, and ISO/IEC have no liability for use of this software
module or modifications thereof in an implementation.  Copyright is
not released for non MPEG-4 conforming products. The MIT Media
Laboratory retains full right to use the code for its own purpose,
assign or donate the code to a third party and to inhibit third
parties from using the code for non MPEG-4 conforming products.  This
copyright notice must be included in all copies or derivative
works. Copyright (c) 1998.

ISO_HEADER_END
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "saol_prec.h"
#include "saol_interp.h"
#include "saol_sched.h"
#include "saol.tab.h"
#ifdef _MPEGPROFILER
  #include "case.h"
#endif

#ifdef _FX_SPEEDC
#include "fx_picola.h"
#else
#include "saol_co_imp.h"
#endif

#ifndef MAX
#define MAX(x,y) (x > y ? x : y)
#endif

#define SGN(x) (x < 0 ? -1 : x == 0 ? 0 : 1)

#ifdef _WIN32
sa_real drand48(void);

sa_real drand48() {
  return((sa_real)rand()/RAND_MAX);
}

#endif

extern sa_real get_table_value(table_storage *t,int idx);
extern int get_table_size(table_storage *t);
extern void set_table_value(table_storage *t, long i, sa_real val);
#ifdef _MPEGPROFILER
extern int grain_factor, grain_afactor;
extern int add_pointer(void *pnt, int bytes);
extern int remove_pointer(void *pnt);
#else
int add_pointer(void *pnt, int bytes) {return 0;}
int remove_pointer(void *pnt) {return 0;}
#endif

/* math functions */

table_storage *co_param_table(actparam *pf,int which) {
  /* get the table which is parameter 'which' of the given context */

  return(pf[which-1].t);
}

sa_real co_param(actparam *pf, int which) {
  /* get the value which is parameter 'which' of the given context */

  return(pf[which-1].val);
}

sa_real interp(sa_decoder *sa,sa_real *buf, int len, sa_real pt,int q) {
  /* no error-checking; guaranteed in-bounds */

  int i;
  sa_real sum = 0,w,g;
  static sa_real *temp = NULL;
  static int maxlen = 0;
  int fl = (int)(floor(pt+0.5)), cl;
  sa_real fr = pt-fl;
  static sa_real pi = (sa_real)3.14159265358979;

  if (fr == 0)  {
#ifdef _MPEGPROFILER
    done_interp = 0;
#endif
    return buf[fl];
  }
    
  g = 0;
    
  fl = fl % len;

  if (sa->all->g->interp) { /* high quality */
	  for (i=-q;i<=q;i++) {	
		  MAC(1); TEST(1); FLOP(25); 
		  w = (sa_real).54 - (sa_real).46*(sa_real)cos(2*pi*(i-fr+q) / (2*q+1));
		  g += w * (sa_real)sin((i - fr) * pi) / ((i - fr) * pi);
	  }
	  
	  for (i=-q;i<=q;i++) {
		  MAC(1); TEST(1); FLOP(29); 
		  w = (sa_real).54 - (sa_real).46*(sa_real)cos(2*pi*(i-fr+q) / (2*q+1));
		  sum += w * (sa_real)sin((i - fr) * pi) / ((i - fr) * pi) * buf[(fl + i + len) % len] / g;
	  }
#ifdef _MPEGPROFILER
	  done_interp = 1;
#endif
	  return sum;
  }

  /* low quality */
  cl = (fl + 1) % len;
#ifdef _MPEGPROFILER
  done_interp = 1;
#endif
  return (1-fr) * buf[fl] + fr * buf[cl];
}

sa_real co_int(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)(int)(x));
}

sa_real co_frac(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return(x - (int)(x));
}

sa_real co_dbamp(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return(90 + 20 * (sa_real)log(x)/(sa_real)log(10));
}

sa_real co_ampdb(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)pow(10,(x-90)/20));
}

sa_real co_abs(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);
#ifdef _MPEGPROFILER
  if(x<0) abs_cs2=1;
#endif
  return((sa_real)fabs(x));
}

sa_real co_sgn(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  if (x < 0) return -1;
  if (x > 0) {
#ifdef _MPEGPROFILER
	  sgn_cs2=1; 
#endif
	  return 1;
  }
  return 0;
}

sa_real co_exp(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  FLOP(5);
  return((sa_real)exp(x));
}

sa_real co_log(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  FLOP(5);
  return((sa_real)log(x));
}

sa_real co_sqrt(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)sqrt(x));
}

sa_real co_sin(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)sin(x));
}

sa_real co_cos(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)cos(x));
}

sa_real co_atan(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)atan(x));
}

sa_real co_pow(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);
  sa_real y = co_param(pf,2);

  FLOP(5);
  return((sa_real)pow(x,y));
}

sa_real co_log10(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)log10(x));
}

sa_real co_asin(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)asin(x));
}

sa_real co_acos(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)acos(x));
}

sa_real co_floor(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  FLOP(5);
  return((sa_real)floor(x));
}

sa_real co_ceil(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  return((sa_real)ceil(x));
}

sa_real co_max(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  int i;
  sa_real max;

  max = pf[0].val;
  for (i=1;i!=pf_ct;i++)
    if (pf[i].val > max) max = pf[i].val;
  
  return(max);

}

sa_real co_min(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  int i;
  sa_real min;

  min = pf[0].val;
  for (i=1;i!=pf_ct;i++)
    if (pf[i].val < min) min = pf[i].val;
  
  return(min);
}


/* pitch converters */
sa_real co_gettune(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  return sa->tuning;
}

sa_real co_settune(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  if (x <= 0)
    runtime(sa,"Global pitch must be positive.");
  sa->tuning = x;
  return x;
}
  
sa_real co_octpch(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real pch = co_param(pf,1);
  int y = (int)pch;
  sa_real z = (sa_real)floor((pch-y)*100) / 100;
  if (z < 0 || z > 0.11) z = 0;

  return y + 100*z / 12;
}

sa_real co_pchoct(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real oct = co_param(pf,1);
  int y = (int)floor(oct);
  sa_real z = (sa_real)floor((oct-y)*12) / 12;

  return(y + 12 * z / 100);
}

sa_real co_cpspch(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real pch = co_param(pf,1);
  int y = (int)floor(pch);
  sa_real z = (sa_real)floor((pch-y)*100+0.5) / 100;
  
  if (z < 0 || z > 0.11) z = 0;
  return(sa->tuning * (sa_real)pow(2.,(y + 100 * z / 12 - 8.75)));  
}

sa_real co_pchcps(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real cps = co_param(pf,1);
  sa_real oct = (sa_real)(log(cps/sa->tuning)/log(2)+8.75);
  int i = (int)floor(oct);
  sa_real frac = (sa_real)floor((oct - i)*12)/12;
  return(i+frac * 12 / 100);
}

sa_real co_cpsoct(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real oct = co_param(pf,1);

  return(sa->tuning * (sa_real)pow(2.,(oct - 8.75)));
}

sa_real co_octcps(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real cps = co_param(pf,1);

  return((sa_real)(log(cps/sa->tuning)/log(2)+8.75));

  
}

sa_real co_pchmidi(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real midi = co_param(pf,1);
  int i = (int)floor((midi-60)/12) + 8;
  sa_real frac = (midi-((i-8)*12+60))/12;

  return(i + frac*12/100);
}

sa_real co_midipch(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real pch = co_param(pf,1);
  int i = (int)floor(pch);
  sa_real frac = pch-i;
  sa_real oct = (i+frac * 100/12);

  return(60 + 12 * (i-8) + (sa_real)floor(frac*100 + 0.5));
}

sa_real co_octmidi(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real midi = co_param(pf,1);

  return((midi-60)/12);
}

sa_real co_midioct(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real oct = co_param(pf,1);
  sa_real k = 12 * (oct - 8) + 60;

  return((sa_real)floor(k+0.5));
}

sa_real co_cpsmidi(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  FLOP(4);  MR(1);
  return(sa->tuning * (sa_real)pow(1.0594631,(x-69.0)));
}

sa_real co_midicps(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real cps = co_param(pf,1);

  return((sa_real)floor(log(cps/sa->tuning)/log(2) * 12 + 69));
}


/* table operations */
sa_real co_ftlen(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);

  TR(1);
  if (!t)
    runtime(sa,"Table not created yet in ftlen().");
  return((sa_real)get_table_size(t));
}

sa_real co_ftloop(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);

  if (!t)
    runtime(sa,"Table not created yet in ftloop().");

  return((sa_real)t->loop);
}

sa_real co_ftloopend(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);

  if (!t)
    runtime(sa,"Table not created yet in ftloop().");

  return((sa_real)t->loopend);
}

sa_real co_ftsr(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);

  if (!t)
    runtime(sa,"Table not created yet in ftloop().");

  return((sa_real)t->srate);
}

sa_real co_ftsetloop(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);
  sa_real x = co_param(pf,2);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by ftsetloop().");
  
  if (x < 0 || x > get_table_size(t)) 
    runtime(sa,"Loop start out of bounds in ftsetloop().");
  t->loop = (long)floor(x + 0.5);
  
  return(x);
}

sa_real co_ftsetend(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);
  sa_real x = co_param(pf,2);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by ftsetend().");
  
  if (x < 0 || x > get_table_size(t)) 
    runtime(sa,"Loop end out of bounds in ftsetloop().");
  t->loopend = (long)floor(x + 0.5);
  
  return(x);
}

sa_real co_ftsetbase(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);
  sa_real x = co_param(pf,2);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by ftsetbase().");
  
  if (x <= 0)
    runtime(sa,"Base frequency must be positive in ftsetbase().");
  t->base = x;
  
  return(x);
}

sa_real co_ftsetsr(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);
  sa_real x = co_param(pf,2);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by ftsetsr().");
  
  if (x <= 0)
    runtime(sa,"Sampling rate must be positive in ftsetsr().");
  
  t->srate = (int)x;
  
  return(x);
}  

sa_real co_ftbasecps(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by ftbasecps().");
  
  return(t->base);
}

sa_real co_tableread(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);
  sa_real idx = co_param(pf,2);
  char s[800];

  TEST(2); TR(1);
  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by tableread().");
  if (idx >= get_table_size(t) || idx < 0) {
    sprintf(s,"tableread out of bounds (index = %.2f, length = %d)",idx,get_table_size(t));
    runtime(sa,s);
  }

  return(interp(sa,t->d,get_table_size(t),idx,sa->interp_q));
}

sa_real co_tablewrite(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *t = co_param_table(pf,1);
  sa_real idx = co_param(pf,2);
  sa_real val = co_param(pf,3);
  long i;
  char s[800];

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by tablewrite().");
  
  FLOP(1); 
  i = (long)(idx + 0.5);	/* round */

  TR(1); TEST(1); 
  if (i >= get_table_size(t)) {
    sprintf(s,"tableread out of bounds (index = %.2f, length = %d)",idx,get_table_size(t));
    runtime(sa,s);
  }

  TW(1); 
  set_table_value(t,i,val);

  return 0;
   
}



sa_real co_oscil(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  oscil_storage *local;
  table_storage *t = co_param_table(pf,1);
  sa_real freq = co_param(pf,2);
  sa_real loops;
  sa_real idx;
  long fl,cl;

  TEST(1);
  if (pf_ct < 3) 
    loops = -1;
  else loops = co_param(pf,3);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by oscil().");
  
  if (!(local = (oscil_storage *)op->local)) {
    PROT_MAL_CO(oscil_storage);
    local = (oscil_storage *)op->local;
    MW(2); TEST(1); 
    local->ph = 0; /* start at 0 phase */
    local->loops = 0;
  }

  TEST(1); 
  if (local->loops == loops)
    return 0;

  TEST(1); 
  if (rate == ASIG) {

    FLOP(1); TR(1); 
    idx = local->ph * get_table_size(t);
    fl = (long)floor(idx);
    cl = (long)ceil(idx);

    MR(1); FLOP(1); MAC(1); MW(1); 
    local->ph += freq/(sa_real)sa->all->g->srate;

    TEST(1); 
    if (local->ph >= 1) {
#ifdef _MPEGPROFILER
      oscil_cs2 = 1;
#endif
      FLOP(2); MR(2); MW(2); 
      local->loops++;
      local->ph = local->ph - (int)local->ph;
    }
    TEST(1);
    if (local->ph < 0) {
#ifdef _MPEGPROFILER
      oscil_cs2 = 1;
#endif
      FLOP(1); MR(2); MW(2);
      local->loops++;
      local->ph = local->ph - (int)local->ph + 1;
    }

    TEST(1);
  
	return(interp(sa,t->d,get_table_size(t),idx,sa->interp_q));
  }
  else return 0;
} 

sa_real co_koscil(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  koscil_storage *local;
  table_storage *t = co_param_table(pf,1);
  sa_real freq = co_param(pf,2);
  sa_real loops;
  sa_real idx, x1, x2;
  long fl,cl;

  TEST(1);
  if (pf_ct < 3)
    loops = -1;
  else loops = co_param(pf,3);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by koscil().");

  TEST(1);
  if (!(local = (koscil_storage *)op->local)) {
    PROT_MAL_CO(koscil_storage);
    local = (koscil_storage *)op->local;
    MW(2);
    local->ph = 0; /* start at 0 phase */
    local->loops = 0;
  }

  TEST(1);
  if (local->loops == loops)
    return 0;
  
  MR(1); TR(1); FLOP(3);
  idx = local->ph * get_table_size(t);
  fl = (long)floor(idx);
  cl = (long)ceil(idx);

  TR(1);
  x1 = get_table_value(t,fl);

  TR(2); TEST(1);
  if (cl < get_table_size(t))
    x2 = get_table_value(t,cl);
  else
    x2 = get_table_value(t,0);

  TEST(1);
  if (rate == KSIG) {
    FLOP(2); MW(1); 
    local->ph += freq/sa->all->g->krate;
    TEST(1); MR(1); 
    if (local->ph >= 1) {
      MR(2); FLOP(2); MW(2); 
      local->loops++;
      local->ph = local->ph - (int)local->ph;
#ifdef _MPEGPROFILER
      koscil_cs2=1;
#endif
    }
  }
  TEST(1); 
  if (cl == fl)
    return(x1);
  else {
    FLOP(6); 
	return(interp(sa,t->d,get_table_size(t),idx,sa->interp_q));
  }
} 

sa_real co_loscil(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  loscil_storage *local;
  table_storage *t = co_param_table(pf,1);
  sa_real freq = co_param(pf,2);
  sa_real basecps = co_param(pf,3);
  sa_real loopstart = co_param(pf,4);
  sa_real loopend = co_param(pf,5);
  sa_real val;
  
  TEST(7); TR(3);

  if (!loopend || pf_ct < 5) loopend = (sa_real)t->loopend;
  if (!loopstart || pf_ct < 4) loopstart = (sa_real)t->loop;
  if (!basecps || pf_ct < 3) basecps = (sa_real)t->base;
  if (!basecps)
    runtime(sa,"Must provide base CPS for table in loscil.");

  TEST(1);

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by loscil().");
  
  if (!(local = (loscil_storage *)op->local)) {
    PROT_MAL_CO(loscil_storage);
    local = (loscil_storage *)op->local;
    local->idx = 0;
  }

   
  TEST(3); MR(2); TR(1);
  if ((loopend && local->idx >= loopend) ||
      local->idx >= get_table_size(t)) {
    MW(1);
    local->idx = loopstart;
#ifdef _MPEGPROFILER
    loscil_cs2=1;
#endif
  }
 
  MR(2); TR(2);

  val = interp(sa,t->d,get_table_size(t),local->idx,sa->interp_q);
  
  if (rate == ASIG) {
    MAC(1); FLOP(2); TR(1); MR(2); MW(1);
    local->idx += (sa_real)t->srate/(sa_real)sa->all->g->srate * freq / basecps;
  }

  return(val);

}

sa_real co_doscil(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  doscil_storage *local;
  table_storage *t = co_param_table(pf,1);
  sa_real x1, x2;
  long fl,cl;
  
  if (!(local = (doscil_storage *)op->local)) {
    PROT_MAL_CO(doscil_storage);
    local = (doscil_storage *)op->local;
    local->idx = 0;
  }

  if (local->idx + (sa_real)t->srate/(sa_real)sa->all->g->srate >= get_table_size(t))
    return 0;
  
  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by doscil().");
  
  fl = (long)floor(local->idx);
  cl = (long)ceil(local->idx);
  x1 = get_table_value(t,fl);
  
  if (cl < get_table_size(t))
    x2 = get_table_value(t,cl);
  else
    x2 = get_table_value(t,0);

  if (rate == ASIG)
    local->idx += (sa_real)t->srate/(sa_real)sa->all->g->srate;

  if (cl == fl)
    return(x1);
  else
	return(interp(sa,t->d,get_table_size(t),local->idx,sa->interp_q));
}


/* signal generators */

sa_real co_kline(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  kline_storage *local;
 
  sa_real x1= co_param(pf,1);
  sa_real dur1 = co_param(pf,2);
  sa_real x2 = co_param(pf,3);
  if (!(local = (kline_storage *)op->local)) {
    PROT_MAL(op->local,kline_storage,co_kline);
    local = (kline_storage *)op->local;
    local->left = x1;
    local->right = x2;
    local->dur = dur1;
    local->varargs_pos = 3;
    local->durtime = 0;
    local->done = 0;
    MW(6);
  }

  if (local->done) return local->right;
  TEST(2);
  if (rate == KSIG) {
    TEST(1);
    while (local->durtime >= local->dur) { /* need 'while' for 0 durations */
      TEST(1);
      if (local->varargs_pos < pf_ct) { /* varargs */
			MW(6); MR(4); TEST(1); FLOP(2);
			local->left = local->right;
			local->dur = pf[local->varargs_pos].val;
			if (++local->varargs_pos == pf_ct)
	  			runtime(sa,"Missing final value in call to 'kline'.");
	  		local->right = pf[local->varargs_pos].val;
			local->varargs_pos++;
			local->durtime = 0;
#ifdef _MPEGPROFILER
			line_cs2 = 1;
#endif
      }
      else {
			local->done = 1;
			return 0;
      }
    }

    FLOP(2); MW(1);
    local->durtime += 1/(sa_real)sa->all->g->krate;
  }
  FLOP(4); MR(4);
  return((local->right-local->left) * (local->durtime)/local->dur + local->left);
}

sa_real co_aline(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  aline_storage *local;

  sa_real x1= co_param(pf,1);
  sa_real dur1 = co_param(pf,2);
  sa_real x2 = co_param(pf,3);

  TEST(1);
  if (!(local = (aline_storage *)op->local)) {
    PROT_MAL(op->local,aline_storage,co_aline);
    local = (aline_storage *)op->local;
    MW(6);
    local->left = x1;
    local->right = x2;
    local->dur = dur1;
    local->varargs_pos = 3;
    local->durtime = 0;
    local->done = 0;
  }

  if (local->done) return 0;
  TEST(2);
  if (rate == ASIG) {
    TEST(1);
    while (local->durtime >= local->dur) { /* need 'while' for 0 durations */
      TEST(1);
      if (local->varargs_pos < pf_ct ) {
			MR(1); MW(1);
			local->left = local->right;
			MR(1); MR(1);
			local->dur = pf[local->varargs_pos].val;
			FLOP(1); MR(1); MW(1); TEST(1);
			if (++local->varargs_pos == pf_ct)
	  			runtime(sa,"Missing final value in call to 'aline'.");
			MR(2); MW(1);
			local->right = pf[local->varargs_pos].val;

			MR(1); FLOP(1);
			local->varargs_pos++;
			MW(2);
			local->durtime = 0;
#ifdef _MPEGPROFILER
			line_cs2 = 1;
#endif
      }
      else {
			MW(1);
			local->done = 1;
			return 0;
      }
    }

    MW(1); FLOP(2);
    local->durtime += 1/(sa_real)sa->all->g->srate;
  }
  FLOP(4); MR(4);
  return((local->right-local->left) * (local->durtime)/local->dur + local->left);
}

sa_real co_kexpon(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  kexpon_storage *local;

  sa_real x1= co_param(pf,1);
  sa_real dur1 = co_param(pf,2);
  sa_real x2 = co_param(pf,3);

  if (!(local = (kexpon_storage *)op->local)) {
    PROT_MAL(op->local,kexpon_storage,co_kexpon);
    local = (kexpon_storage *)op->local;
    local->left = x1;
    local->right = x2;
    local->dur = dur1;
    local->varargs_pos = 3;
    local->durtime = 0;
    local->done = 0;
  }

  if (local->done) return local->right;
  
  while (local->durtime >= local->dur) { /* need 'while' for 0 durations */
    if (local->varargs_pos < pf_ct) {
      local->left = local->right;
      local->dur = pf[local->varargs_pos].val;
      if (++local->varargs_pos == pf_ct)
			runtime(sa,"Missing final value in call to 'kexpon'.");
      local->right = pf[local->varargs_pos].val;
      if (local->left == 0 || local->right == 0)
      	runtime(sa,"x values to aexpon cannot be zero.");
      if (local->left * local->right < 0)
         runtime(sa,"x values to kexpon must have same sign.");
      local->varargs_pos++;
      local->durtime = 0;
#ifdef _MPEGPROFILER
      expon_cs2 = 1;
#endif
    }
    else {
      local->done = 1;
      return 0;
    }
  }

  if (rate == KSIG) local->durtime += 1/(sa_real)sa->all->g->krate;
  return((sa_real)local->left * 
					(sa_real)pow(local->right/local->left,local->durtime/local->dur));
}

sa_real co_aexpon(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  aexpon_storage *local;

  sa_real x1= co_param(pf,1);
  sa_real dur1 = co_param(pf,2);
  sa_real x2 = co_param(pf,3);

  if (!(local = (aexpon_storage *)op->local)) {
    PROT_MAL(op->local,aexpon_storage,co_aexpon);
    local = (aexpon_storage *)op->local;
    local->left = x1;
    local->right = x2;
    local->dur = dur1;
    local->varargs_pos = 3;
    local->durtime = 0;
    local->done = 0;
  }

  if (local->done) return 0;
  
  while (local->durtime >= local->dur) { /* need 'while' for 0 durations */
    if (local->varargs_pos < pf_ct) {
      local->left = local->right;
      local->dur = pf[local->varargs_pos].val;
      if (++local->varargs_pos == pf_ct)
			runtime(sa,"Missing final value in call to 'aexpon'.");
      local->right = pf[local->varargs_pos].val;
      if (local->left == 0 || local->right == 0)
         runtime(sa,"x values to aexpon cannot be zero.");
      if (local->left * local->right < 0)
         runtime(sa,"x values to kexpon must have same sign.");
      local->varargs_pos++;
      local->durtime = 0;
#ifdef _MPEGPROFILER
      expon_cs2 = 1;
#endif
    }
    else {
      local->done = 1;
      return 0;
    }
  }

  if (rate == ASIG) local->durtime += 1/(sa_real)sa->all->g->srate;
  return((sa_real)local->left * 
					(sa_real)pow(local->right/local->left,local->durtime/local->dur));
}

sa_real co_kphasor(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  kphasor_storage *local;
  sa_real freq = co_param(pf,1);
  sa_real old;

  if (!(local = (kphasor_storage *)op->local)) {
    PROT_MAL_CO(kphasor_storage);
    local = (kphasor_storage *)op->local;
    local->ph = 0; /* start at 0 phase */
  }

  old = local->ph;
  if (rate == KSIG) local->ph += freq/(sa_real)sa->all->g->srate;
  if (local->ph >= 1) {
    local->ph = local->ph - (int)local->ph;
#ifdef _MPEGPROFILER
    phasor_cs2 = 1;
#endif
  }

  return(old);
}

sa_real co_aphasor(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  aphasor_storage *local;
  sa_real freq = co_param(pf,1),old;

  if (!(local = (aphasor_storage *)op->local)) {
    PROT_MAL_CO(aphasor_storage);
    local = (aphasor_storage *)op->local;
    local->ph = 0; /* start at 0 phase */
  }

  old = local->ph;
  
  if (rate == ASIG) local->ph += freq/(sa_real)sa->all->g->srate;
  while (local->ph >= 1) {
    local->ph = local->ph - (int)local->ph;
#ifdef _MPEGPROFILER
    phasor_cs2 = 1;
#endif
  }

  return(old);
}

sa_real co_pluck(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real cps = co_param(pf,1);
  sa_real buflen = co_param(pf,2);
  table_storage *init = co_param_table(pf,3);
  sa_real atten = co_param(pf,4);
  sa_real smrate = co_param(pf,5);
  pluck_storage *local;
  long ilen;
  sa_real s;
  int i,j;
  ilen = (int)(buflen + 0.5);

  if (!init)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by pluck().");
  
  if (!(local = (pluck_storage *)op->local)) {
    if (ilen <= 0) 
      runtime(sa,"Buffer length must be positive for pluck().");
    
    PROT_MAL_CO(pluck_storage);
    local = (pluck_storage *)op->local;
    op->dyn = (sa_real *)malloc(ilen * 2 * sizeof(sa_real));
    add_pointer(op->dyn, ilen * 2 * sizeof(float));
    /* holds both the main buffer and the new buffer */
    local->buf = op->dyn;
    local->newbuf = ((sa_real *)op->dyn) + ilen;
    for (i=0;i!=ilen;i++) local->buf[i] = get_table_value(init,i % get_table_size(init));
    local->ph = 0;
    local->ct = 0;
  }

  if (rate == ASIG) {
    if (++local->ct >= smrate) {
      local->ct = 0;
      
      for (i=0;i!=ilen;i++) {
			s = 0;
			for (j=-2;j<=2;j++)
	  			s += local->buf[(i+j+ilen) % ilen];
			local->newbuf[i] = atten * s/5;
      }
      for (i=0;i!=ilen;i++) local->buf[i] = local->newbuf[i];
#ifdef _MPEGPROFILER
      pluck_cs2=1;
#endif
    }
    local->ph += cps / (sa_real)sa->all->g->srate;
    if (local->ph < 0 || local->ph >= 1) {
    	local->ph -= (sa_real)floor(local->ph);
#ifdef _MPEGPROFILER
		pluck_cs3=1;
#endif
    }
  }

  return(interp(sa,local->buf,ilen,local->ph * ilen,sa->interp_q));
	 
}

sa_real co_buzz(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real cps = co_param(pf,1);
  sa_real nharm = co_param(pf,2);
  sa_real lowharm = co_param(pf,3);
  sa_real rolloff = co_param(pf,4);
  sa_real scale;
  
  buzz_storage *local;
  int i;
  sa_real out=0,att;

  TEST(1);
  if (!(local = (buzz_storage *)op->local)) {
    PROT_MAL(op->local,buzz_storage,co_buzz);
    local = (buzz_storage *)op->local;
    MW(1);
    local->ph = 0; /* start at 0 phase */
  }

  TEST(1);
  if (rate == ASIG) {
    TEST(1);
    if (nharm <= 0) {			/* use nyquist */
      FLOP(5);
      nharm = (sa_real)floor((sa_real)sa->all->g->srate/2 / cps) - (lowharm-1);
    }
    FLOP(7);
    scale = (sa_real)(1-fabs(rolloff)) / (sa_real)(1-fabs(pow(rolloff,nharm)));
    out = 0;
    att = 1;
    for (i=(int)(lowharm+0.5);i<=nharm+lowharm-1;i++) {
      TEST(1); FLOP(3);
      out += (sa_real)cos(2 * PI * local->ph * (i+1)) * att * scale;
      FLOP(9); MAC(1);
      att *= rolloff;
      MR(1); FLOP(1); MW(1);
    }

    MW(1); FLOP(1); MR(1);
    local->ph += cps/(sa_real)sa->all->g->srate;
    TEST(1);
    if (local->ph > 1) {
      local->ph -= (int)local->ph;
#ifdef _MPEGPROFILER
      buzz_cs2 = 1;
#endif
      FLOP(1); MR(1); MW(1);
    }
		
  }

  return(out);
}

typedef struct grain_data_struct {
  sa_real freq, amp, dur, time, ph;
  int used;
} grain_data;

sa_real co_grain(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *wave = co_param_table(pf,1);
  table_storage *env = co_param_table(pf,2);
  sa_real density = co_param(pf,3);
  sa_real freq = co_param(pf,4);
  sa_real amp = co_param(pf,5);
  sa_real dur = co_param(pf,6);
  sa_real time = co_param(pf,7);
  sa_real phase = co_param(pf,8);

  grain_storage *local;
  grain_data *grains;
  int i;
  sa_real out;

  if (!wave || !env)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by grain().");
  
  if (!(local = (grain_storage *)op->local)) {
    PROT_MAL(op->local,grain_storage,co_grain);  
    local = (grain_storage *)op->local;
    local->dens_time = 0; 
    local->numg = local->glength = 0;
    local->new_grain_time = 0;
    op->dyn = NULL;
  }
  grains = (grain_data *)op->dyn;
  
  if (rate == ASIG) {
    local->dens_time += (sa_real)1./sa->all->g->srate;
    if (local->dens_time >= 1/density) {
      local->dens_time = 0;
#ifdef _MPEGPROFILER
      grain_cs2=1;
#endif
      if (time >= 0 && time < 1/density)
      	local->new_grain_time = time;
      else
			local->new_grain_time = 0;
    }
    
    if (local->new_grain_time > 0) {
#ifdef _MPEGPROFILER
		grain_cs3=1;
#endif
      local->new_grain_time -= (sa_real)1./sa->all->g->srate;
      if (local->new_grain_time <= 0) { /* time for a new grain */
#ifdef _MPEGPROFILER
		  grain_cs4=1;
#endif
		  if (local->numg == local->glength) { /* have to add storage */
	         if(op->dyn)
            	remove_pointer(op->dyn);
			 op->dyn = (void *)realloc(op->dyn,(local->glength+1) * sizeof(grain_data));
			 add_pointer(op->dyn, (local->glength+1)*5*sizeof(float));
			 grains = (grain_data *)op->dyn;
			 grains[local->glength].used = 0;	
			 local->glength++;
		  }
		 for (i=0;grains[i].used;i++);
         grains[i].freq = freq;
         grains[i].amp = amp;
         grains[i].dur = dur;
         grains[i].time = 0;
         grains[i].ph = phase;
         local->numg++;
         grains[i].used = 1;
         local->new_grain_time = -1;
      }
    }

    /* now synth */
    out = 0;
#ifdef _MPEGPROFILER
    grain_factor=grain_afactor=0;
#endif
    for (i=0;i!=local->glength;i++)
		if (grains[i].used) {
#ifdef _MPEGPROFILER
      		grain_factor++;
#endif
			out += interp(sa,wave->d,get_table_size(wave),grains[i].ph*wave->size,
				sa->interp_q) *
				get_table_value(env,(int)(grains[i].time/grains[i].dur * env->size)) *
				grains[i].amp;
			if (wave->srate && wave->base) {
				grains[i].ph += (sa_real)wave->srate/(sa_real)sa->all->g->srate * grains[i].freq / wave->base;
#ifdef _MPEGPROFILER
				grain_cs5=1;
#endif
			} else if (wave->srate) {
				grains[i].ph += (sa_real)wave->srate/(sa_real)sa->all->g->srate/(sa_real)wave->size;
#ifdef _MPEGPROFILER
				grain_cs6=1;
#endif
			} else {
         	grains[i].ph += grains[i].freq / sa->all->g->srate;
#ifdef _MPEGPROFILER
			grain_cs7=1;
#endif
         }
			if (grains[i].ph >= 1) {
				grains[i].ph = grains[i].ph - (int)grains[i].ph;
#ifdef _MPEGPROFILER
				grain_cs5a = grain_cs7a = 1;
				grain_afactor++;
#endif
         }
			if (grains[i].ph < 0)  {
				grains[i].ph = 1 + grains[i].ph - (int)grains[i].ph;
#ifdef _MPEGPROFILER
				grain_cs5a = grain_cs7a = 1;
				grain_afactor++;
#endif
         }
			grains[i].time += (sa_real)1./sa->all->g->srate;
			if (grains[i].time >= grains[i].dur) { /* this grain's done */
				grains[i].used = 0;
				local->numg--;
			}
		}
  }
  return(out);
}

/* noise generators */

sa_real co_irand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real amp = co_param(pf,1);

  return (drand48() - (sa_real)0.5) * 2 * amp;
}

sa_real co_krand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real amp = co_param(pf,1);

  FLOP(8);
  return (drand48() - (sa_real)0.5) * 2 * amp;
}

sa_real co_arand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real amp = co_param(pf,1);

  FLOP(8);  /* 5 for drand48() */
  return (drand48() - (sa_real)0.5) * 2 * amp;
}

sa_real co_ilinrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real min = co_param(pf,1);
  sa_real max = co_param(pf,2);

  sa_real x,y;
  x = (sa_real)drand48();
  y = (sa_real)drand48();

  return (MAX(x,y)) * (max-min) + min;
  
}

sa_real co_klinrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real min = co_param(pf,1);
  sa_real max = co_param(pf,2);

  sa_real x,y;
  FLOP(10);
  
  x = (sa_real)drand48();
  y = (sa_real)drand48();

  TEST(1); FLOP(1); MAC(1);
  return (MAX(x,y)) * (max-min) + min;
}

sa_real co_alinrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real min = co_param(pf,1);
  sa_real max = co_param(pf,2);

  sa_real x,y;
  x = (sa_real)drand48();
  y = (sa_real)drand48();

  return (MAX(x,y)) * (max-min) + min;
}

sa_real co_iexprand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);

  sa_real x;
  x = (sa_real)drand48();

  return(-(sa_real)log(x)*mean);
}

sa_real co_kexprand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);

  sa_real x;
  x = (sa_real)drand48();

  return(-(sa_real)log(x)*mean);
}

sa_real co_aexprand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);

  sa_real x;
  x = (sa_real)drand48();

  return(-(sa_real)log(x)*mean);
}

sa_real co_kpoissonrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);
  kpoissonrand_storage *local;

  if (!(local = (kpoissonrand_storage *)op->local)) {
    PROT_MAL(op->local,kpoissonrand_storage,co_kpoissonrand);
    local = (kpoissonrand_storage *)op->local;
    local->wait = (int)floor(-log(drand48()) * mean *
			     (sa_real)sa->all->g->srate/(sa_real)sa->all->g->krate + 1);
  }

  if (rate == KSIG) local->wait--;
  if (!local->wait) {
    local->wait = (int)floor(-log(drand48()) * mean *
			     (sa_real)sa->all->g->srate/(sa_real)sa->all->g->krate + 1);
#ifdef _MPEGPROFILER
    poiss_cs2=1;
#endif
    return 1;
  }
  return 0;
}

sa_real co_apoissonrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);
  apoissonrand_storage *local;

  if (!(local = (apoissonrand_storage *)op->local)) {
    PROT_MAL(op->local,apoissonrand_storage,co_apoissonrand);
    local = (apoissonrand_storage *)op->local;
    local->wait = (int)floor(-log(drand48()) * mean * (sa_real)sa->all->g->srate + 1);
  }

  if (rate == ASIG) local->wait--;
  if (!local->wait) {
    local->wait = (int)floor(-log(drand48()) * mean * (sa_real)sa->all->g->srate + 1);
#ifdef _MPEGPROFILER
    poiss_cs2=1;
#endif
    return 1;
  }
  return 0;
}

sa_real co_igaussrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);
  sa_real var = co_param(pf,2);
  sa_real x,y;

  /* Box-Muller method: see Num. Rec. pg 289 */

  x = drand48();
  y = drand48();

  return((sa_real)(sqrt(-2 * log(x)) * cos(2 * PI * y) * sqrt(var) + mean));
  
}

sa_real co_kgaussrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);
  sa_real var = co_param(pf,2);
  sa_real x,y;

  /* Box-Muller method: see Num. Rec. pg 289 */

  x = drand48();
  y = drand48();

  return((sa_real)(sqrt(-2 * log(x)) * cos(2 * PI * y) * sqrt(var) + mean));
}

sa_real co_agaussrand(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real mean = co_param(pf,1);
  sa_real var = co_param(pf,2);
  sa_real x,y;

  /* Box-Muller method: see Num. Rec. pg 289 */

  x = drand48();
  y = drand48();

  return((sa_real)(sqrt(-2 * log(x)) * cos(2 * PI * y) * sqrt(var) + mean));
}


/* filters */

sa_real co_port(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real ctrl = co_param(pf,1);
  real htime = co_param(pf,2);
  port_storage *local;

  if (!(local = (port_storage *)op->local)) {
    PROT_MAL(op->local,port_storage,co_port);
    local = (port_storage *)op->local;

    local->cur = ctrl;
    local->old = ctrl;
    local->newx = ctrl;
    local->time = 0;
  }

  if (ctrl != local->newx) {
    /* if (!ctrl || SGN(ctrl) != SGN(local->cur))
       runtime(sa,"Bad ctrl value in port().\n"); */
    local->old = local->cur;
    local->newx = ctrl;
    local->time = 0;
#ifdef _MPEGPROFILER
    port_cs2 = 1;
#endif
  }

  if (local->cur == local->newx)
    return local->cur;

#ifdef _MPEGPROFILER
  port_cs3 = 1;
#endif
  local->time += (sa_real)1.0/sa->all->g->krate;
  local->cur = local->old + (local->newx - local->old) * (1-(sa_real)pow(2,-local->time / htime));
  return local->cur;
}

sa_real co_hipass(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  real cut = co_param(pf,2);
  hipass_storage *local;
  real c,out;

  if (!(local = (hipass_storage *)op->local)) {
    PROT_MAL(op->local,hipass_storage,co_hipass);
    local = (hipass_storage *)op->local;

    local->oldcut = -1;
    local->a1 = local->a2 = local->a0 = 0;
    local->b1 = local->b2 = local->b0 = 0;
    local->d1 = 0;
    local->d2 = 0;
  }

  if (local->oldcut != cut) {	/* move filter */
    local->oldcut = cut;
    c = (sa_real)tan(PI * cut / (sa_real)sa->all->g->srate);
    local->b0 = 1 / (1 + (sa_real)sqrt(2.0) * c + c * c);
    local->b1 = -2 * local->b0;
    local->b2 = local->b0;
    local->a0 = 1;
    local->a1 = 2 * (c * c - 1) * local->b0;
    local->a2 = (1 - (sa_real)sqrt(2.0) * c + c * c) * local->b0;
  }

  out = input * local->b0 + local->d2;

  if (rate == ASIG) {
    local->d2 = local->d1 - local->a1 * out + local->b1 * input;
    local->d1 = -local->a2 * out + local->b2 * input;
  }
  
  return(out);
}

sa_real co_lopass(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  real cut = co_param(pf,2);
  lopass_storage *local;
  real c,out;

  TEST(2);
  if (!(local = (lopass_storage *)op->local)) {
    PROT_MAL(op->local,lopass_storage,co_lopass);
    local = (lopass_storage *)op->local;

    MW(9);
    local->oldcut = -1;
    local->a1 = local->a2 = local->a0 = 0;
    local->b1 = local->b2 = local->b0 = 0;
    local->d1 = 0;
    local->d2 = 0;
  }

  MR(1); TEST(1);
  if (local->oldcut != cut) {	/* move filter */
    MW(1);
    local->oldcut = cut;
    FLOP(8); MR(1);
    c = 1/(sa_real)tan(PI * cut / (sa_real)sa->all->g->srate);
    FLOP(9);
    local->b0 = 1 / (1 + (sa_real)sqrt(2.0) * c + c * c);
    FLOP(1);
    local->b1 = 2 * local->b0;
    local->b2 = local->b0;
    local->a0 = 1;
    FLOP(4);
    local->a1 = 2 * (1 - c * c) * local->b0;
    FLOP(10);
    local->a2 = (1 - (sa_real)sqrt(2.0) * c + c * c) * local->b0;
    MR(4); MW(6);
  }

  FLOP(2); MR(2);
  out = input * local->b0 + local->d2;

  TEST(1);
  if (rate == ASIG) {
    MW(2); MR(5); FLOP(8);
    local->d2 = local->d1 - local->a1 * out + local->b1 * input;
    local->d1 = -local->a2 * out + local->b2 * input; 
  }

  return(out);
}


sa_real co_bandpass(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  real cf = co_param(pf,2);
  real bw = co_param(pf,3);
  bandpass_storage *local;
  real c,d,out;

  TEST(1);
  if (!(local = (bandpass_storage *)op->local)) {
    PROT_MAL(op->local,bandpass_storage,co_bandpass);
    local = (bandpass_storage *)op->local;
    
    MW(10);
    local->oldcf = -1;
    local->oldbw = -1;
    local->a1 = local->a2 = local->a0 = 0;
    local->b1 = local->b2 = local->b0 = 0;
    local->d1 = 0;
    local->d2 = 0;
  }

  TEST(2);
  if (local->oldcf != cf || local->oldbw != bw) { /* move filter */
    MW(2);
    local->oldcf = cf;
    local->oldbw = bw;

    FLOP(7);
    c = 1/(sa_real)tan(PI * bw / (sa_real)sa->all->g->srate);
    FLOP(8);
    d = 2 * (sa_real)cos(2*PI*cf/(sa_real)sa->all->g->srate);
    MW(1); FLOP(2);
    local->b0 = 1 / (1 + c);
    MW(1);
    local->b1 = 0;
    MW(1); FLOP(1);
    local->b2 = -local->b0;
    MW(1);
    local->a0 = 1;
    MW(1); FLOP(3); MR(1);
    local->a1 = -c * d * local->b0;
    MW(1); FLOP(3); MR(1);
    local->a2 = (c - 1) * local->b0;
  }
  MR(2); FLOP(2);
  out = input * local->b0 + local->d2;

  if (rate == ASIG) {
    MR(3); MAC(2); MW(1);
    local->d2 = local->d1 - local->a1 * out + local->b1 * input;
    FLOP(1); MAC(2); MW(1);
    local->d1 = -local->a2 * out + local->b2 * input;
  }

  return(out);
}

sa_real co_bandstop(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  real cf = co_param(pf,2);
  real bw = co_param(pf,3);
  bandstop_storage *local;
  real c,d,out;

  if (!(local = (bandstop_storage *)op->local)) {
    PROT_MAL(op->local,bandstop_storage,co_bandstop);
    local = (bandstop_storage *)op->local;

    local->oldcf = -1;
    local->oldbw = -1;
    local->a1 = local->a2 = local->a0 = 0;
    local->b1 = local->b2 = local->b0 = 0;
    local->d1 = 0;
    local->d2 = 0;
  }

  if (local->oldcf != cf || local->oldbw != bw) { /* move filter */
    local->oldcf = cf;
    local->oldbw = bw;
    c = (sa_real)tan(PI * bw / (sa_real)sa->all->g->srate);
    d = 2 * (sa_real)cos(2*PI*cf/(sa_real)sa->all->g->srate);
    local->b0 = 1 / (1 + c);
    local->b1 = -d * local->b0;
    local->b2 = local->b0;
    local->a0 = 1;
    local->a1 = local->b1;
    local->a2 = (1 - c) * local->b0;
  }
  out = input * local->b0 + local->d2;

  if (rate == ASIG) {
    local->d2 = local->d1 - local->a1 * out + local->b1 * input;
    local->d1 = -local->a2 * out + local->b2 * input;
  }

  
  return(out);
}

sa_real co_biquad(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  real b0 = co_param(pf,2);
  real b1 = co_param(pf,3);
  real b2 = co_param(pf,4);
  real a1 = co_param(pf,5);
  real a2 = co_param(pf,6);
  biquad_storage *local;
  real out;
  
  if (!(local = (biquad_storage *)op->local)) {
    PROT_MAL(op->local,biquad_storage,co_biquad);
    local = (biquad_storage *)op->local;
    local->d1 = 0;
    local->d2 = 0;
  }
  
  out = input * b0 + local->d2;

  if (rate == ASIG) {
    local->d2 = local->d1 - a1 * out + b1 * input;
    local->d1 = -a2 * out + b2 * input;
  }
  return(out);
}

sa_real co_fir(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  fir_storage *local;
  sa_real out;
  int i;

  int ilen = pf_ct-1;
  
  if (!(local = (fir_storage *)op->local)) {
    PROT_MAL(op->local,fir_storage,co_fir);
    local = (fir_storage *)op->local;
    local->dline = NULL;
    local->dline = (sa_real *)malloc(ilen * sizeof(sa_real));
    for (i=0;i!=ilen;i++)
      local->dline[i] = 0;
    local->pt = 0;
    op->dyn = local->dline; /* so we can free it later */
    add_pointer(op->dyn, ilen * sizeof(float));
  }
  
  if (rate == ASIG) local->dline[local->pt] = input;

  out = 0;
  for (i=0;i!=ilen;i++)
    out += local->dline[(local->pt + i) % ilen] * pf[i+1].val;

  if (rate == ASIG)
    if (++local->pt == ilen) local->pt = 0;
  return out;
}

sa_real co_firt(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  table_storage *t = co_param_table(pf,2);
  real order = co_param(pf,3);
  firt_storage *local;
  sa_real out;
  int i;

  int ilen = 0;

  if (!t)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by firt().");
  
  
  if (pf_ct == 3) {
		order = co_param(pf,3);
		ilen = (int)(floor(order));
  }
  if (pf_ct < 3 || ilen > get_table_size(t)) {
	  ilen = get_table_size(t);
  }
  if (ilen < 1) {
	  runtime(sa,"Order for firt() must be positive.");
  }
 
  if (!(local = (firt_storage *)op->local)) {
    PROT_MAL(op->local,firt_storage,co_firt);
    local = (firt_storage *)op->local;
    local->dline = NULL;
    local->dline = (sa_real *)malloc(ilen * sizeof(sa_real));
    for (i=0;i!=ilen;i++)
      local->dline[i] = 0;
    local->pt = 0;
    op->dyn = local->dline; /* so we can free it later */
    add_pointer(op->dyn, ilen * sizeof(float));
  }

  if (rate == ASIG) local->dline[local->pt] = input;

  out = 0;
  for (i=0;i!=ilen;i++)
    out += local->dline[(local->pt + i) % ilen] * get_table_value(t,i);

  if (rate == ASIG)
    if (++local->pt == ilen) local->pt = 0;

  return out;
}

sa_real co_iir(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  iir_storage *local;
  sa_real out,fb, temp;
  int i;

  int ilen = (pf_ct+1)/2;
  
  if (!(local = (iir_storage *)op->local)) {
    PROT_MAL(op->local,iir_storage,co_iir);
    local = (iir_storage *)op->local;
    local->dline = NULL;
    local->dline = (sa_real *)malloc(2*ilen * sizeof(sa_real));
    for (i=0;i!=2*ilen;i++)
      local->dline[i] = 0;
    local->pt = 0;
    op->dyn = local->dline; /* so we can free it later */
    add_pointer(op->dyn, 2*ilen * sizeof(float));
  }

  fb = 0.0;
  for (i=1;i < ilen; i++)
    fb += local->dline[((local->pt + ilen - i) % ilen) + ilen] * pf[i*2].val;

  if (rate == ASIG) local->dline[local->pt] = input;

  temp = pf[1].val * input;
  for (i=1;i<ilen;i++)
    temp += local->dline[(local->pt + ilen - i) % ilen] * pf[2*i+1].val;

  out = temp -fb;
  if (rate == ASIG) local->dline[local->pt + ilen] = out;
  if (++local->pt == ilen) local->pt = 0;

  return (out);


/* fb = 0;
  for (i=2;i < pf_ct;i+=2)
    fb -= local->dline[(local->pt + i/2) % ilen] * pf[i].val;

  if (rate == ASIG) local->dline[local->pt] = input+fb;

  out = 0;
  for (i=1;i<pf_ct;i+=2)
    out += local->dline[(local->pt + (i-1)/2) % ilen] * pf[i].val;

  if (--local->pt == -1) local->pt = ilen-1;

  return out;  */
}

sa_real co_iirt(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  table_storage *a = co_param_table(pf,2);
  table_storage *b = co_param_table(pf,3);
  real order = 0;
  firt_storage *local;
  sa_real out,fb;
  int i;

  int ilen = 0;

  if (!a || !b)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by iirt().");

  if (pf_ct == 4) {
		order = co_param(pf,4);
		ilen = (int)(floor(order));
  }
  if (pf_ct < 4 || ilen > MAX(get_table_size(a),get_table_size(b))) {
	  ilen = MAX(get_table_size(a),get_table_size(b));
  }
  if (ilen < 1) {
	  runtime(sa,"Order for iirt() must be positive.");
  }
  
  if (!(local = (firt_storage *)op->local)) {
    PROT_MAL(op->local,iirt_storage,co_iirt);
    local = (firt_storage *)op->local;
    local->dline = NULL;
    local->dline = (sa_real *)malloc((ilen+1) * sizeof(sa_real));
    for (i=0;i!=ilen+1;i++)
      local->dline[i] = 0;
    local->pt = 0;
    op->dyn = local->dline; /* so we can free it later */
    add_pointer(op->dyn, ilen * sizeof(float));
  }

  fb = input;
  for (i=1;i!=MIN(ilen+1,a->size);i++) 
	 fb -= local->dline[(local->pt + i) % ilen] * get_table_value(a,i);

  if (rate == ASIG) local->dline[local->pt] = fb;


  out = 0;
  for (i=0;i!=MIN(ilen+1,b->size);i++)
    out += local->dline[(local->pt + i) % ilen] * get_table_value(b,i);

  if (--local->pt == -1) local->pt = ilen-1;
  return out;
}

/* spectral analysis */
sa_real co_fft(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  real input = co_param(pf,1);
  table_storage *re = co_param_table(pf,2);
  table_storage *im = co_param_table(pf,3);
  int length,shift,start;
  int fftsize;
  table_storage *win;
  fft_storage *local;
  complex inb[8192];
  complex out[8192];
  int totalsize, i,pt;

  if (!re || !im)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by fft().");
  
  if (pf_ct < 4)
    length = 0;
  else 
    length = (int)floor(co_param(pf,4) + 0.5);
  
  if (pf_ct < 5)
    shift = 0;
  else
    shift = (int)floor(co_param(pf,5) + 0.5);

  if (pf_ct < 6)
    fftsize = 0;
  else
    fftsize = (int)floor(co_param(pf,6) + 0.5);
  
  if (pf_ct < 7)
    win = NULL;
  else
    win = co_param_table(pf,7);

  if (length == 0)
    length = (int)(pow(2,ceil(log((sa_real)sa->ksmps)/log(2))));

  if (shift == 0)
    shift = length;

  if (fftsize == 0) fftsize = length;

  if (length <= 0)
    runtime(sa,"FFT length must be positive.");

  if (shift < 0)
    runtime(sa,"FFT shift cannot be negative.");

  if (fftsize > 8192)
      runtime(sa,"Maximum FFT length is 8192."); 
  
  if (fabs(log(fftsize) / log(2) - floor(log(fftsize)/log(2))) > 0.0001)
    runtime(sa,"FFT size must be a power of two.");

  if (win && get_table_size(win) < length)
    runtime(sa,"FFT window must be at least as long as FFT length.");

  if (get_table_size(re) < fftsize + 1 || get_table_size(im) < fftsize + 1)
    runtime(sa,"Tables for FFT result must be at least as long as FFT size + 1.");

  if (!(local = (fft_storage *)op->local)) {
    PROT_MAL(op->local,fft_storage,co_fft);
    local = (fft_storage *)op->local;
    
    /* we need to dynamically allocate two buffers, but
       there's only one handle for freeing them later,
       so allocate the memory in one chunk, and split it
       up. */
    
    totalsize = fftsize * sizeof(complex) + /* for basis buffer */
      2 * length * sizeof(real); /* for input samples */
    if (!(op->dyn = (void *)malloc(totalsize)))
      runtime(sa,"Couldn't allocate memory for fft.");
    else
      add_pointer(op->dyn, totalsize*sizeof(float)/sizeof(sa_real));

    local->basis = op->dyn;
    /* buf starts after fftsize complex values */
    local->buf = (real *)((complex *) op->dyn + fftsize);
    local->pt = 0;
    local->p2 = (IsPowerOfTwo(fftsize));
    local->basis = AssignBasis(local->basis,fftsize);
    local->ready = 0;
  }

  if (rate == ASIG) {
    /* buffer samples */
    local->buf[local->pt++] = input;
    local->framect++;
    
    if (local->pt == 2*length) {
      local->pt = 0;
    }

    if (local->framect == shift) {
      local->ready = 1;
      local->framept = local->pt;
      local->framect = 0;
    }
    
    return 0;
  }
    

  if (rate == KSIG) {
    if (local->ready) {
      /* time to do fft */

      start = (local->framept - length + 2*length) % (2*length);
      if (win) 
	for (i=0,pt=start;i!=length;i++,pt++) {
	  inb[i].re = local->buf[pt % (length*2)] * get_table_value(win,i);
	  inb[i].im = 0;
	}
      else 
	for (i=0,pt=start;i!=length;i++,pt++) {
	  inb[i].re = local->buf[pt % (length*2)];
	  inb[i].im = 0;
	}
      for (;i!=fftsize;i++)
	inb[i].re = inb[i].im = 0;
					
      if (local->p2) {
	FFT2real(inb,fftsize,1,local->basis); /* in place */
	for (i=0;i!=fftsize/2;i++) {
	  set_table_value(re,i,inb[i].re);
	  set_table_value(im,i,inb[i].im);
	}
	set_table_value(re,i,inb[i].re);
      }
      else {
	FFTarb(inb, out, fftsize, local->basis);
	for (i=0;i!=fftsize/2;i++) {
	  set_table_value(re,i,out[i].re);
	  set_table_value(im,i,out[i].im);
	}
	set_table_value(re,i,inb[i].re);
      }
					
      local->ready = 0;
      return 1;
    }
  }
	
  return 0;
}



sa_real co_ifft(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  table_storage *re = co_param_table(pf,1);
  table_storage *im = co_param_table(pf,2);
  int length,shift;
  int fftsize;
  table_storage *win;
  ifft_storage *local;
  complex inb[8192],out[8192],*fftbuf;
  int i,update,totalsize;
  sa_real temp;

  if (!re || !im)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by ifft().");
  
  if (pf_ct < 3)
    length = 0;
  else
    length = (int)floor(co_param(pf,3) + 0.5);

  if (pf_ct < 4)
    shift = 0;
  else 
    shift = (int)floor(co_param(pf,4)+0.5);

  if (pf_ct < 5)
    fftsize = 0;
  else
    fftsize = (int)floor(co_param(pf,5)+0.5);

  if (pf_ct < 6)
    win = NULL;
  else 
    win = co_param_table(pf,6);

  if (length == 0)
    length = (int)(pow(2,ceil(log((sa_real)sa->ksmps)/log(2))));

  if (shift == 0)
    shift = length;

  if (fftsize == 0) fftsize = length;

  if (length <= 0)
    runtime(sa,"IFFT length must be positive.");

  if (shift < 0)
    runtime(sa,"IFFT shift cannot be negative.");

  if (fftsize > 8192)
      runtime(sa,"Maximum IFFT length is 8192."); 
  
  if (fabs(log(fftsize) / log(2) - floor(log(fftsize)/log(2))) > 0.0001)
    runtime(sa,"IFFT size must be a power of two.");

  if (win && get_table_size(win) < length)
    runtime(sa,"IFFT window must be at least as long as FFT length.");

  if (get_table_size(re) < fftsize || get_table_size(im) < fftsize )
    runtime(sa,"Tables for IFFT  must be at least as long as FFT size.");


  if (!(local = (ifft_storage *)op->local)) {
    PROT_MAL(op->local,ifft_storage,co_ifft);
    local = (ifft_storage *)op->local;
    totalsize = fftsize * sizeof(complex) + /* for basis buffer */
      2*length * sizeof(real);	/* for input samples */
    if (!(op->dyn = (void *)malloc(totalsize)))
      runtime(sa,"Couldn't allocate memory for ifft.");
    else
      add_pointer(op->dyn, totalsize*sizeof(float)/sizeof(sa_real));

    local->basis = op->dyn;
    local->buf = (real *)((complex *) op->dyn + fftsize);
    for (i=0;i!=2*length;i++)
      local->buf[i] = 0;
    local->pt = 0;
    local->ct = shift - 1; /* do IFFT on first call */
    local->p2 = (IsPowerOfTwo(fftsize));
    local->basis = AssignBasis(local->basis,fftsize);
  }

  if (rate == KSIG) 
    return 0;

  local->ct++;
  if (local->ct == shift) {	/* time for IFFT */
    local->ct = 0;
    inb[0].re = get_table_value(re,0);
    inb[0].im = 0;
    inb[fftsize/2].re = get_table_value(re,fftsize-1);
    inb[fftsize/2].im = 0;
    for (i=1;i!=fftsize/2;i++) {
      inb[fftsize-i].re = inb[i].re = get_table_value(re,i);
      inb[fftsize-i].im = -(inb[i].im = get_table_value(im,i));
    }
    if (local->p2) {
      FFT2torl(inb,local->basis,1.0,fftsize,1);
      fftbuf = inb;
    }
    else {
      FFTarb(inb,out,fftsize,local->basis);
      fftbuf = out;
    }
    for (i=0;i!=length;i++) {
		update = (local->pt + i) % (length*2);
		if (win)
			local->buf[update] += fftbuf[i].re * get_table_value(win,i);
		else
			local->buf[update] += fftbuf[i].re / fftsize;
    }
  }
  temp = local->buf[local->pt];
  local->buf[local->pt] = 0;
  local->pt++;
  if (local->pt == length*2)
    local->pt = 0;
  return(temp);
}


/* gain control */

sa_real co_rms(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  rms_storage *local;
  sa_real input = co_param(pf,1);
  sa_real sum;
  int length = 0,i;

  if (pf_ct > 1)
    length = (int)floor(co_param(pf,2)+0.5);
  if (!length)
    length = (int)floor(sa->all->g->srate/sa->all->g->krate);

  if (!(local = (rms_storage *)op->local)) {
    PROT_MAL(op->local,rms_storage,co_rms);
    local = (rms_storage *)op->local;
    local->buf = (sa_real *)malloc(length * sizeof(sa_real));
    for (i=0;i!=length;i++)
      local->buf[i] = 0;
    local->pt = 0;
    local->last = 0;
    op->dyn = local->buf;	/* so we can free it later */
    add_pointer(op->dyn, length * sizeof(float));
  }
	

  if (rate == KSIG) {		/* return value */ 
    sum = 0;
    for (i=0;i!=length;i++)
      sum += local->buf[i] * local->buf[i];
    local->last = (sa_real)sqrt(sum/length);
#ifdef _MPEGPROFILER
    rms_cs2=1;
#endif
    return(local->last);
  }

  /* else ASIG */
	
  local->buf[local->pt++] = input*input;
  if (local->pt == length)
    local->pt = 0;
  return(local->last);
}

sa_real co_gain(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  /* NB currently implemented incorrectly.  should be block-buffered */
  sa_real input = co_param(pf,1);
  sa_real pwr = co_param(pf,2);
  sa_real sum;
  int length = 0,i;
  gain_storage *local;

  if (pf_ct > 2) 
    length = (int)floor(co_param(pf,3)+0.5);
  if (!length)
    length = (int)floor(sa->all->g->srate / sa->all->g->krate + 0.1);
	
  if (!(local = (gain_storage *)op->local)) {
    PROT_MAL(op->local,gain_storage,co_gain);
    local = (gain_storage *)op->local;
    local->buf = (sa_real *)malloc(length * sizeof(sa_real));
    for (i=0;i!=length;i++)
      local->buf[i] = 0;
    local->pt = 0;
    local->rms = 0;
    op->dyn = local->buf;	/* so we can free it later */
    add_pointer(op->dyn, length * sizeof(float));
  }
	
  if (rate == ASIG) local->buf[local->pt++] = input*input;
  if (local->pt == length) {
    sum = 0;
    for (i=0;i!=length;i++)
      sum += local->buf[i];
    local->rms = (sa_real)sqrt(sum/length);
    local->pt = 0;
#ifdef _MPEGPROFILER
    gain_cs2=1;
#endif
  }
  if (local->rms)
    return(input * pwr/local->rms);
  else 
    return(input);
}

sa_real co_balance(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  sa_real ref = co_param(pf,2);
  sa_real insum,refsum;
  int length = 0,i;
  balance_storage *local;

  if (pf_ct > 2) 
    length = (int)(floor(co_param(pf,3) + 0.5));
  if (!length)
    length = (int)floor(sa->all->g->srate / sa->all->g->krate + 0.1);
	
  if (!(local = (balance_storage *)op->local)) {
    PROT_MAL(op->local,balance_storage,co_balance);
    local = (balance_storage *)op->local;
    local->inbuf = (sa_real *)malloc(length * sizeof(sa_real) * 2);
    local->refbuf = local->inbuf + length;

    for (i=0;i!=length;i++)
      local->inbuf[i] = local->refbuf[i] = 0;
    local->pt = 0;
    local->inrms = local->refrms = 0;
    op->dyn = local->inbuf; /* so we can free it later */
    add_pointer(op->dyn, length * sizeof(float) * 2);
  }
	
  if (ASIG) {
    local->inbuf[local->pt] = input*input;
    local->refbuf[local->pt++] = ref*ref;
	
    if (local->pt == length) {
		insum = refsum = 0;
		for (i=0;i!=length;i++) {
			insum += local->inbuf[i];
			refsum += local->refbuf[i];
		}
		local->inrms = (sa_real)sqrt(insum/length);
		local->refrms = (sa_real)sqrt(refsum/length);
		local->pt = 0;
#ifdef _MPEGPROFILER
		balance_cs2 = 1;
#endif
    }
    if (local->inrms)
		return(input * local->refrms/local->inrms);
    else 
		return(input);
  }
  return(0);

}

sa_real co_compressor(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);
  sa_real comp = co_param(pf,2);
  sa_real thresh = co_param(pf,3);
  sa_real loknee = co_param(pf,4);
  sa_real hiknee = co_param(pf,5);
  sa_real ratio = co_param(pf,6);
  sa_real att = co_param(pf,7);
  sa_real rel = co_param(pf,8);
  sa_real look = co_param(pf,9);
  compressor_storage *local;
  int SR = sa->all->g->srate;
  int len = (int)(SR * look);
  sa_real intratio,comp1,comp2,projEnv,oldval;
  int i;
    

  if (!(local = (compressor_storage *)op->local)) {
    PROT_MAL(op->local,compressor_storage,co_compressor);
    op->dyn = (sa_real *)malloc(len * 2 * sizeof(sa_real));
    add_pointer(op->dyn, len * sizeof(float) * 2);
    /* holds both the main buffer and the new buffer */
    local->xdly = op->dyn; local->xdly_pt = 0;
    for (i=0;i!=len*2;i++) local->xdly[i] = 0;

    local->compdly = ((sa_real *)op->dyn) + len; local->compdly_pt = 0;
    local->gain = 1;
    local->change = 0;
    local->env = 0;
  }

  if (rate == ASIG) {
    oldval = local->xdly[local->xdly_pt];
    local->xdly[local->xdly_pt++] = x;
    if (local->xdly_pt > len) { local->xdly_pt = 0; }

    comp1 = 90 + 20 * (sa_real)log10(fabs(comp));
    comp2 = local->compdly[local->compdly_pt];
    local->compdly[local->compdly_pt++] = comp1;
    if (local->compdly_pt > len) { local->compdly_pt = 0; }

    if (comp2 > local->env) {
    	local->change = (comp2 - local->env) / (SR * att);
    }
    else {
      projEnv = local->change * (SR * look);
      if (projEnv < 0) projEnv = 0;
    }

    if (comp1 > projEnv && comp1 < comp2)  {
      local->change = (comp1 - comp2) / (SR * look);
    }
    local->env += local->change;
    if (local->env < 0) local->env = 0;

    if (local->env < thresh) local->gain = 0;
    else {
      if (local->env > thresh) {
	if (local->env < loknee) {
	  local->gain = 1;
   }
	else if (local->env >= hiknee)  {
	  local->gain = (sa_real)pow(10,((local->env/ratio + (hiknee - loknee) / 2
				 * (1 - 1 / ratio) ) / 20));
   }
	else { /* loknee <= env < hiknee */
	  intratio = (local->env - loknee) / (hiknee - loknee) * (ratio - 1) + 1;
	  local->gain = (sa_real)pow(10,((local->env/intratio + (hiknee - loknee) / 2
				 * (1 - 1 / ratio) ) / 20));
	}
      }
    }
  }
  return(oldval * local->gain);
}
    
	  
sa_real co_sblock(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);
  table_storage *t = co_param_table(pf,2);
  sblock_storage *local;
  int length = sa->ksmps,i,ct;

  if (!t)
	  runtime(sa,"Dynamic wavetable must be allocated before it is used by sblock().");
  
  if (!(local = (sblock_storage *)op->local)) {
    PROT_MAL(op->local,sblock_storage,co_sblock);
    local = (sblock_storage *)op->local;
    local->pt = 0;
    local->buf = (sa_real *)malloc(length * sizeof(sa_real));
    for (i=0;i!=length;i++)
      local->buf[i] = 0;
	op->dyn = local->buf;
    add_pointer(op->dyn, length * sizeof(float));
  }

  if (rate == KSIG) { /* fill table */
    if (get_table_size(t) < length)
      runtime(sa,"Table is too short for sblock.\n");
    for (i=local->pt,ct=0;ct < length;i = (i + 1) % length,ct++)
      set_table_value(t,ct,local->buf[i]);
  }

  if (rate == ASIG) { /* buffer */
    local->buf[local->pt] = x;
    local->pt = (local->pt + 1) % length;
  }

  return 0;
}


/* sample conversion */

sa_real co_decimate(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  decimate_storage *local;

  if (!(local = (decimate_storage *)op->local)) {
    PROT_MAL(op->local,decimate_storage,co_decimate);
    local = (decimate_storage *)op->local;
    local->last = 0;
  }

  if (rate == KSIG)
    return(local->last);
  else {
    local->last = input;
    return(0);
  }
}

sa_real co_upsamp(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  upsamp_storage *local;

  if (!(local = (upsamp_storage *)op->local)) {
    PROT_MAL(op->local,upsamp_storage,co_upsamp);
    local = (upsamp_storage *)op->local;
    local->last = 0;
    local->ct = 0;
  }

  if (local->last != input) {
    if (local->ct < sa->ksmps) {
#ifdef _MPEGPROFILER
    	upsamp_cs2 = 1;
#endif
		return(local->last + (input-local->last) / sa->ksmps * local->ct++);
    } else {
      local->ct = 0;
      local->last = input;
    }
  }
  return(local->last);
}

sa_real co_downsamp(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  table_storage *win = NULL;
  downsamp_storage *local;
  int length = (int)floor(sa->all->g->srate / sa->all->g->krate + 0.1);
  int i;
  sa_real sum;

  if (pf_ct > 1) {
    win = co_param_table(pf,2);
	if (!win)
	  runtime(sa,"Dynamic wavetable must be filled before it is used by downsamp().");

    if (win->size < length)
      runtime(sa,"Window for 'downsamp' must be at least one control period long.");
  }

  if (!(local = (downsamp_storage *)op->local)) {
    PROT_MAL(op->local,downsamp_storage,co_downsamp);
    local = (downsamp_storage *)op->local;
    local->buf = (sa_real *)malloc(length * sizeof(sa_real));
    for (i=0;i!=length;i++) local->buf[i]=0;
    local->pt = 0;
    op->dyn = local->buf;
    add_pointer(op->dyn, length * sizeof(float));
  }

  if (rate == ASIG) {
    local->buf[local->pt++] = input;
    return(0);
  }
	
  if (rate == KSIG) {
    sum = 0;
    if (win) {
      for (i=0;i!=length;i++)
			sum += local->buf[i] * get_table_value(win,i);
#ifdef _MPEGPROFILER
	  downsamp_cs2=1;
#endif
    } else {
      for (i=0;i!=length;i++)
			sum += local->buf[i] / length;
#ifdef _MPEGPROFILER
	  downsamp_cs2=1;
#endif
    }
    local->pt= 0;
    return sum;
  }
  return 0;
}

sa_real co_samphold(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  sa_real gate = co_param(pf,2);
  samphold_storage *local;

  if (!(local = (samphold_storage *)op->local)) {
    PROT_MAL(op->local,samphold_storage,co_samphold);
    local = (samphold_storage *)op->local;
    local->hold = 0;
  }
	
  if (gate)
    return(local->hold = input);
  else
    return(local->hold);
}

sa_real co_delay(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  sa_real dly = co_param(pf,2);
  sa_real out;
  delay_storage *local;
  int i;

  int idly = (int)(floor(dly * (sa_real)sa->all->g->srate + 0.5));
  if (!(local = (delay_storage *)op->local)) {
    PROT_MAL(op->local,delay_storage,co_delay);
    local = (delay_storage *)op->local;
    local->dline = (sa_real *)malloc(idly * sizeof(sa_real));
    for (i=0;i!=idly;i++)
      local->dline[i] = 0;
    local->pt = 0;
    op->dyn = local->dline; /* so we can free it later */
    add_pointer(op->dyn, idly * sizeof(float));
  }

  if (idly == 0)
    return(input);
  else {
    out = local->dline[local->pt];
    if (rate == ASIG) local->dline[local->pt++] = input;
    
    if (local->pt == idly) local->pt = 0;
    return(out);
  }
}

sa_real co_delay1(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  sa_real out;
  delay1_storage *local;
  
  if (!(local = (delay1_storage *)op->local)) {
    PROT_MAL(op->local,delay1_storage,co_delay1);
    local = (delay1_storage *)op->local;
    local->last = 0;
  }
  out = local->last;
  if (rate == ASIG) local->last = input;

  return(out);
}

sa_real co_fdelay(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  /* actually now called 'fracdelay' (fixed in saol_core_opcodes.c) */
  sa_real method = co_param(pf,1);
  sa_real p1;
  sa_real out,tap;
  int i, imethod,pos;
  fdelay_storage *local;
  int imxdly;
  char s[435];

  FLOP(6);
  imethod = (int)floor(method + 0.5);
  TEST(2);
  if (imethod < 1 || imethod > 5) {
    sprintf(s,"Unknown method for 'fracdelay': %d",imethod);
    runtime(sa,s);
  }

  TEST(5);
  switch (imethod) {
  case 1: /* initialize */

    TEST(1);
    if (pf_ct < 2) {
      runtime(sa,"Must provide length for initialize method of 'fracdelay'");
    } else {
      p1 = co_param(pf,2);
      MR(1);
    }
   
    MR(1); TEST(1);
    if (op->local) {
      free(op->local);
      remove_pointer(op->dyn);
      free(op->dyn);
    }
     
    MR(1); FLOP(7);
    imxdly = (int)floor(p1 * (sa_real)sa->all->g->srate + 0.5);
    
    PROT_MAL(op->local,fdelay_storage,co_fdelay);
    MR(1); MW(1);
    local = (fdelay_storage *)op->local;
    FLOP(7); MW(1);
    local->dline = (sa_real *)malloc(imxdly * sizeof(sa_real));

    for (i=0;i!=imxdly;i++) {
      TEST(1); MW(1);
      local->dline[i] = 0;
    }
    MW(3); MR(1);
    local->pt = 0;
    local->len = imxdly;
    op->dyn = local->dline; /* so we can free it later */
    add_pointer(op->dyn, imxdly * sizeof(float));
    out = 0;
    break;
    
  case 2: /* tap */
    MR(1); TEST(1);
#ifdef _MPEGPROFILER
    fdelay_m2=1;
#endif
    if (!(local = (fdelay_storage *)op->local)) /* not initialized */ {
      runtime(sa,"'fracdelay' not initialized.");
    }
    MR(1);
    if (pf_ct < 2) {
      runtime(sa,"Must provide top position for method 2 of 'fracdelay'");
    } else p1 = co_param(pf,2);
   
    FLOP(1); MR(1);
    tap = p1 * (sa_real)sa->all->g->srate;
    MR(1); TEST(2);
    if (tap < 0 || tap > local->len) {
      sprintf(s,"'fracdelay' out of bounds (length %d, tap at %.2lf).",local->len,tap);
      runtime(sa,s);
    }
    FLOP(1); MR(1);
    tap = (tap + local->pt); if (tap >= local->len) tap -= local->len;
	out = interp(sa,local->dline,local->len,tap,sa->interp_q);

    break;
    
  case 3: /* set */
    MR(1); TEST(1);
#ifdef _MPEGPROFILER
    fdelay_m3=1;
#endif
    if (!(local = (fdelay_storage *)op->local)) /* not initialized */ {
      runtime(sa,"'fracdelay' not initialized.");
    }

    TEST(1);
    if (pf_ct < 3)
      runtime(sa,"3 parameters required for 'fracdelay' set method.\n");

    MR(1);
    p1 = co_param(pf,2);
   
    FLOP(7); MR(1);
    pos = (int)floor(p1 * (sa_real)sa->all->g->srate + 0.5);

    MR(1); TEST(2);
    if (pos < 0 || pos >= local->len) {
      sprintf(s,"'fracdelay' out of bounds (length %d, insert at %d).",local->len,pos);
      runtime(sa,s);
    }

    FLOP(1); MR(1);
    pos = pos + local->pt;
    TEST(1); MR(1);
    if (pos >= local->len) { FLOP(1); MR(1); pos = pos - local->len; }
    MW(1); MR(1);
    local->dline[pos] = co_param(pf,3);

    out = 0;
    break;

  case 4: /* add in */
    TEST(1); MR(1);
#ifdef _MPEGPROFILER
    fdelay_m4=1;
#endif
    if (!(local = (fdelay_storage *)op->local)) /* not initialized */ {
      runtime(sa,"'fracdelay' not initialized.");
    }
    TEST(1);
    if (pf_ct < 3)
      runtime(sa,"3 parameters required for 'fracdelay' add in method.\n");
    MR(1);
    p1 = co_param(pf,2);
   
    FLOP(7);
    pos = (int)floor(p1 * (sa_real)sa->all->g->srate + 0.5);
    TEST(2); MR(1);
    if (pos < 0 || pos >= local->len) {
      sprintf(s,"'fracdelay' out of bounds (length %d, add in at %d).",local->len,pos);
      runtime(sa,s);
    }
    FLOP(1); MR(1);
    pos = pos + local->pt;
    TEST(1); MR(1);
    if (pos >= local->len) { MR(1); FLOP(1); pos = pos - local->len; }
    MW(1); MR(1); FLOP(1);
    local->dline[pos] += co_param(pf,3);

    out = 0;
    break;

  case 5: /* shift */
    TEST(1); MR(1);
#ifdef _MPEGPROFILER
    fdelay_m5=1;
#endif
    if (!(local = (fdelay_storage *)op->local)) /* not initialized */ {
      runtime(sa,"'fracdelay' not initialized.");
    }
    MR(1); FLOP(1);
    pos = local->pt -1;
    TEST(1);
    if (pos < 0) { FLOP(1); MR(1);  pos = local->len - 1; }
    MR(1);
    out = local->dline[pos];
    MW(1);
    local->dline[pos] = 0;
    TEST(1);
    if (rate == ASIG)  {
      local->pt = pos;
      MW(1);
    }
    break;

  }
  return(out);
}

sa_real co_comb(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  sa_real time = co_param(pf,2);
  sa_real gain = co_param(pf,3);
  sa_real out;
  comb_storage *local;
  int itime = (int)(floor(time * (sa_real)sa->all->g->srate + 0.5));
  int i;

  TEST(1);
  if (!(local = (comb_storage *)op->local)) {
    PROT_MAL(op->local,comb_storage,co_comb);
    local = (comb_storage *)op->local;
    local->dline = (sa_real *)malloc(itime * sizeof(sa_real));
    local->pt = 0;
    for (i=0;i!=itime;i++)
      local->dline[i] = 0;
    op->dyn = local->dline;
    add_pointer(op->dyn, itime * sizeof(float));
    MW(i+3);
  }

  FLOP(2); MR(2);
  out = local->dline[local->pt]; /* gain * (input + local->dline[local->pt]); */
  if (rate == ASIG) { 
	   MR(1); MW(1); FLOP(1);
		 local->dline[local->pt++] = input + out * gain;
	}
  if (local->pt == itime) {MW(1); local->pt = 0; }
  TEST(2);

  return out;
}

sa_real co_allpass(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real input = co_param(pf,1);
  sa_real time = co_param(pf,2);
  sa_real gain = co_param(pf,3);
  sa_real out;
  allpass_storage *local;
  int itime = (int)(floor(time * (sa_real)sa->all->g->srate + 0.5));
  int i;

  TEST(1);
  if (!(local = (allpass_storage *)op->local)) {
    PROT_MAL(op->local,allpass_storage,co_allpass);
    local = (allpass_storage *)op->local;
    local->dline = (sa_real *)malloc(itime * sizeof(sa_real));
    local->pt = 0;
    for (i=0;i!=itime;i++)
      local->dline[i] = 0;
    op->dyn = local->dline;
    add_pointer(op->dyn, itime * sizeof(float));
    MW(i+2);
  }

  FLOP(3); MR(1);
  out = -gain * input + local->dline[local->pt];
  TEST(1);
  if (rate == ASIG) {
    MW(2); FLOP(1); MAC(1);
    local->dline[local->pt++] = gain * out + input;
  }
  TEST(1); MR(1);
  if (local->pt == itime) { MW(1); local->pt = 0; }

  return out;
}

sa_real co_gettempo(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  return(sa->sched->tempo);
}

sa_real co_settempo(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  sa_real x = co_param(pf,1);

  if (x <= 0)
    runtime(sa,"Parameter to settempo() must be strictly positive.");

  sa->sched->last_score_tempo = sa->sched->tempo;
  sa->sched->tempo = x;
  sa->sched->last_tempo_time = sa->sched->time;
      
  /* go through the pending list and change the scheduled times */
  scale_sched_events(sa, sa->sched->pending);

  return x;
}

  
#ifdef _FX_SPEEDC
sa_real co_fx_speedc(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
    fx_speedc_storage *local;
    int i;

/* ISO_ONLY_CODE */
  if(!sa->spc_buf) {
        printf("\n buffer for AudioFX speed control is not allocated\n");
      exit(1);
  }
  if(1!=sa->inchan) {
    printf("\n AudioFX speed control (PICOLA) supports mono-signal only\n");
    exit(1);
  }

    sa->fx_speedc = 1;

    if(!(local = (fx_speedc_storage *)op->local)) {
    PROT_MAL(op->local, fx_speedc_storage, co_speedc);
        local = (fx_speedc_storage *)op->local;
    local->scf = 1.;
    local->min_pitch = (int)(sa->all->g->srate/200);
    local->max_pitch = (int)(sa->all->g->srate/50);
    local->pitch = -1;
        local->start_point = 0;
    local->inend_point = 0;
    local->outend_point = 0;
    local->output_point = 0;
    local->write_point = 0;
    local->frac = 0.;
    local->inbuf_frame
      = (local->max_pitch*2+sa->ksmps-1)/sa->ksmps + 2;
    local->len_inbuf = local->inbuf_frame*sa->ksmps;
    local->outbuf_frame
      = (local->max_pitch*2+sa->ksmps*2-1)/(sa->ksmps*2) + 2;
    local->len_outbuf = local->outbuf_frame*sa->ksmps*2;
    local->target_point = local->len_inbuf;

    local->inbuf =
      (sa_real *)malloc((local->len_inbuf+local->len_outbuf)
          * sizeof(sa_real));
    for(i=0;i<(local->len_inbuf+local->len_outbuf);i++)
          local->inbuf[i] = 0.;
    op->dyn = local->inbuf;
    local->outbuf = local->inbuf + local->len_inbuf;
    local->num_in_samples = sa->ksmps;
        local->num_out_samples = 0;
    local->init = 1;
  }

  local->scf = co_param(pf, 1);

  sa->num_spc_samples
    = (int)(sa->ksmps/local->scf);
    local->num_out_samples = sa->num_spc_samples;
  local->scf = sa->ksmps/(sa_real)sa->num_spc_samples;

  if(local->scf>=1.) {

    local->outbuf_frame = (local->max_pitch+local->num_in_samples
			   -1)/local->num_in_samples + 2;
  }else {
    local->outbuf_frame = (local->max_pitch+local->num_out_samples
			   -1)/local->num_in_samples + 2;
  }

  local->len_outbuf = local->outbuf_frame*local->num_in_samples;

  fx_picola(sa->inbus->val[0], sa->spc_buf[0], local);

#ifdef PICOLA_VFL
  sa->num_spc_samples = local->num_out_samples;
#endif
/* END_ISO_ONLY_CODE */

  return 0;
}
#endif


/* NON-NORMATIVE OPCODES */

/* ie, these are not in the standard */

sa_real co_kdump(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  int i;

  if (rate != KSIG) return 0;
  printf("KDUMP (%.4f): ",sa->sched->time);
  for (i=0;i!=pf_ct;i++)
    printf("%.4f ",pf[i].val);

  printf("\n");
  return 0;
}

sa_real co_idump(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  int i;

  if (rate != IVAR) return 0;
  printf("IDUMP (%.4f): ",sa->sched->time);
  for (i=0;i!=pf_ct;i++)
    printf("%.4f ",pf[i].val);

  printf("\n");
  return 0;
}

sa_real co_adump(sa_decoder *sa, opval *op, actparam *pf, int pf_ct, long rate) {
  int i;

  if (rate != ASIG) return 0;
  printf("ADUMP (%.5f): ",sa->sched->time);
  for (i=0;i!=pf_ct;i++)
    printf("%.4f ",pf[i].val);
  printf("\n");
  return 0;
  
}
