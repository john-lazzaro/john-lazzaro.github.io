/*

This software module was originally developed by 

Luke Dahl, Brian Link (E-mu Systems)


in the course of development of the MPEG-4 Audio (ISO/IEC 14496-3) standard. 
This software module is an implementation of a part of one or more 
MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio 
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC 14496-3) 
free license to this software module or modifications thereof for use 
in hardware or software products claiming conformance to the MPEG-4 Audio 
(ISO/IEC 14496-3). Those intending to use this software module in hardware 
or software products are advised that its use may infringe existing patents. 
The original developer of this software module and his/her company, the 
subsequent editors and their companies, and ISO/IEC have no liability for 
use of this software module or modifications thereof in an implementation. 
Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming 
products. E-mu Systems retains full right to use the code for his/her own 
purpose, assign or donate the code to a third party and to inhibit third 
parties from using the code for non MPEG-4 Audio (ISO/IEC 14496-3) 
conforming products. This copyright notice must be included in all copies 
or derivative works. 

Copyright (C) 1997 E-mu Systems, Inc.

*/
/*****************************************************************************
;
;	sf_param_trans.c
;
;	Parameter Transformation functions and tables.
;
;	History:
;		created	9/97	Luke Dahl, Brian Link
;
*****************************************************************************/



#include <math.h>
#include "sf_wave_def.h"
#include "sf_wave_equ.h"
#include "sf_param_trans.h"

#define PITCHOCTOFFSET 10
#define NUMOCT 16
#define MAXOCTAVESDOWN (-PITCHOCTOFFSET)
#define MAXOCTAVESUP   (NUMOCT - PITCHOCTOFFSET - 1)

/* Globals */
double PitchOctLookup[NUMOCT] = 
{
	0.0009765625, 0.001953125, 0.00390625, 0.0078125, 0.015625, 0.03125, 0.0625, 0.125, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0 
};

double PitchSemiLookup[13] =
{
	1.0,
	1.05946,
	1.12246,
	1.18921,
	1.25992,
	1.33484,
	1.41421,
	1.49831,
	1.58740,
	1.68179,
	1.78180,
	1.88775,
	2.0
};


/* Functions: */
/*	Parameter DiffCents is (DesiredCents - SampleCents) */
double CalcPhaseInc(int DiffCents)
{
	int Octaves, Semi;
	double PhaseInc;
	double Fraction, SemiFrac;
	
	Octaves = (int) (DiffCents / 1200);
	if (DiffCents >= 0)
	{
		if (Octaves >= MAXOCTAVESUP)		
		{
			PhaseInc = PitchOctLookup[MAXOCTAVESUP + PITCHOCTOFFSET]; 
			return (PhaseInc);
		}
	}
	else
	{
		if (DiffCents % 1200 < 0)
		{
			Octaves -= 1;
			DiffCents += -Octaves * 1200;
		}
		if (Octaves < MAXOCTAVESDOWN) 
		{
			PhaseInc = PitchOctLookup[0];		
			return (PhaseInc);
		}
	}

	Semi = (int)((DiffCents % 1200) / 100);
	SemiFrac = ((DiffCents % 1200) / 100.0) - Semi;

/*	Linearly interpolate between semitones */

	assert(Semi >= 0 && Semi <= 12);
	assert(Octaves + PITCHOCTOFFSET >= 0 && Octaves + PITCHOCTOFFSET <= NUMOCT);

	Fraction = (1.0 - SemiFrac) * PitchSemiLookup[Semi] + 
			SemiFrac * PitchSemiLookup[Semi + 1];
	PhaseInc = PitchOctLookup[Octaves + PITCHOCTOFFSET] * Fraction;
	return (PhaseInc);
}

/* Convert from raw SF units to native units for this synhesizer */
void sf_xlat(sfData *rawsp, sfStuff *sfBank, struct SynthParams *nativesp, 
		int srate, int krate, SHORT note, SHORT keyvel)
{
	short origKey;			/* must be 16 bits */
	short correction;		/* must be 16 bits */
	int	  srcor;
	double srratio;
	int k;
	double temp;

	/* These two lines added 6/22/98 since these are not handled correctly in Todor's
		GetSynthParams */
	rawsp->shKeynum = note;
	rawsp->shVelocity = keyvel;


	/************************************************/
	/*** convert sample addresses for oscillator  ***/
	/************************************************/
	
	/* NEW code for dls translation */
	nativesp->Start = rawsp->pfWave + rawsp->dwStart;
	nativesp->End = rawsp->pfWave + rawsp->dwEnd;
	nativesp->Startloop = rawsp->pfWave + rawsp->dwStartloop;
	nativesp->Endloop = rawsp->pfWave + rawsp->dwEndloop;

	if (rawsp->shSampleModes == 0)
		nativesp->SampleMode = LOOP_NONE;
	else if (rawsp->shSampleModes == 3)
		nativesp->SampleMode = LOOP_HOLD;
	else
		nativesp->SampleMode = LOOP_CONT;
	

	/************************************************/
	/*** convert to desired sample pitch in cents ***/
	/************************************************/
	
	/* want top byte as signed; gives MIDI keynum */
	origKey = (rawsp->shOrigKeyAndCorr & 0xff00) >> 8;
	if (origKey < 0 || origKey > 127)	/* constrain to legal range */
		origKey = 60;

	/* want bottom byte as signed; give correction in cents */
	correction = (short)(rawsp->shOrigKeyAndCorr << 8) >> 8;
	/* may be overridden */
	if (rawsp->shOverridingRootKey >= 0 && rawsp->shOverridingRootKey <= 127)
	{
		origKey = rawsp->shOverridingRootKey;
	}

	/* correct for sample rate of sample */
	srratio = (double)rawsp->dwSampleRate / (double)srate;
	srcor = (int) (3986.3 * log10(srratio));

	/* Calc Pitch */
	nativesp->InitPitch =
		(rawsp->shKeynum - origKey) * rawsp->shScaleTuning +
		+ rawsp->shCoarseTune * 100. + rawsp->shFineTune + correction + srcor;

	nativesp->SFLfo1ToPitchVal = (double)rawsp->shModLfoToPitch;
	nativesp->SFLfo2ToPitchVal = (double)rawsp->shVibLfoToPitch;
	nativesp->Lfo1ToPitch = (double)rawsp->shModLfoToPitch;
	nativesp->Lfo2ToPitch = (double)rawsp->shVibLfoToPitch;
	nativesp->PitchEnvToPitch = (double)rawsp->shModEnvToPitch;

	/************************************************/
	/*** copy over filter parms					  ***/
	/************************************************/
	nativesp->FilterFc = (double) rawsp->shInitialFilterFc -
					2400. * (127. - rawsp->shVelocity) / 128.;
	nativesp->InitFilterFc = nativesp->FilterFc;
	nativesp->FilterQ = (double) rawsp->shInitialFilterQ;
	nativesp->Lfo1ToFilterFc = (double) rawsp->shModLfoToFilterFc;
	nativesp->PitchEnvToFilterFc = (double) rawsp->shModEnvToFilterFc;

	/************************************************/
	/*** copy attenuation values				  ***/
	/************************************************/

	nativesp->SFVolValue = rawsp->shInstVol;
 	/* Attenuation is scaled by velocity according to 20*log10((vel / 127.0)^2) in dB */
	/* We keep attenuation in cB */
	/* DLS2 note:  "attenuation" now funcions as a gain! */
	nativesp->Attenuation = (rawsp->shInstVol) + 400.0 * log10(rawsp->shVelocity / 127.0);  
	nativesp->Tremolo = rawsp->shModLfoToVolume;

	/************************************************/
	/*** convert bus sends						  ***/
	/************************************************/

	nativesp->SFPanValue = rawsp->shPanEffectsSend;    /* kept for Cont Ctrl */
	nativesp->SFRvbSendVal = rawsp->shReverbEffectsSend;
	nativesp->SFChsSendVal = rawsp->shChorusEffectsSend;

	if (rawsp->shPanEffectsSend < -500)
	{
		nativesp->LSend = 1.0;
		nativesp->RSend = 0;
	}
	else if (rawsp->shPanEffectsSend > 500)
	{
		nativesp->LSend = 0;
		nativesp->RSend = 1.0;
	}
	else
	{
		nativesp->LSend = -0.001 * (rawsp->shPanEffectsSend - 500.);
		nativesp->RSend = 0.001 * (rawsp->shPanEffectsSend + 500.);
	}

	if (rawsp->shReverbEffectsSend < 0)
		nativesp->RvbSend = 0;
	else if (rawsp->shReverbEffectsSend > 1000)
		nativesp->RvbSend = 1.0;
	else
		nativesp->RvbSend = 0.001 * rawsp->shReverbEffectsSend;

	if (rawsp->shChorusEffectsSend < 0)
		nativesp->ChsSend = 0;
	else if (rawsp->shChorusEffectsSend > 1000)
		nativesp->ChsSend = 1.0;
	else
		nativesp->ChsSend = 0.001 * rawsp->shChorusEffectsSend;

	/************************************************/
	/*** convert Lfo1 (Mod) values				  ***/
	/************************************************/

	/* (seconds of delay) * calls/second = (# calls to achieve delay) */
	if (rawsp->shDelayModLfo == -32768)
		nativesp->Lfo1.delay = 0;
	else
		nativesp->Lfo1.delay =
		(int)(TimeCentsToSeconds(rawsp->shDelayModLfo) * krate);
	/* (magnitude of saw) * periods/sec / calls/sec = amp change per call */
	nativesp->Lfo1.freq =
		2. * CentsToHertz(rawsp->shFreqModLfo) / krate;

	/************************************************/
	/*** convert Lfo2 (Vib) values				  ***/
	/************************************************/

	/* (seconds of delay) * calls/second = (# calls to achieve delay) */
	if (rawsp->shDelayVibLfo == -32768)
		nativesp->Lfo2.delay = 0;
	else
		nativesp->Lfo2.delay =
		(int)(TimeCentsToSeconds(rawsp->shDelayVibLfo) * krate);
	/* (magnitude of saw) * periods/sec / calls/sec = amp change per call */
	nativesp->Lfo2.freq =
		2. * CentsToHertz(rawsp->shFreqVibLfo) / krate;

	/************************************************/
	/*** convert Pitch Envelope (Mod) values	  ***/
	/************************************************/

	/* DELAY */
	if (rawsp->shDelayModEnv == -32768)
		nativesp->PitchEnv.delay = 0;
	else
	/* (seconds of delay) * calls/second = (# calls to achieve delay) */
		nativesp->PitchEnv.delay = 
			(int)(TimeCentsToSeconds(rawsp->shDelayModEnv) * krate);

	/* ATTACK */
	if (rawsp->shAttackModEnv == -32768)
		nativesp->PitchEnv.attack = 1.0;		/* reach peak immediately */
	else{
		temp = rawsp->shAttackModEnv + (keyvel * rawsp->shAttackScaleModEnv / 128.);	
		nativesp->PitchEnv.attack =
			1. / (TimeCentsToSeconds(temp) * krate);
	}

	/* HOLD */
	if (rawsp->shHoldModEnv == -32768)
		nativesp->PitchEnv.hold = 0;
	else
	/* (seconds of hold) * calls/second = (# calls to achieve hold) */
		nativesp->PitchEnv.hold = 
			(int)(TimeCentsToSeconds(rawsp->shHoldModEnv) * krate);

	/* DECAY */
	if (rawsp->shDecayModEnv == -32768)
		nativesp->PitchEnv.decay = 0.0;
	else{
		temp = rawsp->shDecayModEnv + (note * rawsp->shAutoDecayModEnv / 128.);
		k = (int) (TimeCentsToSeconds(temp) * (double) krate);	/*num of frames to reach -96dB*/
		nativesp->PitchEnv.decay = pow(0.000015849, (1./(k-1)));
	}
	
	/* SUSTAIN */
	if (rawsp->shSustainModEnv < 0)
		nativesp->PitchEnv.sustain = 0.0;
	else if (rawsp->shSustainModEnv > 1000)
		nativesp->PitchEnv.sustain = 1.0;
	else
		nativesp->PitchEnv.sustain = 0.001 * rawsp->shSustainModEnv;
	
	/* RELEASE */
	if (rawsp->shReleaseModEnv == -32768)
		nativesp->PitchEnv.release = 0.0;
	else{
		k = (int) (TimeCentsToSeconds(rawsp->shReleaseModEnv) * (double) krate);	/*num of frames to reach -96dB*/
		nativesp->PitchEnv.release = pow(0.000015849, (1./(k-1)));
	}


	/************************************************/
	/*** convert Volume Envelope (Vol) values	  ***/
	/************************************************/

	/* DELAY */
	if (rawsp->shDelayVolEnv == -32768)
		nativesp->VolEnv.delay = 0;
	else
	/* (seconds of delay) * calls/second = (# calls to achieve delay) */	
		nativesp->VolEnv.delay = 
			(int)(TimeCentsToSeconds(rawsp->shDelayVolEnv) * krate);

	/* ATTACK */
	if (rawsp->shAttackVolEnv == -32768)
		nativesp->VolEnv.attack = 1.0;		/* reach peak immediately */
	else{
	/* (magnitude of 1.0) / ((attack time) * calls/second) = increment per call */
		temp = rawsp->shAttackVolEnv + (keyvel * rawsp->shAttackScaleVolEnv / 128.);	
		nativesp->VolEnv.attack =
			1. / (TimeCentsToSeconds(temp) * krate);
	}

	/* HOLD */
	if (rawsp->shHoldVolEnv == -32768)
		nativesp->VolEnv.hold = 0;
	else
	/* (seconds of hold) * calls/second = (# calls to achieve hold) */
		nativesp->VolEnv.hold = 
			(int)(TimeCentsToSeconds(rawsp->shHoldVolEnv) * krate);
	
	/* DECAY */
	if (rawsp->shDecayVolEnv == -32768)
		nativesp->VolEnv.decay = 0.0;
	else{
		temp = rawsp->shDecayVolEnv + (note * rawsp->shAutoDecayVolEnv / 128.);
		k = (int) (TimeCentsToSeconds(temp) * (double) krate);	/*num of frames to reach -96dB*/
		nativesp->VolEnv.decay = pow(0.000015849, (1./(k-1)));
	}

	/* SUSTAIN */
	if (rawsp->shSustainVolEnv < 0)
		nativesp->VolEnv.sustain = 0.0;
	else if (rawsp->shSustainVolEnv > 1000)
		nativesp->VolEnv.sustain = 1.0;
	else
		nativesp->VolEnv.sustain = rawsp->shSustainVolEnv / 1000.;

	/* RELEASE */
	if (rawsp->shReleaseVolEnv == -32768)
		nativesp->VolEnv.release = 0.0;
	else{
		k = (int) (TimeCentsToSeconds(rawsp->shReleaseVolEnv) * (double) krate);	/*num of frames to reach -96dB*/
		nativesp->VolEnv.release = pow(0.000015849, (1./(k-1)));
	}

}

double TimeCentsToSeconds(double tc)
{
	return (exp(tc * log(2) / 1200.));	/* log(x)/log(2) give log base 2 of x */
}

double CentsToHertz(double c)
{
	return (8.176 * exp(c * log(2) / 1200.));
}

