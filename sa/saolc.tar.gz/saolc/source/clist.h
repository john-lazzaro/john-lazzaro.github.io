
/*

clist.h

This software module was developed by Todor Fay (Microsoft Corp)
in the course of development of the MPEG-4 Audio (ISO/IEC 14496-3) standard. 
This software module is an implementation of a part of one or more 
MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio 
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC 14496-3) 
free license to this software module or modifications thereof for use 
in hardware or software products claiming conformance to the MPEG-4 Audio 
(ISO/IEC 14496-3). Those intending to use this software module in hardware 
or software products are advised that its use may infringe existing patents. 
The original developer of this software module and his/her company, the 
subsequent editors and their companies, and ISO/IEC have no liability for 
use of this software module or modifications thereof in an implementation. 
Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming 
products. Microsoft retains full right to use the code for its own 
purpose, assign or donate the code to a third party and to inhibit third 
parties from using the code for non MPEG-4 Audio (ISO/IEC 14496-3) 
conforming products. This copyright notice must be included in all copies 
or derivative works. 

Copyright (c) Microsoft Corporation 1996, 1998
*/

#ifndef __CLIST_H__
#define __CLIST_H__

class CListItem
{ 
public:
    CListItem() { m_pNext=NULL; };
    CListItem *GetNext() const {return m_pNext;};
    void SetNext(CListItem *pNext) {m_pNext=pNext;};
    LONG GetCount() const;
    BOOL IsMember(CListItem *pItem);
    CListItem* Cat(CListItem* pItem);
    CListItem* AddTail(CListItem* pItem) {return Cat(pItem);};
    CListItem* Remove(CListItem* pItem);
    CListItem* GetPrev(CListItem *pItem) const;
    CListItem* GetItem(LONG index);

private:
    CListItem *m_pNext;
};

class CList
{
public:
    CList() {m_pHead=NULL;};
    CListItem *GetHead() const { return m_pHead;};

    void RemoveAll() { m_pHead=NULL;};
    long GetCount() const {return m_pHead->GetCount();}; 
    CListItem *GetItem(LONG index) { return m_pHead->GetItem(index);}; 
    void InsertBefore(CListItem *pItem,CListItem *pInsert);
    void Cat(CListItem *pItem) {m_pHead=m_pHead->Cat(pItem);};
    void Cat(CList *pList)
        {
            m_pHead=m_pHead->Cat(pList->GetHead());
        };
    void AddHead(CListItem *pItem)
        {
            pItem->SetNext(m_pHead);
            m_pHead=pItem;
        }
    void AddTail(CListItem *pItem) {m_pHead=m_pHead->AddTail(pItem);};
    void Remove(CListItem *pItem) {m_pHead=m_pHead->Remove(pItem);};
    CListItem *GetPrev(CListItem *pItem) const {return m_pHead->GetPrev(pItem);};
    CListItem *GetTail() const {return GetPrev(NULL);};
    BOOL IsEmpty(void) const {return (m_pHead==NULL);};
    BOOL IsMember(CListItem *pItem) {return (m_pHead->IsMember(pItem));};
    CListItem *RemoveHead(void)
        {
            CListItem *li;
            li=m_pHead;
            if(m_pHead)
                m_pHead=m_pHead->GetNext();
            if (li)
                li->SetNext(NULL);
            return li;
        }

protected:
    CListItem *m_pHead;
};

#endif // __CLIST_H__
