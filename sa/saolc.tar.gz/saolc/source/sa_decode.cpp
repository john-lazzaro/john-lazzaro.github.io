/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* sa_decode.cpp: Bitstream-parsing code for saolc.

  This is the top-level part of the code that deals with the bitstream data.
  It exposes two important functions: process_header(), which deals with
  the bitstream header, and receive_au(), which deals with access units.
  process_header() writes temporary files to disk so that they can be handled
  by the main part of the implementation; receive_au() creates events and
  registers them with the scheduler.
  
	Most of the important file-parsing code actually lives in sa_bitstream.h.
*/

#include "saol.tab.h"

extern "C"  {
#include "saol.h"
#include "aifif.h"  
#include "saol_sched.h"
}

#include "bitstream.h"
#include "saol_tok_table.h"
#include "sa_bitstream.h"

void dump_orc(struct cmdinfo *cmd,StructuredAudioSpecificConfig *,orc_file *);
void dump_score(struct cmdinfo *cmd,StructuredAudioSpecificConfig *info, score_file *s);
void dump_midi(struct cmdinfo *cmd,StructuredAudioSpecificConfig *info, midi_file *);
int isSample(int sym);
SA_access_unit *get_next_au(sa_decoder *sa);
void decode_score_au(sa_decoder *sa,event *ev, score_line *sl);
int decode_midi_au(sa_decoder *sa,event *ev, midi_event *mid);
void decode_sample_au(sa_decoder *sa,sample *samp);
char *get_bitstream_sym_name(sa_decoder *sa,sa_symbol sym);


void make_midi_au_event(event *ev,long type,int channel, int note, int val);
int get_vlq_length(unsigned char *buf,int *len);
	
void process_header(sa_decoder *sa,cmdinfo *cmd) {
/* Read in the bitstream header and dump out all of the chunks in text
format so that they can be read in by the text parser.  It's not
necessary according to the spec to go through text files, but we do it here so that a 
	   single parse can be used both for bitstreams and for textual SAOL */
	StructuredAudioSpecificConfig *info;
	Bitstream *in;
	int i;
	
	samp_ct = 0;
	info = new StructuredAudioSpecificConfig; // make a new header structure
	info->sym = NULL;             // it has no symbol table 
	in = new Bitstream(cmd->bit,BS_INPUT); // open an input file
	
	info->get(cmd,*in);          // fill the bitstream with data from the file
	
	for (i=0;i!=all.num_orc;i++)  // dump out the orchestras
		dump_orc(cmd,info,all.all_orc[i]);
	
	for (i=0;i!=all.num_sco;i++)  // and the scores
		dump_score(cmd,info,all.all_score[i]);
	
	for (i=0;i!=all.num_midi;i++) // and the MIDI files
		dump_midi(cmd,info,all.all_midi[i]);
	
	sa->in_bitstream = in;        // keep track of the bitstream file
	sa->cached_au = (void *)get_next_au(sa);  // cache the first AU
	sa->bit_sym = (void *)info->sym;  // keep track of the bitstream symbol table
	
}

void dump_orc(struct cmdinfo *cmd,StructuredAudioSpecificConfig *info, orc_file *o) {
/* pretty-print the tokenized orchestra O to a text file 
INFO is the whole header -- we need it for the symbol table 
CMD is the command-line information -- that's where the filename is 

  all we really do is dump out the file token-by-token.  We look up
	   symbols in the symbol table to find out their names.*/
	int i,j,line_tok_ct;
	int indent =0;
	FILE *fp;
	
	// open the file where we're going to put the orch
	if (!(fp = fopen(cmd->orc,"w"))) {
		printf("Couldn't write temporary orc file.\n");
		exit(1);
	}
	
	// go through all of the tokens
	line_tok_ct = 0;
	for (i=0;i!=o->length;i++) {
		line_tok_ct++; 
		if (line_tok_ct > 20) { // break line
			 fprintf(fp,"\n");
			 for (j=0;j!=indent+5;j++) fprintf(fp," ");
			 line_tok_ct = 0;
			 }
		switch(o->data[i].token) {
    			
		case TOK_SYMBOL:  // it's a symbol, which is either a pointer to a sample, or a name
			// look for the symbol in the list of samples
			if (isSample(o->data[i].sym.sym)) // if it is a sample,
				// print out a pointer to the file where we dumped the sample (YYY)
				fprintf(fp,"\"%s%csamp_%d.aif\"",cmd->temp,DIRSEP,o->data[i].sym.sym);
			else { // not a sample, print out the symbol name
				fprintf(fp,"%s ",info->sym->ref(o->data[i].sym));
			}
			break;
			
		case TOK_NUMBER: // it's a floating-point number
			fprintf(fp,"%lg ",o->data[i].val);
			break;
			
		case TOK_INT: // it's an integer value
			fprintf(fp,"%d ",o->data[i].ival);
			break;
			
		case TOK_STRING: // it's a string constant, dump it out
			fprintf(fp,"\"");
			for (j=0;j!=o->data[i].length;j++) fprintf(fp,"%c ",o->data[i].str[i]);
			fprintf(fp,"\" ");
			break;
			
		case TOK_BYTE: // it's a byte value
			fprintf(fp,"%d ",o->data[i].ival);
			break;
			
		case TOK_EOO: // it's the end of the orchestra 
			fprintf(fp,"\n");
			break;
			
		default: // it's a reserved word, punctuation mark, core opcode, or ctg.
			// look up the string version in the table (in saol_tok_table.h)
			fprintf(fp,"%s ",tok_str(o->data[i].token));
			
			// this is all just pretty-printing
			switch(o->data[i].token) {
			case TOK_LC :  // a '{' symbol
				indent += 2;  // indent and start newline
				fprintf(fp,"\n");
				for (j=0;j!=indent;j++) fprintf(fp," ");
				break;
			case TOK_RC :  // a '}' symbol
				indent -= 2;  // unindent and newline
				fprintf(fp,"\n"); 
				for (j=0;j!=indent;j++) fprintf(fp," ");
				// if this ends a major block, extra newline
				if (!indent) fprintf(fp,"\n");
				break;
			case TOK_SEM: // a ';' symbol
				fprintf(fp,"\n"); // newline and indent
				for (j=0;j!=indent;j++) fprintf(fp," ");
				break;
			}
		}
	}
	fclose(fp);
}

void dump_score(struct cmdinfo *cmd,StructuredAudioSpecificConfig *info, score_file *s) {
	/* dump the tokenized score file S out in textual format. */
	int i,j;
	FILE *fp;
	
	/* open the file */
	if (!(fp = fopen(cmd->sco,"w"))) {
		printf("Couldn't write temporary score file.\n");
		exit(1);
	}
	
	/* go through each line */
	for (i=0;i!=s->num_lines;i++) {
		switch (s->lines[i]->type) {
			
		case 0 : /* an instrument line (there should really be an enum for these cases) */
			// see if the line has a label
			if (s->lines[i]->inst.has_label)
				// yes, print out the label-symbol name
				fprintf(fp,"%s: ",info->sym->ref(s->lines[i]->inst.label));
			// the event time
			fprintf(fp,"%lf ",s->lines[i]->time);
			// the instrument name
			fprintf(fp,"%s ",info->sym->ref(s->lines[i]->inst.iname_sym));
			// the duration
			fprintf(fp,"%lf ",s->lines[i]->inst.dur);
			// all the pfield values
			for (j=0;j!=s->lines[i]->inst.num_pf;j++)
				fprintf(fp,"%lf ",s->lines[i]->inst.pf[j]);
			fprintf(fp,"\n");
			break;

		case 1: /* a control line */
			// print out the time
			fprintf(fp,"%lf ",s->lines[i]->time);
			// the label, if the line has one
			if (s->lines[i]->control.has_label)
				fprintf(fp,"%s ",info->sym->ref(s->lines[i]->control.label));
			// the "control" tag and the controller name
			fprintf(fp,"control %s ",info->sym->ref(s->lines[i]->control.varsym));
			// the new value
			fprintf(fp,"%lf\n",s->lines[i]->control.value);
			break;

		case 2: /* a table line */
			// print out the time and the 'table' tag
			fprintf(fp,"%lf table ",s->lines[i]->time);
			// the table name
			fprintf(fp,"%s ",info->sym->ref(s->lines[i]->table.tname));
			// the table generator (a builtin token name)
			fprintf(fp,"%s ",tok_str(s->lines[i]->table.tgen));
			// all the parameters
			for (j=0;j!=s->lines[i]->table.num_pf;j++) {
				score_line *sl = s->lines[i];
				if (j == 1 && sl->table.refers_to_sample)
					fprintf(fp,"samp_%d.aif ",sl->table.table_sym.sym);
				else
					fprintf(fp,"%lf ",sl->table.pf[j]);
			}
			fprintf(fp,"\n");
			break;

		case 4: /* an end line */
			fprintf(fp,"%lf end\n",s->lines[i]->time);
			break;

		case 5: /* a tempo line */
			fprintf(fp,"%lf tempo %lf\n",s->lines[i]->time,s->lines[i]->tempo.tempo);
			break;

		}
	}
	fclose(fp);
}

void dump_midi(struct cmdinfo *cmd,StructuredAudioSpecificConfig *info, midi_file *m) {
	/* dumping a MIDI file is easy, since a MIDI file is just a block of
	   data */
	int i;
	FILE *fp;
	
	if (!(fp = fopen(cmd->midi,"wb"))) {
		printf("Couldn't write temporary MIDI file.\n");
		exit(1);
	}
	
	for (i=0;i!=m->length;i++)
		fputc(m->data[i],fp);
	fclose(fp);
}


/* this is what to do on a bitstream-parsing error (nothing much!) */
void flerror(char *s) { printf("%s",s); exit(1); }

int isSample(int sym) {
/* check if a symbol is the name of some sample (maybe would be better integrated
   into the bitstream symbol table) */
	int i;
	
	for (i=0;i!=samp_ct;i++)
		if (samp_table[i] == sym) return 1;
		return 0;
}



extern "C" {
	void receive_au(sa_decoder *sa) {
	/* in a real streaming system, this is where we'd talk to the
	   systems layer.  Here, we always cache the next AU out of
	   the file (the first one was cached at startup in process_bitstream()).  
	   At each time step, if it's time for the cached 
	   AU (by DTS, not event time if it's present), we dispatch
	   it and any more that need to be dispatched.  When we find
	   the first one that is in the future, we cache it and
		return. */
		
		Bitstream *in = (Bitstream *)sa->in_bitstream;
		event *ev;
		SA_access_unit *au;
		int i;
		
		if (sa->cached_au == NULL) return; /* no mo' events */
		au = (SA_access_unit *)sa->cached_au;
		
		if (au->dts > sa->sched->time) return; /* not time */
		
		/* otherwise, the cached AU is ready to be dispatched */
		
		
		while (au) {
			
			
			for (i=0;i!=au->num_events;i++) {
				/* many events in one AU */
				if (!(ev = (event *)malloc(sizeof(event))))
					runtime(sa,"Couldn't make event in receive_au.");

				switch (au->events[i]->event_type) {
				case 0: /* score line */
				/* In a real streaming system, the event might have 
				arrived late -- the use_if_late bit needs to be inspected
					per SC 5.7.3.3.8 */
					
					if (au->events[i]->score_ev.has_time)
						ev->time = au->events[i]->score_ev.time;
					else
						ev->time = sa->sched->time; /* use right now */
					
					/* make an event from the AU */
					decode_score_au(sa,ev,&au->events[i]->score_ev);
					/* send the event to the scheduler */
					schedule_event(sa,ev);					
					break;
					
				case 1: /* midi_event */
					ev->time = sa->sched->time;
					if (decode_midi_au(sa,ev,&au->events[i]->midi_ev))
					/* send the event to the scheduler */
						schedule_event(sa,ev);	
					break;
					
				case 2: /* sample */
					ev->time = sa->sched->time;
					decode_sample_au(sa,&au->events[i]->samp);
					break;
				}
				

			}
			au = get_next_au(sa);
			
			/* this works because AUs are guaranteed to be in order */
			
			if (au && au->dts > sa->sched->time) {
				sa->cached_au = (void *)au;
				au = NULL;
			}
		}
	}
	
}

void decode_score_au(sa_decoder *sa,event *ev,score_line *sl) {
	/* make a scheduler event out of an AU */
	instr_event *inst;
	control_event *ctrl;
	table_event *table;
	int i;
	char s[800];
	
	ev->name = NULL;
	ev->label = NULL;
	ev->dur = 0;
	ev->val = NULL;
	ev->h = NULL;
	ev->numval = 0;
	ev->type = -1;
	ev->ext = 0;

	if(sa->dump_au == NULL) {
		sprintf(s,"%s%ctemp_au.sas",sa->cmd->temp,DIRSEP);
		// open the file where we're going to put the decoded access units
		if (!(sa->dump_au = fopen(s,"w"))) {
			printf("Couldn't write temporary au file.\n");
			exit(1);
		}
	}
	
	switch (sl->type) {
	case 0: /* instr event */
		inst = &sl->inst;
		
		if (inst->has_label) {
			ev->label = get_bitstream_sym_name(sa,inst->label);
			// and dump it to the temporary file
			fprintf(sa->dump_au,"%s: ",ev->label);
		}
		// dump event time
		fprintf(sa->dump_au,"%lf ",ev->time);
		ev->name = get_bitstream_sym_name(sa,inst->iname_sym);
		fprintf(sa->dump_au,"%s ",ev->name);
		ev->dur = inst->dur;
		fprintf(sa->dump_au,"%lf ",ev->dur);
		ev->numval = inst->num_pf;
		if (!(ev->val = (sa_real *)malloc(ev->numval * sizeof(sa_real))))
			if (ev->numval) 
			  runtime(sa,"Couldn't allocate memory in decode_score_au().");
		for (i=0;i!=ev->numval;i++) {
			ev->val[i] = inst->pf[i];
			fprintf(sa->dump_au,"%lf ",ev->val[i]);
		}
		ev->type = INSTR_EVENT;
		fprintf(sa->dump_au,"\n");
		break;
		
	case 1: /* control event */
		ctrl = &sl->control;

		// dump event time
		fprintf(sa->dump_au,"%lf ", ev->time);

		if (ctrl->has_label) {
			ev->label = get_bitstream_sym_name(sa,ctrl->label);
			// dump label, if one
			fprintf(sa->dump_au,"%s ",ev->label);
		}
		ev->name = get_bitstream_sym_name(sa,ctrl->varsym);
		// dump "control var_name"
		fprintf(sa->dump_au,"control %s ",ev->name);
		ev->numval = 1;
		if (!(ev->val = (sa_real *)malloc(sizeof(sa_real))))
			runtime(sa,"Couldn't allocate memory in decode_score_au().");
		ev->val[0] = ctrl->value;
		// dump new value
		fprintf(sa->dump_au,"%lf\n",ctrl->value);
		ev->type = CONTROL_EVENT;
		break;
		
	case 2: /* table event */
		ev->type = TABLE_EVENT;
		table = &sl->table;
		// dump time and " table "
		fprintf(sa->dump_au,"%lf table ",ev->time);
		
		ev->name = get_bitstream_sym_name(sa,table->tname);
		fprintf(sa->dump_au,"%s ",ev->name);

		if (table->destroy) { /* XXX */
			fprintf(sa->dump_au,"destroy\n");
		}
		else {
			ev->sampname = NULL;

			ev->label = tok_str(table->tgen);
			fprintf(sa->dump_au,"%s ",ev->label);
			ev->numval = table->num_pf;
			if (!(ev->val = (sa_real *)malloc(sizeof(sa_real) * ev->numval)))
				runtime(sa,"Couldn't allocate memory in decode_score_au().");
			for (i=0;i!=ev->numval;i++) {
				ev->val[i] = table->pf[i];
				if (i == 1 && table->refers_to_sample) {
					char fn[80];

					sprintf(fn,"%s%csamp_%s.aif",sa->cmd->temp,DIRSEP,get_bitstream_sym_name(sa,table->table_sym));
					ev->sampname = strdup(fn);
					fprintf(sa->dump_au,"%s ",ev->sampname);
				}
				else {
					fprintf(sa->dump_au,"%lf ",ev->val[i]);
				}
			}
			fprintf(sa->dump_au, "\n");
		}
		
		break;	
		
	case 4: /* end event */
		ev->type = END_EVENT;
		fprintf(sa->dump_au,"%lf end\n",ev->time);
		/* don't need to do anything */
		break;
		
	case 5: /* tempo event */
		ev->numval = 1;
		if (!(ev->val = (sa_real *)malloc(sizeof(sa_real))))
			runtime(sa,"Couldn't allocate memory in decode_score_au().");
		ev->val[0] = sl->tempo.tempo;
		// dump line
		fprintf(sa->dump_au,"%lf tempo %lf\n", ev->time, sl->tempo.tempo);

		break;
	}
}

int decode_midi_au(sa_decoder *sa, event *ev, midi_event *mid) {
	/* this is ugly -- it's too much like the SMF parsing code in 
	   saol_midi.c.  The two functions should be unified somehow.
	
	  return 1 iff we actually got a useful event */

	unsigned char evtype;
	
	evtype = mid->data[0];
	
	switch (evtype) {
	case 0xF0:
	case 0xF7: /* sysex */
		/* skip */
		return 0;
		break;
	
	default: /* MIDI message */
		
		switch (evtype & 0xF0) { /* test high nybble */
		case 0x80 : /* noteoff */
			make_midi_au_event(ev,MIDI_OFF_EVENT,(evtype & 0x0F) + 1,mid->data[1],mid->data[2]);
			break;
		case 0x90 : /* noteon */
			make_midi_au_event(ev,MIDI_ON_EVENT,(evtype & 0x0F) + 1,mid->data[1],mid->data[2]);
			break;
		case 0xA0 : /* aftertouch */
			make_midi_au_event(ev,MIDI_TOUCH_EVENT,(evtype & 0x0F) + 1,mid->data[1],mid->data[2]);
			break;
		case 0xB0 : /* control */
			make_midi_au_event(ev,MIDI_CONTROL_EVENT,(evtype & 0x0F) + 1,mid->data[1],mid->data[2]);
			break;
		case 0xC0 : /* program change */
			make_midi_au_event(ev,PROGRAM_CHANGE_EVENT,(evtype & 0x0F) + 1, mid->data[1],-1);
			ev->numval = 2;
			break;
		case 0xD0 : /* channel touch */
			make_midi_au_event(ev,MIDI_CTOUCH_EVENT,(evtype & 0x0F) + 1, mid->data[1],-1);
			ev->numval = 2;
			break;
		case 0xE0 : /* pitch wheel */
			make_midi_au_event(ev,MIDI_PITCH_EVENT,(evtype & 0x0F) + 1, mid->data[1],-1);
			ev->numval = 2;
			break;
		default : /* running status -- use channel and type from last event */
			if (!(evtype & 0x80)) {
				/* NB evtype is actually the first data byte */
				make_midi_au_event(ev,sa->last_midi_type,sa->last_midi_ch,evtype,mid->data[1]);
				if (ev->type == MIDI_OFF_EVENT && ev->val[2] == 0)
					ev->type = MIDI_ON_EVENT;
			}
			else {
				if (sa->verbose) printf("Can't deal with MIDI event 0x%x.\n",evtype);
			}
		}
		sa->last_midi_type = ev->type; /* keep track of last type */
		if (sa->last_midi_type == MIDI_OFF_EVENT) sa->last_midi_type = MIDI_ON_EVENT;
		sa->last_midi_ch = (int)ev->val[0]; /* and last channel */
		
		return 1;
		break;
	}
}

int get_vlq_length(unsigned char *buf,int *len) {
	/* some MIDI data (for example, delta-times) are stored as 
	   variable-length quantities.  Get a VLQ. */
	unsigned char c;
	int val = 0, ct = 0;
	
	/* dummy to start */
	c = (unsigned char)0xFF;
	while (c & 0x80) {  /* if the high bit of the last byte is set */
		c = buf[ct++];  /* get another character */
		val = (val << 7) | (c & 0x7F); /* the low seven bits get added in */
	}
	*len = ct;
	return val;
}



void make_midi_au_event(event *ev, long type,int channel, int note, int val) {
	/* make some other kind of midi event, with three params */

	ev->numval = 3;
	ev->type = type;
	ev->val = (sa_real *)calloc(3,sizeof(sa_real));
	ev->val[0] = (sa_real)channel;
	ev->val[1] = (sa_real)note;
	ev->val[2] = (sa_real)val;
				
	if (type == MIDI_ON_EVENT && val == 0) ev->type = MIDI_OFF_EVENT;
}
	

void decode_sample_au(sa_decoder *sa, sample *samp) {
	// samp is a sample to be processed
	char fn[80];

	sprintf(fn,"%s%csamp_%s.aif",sa->cmd->temp,DIRSEP,
		get_bitstream_sym_name(sa,samp->sample_name_sym));
	samp->save(fn);
}

SA_access_unit *get_next_au(sa_decoder *sa) {
	/* get the next AU from the bitstream file */
	SA_access_unit *au = new SA_access_unit;
	
	au->get(*(Bitstream *)sa->in_bitstream,sa->cmd);
	if (au->out_of_data)
		return NULL;
	else return au;
}

char *get_bitstream_sym_name(sa_decoder *sa,sa_symbol s) {
	/* given a symbol S, get the name of the symbol from the bitstream 
	   symbol table */
	sa_symtable *sym;
	char *name;
	
	/* if the decoder has a bitstream symbol table */
	if (sa->bit_sym) {
		sym = (sa_symtable *)sa->bit_sym;
		return(sym->ref(s)); /* look up the symbol table */
	}
	else { /* no bitstream symbol table */
		name = new char [40];
		sprintf(name,"_sym_%d",s.sym); /* make a fake name */
		return name;
	}
}
