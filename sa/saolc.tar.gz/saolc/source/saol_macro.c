/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#include <string.h>
#include <stdlib.h>
#include "saol.h"
#include "saol_co_imp.h"
#include "saol.tab.h"
#include <malloc.h>

/* saol_macro.c : macro-expand the user-defined opcodes into the instruments.

  This module is very complicated, but is central to the operation of the
  saolc preprocessor.  It converts the orchestra, which contains user-defined
  opcodes in addition to instruments, into a list of instruments, by 
  macro-expansion.  This is always possible because recursive and mutually
  recursive opcodes are not permitted. (5.8.6.7.6).
  
	The module functions through a complicated recursive-descent renaming
	process.  We traverse the call graph and rename each variable in each
	opcode according to where it is called.  Then we macro-paste the 
	UDO into the caller.  This process is further complicated by
	the interaction with opcode arrays and array variables.

  The basic idea is that we have an instrument that calls a UDO:
   
	instr inst1(p1) {
	  asig x;

      x = foo(p1 * 3);
	  output(x);
	}


   The UDO has some code:

    aopcode foo(asig x) {
	  asig y;

      y = x * 4;
	  return(y * y * 12);
   }

   We want to paste the UDO code into the instrument:

    instr inst1(p1) {
	   asig x, __foo_x, __foo_y;
	   
	   __foo_x = p1 * 3;
	   __foo_y = _foo_x * 4;
	   __foo_rtn = _foo_y * foo_y * 12;
	   x = __foo_rtn;

       output(x);

  This gets complicated fast if there's lots of UDO calls and especially if
  there's oparrays and calls with vector returns.

*/

/* a NAME MAP keeps track of all the renaming that has been done 
for a particular UDO.  */

typedef struct name_map_struct {
	char *namehead;  /* the current prefix used for renaming */
	struct name_map_elem_struct *names; /* all of the names in the UDO */
	int size; /* the number of names in the UDO */
} name_map;

/* each ELEMENT of the NAME MAP keeps together the data that is needed
to figure out the new name, new opcode width, and new array width 
for each variable */

typedef struct name_map_elem_struct {
	char *orig; /* the original name of a variable */
	char *newn; /* the new name of a variable */
	expr *exprn; /* the new index expression for the variable */
	int opwidth;
	long rate; /* the new rate of the variable */
	int width; /* the new width of the variable */
} name_map_elem;

/* an OPARRAY_COUNT_LIST keeps track of the renumbering of oparray instances
   as we descend through scopes */

typedef struct oparray_count_list {
	char *name;
	int count;
	int oldcount;
	struct oparray_count_list *next;
} oparray_count_list;

block *macro_expand_block(symtable *,instr_decl *,block *, block *, name_map *, symtable *,
						  char *, int *, expr *, int,long,long,oparray_count_list *);
expr *has_user_opcode(statement *,int);
expr *has_user_opcode_expr(expr *, int *);
void macro_expand_expr(instr_decl *, expr *, name_map *, symtable *, expr *, int,
					   oparray_count_list *);
name_map *add_name_map(symtable *,name_map *, expr *, int, expr *, expr **,int,instr_decl *,
					   oparray_count_list *);
void replace_macro_name(expr *, symtable *,name_map *,instr_decl *id,expr *,int,
						oparray_count_list *);
expr *fake_md_array(expr *x, int xw, expr *y);
void cleanup_opcalls(instr_decl *);
void walk_block_mark_opcall(block *b, int *);
void walk_expr_mark_opcall(expr *, int *);
extern void block_rate(sa_decoder *, symtable *, block *, int, long, long);
expr *number(int);
oparray_count_list *ocl_all_oparrays(symtable *);
void add_oparray(oparray_count_list **, char *, int);
oparray_count_list *oparray_in_list(oparray_count_list *, char *);
oparray_count_list *copy_ocl(oparray_count_list *);

void macro_expand(sa_decoder *sa) {
	/* put the opcodes into the instruments */
	instr_list *il;
	oparray_count_list *ocl;
	int ct = 0;
	
	for (il=sa->all->il;il;il=il->next) {
		/* go through all the instruments */
		
		if (sa->verbose) { /* dump out the original code */
			printf("------------------------------------\n");
			print_block(il->i->code);
			printf("------------------------------------\n");
		}
		

		/* remember all the oparrays the instrument uses */
		ocl = ocl_all_oparrays(il->i->sym);

		/* macro-expand the main code block of the instrument */
		il->i->code = macro_expand_block(il->i->sym, il->i, il->i->code, NULL,
			NULL,il->i->sym,NULL,&ct,NULL,1,0,0,ocl);
		
		/* remove any symbols that are unused in the demacroized instrument. */  
		remove_unused_symbols(sa,il->i,il->i->sym);
		
		/* count and link all the remaining (core) calls to opcodes so we 
		   allocate state space for them later */
		cleanup_opcalls(il->i);
		
		if (sa->verbose) print_block(il->i->code); /* dump out the new code */
		if (sa->verbose) dump_sym_table(il->i->sym); /* dump out the symbol table */
	}
}


block *macro_expand_block(symtable *outer,
						  instr_decl *id, block *b, block *jump,
						  name_map *nm, symtable *t, char *lvalue,
						  int *ct, expr *index, int maxindex, long xopcoderate,
						  long guardrate, oparray_count_list *ocl) {
	
 /* Replace all the local variables and formal parameters in a code block 
 with new names.  This is the main function of the macro expansion routine.
 
  OUTER is the symbol table of the instrument that contains this block.
  ID is the instrument declaration of the containing instrument
  BLOCK is a block of code to macro-expand
  JUMP is the basic block we go to after this one
  NM is the name map that corresponds to the caller
  T is the symbol table of the caller (only one frame above, where
  OUTER is the topmost frame)
  LVALUE will be used to hold the name of the expression that
  substitutes for a call to "return"
  CT is the number of UDOs we've substituted so far (passes up the
  recursion as well as down)
  INDEX
  MAXINDEX is the number of times we're instantiating this code 
  block; it's the product of the oparray widths above us in the
  calling tree.
  XOPCODERATE is the real rate of XSIG variables in this block
  GUARDRATE is the rate of a guard expression containing this block
  OCL is the current list of all the oparray counts above us
  
   We have to do the following things:
   -- go through all the statements in the block
   -- for each statement, if it has UDOs, then
   - make a new variable for the 'return' of the UDO
   - figure out the new names of all the local variables in the UDO
   - turn the UDO parameters into assignments if they're call-by-value
   - make a new code block containing the UDO code
   - in the new code block (recursive call)
   - replace all the local variables and formal parameters 
   with their new names
   - expand any UDOs
   - paste the new code block in, in place of the UDO call.
   - add jumps corresponding to "return" statements in the new code
   - add a second version of the code if the statement is a 'while' loop
   - replace all the local variables and formal parameters
   with their new names
   
	Whee, it's complicated!  
								
	*/
	
	statement *p,*newst;
	block *last,*first,*opc,*newb,*hold,*hold2,*pos,*oldjump;
	expr *op,*newindex,*newe,*idx,*idx2;
	char s[800];
	symbol *sym;
	int linect,newmax,i,j,pct,lastj;
	long newtype,fastest,temp;
	symbol *newsym;
	name_map *new_nm;
	opcode_decl *decl;
	formalparam_list *fpl;
	exprlist *actl,*el,*lastel;
	oparray_count_list *this_ocl;
	
	first = b;  /* keep track of the beginning of the block */
	
	this_ocl = copy_ocl(ocl);	
	/* go through all of the statements in the block */
	for (b,last = NULL;b;last = b,b=b->next) {
		
		linect = 0;
		
		/* fix the rate of this statement */
		if (b->st->rate == XSIG) b->st->rate = xopcoderate;

		/* has_user_opcode() successively returns each of the calls to UDOs
		in a statement and all its subexpressions */
		while (op = has_user_opcode(b->st,linect)) {
			
			/* OP is a UDO expression */
			
			linect++; /* just housekeeping for the has_user_opcode() iterator */
			
			/* make a new variable for the 'return' of the UDO */
			sprintf(s,"__rtn%d",*ct); /* its name is '__rtnXX' for the XXth UDO in the instrument */
			
			op->opdummy = strdup(s);  /* holds the name for the recursive call */
			
			/* this is the code of the the opcode */
			decl = (opcode_decl *)op->defn->defn;
			
			/* this is the list of symbols defined in the opcode */
			sym = op->defn;
			
			/* figure out the type of the 'return' variable based on the rate of the opcode */
			switch (sym->type) {
			case IOPCODE: newtype = IVAR; break;
			case KOPCODE: newtype = KSIG; break;
			case AOPCODE: newtype = ASIG; break;
			case OPCODE: newtype = xopcoderate; break; /* YYY */
			default: printf("Unknown type in macro_expand_block!");
			}
			
			/* add the new symbol to the symbol table of the instrument */
			newsym = add_sym_table_name(outer,s,newtype,NULL);
			newsym->imported = 0;  /* it's not imported */
			newsym->exported = 0;  /*      or exported */
			newsym->glink = NULL;  /*      or global */
			newsym->binding = LOCAL;  /* it's a nice local variable */
			newsym->mark = 1;      /* we've seen it (don't remove it in remove_unused_symbols()!) */
			
			/* figure out the number of values returned from various instances of the opcode */
			newmax = maxindex;     /* at least as many as this block */
			if (op->op == OPARRAY)  /* but if the UDO is an oparray, */
				newmax *= op->oparray_defn->width;  /* it's times the width of the oparray */
			newsym->width = newmax * decl->width;   /* and it's always times the return width of the UDO */
			
			/* so if we call an oparray foo[3], and each instance of foo() returns 6 values, and
			the current block is being instanced four times, then the new variable (and new block)
			has 4 * 3 * 6 = 72 values */
			
			/* figure out the new names for all the local variables in the UDO */
			
			/* update the name map by adding all the new variable names. 
			   this also adds the UDO symbols to the instrument symbol table */
			new_nm = add_name_map(outer,nm,op,*ct,index,&newindex,newmax,id,ocl);
			
			/* NEWINDEX YYY */
			
			/* keep track of how many substitutions we've done */
			(*ct)++;
			
			/* make two deep copies of the code block of the UDO (we only use 
			one of them unless it's a 'while' statement)*/
			
			hold = copy_block(decl->code);
			hold2 = copy_block(hold);
			
			fastest = 0;  /* we need to keep track of the fastest formal parameter so we
			can assign an xsigrate to the UDO */
			
			/* add assignments for the call-by-value formal parameters --
			for a call  foo(3,4,x*y)  to an opcode  aopcode foo(ksig x1, ksig y2, asig z)
			we get
            foo_x1 = 3;
            foo_y2 = 4;
            foo_z = x * y;
			*/
			
			for (fpl=decl->params,actl=op->params;  /* go through the lists of formal and actual parameters */
			fpl && fpl->fp;
			fpl=fpl->next,actl=actl->next)
				
			/* check if the parameter is call-by-reference (it's call by reference iff
			it's an identifier or an array reference -- 5.8.6.7.6) */
			
			if (fpl->fp && actl->p->op != IDENT && actl->p->op != ARRAYREF) {  /* not call-by-ref */
				
				/* make a new statement: it's an EQ statement with the actual parameter as the rhs expression */
				p = new_statement(EQ,copy_expr(actl->p),NULL);
				
				/* if the rate is XSIG, then the rate of the assignment is the rate of the actual parameter,
				else the rate is the rate of the formal parameter (YYY) */
				
				p->rate = fpl->fp->type != XSIG ? fpl->fp->type :
				p->expr->rate;
				
				/* if the rate of the assignment is slower than the guardrate, then make
				it the guardrate */
				
				if (p->rate < guardrate) p->rate = guardrate;
				
				/* check to see if this the fastest formal parameter */
				if (p->rate > fastest) fastest = p->rate;
				
				/* make the lvalue expression - it's just an identifier */
				p->lvalue = new_expr(NULL,NULL,NULL,IDENT);
				
				/* the original name is the formal parameter (it gets replaced below */
				p->lvalue->d = new_terminal(IDENT,strdup(fpl->fp->n->name));
				
				/* the width is the width of the formal parameter */
				p->lvalue->width = fpl->fp->n->width;
				
				/* replace all the names in the assignment expression (both sides) with their new names */
				macro_expand_expr(id,p->lvalue,new_nm,t,newindex,newmax,ocl);
				macro_expand_expr(id,p->expr,nm,t,newindex,newmax,ocl);
				
				/* add the assignment after the last statement */
				newb = new_block(); /* make a block of one statement containing the new assignment */
				add_block(newb,p);
				
				if (!last) {  /* the current statement is the first one in the block */
					newb->next = first;
					first = newb;
					last = newb;
				} else {     /* the current statement isn't the first one */
					newb->next = last->next;
					last->next = newb;
					last = newb;
				}
			} else { 
            /* all that stuff was if the formal parameter was call-by-value.  if it's
			actually call-by-reference, then it's a simple name replacement.  All 
				we have to do is check if this is the fastest formal parameter */
				temp = (fpl->fp->type != XSIG ? fpl->fp->type : actl->p->rate);
				if (temp > fastest && temp != TABLE) fastest = temp;
			}
			
			/* if we didn't know the xsigrate before, then an xopcode is the rate of the fastest
			actual parameter, as just determined above */
			if (!newsym->type) newsym->type = fastest; 
			
			/* replace names in the code */
			
			/* keep track of the next basic block */

			oldjump = jump;
			
			/* find the end of the codeblock in the UDO */
			jump = b;
			
			/* recursive call: macro expand the codeblock of the UDO

			     JUMP                 becomes the end of the new codeblock
			     NEW_NM          (NM) includes the names from the new UDO
		         DECL->SYM        (T) is the symbol table of the UDO codeblock
			     OP->OPDUMMY (LVALUE) is the name on the lvalue of the 'return' assignment we made
			     CT                   includes the ones we counted
			     NEWINDEX     (INDEX) includes YYY
			     NEWMAX    (MAXINDEX) has the width of the return we calculated above
			     FASTEST   (XSIGRATE) is the fastest actparam 
				 OCL                  passes the oparray information down and pulls it back up

			     others don't change from this iteration*/
			
			hold = macro_expand_block(outer,id,hold,jump,new_nm,decl->sym,op->opdummy,ct,newindex,
				newmax,fastest,guardrate,ocl);

			/* now the code block in HOLD has all its names fixed up right, and
			    all the user-defined opcodes inside it expanded. Note that CT might have
			    changed, so might HOLD.  */

			jump = oldjump;
			
			/* paste the code in: scan through the modified code to find its last statement */
			for (opc=hold;opc && opc->next;opc=opc->next);


			if (opc) { /* o/w, no code in the opcode */
				if (last) { /* link into the middle of this code block */
					opc->next = last->next;
					last->next = hold;
					last = opc;
				} else {   /* the new code block goes at the beginning of this code block */
					opc->next = first;
					first = hold;
				}
			}

			/* for a WHILE, also paste at end of WHILE loop 
			
			      while (udo(foo)) { <block> ; } 
			
			   needs to become
			
			      <block from udo()>
			      udo_return = <return statement from udo()
			      while (udo_return) {
			         <block>
			         <block from udo()>
			          udo_return = <return statement from udo()>
			      }
			
			*/
			if (b->st->type == WHILE) {  /* same thing as above, but at the end of the WHILE */
				oldjump = jump;
				for (jump=hold2;jump && jump->next;jump=jump->next) ;
				
				hold2 =  macro_expand_block(outer,id,hold2,jump,new_nm,decl->sym,
					op->opdummy,ct,newindex,newmax,fastest,guardrate,ocl);
				jump = oldjump;
				for (opc=hold2;opc && opc->next;opc=opc->next);
				if (opc) {
					for (pos=b->st->b;pos && pos->next;pos = pos->next);
					pos->next = hold2;
				}
			}
    }
	
	/* now we have to change the names in each expression in the current statement */

    p = b->st;
    switch (p->type) {
    case EQ:
		/* fix the lvalue */
		/* macro_expand_expr() walks an expression and replaces all the names
		   according to the name_map in NM */
		if (p->lvalue) macro_expand_expr(id,p->lvalue,nm,t,index,maxindex,this_ocl);

		/* the lvalue turned into a standard name; this is bad although not flagged in the text */
		if (p->lvalue && p->lvalue->op == IDENT && is_std_name(p->lvalue->d->iname)) {
			sprintf(s,"Macro expansion makes standard name '%s' an lvalue.",p->lvalue->d->iname);
			parse_error_line(s,p->lineno);
		}
		
		/* we need to run this statement faster to match the guard */
		if (p->rate < guardrate) p->rate = guardrate;

		/* fix up the rvalue */
		macro_expand_expr(id,p->expr,nm,t,index,maxindex,this_ocl);
		break;

    case IF:
    case WHILE:
		/* fix up the guard expression */
		macro_expand_expr(id,p->expr,nm,t,index,maxindex,this_ocl);

		/* fix up the code block */
		p->b = macro_expand_block(outer,id,p->b,jump,nm,t,lvalue,ct,index,maxindex,xopcoderate,
			MAX(p->rate,guardrate),this_ocl);
		break;
		
    case ELSE:
		/* fix up the guard expression and both blocks */
		macro_expand_expr(id,p->expr,nm,t,index,maxindex,this_ocl);
		p->b = macro_expand_block(outer,id,p->b,jump,nm,t,lvalue,ct,index,maxindex,xopcoderate,
			MAX(p->rate,guardrate),this_ocl);
		p->elseb = macro_expand_block(outer,id,p->elseb,jump,nm,t,lvalue,ct,index,maxindex,xopcoderate,
			MAX(p->rate,guardrate),this_ocl);
		break;

    case OUTPUT:
    case OUTBUS:
    case INSTR:
    case SPATIALIZE:
		/* walk down the parameter list and fix up all the expressions */
		for (el = p->params;el && el->p;el=el->next)
			if (el->p) macro_expand_expr(id,el->p,nm,t,index,maxindex,this_ocl);
			break;

    case RETURN:
		/* return is special -- we turn it into an assignment statement with the
		   lvalue given in LVALUE */

		/* first, walk the parameter list and fix all the expressions */

		for (el=p->params;el && el->p; el=el->next)
			macro_expand_expr(id,el->p,nm,t,index,maxindex,this_ocl);

		/* turn the statement into a assignment */
		p->type = EQ;
		if (!p->rate) p->rate = KSIG;
		
		/* count the total number of return values */
		for (pct=0,el=p->params;el && el->p;pct += el->p->width,el=el->next);
		
		/* if the opcode call that we're expanding now is an oparray, then it
		    has passed us an index expression, which is the oparray index. 
			What we do here depends on the number of intrinsic return values 
			from the function and the index expression 
		
		     That is, for an oparray call 
		
		        x = foo[k]();
		
		     where "kopcode foo() { x = 12; return(x,3); }" 
		
		     we want to become
			  
				_foo_x[k] = 12;
				_foo_ret[k][0] = _foo_x[k];
				_foo_ret[k][1] = 3;
				x = _foo_ret[k];

             but there's not really n-dimensional arrays in SAOL, so we have to fake it.
		*/

		if (!index && pct == 1) {

			/* there's no index expression, and only one return value:
			      the lvalue of the assignment expression is just the
				  simple variable name given by LVALUE */

			p->lvalue = new_expr(NULL,NULL,NULL,IDENT);
			p->lvalue->d = new_terminal(IDENT,lvalue);
			p->lvalue->d->sym = get_sym_decl(outer,lvalue);
			p->lvalue->width = 1;

			/* the rhs is the first parameter of the RETURN statement */
			p->expr = p->params->p;

			/* after executing, jump to the end of the code block (since 'return'
		       short-circuits but '=' doesn't) */
			p->jump = jump;
		
		}
		
		if (index && pct == 1) {
			
		    /* there's an index expression, and one return value:
			     the lvalue of the assignment replacing the 'return' is 
			     an array indexed by the old index expression */

			p->lvalue = new_expr(index,NULL,NULL,ARRAYREF);
			p->lvalue->d = new_terminal(IDENT,lvalue);
			p->lvalue->d->sym = get_sym_decl(outer,lvalue);
			p->lvalue->width = 1;
			p->expr = p->params->p;
			p->jump = jump;
		}

		if (!index && pct != 1) {

			/* there's no index expression, but there are multiple return values.
			    we make multiple assignment statements, one for each return value, 
				and hook them into the code block.

			    The multiple return values are some combination of arrays and
				single values:

				   ksig k[4], x, y; ... return(x,x,k,k[2],y);

				has 8 return values:
			
			       _foo_ret[0] = _foo_x;
			       _foo_ret[1] = _foo_x;
				   _foo_ret[2] = _foo_k[0];
				   _foo_ret[3] = _foo_k[1];
				   ...

				NB we don't have to worry about WHILE here since the WHILE loop guard
			    must be single-valued (5.8.6.6.6) */
			
			/* go through all the return values */
			for (i=0;i!=pct;i++) {
				/* find the expression that corresponds to the particular one we're on */
				for (el=p->params,lastj=j=0,lastel=el;j<=i && el;lastj=j,j+=el->p->width,lastel=el,el=el->next);

				/* now LASTEL has the return expression we need */
				if (lastel->p->width > 1) {
					/* figure out which return value we need */
					idx = number(i-lastj);

					/* make an array index (like k[1] in the above comment */
					newe = new_expr(idx,NULL,NULL,ARRAYREF);
					newe->d = copy_terminal(lastel->p->d);
					newe->width = 1;
				} else {

					/* don't need one -- just copy the parameter (like 'x' in the above comment) */
					newe = copy_expr(lastel->p);
				}
				if (i==0) {
					/* first return value -- turn the RETURN statement into the assignment */
					newst = p; p->type = EQ; p->expr = newe;
				}
				else {
					/* make a new assignment and link it into the code block */
					newst = new_statement(EQ,newe,NULL);
					newb = new_block();
					newb->st = newst;
					newb->next = b->next;
					b->next = newb;
				}
				/* make the lhs */
				newst->lvalue = new_expr(NULL,NULL,NULL,ARRAYREF);
				newst->lvalue->d = new_terminal(IDENT,lvalue);
				newst->lvalue->d->sym = get_sym_decl(outer,lvalue);
				newst->lvalue->width = 1;
				newst->rate = p->rate;
				idx = number(i);
				newst->lvalue->left = idx;
			}
			/* jump after the last one */
			newst->jump = jump;
			
		}
		if (index && pct != 1) {
			/* this is the funny case -- it has to go like this:

               m = foo[k]();  ->   return(x,x,k,k[2],y);

               which has to become

                 _foo_ret[k][0] = _foo_x[k];
				 _foo_ret[k][1] = _foo_x[k];
				 _foo_ret[k][2] = _foo_k[k][0];
				 _foo_ret[k][3] = _foo_k[k][1];
		
			it's the same as the previous case, but the indexes of the
			return values and array-return values are multi-dimensional arrays.
			*/
		
			for (i=0;i!=pct;i++) {
				for (el=p->params,lastj=j=0,lastel=el;
				j<=i && el;
				lastj=j,j+=el->p->width,lastel=el,el=el->next);
				if (lastel->p->width > 1) {
					idx = number(i-lastj);
					/* note md array (actually gives us _foo_ret[(k * pct) + i)] */
					newe = fake_md_array(index,pct,idx);
					newe = new_expr(newe,NULL,NULL,ARRAYREF);
					newe->d = copy_terminal(lastel->p->d);
					newe->width = 1;
					
				} else {
					newe = copy_expr(lastel->p);
				}
				if (i==0) {
					newst = p; p->type = EQ; p->expr = newe;
				}
				else {
					newst = new_statement(EQ,newe,NULL);
					newb = new_block();
					newb->st = newst;
					newb->next = b->next;
					b->next = newb;
				}
				newst->lvalue = new_expr(NULL,NULL,NULL,ARRAYREF);
				newst->lvalue->d = new_terminal(IDENT,lvalue);
				newst->lvalue->d->sym = get_sym_decl(outer,lvalue);
				newst->lvalue->width = 1;
				idx2 = number(i);
				/* md array again */
				idx =  fake_md_array(index,pct,idx2); 
				newst->lvalue->left = idx;
			
			}

			newst->jump = jump;
		}
		break;      
    case EXTEND:
		/* just deal with expression */
		macro_expand_expr(id,p->expr,nm,t,index,maxindex,this_ocl);
		break;
    case TURNOFF:
		/* nothing to do here */
		break;
    }
  }
  return first; /* might have changed */
}

expr *has_user_opcode(statement *st,int ct) {
/* if there are at least CT opcode calls embedded in this
	statement (in a depth-first traversal), return the CTth one.  
	If not, return NULL. */
	expr *p;
	exprlist *el;
	
	switch (st->type) {
	case EQ:
		if (st->lvalue && (p = has_user_opcode_expr(st->lvalue,&ct)))
			/* NB ct might have changed (gotten smaller) */
			return p;
		if (p = has_user_opcode_expr(st->expr,&ct))
			return p;
		break;
	case ELSE:
	case IF:
	case WHILE:
		if (p = has_user_opcode_expr(st->expr,&ct))
			return p;
	case EXTEND:
	case RETURN:
		for (el=st->params;el && el->p;el=el->next)
			if (p=has_user_opcode_expr(el->p,&ct))
				return p;
			break;
	case OUTPUT:
	case OUTBUS:
	case INSTR:
	case SPATIALIZE:
		for (el = st->params;el && el->p; el=el->next)
			if (el->p && (p=has_user_opcode_expr(el->p,&ct)))
				return p;
			break;
	}
	return NULL;
}

expr *has_user_opcode_expr(expr *p, int *ct) {
	/* if there are at least CT opcode calls embedded in this
	   epxression, return the CTth one.  return NULL if there are not 
	   at least CT opcode calls embedded in this expression.  */
	expr *p2;
	exprlist *el;
	
	switch (p->op) {
	case IDENT:
	case NUMBER:
	case STRCONST:
		return NULL;
	case UMINUS:
	case LP:
	case NOT:
	case ARRAYREF:
		return(has_user_opcode_expr(p->left,ct));
	case Q:
		if (p2=has_user_opcode_expr(p->left,ct))
			return p2;
		if (p2=has_user_opcode_expr(p->right,ct))
			return p2;
		if (p2=has_user_opcode_expr(p->extra,ct))
			return p2;
		break;
	case LEQ:
	case GEQ:
	case EQEQ:
	case NEQ:
	case GT:
	case LT:
	case AND:
	case OR:
	case PLUS:
	case MINUS:
	case STAR:
	case SLASH:
		if (p2=has_user_opcode_expr(p->left,ct))
			return p2;
		if (p2=has_user_opcode_expr(p->right,ct))
			return p2;
		break;
	case SASBF:
		for (el=p->params;el && el->p;el=el->next)
			if (el->p && (p2=has_user_opcode_expr(el->p,ct)))
				return p2;
			break;
	case OPCALL:
	case OPARRAY:
		if (!is_core_opcode(p->d->iname)) {
			if (!*ct)
				return p;
			(*ct)--;
		}
		for (el=p->params;el && el->p;el=el->next)
			if (el->p && (p2=has_user_opcode_expr(el->p,ct)))
				return p2;
			if (p->op == OPARRAY)
				if (p2 = has_user_opcode_expr(p->left,ct))
					return p2;
				break;
	}
	return NULL;
}


expr *fake_md_array(expr *x, int xw, expr *y) {
/* return [x][y], which is really [x * xw + y], where xw is the
	width of the major dimension */
	expr *e;
	
	if (x) {
		e = number(xw);
		e = new_expr(new_expr(copy_expr(x),e,NULL,STAR),copy_expr(y),NULL,PLUS);
		e->width = 1;
		e->left->width = 1;
	}
	else e = y;
	return e;
}

void macro_expand_expr(instr_decl *id, expr *p,
					   name_map *nm, symtable *t, expr *index, int maxwidth,
					   oparray_count_list *ocl) {
	
	/* replace all the names in the expression with their new names, 
	   according to the name_map NM

	   ID       is the instrument we're in
	   P        is the expression to replace
	   NM       is the name map that tells us what replacements to make
	   T        is the symbol table of the instrument
	   INDEX    is the index of an opcode array expression binding this expression
	   MAXWIDTH is the width of the opcode array binding us 
	   OCL      is the list of all the oparrays we've seen so far
	   
    */
	exprlist *el;
	symbol *newsym;
	oparray_count_list *o;
	
	switch (p->op) { /* most of these are obvious */
	case IDENT:
		replace_macro_name(p,id->sym,nm,id,index,maxwidth,ocl);
		break;
	case NUMBER:
	case STRCONST:
		break;
	case ARRAYREF:
		macro_expand_expr(id,p->left,nm,t,index,maxwidth,ocl);
		replace_macro_name(p,id->sym,nm,id,index,maxwidth,ocl);
		break;
	case SASBF:
		for (el = p->params; el && el->p;el=el->next)
			macro_expand_expr(id,el->p,nm,t,index,maxwidth,ocl);
		break;
	case OPARRAY:

		/* what to do when we are expanding 

           opcode bar() {
             ksig k; 
			 oparray foo[12];
             ...
             ... foo[k](x) ...     ( -> return(x,y,z,w); // 4 return values )
		   }

           in a name map where k -> _bar_k[q] -- that is, bar() itself is
		   being used in an opcode array?

           This has to become:

             ... _bar_foo_ret[_bar_k[q]*4*12:bar_k[q]*4*12+3] ... (Matlab notation)

           We represent this by just having both an index expression *and*
		   a non-unity width for the opcode -- this is illegal in SAOL, but we
		   support it in the array operations in the interpreter.
		*/

		/* first do the index expression ("k" -> _bar_k[q]) */
		macro_expand_expr(id,p->left,nm,t,index,maxwidth,ocl);
		
		if (p->width > 1) {
			/* if the oparray returns multiple values */

			/* now make it _bar_k[q]*4:bar_k[q]*4+3 */
			p->left = new_expr(p->left,number(p->width),NULL,STAR);
			p->left->width = p->left->left->width;
		}

		/* now make it the right answer -- if there's no passed-down index expression,
		   just gives us back p->left */
		p->left = fake_md_array(index,p->oparray_defn->width,p->left);
		
		/* if the same oparray has been used in a scope above us,
		   we have to push forward all of the indices */
		if (o = oparray_in_list(ocl,p->d->iname)) {
			if (o->oldcount) {
				p->left = new_expr(p->left,number(o->oldcount),NULL,PLUS);
			}
		}
		
		if (!is_core_opcode(p->d->iname)) { 
			/* it's a UDO -- replace the opcode call with the return-assignment name */
			p->op = ARRAYREF;
			p->d = new_terminal(IDENT,p->opdummy);
			p->d->sym = get_sym_decl(id->sym,p->opdummy);
			
			for (el=p->params;el && el->p;el=el->next)
				macro_expand_expr(id,el->p,nm,t,index,maxwidth,ocl);
		}
		else {
			/* it's a built-in; it's just a bigger oparray.  do the parameter 
			   expressions (we don't need to do that for the UDO case, since the
			   opcode call is going away */
			for (el = p->params; el && el->p; el=el->next)
				macro_expand_expr(id,el->p,nm,t,index,maxwidth,ocl);
			
			/* attach in the opcode call if it's not already there */
			p->oparray_defn = get_sym_decl_last(id->sym,p->d->iname);
		}
		
		break;
	case OPCALL:
		if (!is_core_opcode(p->d->iname)) { /* is it a UDO? */
			if (index) { /* yes, turn it into an array expression */
				p->op = ARRAYREF;
				p->left = copy_expr(index);
			} else {     /* or just a name */
				p->op = IDENT;
			}            
			/* replace the opcode name with the return assignment name. */
			p->d = new_terminal(IDENT,p->opdummy);
			p->d->sym = get_sym_decl(id->sym,p->opdummy);
			for (el=p->params;el && el->p;el=el->next)
				macro_expand_expr(id,el->p,nm,t,index,maxwidth,ocl);
			/* we deal with the parameters when we de-macroize this opcode call away */
		}
		else  /* it's a built-in opcode */
			if (index) {  /* it might turn into an oparray */
				p->op = OPARRAY;
				p->left = index;
				newsym = add_sym_table_name(id->sym,p->d->iname,OPARRAY,NULL);
				newsym->width = maxwidth; 
				newsym->mark = 1;
				p->oparray_defn = newsym;
			}
			/* deal with the parameters */
			for (el = p->params;el && el->p; el=el->next)
				macro_expand_expr(id,el->p,nm,t,index,maxwidth,ocl);
			break;
	case UMINUS:
	case LP:
	case NOT:
		macro_expand_expr(id,p->left,nm,t,index,maxwidth,ocl);
		break;
	case Q:
		macro_expand_expr(id,p->left,nm,t,index,maxwidth,ocl);
		macro_expand_expr(id,p->right,nm,t,index,maxwidth,ocl);
		macro_expand_expr(id,p->extra,nm,t,index,maxwidth,ocl);
		break;
	case LEQ:
	case GEQ:
	case EQEQ:
	case NEQ:
	case GT:
	case LT:
	case AND:
	case OR:
	case PLUS:
	case MINUS:
	case STAR:
	case SLASH:
		macro_expand_expr(id,p->left,nm,t,index,maxwidth,ocl);
		macro_expand_expr(id,p->right,nm,t,index,maxwidth,ocl);
		break;
	}
}

name_map *add_name_map(symtable *outer,name_map *old,
					   expr *opexp,int opct,expr *index, expr **newindex,
					   int maxwidth,instr_decl *id,oparray_count_list *ocl) {
	
					   /* add all the names in a UDO to a name map 
					   
						OUTER is the symbol table of the instrument we're in.
						OLD   is the name nap to add onto
						OPEXP is the expression containing the call to the UDO
						OPCT  is how many calls to UDOs there have been so far
						INDEX is the index expression attached to a binding oparray
						NEWINDEX will be used to pass back a new index expression
						MAXWIDTH is the total length of a binding oparray expression
						
						 This doesn't just add the names to the map, but
						 adds all the symbols to the instrument symbol table as well.
	*/
	
	name_map *newn;
	int ct = 0;
	opcode_decl *decl;
	symtable *t,*t2;
	symbol *newsym;
	formalparam_list *fpl;
	exprlist *el;
	long fastest;
	expr *e;
	
	/* make a new name map */
	PROT_MAL(newn,name_map,addname_map);
	newn->namehead = (char *)malloc(1000 * sizeof(char));
	
	/* create the prefix for all the names -- all the names start with 
	   _foo_, or _foo_arr_ if it's an oparray, or _..._foo_ if we're
	   deep in a call stack.  */
	
	if (opexp->op == OPARRAY) {
		
		if (old) /* include the old prefix */
			sprintf(newn->namehead,"%s_%s_arr",old->namehead,opexp->d->iname);
		else
			sprintf(newn->namehead,"__%s_arr",opexp->d->iname);
		
		*newindex = fake_md_array(index,opexp->oparray_defn->width,opexp->left);
		
	}
	
	else /* OPCODE */ {
		*newindex = index;
		if (old)
			sprintf(newn->namehead,"%s_%s%d",old->namehead,opexp->d->iname,opct);
		else
			sprintf(newn->namehead,"__%s%d",opexp->d->iname,opct);
	}
	
	/* find the opcode declaration */
	decl = (opcode_decl *)opexp->defn->defn;
	
	/* count up all the local symbols */
	for (t=decl->sym;t && t->s;t=t->next) {
		if (t->s)
			ct++;
	}
	for (fpl = decl->params; fpl && fpl->fp;fpl=fpl->next) ct++;
	
	/* allocate a new name for each local symbol */
	newn->size = ct;
	newn->names = (name_map_elem *)calloc(ct,sizeof(name_map_elem));
	
	ct = 0;
	fastest = 0;
	for (t=decl->sym;t && t->s;t=t->next) { /* go through all symbols */
		if (t->s) {
			newn->names[ct].orig = t->s->name;
			newn->names[ct].newn = NULL;
			
			if (t->s->binding == FORMALPARAM) { /* if it's a fp */
				
				for (t2=decl->sym,el=opexp->params; t2->s != t->s; t2 = t2->next) {
					/* find matching actual param */
					if (t2->s->binding == FORMALPARAM)
						el=el->next; 
				} 
				
				/* EL->P is now the corresponding actual param to the formal param T->S */
				
				if (el->p->op == IDENT || el->p->op == ARRAYREF) { 
					/* call by reference, so the replacement is just the act param expression */
					e = copy_expr(el->p);
					replace_macro_name(e,outer,old,id,index,maxwidth,ocl);
					newn->names[ct].newn = strdup(e->d->iname);
					newn->names[ct].exprn = e->left;
				}
				
			}
			
			/* if it's a standard name, or it's a global variable, don't change the 
			name, but do make sure it's in the symbol table for the instrument */
			if (t->s->binding == STANDARD_NAME
				|| (t->s->binding == LOCAL &&
				(t->s->imported || t->s->exported))){  
				if (!get_sym_decl(outer,t->s->name)) { 
					/* not in symbol table; add it */
					newsym = add_sym_table_name(outer,t->s->name,t->s->type,NULL);
					if (t->s->binding != LOCAL) {
						newsym->width = t->s->width;
						newsym->mark = 0;
					}
					else {
					    newsym->width = t->s->width * maxwidth;
						newsym->mark = 1;
					}
					newsym->imported = t->s->imported; 
					newsym->exported = t->s->exported;
					newsym->glink = t->s->glink;
					newsym->binding = t->s->binding;
				}
				/* don't change the name */
				newn->names[ct].newn = strdup(t->s->name);
			}
			
			
			if (t->s->type == OPARRAY) {
				oparray_count_list *o;
				/* don't change the name, but add it into the instrument symbol table */
				if (o = oparray_in_list(ocl,t->s->name)) {
				/* the oparray was already used in the caller, so we have
					to renumber all the uses in this scope */
					o->oldcount = o->count;
					o->count += t->s->width * maxwidth;
				} else {
					/* add it in the instrument */
					newsym = add_sym_table_name(outer,t->s->name,t->s->type,NULL);
					newsym->width = t->s->width * maxwidth;
					newsym->imported = t->s->imported; 
					newsym->exported = t->s->exported;
					newsym->glink = t->s->glink;
					newsym->mark = 1;
					newsym->binding = t->s->binding;
					add_oparray(&ocl,t->s->name,t->s->width);
				}
				newn->names[ct].newn = strdup(t->s->name);
			}
			if (!newn->names[ct].newn) { /* not any of the above */
				
				/* make space for the new name */
				newn->names[ct].newn =
					(char *)malloc(sizeof(char) *
					(strlen(newn->namehead) + strlen(t->s->name) +2));
				
				/* the new name is the prefix attached to the old name */
				sprintf(newn->names[ct].newn,"%s_%s",newn->namehead,t->s->name);
				
				/* add the new name to the instrument symbol table */
				newsym = add_sym_table_name(outer,newn->names[ct].newn,t->s->type,NULL);
				
				
				if (t->s->type == XSIG && t->s->binding == FORMALPARAM) {
					/* it's a call-by-value formal parameter */
					for (t2=decl->sym,el=opexp->params;
					t2->s != t->s;
					t2 = t2->next)
						if (t2->s->binding == FORMALPARAM)
							el=el->next; /* find matching actual param */
						newsym->type = el->p->rate;
						if (newsym->type > fastest)
							fastest = newsym->type; /* keep track of the fastest formal parameter */
				}
				
				if (newsym->type == XSIG) newsym->type = fastest;
				
				if (t->s->type == TABLE)
					newsym->table = t->s->table; /* just pointer copy the table declaration */
				
				/* the width of the declaration, for each of the opcode states binding this opcode */
				
				newsym->width = t->s->width * maxwidth;
				
				if (t->s->binding != FORMALPARAM) {
					newsym->imported = t->s->imported;
					newsym->exported = t->s->exported;
				}
				newsym->glink = NULL;
				newsym->binding = LOCAL;
				newsym->mark = 1;
				
				if (opexp->op == OPARRAY) { /* oparray */ 
					/* make a note of the oparray index expression */
					newn->names[ct].exprn =
						new_expr(number(t->s->width),copy_expr(*newindex),NULL,STAR);
					newn->names[ct].exprn->width = 1;
				}
			}
			newn->names[ct].rate = t->s->type;
			newn->names[ct].width = t->s->width;
			ct++;
			}
			
			
	}
	return newn;
}


void replace_macro_name(expr *p, symtable *outer,name_map *nm,instr_decl *id,expr *index,int maxwidth,oparray_count_list *ocl) {
	/* p is an ident or an arrayref - replace it according to the name map NM */
	
	int i;
	symbol *sym;
	
	if (!nm) return;

	/* find the old name in the name map */
	for (i=0;i!=nm->size && nm->names[i].orig && strcmp(nm->names[i].orig,p->d->iname);i++);
	if (i >= nm->size || !nm->names[i].orig) {
		sym = get_sym_decl(outer,p->d->iname);
		sym->mark = 1; /* we've seen the name */
		return; /* but no replacement */
	}
	
	/* change the name */
	p->d->iname = nm->names[i].newn;
	/* attach the symbol table entry */
	p->d->sym = get_sym_decl(outer,nm->names[i].newn);
	p->d->sym->mark = 1;

	/* set the rate */
	p->rate = nm->names[i].rate;
	

	/* if there's an oparray index expression, we need to turn names into opcode calls */
 	if (nm->names[i].exprn && !p->d->sym->table && !(p->d->sym->glink && p->d->sym->glink->table)) { 
		p->op = ARRAYREF;
		if (p->left) {
			/* the index is the sum of the array width and the current offset */
			p->left = new_expr(nm->names[i].exprn,p->left,NULL,PLUS);
			p->left->rate = p->left->left->rate;
			p->left->width = 1;
		}
		else
			/* just the array width */
			p->left = fake_md_array(NULL,0,nm->names[i].exprn);
	}
	if (p->left)  /* it's an array */
		macro_expand_expr(id,p->left,nm,outer,index,maxwidth,ocl);
}

void cleanup_opcalls(instr_decl *id) {
	/* this routine is called after all the macro expansion is done.  All we have left to
	   do is count up calls to core opcodes, so that we know how much state space we'll need
	   for this instrument.  There's no more UDOs anymore. */

	symtable *t,*first,*last;
	int ct=0;
	
	last=NULL; first=t=id->sym;
	while (t && t->s) {
		/* go through the symbol table */
		if (t->s->type == OPARRAY) {
			if (is_core_opcode(t->s->name)) {
				/* count up the total oparray width for all oparrays in the instrument */
				t->s->offset = ct;
				ct += t->s->width;
				last = t;
				t=t->next;
			} else { /* left-over old UDO oparray, remove it */
				first = id->sym = remove_sym_table(first,last,&t);
			}
		} else {
			last = t;
			t = t->next;
		}
	}
	
	/* count up all the opcalls in the code block */
	walk_block_mark_opcall(id->code, &ct);

	/* mark the total in the instr decl */
	id->opsize = ct;
	
}

void walk_block_mark_opcall(block *b, int *ct) {
	/* count up all the opcalls in a code block */
	exprlist *el;
	
	for (; b; b=b->next) 
		switch (b->st->type) {
    case EQ:
		if (b->st->lvalue) walk_expr_mark_opcall(b->st->lvalue,ct);
		walk_expr_mark_opcall(b->st->expr,ct);
		break;
    case IF:
    case WHILE:
		walk_expr_mark_opcall(b->st->expr,ct);
		walk_block_mark_opcall(b->st->b,ct);
		break;
    case ELSE:
		walk_expr_mark_opcall(b->st->expr,ct);
		walk_block_mark_opcall(b->st->b,ct);
		walk_block_mark_opcall(b->st->elseb,ct);
		break;
    case EXTEND:
		walk_expr_mark_opcall(b->st->expr,ct);
		break;
    case RETURN:
		interror("return() still left in code.");
		break;
    case OUTPUT:
    case OUTBUS:
    case INSTR:
    case SPATIALIZE:
		for (el = b->st->params;el && el->p; el=el->next)
			walk_expr_mark_opcall(el->p,ct);
		break;
	}
}

void walk_expr_mark_opcall(expr *p, int *ct) {
	/* count up all the opcalls in an expression */
	exprlist *el;
	
	switch(p->op) {
		
	case IDENT:
	case NUMBER:
	case STRCONST:
		break;
	case ARRAYREF: 
	case UMINUS:
	case LP:
	case NOT:
		walk_expr_mark_opcall(p->left,ct);
		break;
	case SASBF:
		for (el = p->params;el && el->p; el = el->next)
			walk_expr_mark_opcall(el->p,ct);
		break;
	case OPARRAY:
		/* don't count oparrays since they live in the symbol table */
		walk_expr_mark_opcall(p->left,ct);
		for (el = p->params;el && el->p; el = el->next)
			walk_expr_mark_opcall(el->p,ct);
		break;
	case OPCALL:
		p->op_offset = (*ct)++; /* found one */
		for (el = p->params;el && el->p; el = el->next)
			walk_expr_mark_opcall(el->p,ct);
		break;
	case Q:
		walk_expr_mark_opcall(p->left,ct);
		walk_expr_mark_opcall(p->right,ct);
		walk_expr_mark_opcall(p->extra,ct);
		break;
	case LEQ:
	case GEQ:
	case EQEQ:
	case NEQ:
	case GT:
	case LT:
	case AND:
	case OR:
	case PLUS:
	case MINUS:
	case STAR:
	case SLASH:
		walk_expr_mark_opcall(p->left,ct);
		walk_expr_mark_opcall(p->right,ct);
		break;
	}
}

expr *number(int x) {
	/* make an expression containing just a number */
	expr *newe;
	terminal *newt;
	char s[100];
	
	newe = new_expr(NULL,NULL,NULL,NUMBER);
	newe->width = 1;
	sprintf(s,"%d",x);
	newt = new_terminal(NUMBER,s);
	set_expr_data(newe,newt);
	return(newe);
}

oparray_count_list *ocl_all_oparrays(symtable *t) {
	oparray_count_list *ocl = NULL;

	for (t; t && t->s; t=t->next) {
		if (t->s->type == OPARRAY)
			add_oparray(&ocl,t->s->name,t->s->width);
	}
	return ocl;
}

void add_oparray(oparray_count_list **ocl, char *name, int width) {
	oparray_count_list *p;

	p = (oparray_count_list *)malloc(sizeof(oparray_count_list));
	p->name = strdup(name);
	p->count = width;
	p->oldcount = 0;
	p->next = *ocl;

	*ocl = p;
}

oparray_count_list *oparray_in_list(oparray_count_list *ocl, char *name) {
	
	for (ocl; ocl; ocl=ocl->next)
		if (!strcmp(ocl->name,name))
			return ocl;

    return NULL;
}

oparray_count_list *copy_ocl(oparray_count_list *ocl) {

	oparray_count_list *end;

	if (!ocl) return NULL;
	else {
		end = copy_ocl(ocl->next);
		add_oparray(&end,ocl->name,ocl->count);
		end->oldcount = ocl->oldcount;
		return end;
	}
}
