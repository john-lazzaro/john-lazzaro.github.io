/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_midi.c : routines for parsing and creating events from MIDI files.
    The only exposed interfaces are parse_midi() and get_next_event(), at the 
	end.  parse_midi() is used when decoding a SMF.  get_next_event() is 
	used when encoding from a SMF into streaming MIDI events.

    The MIDI syntax isn't in the SA spec, but in the MIDI spec, as referenced 
    in the SA spec.  The MIDI spec is available for purchase from the MMA,
    www.midi.org */

#include <stdio.h>

#include "saol_prec.h"
#include "saol_sched.h"
#include "saol.h"

void swapdouble(double *b) {
	/* swap a double from big-endian to little-endian format */
	char *x = (char *)b;
	char t[4];
	
	/* if __BYTE_COHERENT is set, we need to swap MIDI bytes as we 
	   read them.  */
#ifdef __BYTE_COHERENT
	t[0] = x[0];
	t[1] = x[1];
	t[2] = x[2];
	t[3] = x[3];
	x[0] = x[7]; x[1] = x[6]; x[2] = x[5]; x[3] = x[5];
	x[4] = t[3]; x[5] = t[2]; x[6] = t[1]; x[7] = t[0];
#endif
}

void swapint(int *b) {
	/* swap a four-byte value */
	char *x = (char *)b;
	char t1,t2;
	
#ifdef __BYTE_COHERENT
	t1 = x[0];
	t2 = x[1];
	x[0] = x[3];
	x[1] = x[2];
	x[2] = t2;
	x[3] = t1;
#endif
}

void swapshort(short *b) {
	/* swap a two-byte value */
	char *x = (char *)b;
	char t;
	
#ifdef __BYTE_COHERENT
	t = x[0];
	x[0] = x[1];
	x[1] = t;
#endif
}

typedef struct midi_info_struct {
	/* all of the information about the header of a MIDI file */
	short format, ntracks,ticks,fps,res;
} midi_info;

midi_info *get_header(sa_decoder *sa, FILE *fp, char *fn) {
	/* get the header from the file FP (name FN just used for error methods) */
	char buf[20];
	int *ibuf = (int *)buf;
	short *sbuf = (short *)buf;
	signed short sgfps;
	short division;
	char s[800];
	int ct;
	midi_info *m = (midi_info *)malloc(sizeof(midi_info));
	
	/* read the header ID -- four bytes, should be "MThd" */

	ct = fread(buf,1,4,fp);
    buf[ct] = 0;
    
	if (ct != 4 || strcmp("MThd",buf)) {
		sprintf(s,"'%s' is not a MIDI file (got header ID '%s', length %d)",fn,buf,ct);
		runtime(sa,s);
	}
	
	/* read the size of the header chunk (should be 6) */
	ct = fread(buf,1,4,fp);
	swapint((int *)buf);
	if (ct != 4 || *ibuf != 6) {
		sprintf(s,"Got bad header size in '%s' (%d) (%d)",fn,ct,*ibuf);
		runtime(sa,s);
	}
	
	/* get the format (should be 0 or 1) */
	ct = fread(buf,1,2,fp);
	swapshort((short *)buf);
	m->format = *sbuf;
	if (ct != 2 || m->format < 0 || m->format > 2) {
		sprintf(s,"Got bad format in '%s' (%d).",fn,m->format);
		runtime(sa,s);
	}
	if (m->format == 2) {
		runtime(sa,"Can't deal with SMF format 2.");
	}
	
	/* get the number of tracks */
	ct = fread(buf,1,2,fp);
	swapshort((short *)buf);
	m->ntracks = *sbuf;
	
	if (ct != 2 || m->ntracks < 0) {
		sprintf(s,"Got bad ntracks in '%s' (%d).",fn,m->ntracks);
		runtime(sa,s);
	}
	
	/* get the division (ticks/sec) */
	ct = fread(buf,1,2,fp);
	swapshort((short *)buf);
	division = *sbuf;
	
	if (ct != 2) {
		sprintf(s,"Got bad division in '%s'",fn);
		runtime(sa,s);
	}
	
	/* if high bit is set XXX */
	if (!(division & (1 << 15))) {
		m->ticks = division;
		m->fps = 0;
		m->res = 0;
	}
	else {
		sgfps = (division & 0x7F00) >> 8;
		m->fps = -sgfps;
		
		m->res = (division & 0x00FF);
		m->ticks = 0;
	}
	
	return m;
}

int get_vlq(FILE *fp) {
	/* some MIDI data (for example, delta-times) are stored as 
	   variable-length quantities.  Get a VLQ. */
	char c;
	int val = 0;
	
	/* dummy to start */
	c = (char)0xFF;
	while (c & 0x80) {  /* if the high bit of the last byte is set */
		c = fgetc(fp);  /* get another character */
		val = (val << 7) | (c & 0x7F); /* the low seven bits get added in */
	}
	return val;
}


int get_vlq_string(FILE *fp, char **d) {
	/* some MIDI data (for example, delta-times) are stored as 
	   variable-length quantities.  Get a VLQ.  Also return the 
	   data back to the caller */
	char c;
	char buf[20];
	int ct=0;
	int val = 0;
	
	/* dummy to start */
	c = (char)0xFF;
	while (c & 0x80) {  /* if the high bit of the last byte is set */
		c = fgetc(fp);  /* get another character */
		buf[ct++] = c;
		val = (val << 7) | (c & 0x7F); /* the low seven bits get added in */
	}
	buf[ct] = 0;
	*d = strdup(buf);
	return val;
}

#ifndef _SAENC
event *midi_tempo_event(sa_real,int);
event *make_midi_event(long,sa_real,int,int,int);

int get_midi_event(sa_decoder *sa, midi_info *m, FILE *fp, sa_real *last) {
	/* get a midi event from the file, decode it, and send it to the scheduler. 
	   return 1 on end-of-track, 0 otherwise */
	int delta,length;
	int data;
	unsigned char evtype,mtype,junk;
	event *ev = NULL;
	static int last_ch = -1;
	static int last_type = -1;
	static int buflen;
	static char *buf;
	
	/* if first call, initialize buffers */
	if (last_ch == -1) {
		buflen =0;
		buf = NULL;
	}
	
	/* get the delta-time */
	delta = get_vlq(fp);

	/* figure out how much time it corresponds to */
	if (m->ticks) {
		*last += (sa_real) delta / m->ticks/2;
	} else
		*last += (sa_real) delta / m->fps / m->res;
	
	/* get the event type */
	evtype = fgetc(fp);
	
	switch (evtype) {
	case 0xF0:
	case 0xF7: /* sysex */
		/* get the sysex length */
		length = get_vlq(fp);
		/* maybe have to make the buffer longer */
		if (length > buflen) {
			buf = (char *)realloc(buf,length);
			buflen = length;
		}
		/* get the sysex, but skip it */
		fread(buf,1,length,fp);
		break;
		
	case 0xFF: /* meta event */
		mtype = fgetc(fp); /* get the type of the meta event */
		
		switch (mtype) {
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04: /* text */
			length = get_vlq(fp); /* get the length */
			if (length > buflen) {
				buf = (char *)realloc(buf,length+2);
				buflen = length+1;
			}
			/* get the text */
			fread(buf,1,length,fp);
			buf[length] = 0;
			/* just dump it out */
			if (sa->verbose) printf("MIDI text: '%s'.\n",buf);
			break;
		case 0x2F: /* end of track */
			/* there's one byte here */
			junk = fgetc(fp);
			return 1;
			
		case 0x51: /* tempo -- make MIDI tempo event*/
			junk = fgetc(fp);
			fread(&data,1,3,fp);
			swapint((int *)&data);
			
			ev = midi_tempo_event(*last,data);
			schedule_event(sa,ev);
			break;
			
		default: /* don't understand it, just skip */
			length = get_vlq(fp); /* get the length */
			if (length > buflen) {
				buf = (char *)realloc(buf,length);
				buflen = length;
			}
			fread(buf,1,length,fp); /* get the data */
			if (sa->verbose) printf("Can't deal with meta event type 0x%x; skipped %d bytes.\n",mtype,length);
			
		}
		
		break;
		default: /* MIDI message */
			
			switch (evtype & 0xF0) { /* test high nybble */
				unsigned char x1, x2;
			case 0x80 : /* noteoff */
				x1 = fgetc(fp);
				x2 = fgetc(fp);
				ev = make_midi_event(MIDI_OFF_EVENT,*last,(evtype & 0x0F) + 1,x1,x2);
				schedule_event(sa,ev);
				break;
			case 0x90 : /* noteon */
				x1 = fgetc(fp);
				x2 = fgetc(fp);
				ev = make_midi_event(MIDI_ON_EVENT,*last,(evtype & 0x0F) + 1,x1,x2);
				schedule_event(sa,ev);
				break;
			case 0xA0 : /* aftertouch */
				x1 = fgetc(fp);
				x2 = fgetc(fp);
				ev = make_midi_event(MIDI_TOUCH_EVENT,*last,(evtype & 0x0F) + 1,x1,x2);
				schedule_event(sa,ev);
				break;
			case 0xB0 : /* control */
				x1 = fgetc(fp);
				x2 = fgetc(fp);
				ev = make_midi_event(MIDI_CONTROL_EVENT,*last,(evtype & 0x0F) + 1,x1,x2);
				schedule_event(sa,ev);
				break;
			case 0xC0 : /* program change */
				ev = make_midi_event(PROGRAM_CHANGE_EVENT, *last,(evtype & 0x0F) + 1,fgetc(fp),-1);
				ev->numval = 2;
				schedule_event(sa,ev);
				break;
			case 0xD0 : /* channel touch */
				ev = make_midi_event(MIDI_CTOUCH_EVENT, *last,(evtype & 0x0F) + 1,fgetc(fp),-1);
				ev->numval = 2;
				schedule_event(sa,ev);
				break;
			case 0xE0 : /* pitch wheel */
				ev = make_midi_event(MIDI_PITCH_EVENT, *last,(evtype & 0x0F) + 1,fgetc(fp),-1);
				ev->numval = 2;
				schedule_event(sa,ev);
				break;
			default : /* running status -- use channel and type from last event */
				if (!(evtype & 0x80)) {
					/* NB evtype is actually the first data byte */
					ev = make_midi_event(last_type, *last,last_ch,evtype,fgetc(fp));
					if (ev->type == MIDI_OFF_EVENT && ev->val[2] != 0)
						ev->type = MIDI_ON_EVENT;
					schedule_event(sa,ev);
				}
				else {
					if (sa->verbose) printf("Can't deal with MIDI event 0x%x.\n",evtype);
				}
			}
			last_type = ev->type; /* keep track of last type */
			if (last_type == MIDI_OFF_EVENT) last_type = MIDI_ON_EVENT;
			last_ch = (int)ev->val[0]; /* and last channel */
  }
  return 0;
}

/* don't have make_event() in the encoder. */

event *midi_tempo_event(sa_real time, int data) {
	/* make a midi tempo event -- DATA is the new tempo */
	event *ev;

	ev = make_event(MIDI_TEMPO_EVENT, time);
	ev->numval = 1;
	ev->val = (sa_real *)malloc(sizeof(sa_real));
	ev->val[0] = 60 * (sa_real)120. / (data/1000000);
	
	return(ev);
}

event *make_midi_event(long type,sa_real time, int channel, int note, int val) {
	/* make some other kind of midi event, with three params */

	event *ev;
	ev = make_event(type, time);
	ev->numval = 3;
	ev->val = (sa_real *)calloc(3,sizeof(sa_real));
	ev->val[0] = (sa_real)channel;
	ev->val[1] = (sa_real)note;
	ev->val[2] = (sa_real)val;
				
	if (type == MIDI_ON_EVENT && val == 0) ev->type = MIDI_OFF_EVENT;
	return(ev);
}
	
	
int get_track(sa_decoder *sa, midi_info *m, FILE *fp, char *fn) {
	/* make events for all the MIDI events in a track.  Return the number of events. */
	int ct,ev=0;
	sa_real lasttime = 0;
	char trklen[4],s[854];
	
	/* get the track header ID (should be 'MThd') */ 
	ct = fread(trklen,1,4,fp);
	if (ct != 4 || !strcmp("MThd",trklen)) {
		trklen[ct] = 0;
		sprintf(s,"Bad track chunk in '%s' (got header ID '%s', length %d)",fn,trklen,ct);
		runtime(sa,s);
	}
	
	/* get the header length (should be 4) */
	ct = fread(trklen,1,4,fp);
	swapint((int *)trklen);
	if (ct != 4) {
		sprintf(s,"Got bad header size in '%s'",fn);
		runtime(sa,s);
	}
	
	/* get all the events in the track */
	while (!get_midi_event(sa, m, fp, &lasttime)) {
		ev++; /* count them */
		if (!(ev % 500)) { printf("."); fflush(stdout); } /* progress meter */
	}
	return(ev);
}


void parse_midi(sa_decoder *sa, char *fn) {
	/* make events for all the MIDI events in a MIDI file */
	FILE *fp;
	char s[800];
	midi_info *m;
	int i;
	int tot = 0;
	
	/* open the file */
	if (!(fp = fopen(fn,"rb"))) {
		sprintf(s,"Couldn't open MIDI file '%s'.",fn);
		runtime(sa,s);
	}
	
	/* get the header */
	m = get_header(sa,fp,fn);
	
	printf("Reading MIDI ..");
	
	/* get each track (sends events to scheduler) */
	for (i=0;i!=m->ntracks;i++)
		tot += get_track(sa,m,fp,fn);
	
	/* report results */
	printf("\n");
	printf("Got %d MIDI events in %d track",tot,m->ntracks);
	if (m->ntracks != 1) printf("s");
	printf(".\n");
}

#endif	

/* this is only used by the encoder, so it doesn't have to be thread-safe */

midi_msg *get_next_event(FILE *fp,char *fn) {
	static int init = 0;
	static midi_info *info;
	static int track = 0, track_ct = 0;
	static int buflen = 256;
	static sa_real tempo;
	static sa_real t;
	static char *buf = NULL;
	unsigned char evtype, mtype, junk, data[4];
	char *vlq=NULL;
	static char last_ev;
	midi_msg *m = malloc(sizeof(midi_msg));
	char trklen[8];
	int ct, length;
	int delta;


	m->t = 0;
	m->event = NULL;
	m->length = 0;

	if (!init) {
		init  =1;
		tempo = 120;
		buf = (char *)malloc(256 * sizeof(char));
		info = get_header(NULL,fp,fn);
	}

	if (!track) { /* end of track */
		track_ct++;
		t = 0;
		if (track_ct == info->ntracks) /* done */
			return NULL;

		/* get track header */

	   	/* get the track header ID (should be 'MThd') */ 
		ct = fread(trklen,1,4,fp);
		if (ct != 4 || !strcmp("MThd",trklen)) {
			trklen[ct] = 0;
			printf("Bad track chunk in '%s' (got header ID '%s', length %d)",fn,trklen,ct);
			return(NULL);
		}
		
		/* get the header length (should be 4) */
		ct = fread(trklen,1,4,fp);
		swapint((int *)trklen);
		if (ct != 4) {
			printf("Got bad header size in '%s'",fn);
			return(NULL);
		}
		track = 1; /* now we're in a track */
	}
	
	/* get the delta-time of the next event */
	
	delta = get_vlq(fp);
	
	/* figure out how much time it corresponds to */
	if (info->ticks) {
		t += (sa_real) delta / info->ticks/2 / tempo * 60;
	} else
		t += (sa_real) delta / info->fps / info->res;
	
	m->t = t;
	/* get the event type */
	evtype = fgetc(fp);
	
	switch (evtype) {

	/* we don't really do anything with a sysex -- we just
		collect its data */

	case 0xF7: /* sysex */
		/* get the sysex length */
		length = get_vlq_string(fp,&vlq);
		
		/* maybe have to make the buffer longer */
		if (length > buflen) {
			buf = (char *)realloc(buf,length);
			buflen = length;
		}
		/* get the sysex data */
		fread(buf,1,length,fp);
		
		m->event = (char *)malloc((length + strlen(vlq) + 1)*sizeof(char));
		m->event[0] = evtype;
		strncpy(&m->event[1],vlq,strlen(vlq));
		strncpy(&m->event[strlen(vlq)+1],buf,length);
		m->length = length + strlen(vlq) + 1;
		free(vlq);
		
		return(m);
		
		break;			
		
	case 0xFF: /* meta event */

		/* meta event doesn't go in the stream -- skip and move on */

		mtype = fgetc(fp); /* get the type of the meta event */
		
		switch (mtype) {
		case 0x2F: /* end of track */
			/* there's one byte here */
			junk = fgetc(fp);
			track = 0; /* start next track */
			free(m);
			m = get_next_event(fp,fn);
			return m;
			
		case 0x51: /* tempo */
			junk = fgetc(fp);
			fread(&data,1,3,fp);
			swapint((int *)&data);
			tempo = 60 * (sa_real)120. / (*((int *)data)/1000000);
			
			m = get_next_event(fp,fn);

			break;
			
		default: /* anything else: could be text, timesig, ... */
			/* get the length */
			length = get_vlq_string(fp,&vlq);
			
			/* maybe have to make the buffer longer */
			if (length > buflen) {
				buf = (char *)realloc(buf,length);
				buflen = length;
			}
			/* get the sysex data */
			fread(buf,1,length,fp);
			
			free(vlq);

			m = get_next_event(fp,fn);

			break;			
		}
		
		break;
		
	default: /* MIDI message */
		
		switch (evtype & 0xF0) { /* test high nybble */
		case 0x80 : /* noteoff */
		case 0x90 : /* noteon */
		case 0xA0 : /* aftertouch */
		case 0xB0 : /* control */
			last_ev = evtype; /* save for running status */
			fread(buf,1,2,fp); /* 2-byte message */
			m->event = (char *)malloc(3 * sizeof(char));
			m->event[0] = evtype;
			m->event[1] = buf[0];
			m->event[2] = buf[1];
			m->length = 3;
			break;
		case 0xC0 : /* program change */
		case 0xD0 : /* channel touch */
		case 0xE0 : /* pitch wheel */
			/* one-byte message */
			m->event = (char *)malloc(2 * sizeof (char));
			m->event[0] = evtype;
			m->event[1] = fgetc(fp);
			m->length = 2;
			break;
		default : /* running status -- use channel and type from last event */
			/* no more running status -- easier to deal with */
			m->event = (char *)malloc(3 * sizeof(char));
			m->event[0] = last_ev;
			m->event[1] = evtype; /* actually the first data byte */
			m->event[2] = fgetc(fp);
			m->length = 3;
		}
	}
	return m;
  }
