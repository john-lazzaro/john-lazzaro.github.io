/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#ifndef _sa_bitstream_h_
#define _sa_bitstream_h_

#include <vector>
using namespace std;

// Maximum size of parsable arrays
static const int _F_SIZE = 64;

// Temporary variable for parse sizes
// (to preserve order or parse and init evaluations)
static int _F_parse;

// Temporary variables for ID parsing
static int         _F_i_id;
static float       _F_f_id;
static double      _F_d_id;
static long double _F_ld_id;
// Bitstream error reporting function
void flerror(char *s);
int samp_table[1024],samp_ct = 0;



class sa_symbol { // 'symbol' in Subclause 5.5.2
public:
    unsigned int sym;

    sa_symbol(int i) {
      sym = i;
    }

    sa_symbol() { sym  = 0; }
    
	int num() { return sym; }

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        sym = _F_bs.getbits(16);
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(sym, 16);
        return _F_ret;
    }
};

class sym_name {
public:
    unsigned int length;
    char name[_F_SIZE];


  sym_name() {
    length = 0;
  }
  
  sym_name(char *text) {
    length = strlen(text);
    strcpy(name,text);
  }
  
    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        length = _F_bs.getbits(4);
        int _F_name_dim0, _F_name_dim0_end;
        _F_name_dim0_end = length;
        for (_F_name_dim0 = 0; _F_name_dim0 < _F_name_dim0_end; _F_name_dim0++) {
            name[_F_name_dim0] = _F_bs.getbits(8);
        }
 name[length] = 0; 
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(length, 4);
        int _F_name_dim0, _F_name_dim0_end;
        _F_name_dim0_end = length;
        for (_F_name_dim0 = 0; _F_name_dim0 < _F_name_dim0_end; _F_name_dim0++) {
            _F_bs.putbits(name[_F_name_dim0], 8);
        }
        return _F_ret;
    }
};

#define _F_SIZE 8192


class sa_symtable {  // 'symtable' in Clause 5.5.2
public:
    unsigned int length;
    vector<sym_name> name;


  public: sa_symtable() {
  length = 0;
  }
  
  public: sa_symbol add(char *text) {
    int i= 0;
    while (i < length && strcmp((const char *)name[i].name,text)) i++;

    if (i == length) {
      sym_name n(text);
      name.push_back(n);
      length++;
    }
    sa_symbol sym(i);
    return sym;
  }

  public: 
	  char *ref(sa_symbol s) {
		  int i;
		  char *st;
		  
		  if (this)
			  for (i=0;i!=length;i++)
				  if (i == s.sym)
					  return name[i].name;
				  
				  st = new char[40];
				  sprintf(st,"_sym_%d",s.sym);
				  
				  return st;
	  }
	  
		  
		  
  public: 
	  virtual int get(Bitstream& _F_bs) {
		  int _F_ret=0;
		  length = _F_bs.getbits(16);
		  sym_name n;
		  
		  int _F_name_dim0, _F_name_dim0_end;
		  _F_name_dim0_end = length;
		  
		  for (_F_name_dim0 = 0; _F_name_dim0 < _F_name_dim0_end; _F_name_dim0++) {
			  _F_ret = n.get(_F_bs);
			  name.push_back(n);
		  }
		  return _F_ret;
	  }
	  
  public: 
	  virtual int put(Bitstream& _F_bs) {
		  int _F_ret=0;
		  _F_bs.putbits(length, 16);
		  int _F_name_dim0, _F_name_dim0_end;
		  _F_name_dim0_end = length;
		  for (_F_name_dim0 = 0; _F_name_dim0 < _F_name_dim0_end; _F_name_dim0++) {
			  _F_ret += name[_F_name_dim0].put(_F_bs);
		  }
		  return _F_ret;
	  }
};

#undef _F_SIZE
#define _F_SIZE 256


class orch_token {
public:
    int done;
    unsigned int token;
    sa_symbol sym;
    float val;
    unsigned int ival;
    int length;
    char str[_F_SIZE];

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        token = _F_bs.getbits(8);
        switch (token)
            {
            case 0xF0:
                _F_ret += sym.get(_F_bs);
                break;
            case 0xF1:
                val = _F_bs.getfloat();
                break;
            case 0xF2:
                ival = _F_bs.getbits(32);
                break;
            case 0xF3:
                length = _F_bs.getbits(8);
                int _F_str_dim0, _F_str_dim0_end;
                _F_str_dim0_end = length;
                for (_F_str_dim0 = 0; _F_str_dim0 < _F_str_dim0_end; _F_str_dim0++) {
                    str[_F_str_dim0] = _F_bs.getbits(8);
                }
                break;
	    case 0xF4:
	        ival = _F_bs.getbits(8);
		break;
            case 0xFF:
                done=1;
                break;
            }
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(token, 8);
        switch (token)
            {
            case 0xF0:
                _F_ret += sym.put(_F_bs);
                break;
            case 0xF1:
                _F_bs.putfloat(val);
                break;
            case 0xF2:
               _F_bs.putbits(ival, 32);
                break;
            case 0xF3:
                _F_bs.putbits(length, 8);
                int _F_str_dim0, _F_str_dim0_end;
                _F_str_dim0_end = length;
                for (_F_str_dim0 = 0; _F_str_dim0 < _F_str_dim0_end; _F_str_dim0++) {
                    _F_bs.putbits(str[_F_str_dim0], 8);
                }
                break;
	    case 0xF4:
	      _F_bs.putbits(ival,8);
	      break;
            case 0xFF:
                done=1;
                break;
            }
        return _F_ret;
    }
};

#undef _F_SIZE
#define _F_SIZE 8192


class orc_file {
public:
    unsigned int length;
    vector<orch_token> data;

  orc_file() { length = 0; }

  void add(orch_token ot) {
    data.push_back(ot);
    length++;
  }
  

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        length = _F_bs.getbits(16);
        int _F_data_dim0, _F_data_dim0_end;
        _F_data_dim0_end = length;
	orch_token o;
	
        for (_F_data_dim0 = 0; _F_data_dim0 < _F_data_dim0_end; _F_data_dim0++) {
	  _F_ret += o.get(_F_bs);
	  data.push_back(o);
        }
	
	printf("got orc file.\n"); 
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(length, 16);
        int _F_data_dim0, _F_data_dim0_end;
        _F_data_dim0_end = length;
        for (_F_data_dim0 = 0; _F_data_dim0 < _F_data_dim0_end; _F_data_dim0++) {
            _F_ret += data[_F_data_dim0].put(_F_bs);
        }
        return _F_ret;
    }
};

#undef _F_SIZE
#define _F_SIZE 256


class instr_event {
public:
    unsigned int has_label;
    sa_symbol label;
    sa_symbol iname_sym;
    float dur;
    unsigned int num_pf;
    float pf[_F_SIZE];

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        has_label = _F_bs.getbits(1);
        if (has_label)
            _F_ret += label.get(_F_bs);
        _F_ret += iname_sym.get(_F_bs);
        dur = _F_bs.getfloat();
        num_pf = _F_bs.getbits(8);
        int _F_pf_dim0, _F_pf_dim0_end;
        _F_pf_dim0_end = num_pf;
        for (_F_pf_dim0 = 0; _F_pf_dim0 < _F_pf_dim0_end; _F_pf_dim0++) {
            pf[_F_pf_dim0] = _F_bs.getfloat();
        }
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(has_label, 1);
        if (has_label)
            _F_ret += label.put(_F_bs);
        _F_ret += iname_sym.put(_F_bs);
        _F_bs.putfloat(dur);
        _F_bs.putbits(num_pf, 8);
        int _F_pf_dim0, _F_pf_dim0_end;
        _F_pf_dim0_end = num_pf;
        for (_F_pf_dim0 = 0; _F_pf_dim0 < _F_pf_dim0_end; _F_pf_dim0++) {
            _F_bs.putfloat(pf[_F_pf_dim0]);
        }
        return _F_ret;
    }
};

class control_event {
public:
    unsigned int has_label;
    sa_symbol label;
    sa_symbol varsym;
    float value;

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        has_label = _F_bs.getbits(1);
        if (has_label)
            _F_ret += label.get(_F_bs);
        _F_ret += varsym.get(_F_bs);
        value = _F_bs.getfloat();
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(has_label, 1);
        if (has_label)
            _F_ret += label.put(_F_bs);
        _F_ret += varsym.put(_F_bs);
        _F_bs.putfloat(value);
        return _F_ret;
    }
};

class table_event {
public:
    sa_symbol tname;
    unsigned int tgen;
	unsigned int destroy;
    unsigned int refers_to_sample;
    sa_symbol table_sym;
    unsigned int num_pf;
    float *pf;

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_ret += tname.get(_F_bs);
		destroy = _F_bs.getbits(1);
		if (!destroy) {
			tgen = _F_bs.getbits(8);	
			refers_to_sample = _F_bs.getbits(1);
			if (refers_to_sample)
				_F_ret += table_sym.get(_F_bs);
			num_pf = _F_bs.getbits(16);
			pf = (float *)calloc(sizeof(float),num_pf);
			
			int _F_pf_dim0, _F_pf_dim0_end;
			_F_pf_dim0_end = num_pf;
			for (_F_pf_dim0 = 0; _F_pf_dim0 < _F_pf_dim0_end; _F_pf_dim0++) {
				pf[_F_pf_dim0] = _F_bs.getfloat();
			}
		}
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_ret += tname.put(_F_bs);
		_F_bs.putbits(destroy,1);
		if (!destroy) {
			_F_bs.putbits(tgen, 8);
			_F_bs.putbits(refers_to_sample, 1);
			if (refers_to_sample)
				_F_ret += table_sym.put(_F_bs);
			_F_bs.putbits(num_pf, 16);
			int _F_pf_dim0, _F_pf_dim0_end;
			_F_pf_dim0_end = num_pf;
			for (_F_pf_dim0 = 0; _F_pf_dim0 < _F_pf_dim0_end; _F_pf_dim0++) {
				_F_bs.putfloat(pf[_F_pf_dim0]);
			}
		}
        return _F_ret;
    }
};


class end_event {
  /* This is correct; no data, don't do anything. */
public:

    public: virtual int get(Bitstream& _F_bs) {
      return 0;
    }

    public: virtual int put(Bitstream& _F_bs) {
      return 0;
    }
};


class tempo_event {
public:
    float tempo;

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;
        tempo = _F_bs.getfloat();
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putfloat(tempo);
        return _F_ret;
    }
};

class score_line {
public:
    int has_time;
    int use_if_late;
    int priority;
    float time;
    unsigned int type;
    instr_event inst;
    control_event control;
    table_event table;
    tempo_event tempo;
    end_event end;

    public: virtual int get(Bitstream& _F_bs) {
        int _F_ret=0;

	has_time = _F_bs.getbits(1);
	if (has_time) {
	  use_if_late = _F_bs.getbits(1);
	  time = _F_bs.getfloat();
	} else {
	  use_if_late = 0;
	  time = -1;
	}
	priority = _F_bs.getbits(1);
	
        type = _F_bs.getbits(3);
        switch (type)
            {
            case 0:
                _F_ret += inst.get(_F_bs);
                break;
            case 1:
                _F_ret += control.get(_F_bs);
                break;
            case 2:
                _F_ret += table.get(_F_bs);
                break;
            case 5:
                _F_ret += tempo.get(_F_bs);
                break;
            case 4:
                _F_ret += end.get(_F_bs);
                break;
            }
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
	_F_bs.putbits(has_time,1);
	if (has_time) {
	  _F_bs.putbits(use_if_late,1);
	  _F_bs.putfloat(time);
	}
	_F_bs.putbits(priority,1);
	_F_bs.putbits(type, 3);
	
        switch (type)
            {
            case 0:
                _F_ret += inst.put(_F_bs);
                break;
            case 1:
                _F_ret += control.put(_F_bs);
                break;
            case 2:
                _F_ret += table.put(_F_bs);
                break;
            case 5:
                _F_ret += tempo.put(_F_bs);
                break;
            case 4:
                _F_ret += end.put(_F_bs);
                break;
            }
        return _F_ret;
    }
};


class score_file {
public:
    unsigned int num_lines;
    vector<score_line *>lines;

public: score_file() { num_lines = 0;  }
    
  public: void add(score_line *s) {
    num_lines++;
    lines.push_back(s);
  }
 

    public: virtual int get(struct cmdinfo *cmd,Bitstream& _F_bs) {
        int _F_ret=0;
        num_lines = _F_bs.getbits(20);
        int _F_lines_dim0, _F_lines_dim0_end;
        _F_lines_dim0_end = num_lines;
	score_line *sl;
	
        for (_F_lines_dim0 = 0; _F_lines_dim0 < _F_lines_dim0_end; _F_lines_dim0++) {
	  sl = new score_line;
	  _F_ret += sl->get(_F_bs);
	  lines.push_back(sl);
        }
	cmd->has_sco = 1;
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(num_lines, 20);
        int _F_lines_dim0, _F_lines_dim0_end;
        _F_lines_dim0_end = num_lines;
        for (_F_lines_dim0 = 0; _F_lines_dim0 < _F_lines_dim0_end; _F_lines_dim0++) {
            _F_ret += lines[_F_lines_dim0]->put(_F_bs);
        }
        return _F_ret;
    }
};


class midi_event {
   
public:
 unsigned int length;
  vector <unsigned char> data;

  midi_event(void) {
    length = 0;
  }
  
    public: virtual int get(Bitstream& _F_bs) {
      int i;
      int _F_ret=0;

      
      length = _F_bs.getbits(24);
      data.reserve(length);
      
      for (i=0;i!=length;i++)
	data.push_back(_F_bs.getbits(8));

      return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int i;
        int _F_ret=0;

	_F_bs.putbits(length,24);
	for (i=0;i!=length;i++)
	  _F_bs.putbits(data[i],8);
	
        return _F_ret;
    }
};

class midi_file {
public:
    unsigned int length;
    vector <unsigned char> data;

    public: virtual int get(struct cmdinfo *cmd, Bitstream& _F_bs) {
        int _F_ret=0;
        length = _F_bs.getbits(32);
        int _F_data_dim0, _F_data_dim0_end;
        _F_data_dim0_end = length;

	data.reserve(length);
	
        for (_F_data_dim0 = 0; _F_data_dim0 < _F_data_dim0_end; _F_data_dim0++) {
            data.push_back(_F_bs.getbits(8));
        }
	cmd->has_midi = 1;
        return _F_ret;
    }

    public: virtual int put(Bitstream& _F_bs) {
        int _F_ret=0;
        _F_bs.putbits(length, 32);
        int _F_data_dim0, _F_data_dim0_end;
        _F_data_dim0_end = length;
        for (_F_data_dim0 = 0; _F_data_dim0 < _F_data_dim0_end; _F_data_dim0++) {
            _F_bs.putbits(data[_F_data_dim0], 8);
        }
        return _F_ret;
    }
};

class bit_data {  // not part of the bitstream -- used for decoding
  public:
  int num_orc, num_sco, has_sym, num_midi;
  orc_file *all_orc[20];
  score_file *all_score[20];
  midi_file *all_midi[20];

  void add_orc(orc_file *o) {
    all_orc[num_orc++] = o;
  }

  void add_score(score_file *s) {
    all_score[num_sco++] = s;
  }

  void add_midi(midi_file *m) {
    all_midi[num_midi++] = m;
  }

  /* should do this for SBF as well */
  
} all;
 
class sample {
public:
    sa_symbol sample_name_sym;
    char fn[20]; 
    unsigned int length;
    unsigned int has_srate;
    unsigned int srate;
    unsigned int has_loop;
    unsigned int loopstart;
    unsigned int loopend;
    unsigned int has_base;
    float basecps;
    unsigned int float_sample;
    vector<float> fs_data;
    vector<int> s_data;
    
 public: void save(char *);

  sample() {
    length = 0;
   }
      
 public: virtual int get(struct cmdinfo *cmd,Bitstream& _F_bs) {
   int _F_ret=0;
   _F_ret += sample_name_sym.get(_F_bs);
   length = _F_bs.getbits(24);
   has_srate = _F_bs.getbits(1);
   
   if (has_srate)
     srate = _F_bs.getbits(17);
   
   has_loop = _F_bs.getbits(1);
   
   if (has_loop)
     {
       loopstart = _F_bs.getbits(24);
       loopend = _F_bs.getbits(24);
     }
   
   has_base = _F_bs.getbits(1);
   
   if (has_base)
     basecps = _F_bs.getfloat();
   
   float_sample = _F_bs.getbits(1);
   
   if (float_sample)
     {
       int _F_fs_data_dim0, _F_fs_data_dim0_end;
       //       _F_bs.align(8); 
       _F_fs_data_dim0_end = length;
       fs_data.reserve(length);
       
       for (_F_fs_data_dim0 = 0;
	    _F_fs_data_dim0 < _F_fs_data_dim0_end;
	    _F_fs_data_dim0++) {
	 fs_data.push_back(_F_bs.getfloat());
       }
     }
   else
     {
       int _F_s_data_dim0, _F_s_data_dim0_end;
       // _F_bs.align(8); 
       _F_s_data_dim0_end = length;
       s_data.reserve(length);
       
       for (_F_s_data_dim0 = 0;
	    _F_s_data_dim0 < _F_s_data_dim0_end;
	    _F_s_data_dim0++) {
	 s_data.push_back(_F_bs.getbits(16));
       }
     }
   return _F_ret;
 }

  virtual int put(Bitstream& _F_bs) {
    int _F_ret=0;
    _F_ret += sample_name_sym.put(_F_bs);
    _F_bs.putbits(length, 24);
    _F_bs.putbits(has_srate, 1);
    if (has_srate)
      _F_bs.putbits(srate, 17);
    _F_bs.putbits(has_loop, 1);
    if (has_loop)
      {
	_F_bs.putbits(loopstart, 24);
	_F_bs.putbits(loopend, 24);
      }
    _F_bs.putbits(has_base, 1);
    if (has_base)
      _F_bs.putfloat(basecps);
    _F_bs.putbits(float_sample, 1);
    if (float_sample)
      {
	int _F_fs_data_dim0, _F_fs_data_dim0_end;
	//	_F_bs.align(8);
	_F_fs_data_dim0_end = length;
	for (_F_fs_data_dim0 = 0;
	     _F_fs_data_dim0 < _F_fs_data_dim0_end;
	     _F_fs_data_dim0++) {
	  _F_bs.putfloat(fs_data[_F_fs_data_dim0]);
	}
      }
    else
      {
	int _F_s_data_dim0, _F_s_data_dim0_end;
	//	_F_bs.align(8);
	_F_s_data_dim0_end = length;
	for (_F_s_data_dim0 = 0;
	     _F_s_data_dim0 < _F_s_data_dim0_end;
	     _F_s_data_dim0++) {
	  _F_bs.putbits((unsigned short)s_data[_F_s_data_dim0], 16);
	}
      }
    return _F_ret;
  }
};

class sbf {
public:
  
  int length;
  vector<char> data;
  
  sbf() {
    length = 0;
   }
  
  virtual int get(struct cmdinfo *cmd,Bitstream& _F_bs) {
    int i;
    int _F_ret = 0;
    char fn[80];
    FILE *fp;
    
    length = _F_bs.getbits(32);
    data.reserve(length);
    
    printf("%d\n",length);
    for (i=0;i!=length;i++)
      data.push_back(_F_bs.getbits(8));
    
    sprintf(fn,"%s%c%s",cmd->temp,DIRSEP,"temp.sbf");
    fp = fopen(fn,"w");
    for (i=0;i!=length;i++)
      fputc(data[i],fp);
    fclose(fp);
    
    cmd->has_sbf = 1;
    return _F_ret;
  }
  
public:
  virtual int put(Bitstream& _F_bs) {
    int _F_ret=0,i;
    
    _F_bs.putbits(length,32);
    for (i=0;i!=length;i++)
      _F_bs.putbits(data[i],8);
    return _F_ret;
  }
};


class StructuredAudioSpecificConfig { // the bitstream header
public:
    unsigned int more_data;
    unsigned int chunk_type;
    orc_file *orc;
    score_file *score;
    midi_file *SMF;
    sample *samp;
    sa_symtable *sym;
    sbf *sample_bank;

public: virtual int get(struct cmdinfo *cmd, Bitstream& _F_bs) {
    int _F_ret=0;
	char fn[60];

    more_data = _F_bs.getbits(1);
    if (more_data != 1) {
        flerror("Const value mismatch for 'more_data'\n");
        _F_ret++;
    }

    while (more_data)
        {
            chunk_type = _F_bs.getbits(3);
            switch (chunk_type)
                {
                case 0:
                    orc = new orc_file;
                    _F_ret += orc->get(_F_bs);
                    all.add_orc(orc); 
                    break;
                case 1:
                    score = new score_file;
                    _F_ret += score->get(cmd,_F_bs);
                    all.add_score(score); 
                    break;
                case 2:
                    SMF = new midi_file;
                    _F_ret += SMF->get(cmd,_F_bs);
					all.add_midi(SMF);
                    break;
                case 3:
                  samp = new sample;
                  _F_ret += samp->get(cmd,_F_bs);
				  samp_table[samp_ct++] = samp->sample_name_sym.sym;
				  sprintf(fn,"%s%csamp_%d.aif",cmd->temp,DIRSEP,samp->sample_name_sym.sym);
				  samp->save(fn);
                  break;
                case 4:
                  sample_bank = new sbf;
                  _F_ret += sample_bank->get(cmd,_F_bs);
                  break;
                case 5:
                  sym = new sa_symtable;
                  _F_ret += sym->get(_F_bs);
                  all.has_sym = 1; 
                  break;
                }
            more_data = _F_bs.getbits(1);
        }
    return _F_ret;
}

public: virtual int put(Bitstream& _F_bs) {
    int _F_ret=0;
    _F_parse = 1;
    more_data = 1;
    _F_bs.putbits(more_data, _F_parse);
    while (more_data)
        {
            _F_bs.putbits(chunk_type, 3);
            switch (chunk_type)
                {
                case 0:
                    _F_ret += orc->put(_F_bs);
                    break;
                case 1:
                    _F_ret += score->put(_F_bs);
                    break;
                case 2:
                    _F_ret += SMF->put(_F_bs);
                    break;
                case 3:
                    _F_ret += samp->put(_F_bs);
                    break;
                case 4:
                    _F_ret += sample_bank->put(_F_bs);
                    break;
                case 5:
                    _F_ret += sym->put(_F_bs);
                    break;
                }
            _F_bs.putbits(more_data, 1);
        }
    return _F_ret;
}
};


class au_event {
public:
	score_line score_ev;
	midi_event midi_ev;
	sample samp;
	int event_type;
} ;


class SA_access_unit {
public:
  unsigned int num_events;
  float dts;
  unsigned int out_of_data;
  vector<au_event *> events;

  virtual int get(Bitstream& _F_bs, struct cmdinfo *cmd) {
    int _F_ret=0;
	num_events = 0;
	out_of_data = 0;
	au_event *au;


	dts = _F_bs.getfloat();  // VIOLATION -- simple au packaging
	if (_F_bs.geterror() == E_END_OF_DATA) {
		out_of_data = 1;
		return -1;
	}

	int more_data = _F_bs.getbits(1);
	
	if (!more_data) { // bad bitstream 
		flerror("Const value mismatch for 'more_data'\n");
		_F_ret++;		
	}

	while (more_data) {
		au = new au_event;
		num_events++;

		au->event_type = _F_bs.getbits(2);
		switch (au->event_type)
		{
		case 0:
		case 3:
			_F_ret += au->score_ev.get(_F_bs);
			break;
		case 1:
			_F_ret += au->midi_ev.get(_F_bs);
			break;
		case 2:
			_F_ret += au->samp.get(cmd,_F_bs);
			break;
		}
		
		events.push_back(au);
		more_data = _F_bs.getbits(1);

		if (_F_bs.geterror() == E_END_OF_DATA) {
			out_of_data = 1;
		}

	}
	return _F_ret;
  }
 

public:
  virtual int put(Bitstream& _F_bs) {
    int _F_ret=0;
	int i;
   
	_F_ret += (int)_F_bs.putfloat(dts);    // VIOLATION

	for (i=0;i!=num_events;i++) {
		
		_F_ret += _F_bs.putbits(1,1); // more_data

		_F_ret += _F_bs.putbits(events[i]->event_type,2);

		switch (events[i]->event_type) {

		case 0:
			_F_ret += events[i]->score_ev.put(_F_bs);
			break;
		case 1:
			_F_ret += events[i]->midi_ev.put(_F_bs);
			break;
		case 2:
			_F_ret += events[i]->samp.put(_F_bs);
			break;
		}
    
	}
	_F_ret += _F_bs.putbits(0,1); // no more data

    return _F_ret;
  }

};

bool operator<(SA_access_unit a, SA_access_unit b) {
	// NB backwards since we want lowest "priority" (time) at the front
	return a.dts > b.dts;
}

void sample::save(char *fn) {
  AIF_STRUCT *out;
  short outbuf[1024];
  long pvb[16];
  int pvl = 0,ct,i,j,tot=0;
  
 
  out = aifNew();
  pvb[pvl++] = AIF_P_SAMPRATE; pvb[pvl++] = srate;
  pvb[pvl++] = AIF_P_CHANNELS; pvb[pvl++] = 1;
  pvb[pvl++] = AIF_P_SAMPSIZE; pvb[pvl++] = 16;
  pvb[pvl++] = AIF_P_FILETYPE; pvb[pvl++] = AIF_FT_AIFF;
  
  aifSetParams(out,pvb,pvl);
  aifOpenWrite(out,fn,UNK_LEN);

  for (i=0;i<=length / 1024;i++) {
    ct = MIN(1024,length-i*1024);
    for (j=0;j!=ct;j++)
      if (float_sample)
	outbuf[j] = (short)(fs_data[i*1024+j] * 32767);
      else
	outbuf[j] = s_data[i*1024+j];
    aifWriteFrames(out,outbuf,ct);
    tot += ct;
  }
  aifClose(out);
}


#endif /* ! _sa_bitstream_h_ */
