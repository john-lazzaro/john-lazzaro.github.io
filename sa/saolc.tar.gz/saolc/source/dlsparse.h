/*

DLSParse.h

This software module was developed by Todor Fay (Microsoft Corp)
in the course of development of the MPEG-4 Audio (ISO/IEC 14496-3) standard. 
This software module is an implementation of a part of one or more 
MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio 
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC 14496-3) 
free license to this software module or modifications thereof for use 
in hardware or software products claiming conformance to the MPEG-4 Audio 
(ISO/IEC 14496-3). Those intending to use this software module in hardware 
or software products are advised that its use may infringe existing patents. 
The original developer of this software module and his/her company, the 
subsequent editors and their companies, and ISO/IEC have no liability for 
use of this software module or modifications thereof in an implementation. 
Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming 
products. Microsoft retains full right to use the code for its own 
purpose, assign or donate the code to a third party and to inhibit third 
parties from using the code for non MPEG-4 Audio (ISO/IEC 14496-3) 
conforming products. This copyright notice must be included in all copies 
or derivative works. 

Copyright (c) Microsoft Corporation 1996, 1998
*/

#ifdef _WIN32
#include <windows.h>
#include <windowsx.h>
#endif
#include <stdio.h>
#include "clist.h"
#include "sfe_sfdata.h"
#include "dls.h"
#include "dls2.h"

/*  For internal representation, volume is stored in Volume Cents, 
    where each increment represents 1/100 of a dB.
    Pitch is stored in Pitch Cents, where each increment
    represents 1/100 of a semitone.
*/ 

typedef long    PREL;   // Pitch cents, for relative pitch.
typedef short	PRELS;	// Pitch cents, in storage form.
typedef long    VREL;   // Volume cents, for relative volume.
typedef short	VRELS;	// Volume cents, in storage form.
typedef long    TREL;   // Time cents, for relative time
typedef short	TRELS;	// Time Cents, in storage form.
typedef short   PERCENT; // Percentage in 0.1% units.

#define FORCEBOUNDS(data,min,max) {if (data < min) data = min; else if (data > max) data = max;}

#define mmioFOURCC(ch0, ch1, ch2 ,ch3) MAKEFOURCC(ch0,ch1,ch2,ch3)
#define MAKEFOURCC(ch0, ch1, ch2, ch3)                              \
		((DWORD)(BYTE)(ch0) | ((DWORD)(BYTE)(ch1) << 8) |   \
		((DWORD)(BYTE)(ch2) << 16) | ((DWORD)(BYTE)(ch3) << 24 ))

#define RIFF_TAG    MAKEFOURCC('R','I','F','F')
#define LIST_TAG    MAKEFOURCC('L','I','S','T')
#define WAVE_TAG    MAKEFOURCC('W','A','V','E')
#define FMT__TAG    MAKEFOURCC('f','m','t',' ')
#define DATA_TAG    MAKEFOURCC('d','a','t','a')
#define FACT_TAG    MAKEFOURCC('f','a','c','t')

// For memory mapped riff file io:

typedef struct RIFF {  
    DWORD ckid;
    DWORD cksize;
} RIFF;

typedef struct RIFFLIST {
    DWORD ckid;
    DWORD cksize;
    DWORD fccType;
} RIFFLIST;


#define STACK_DEPTH 20

class Stack {
public:
    BOOL    Push(long lData);
    long    Pop();
    void    Init();
private:
    long    QueryID(DLSID dlsid);
    DWORD   m_dwIndex;
    long    m_lStack[STACK_DEPTH];
};

class CDLEvaluator {
public:
    BOOL    Evaluate(BYTE *p, BYTE *pEnd);
private:
    long CDLEvaluator::QueryID(DLSID dlsid);
    Stack   m_Stack;
};

/*  SourceLFO is the file format definition of the LFO in an
    instrument. This is used to represent an LFO as part of
    a specific articulation set within an instrument that
    has been loaded from disk. Once the instrument is chosen
    to play a note, this is also copied into the Voice
    object.
*/

class SourceLFO
{
public:
                SourceLFO();
    void        Init();             // Initializes all parameters.
    void        Verify();           // Verifies that the data is valid.
    TRELS       m_trFrequency;      // Frequency, in absolute time cents.
    TRELS       m_trDelay;          // How long to delay in time cents.
    VRELS       m_vrMWVolumeScale;  // Scaling of volume LFO by Mod Wheel.
    PRELS       m_prMWPitchScale;   // Scaling of pitch LFO by Mod Wheel.
	PRELS		m_prMWFilterScale;	// Scaling of filter LFO by Mod Wheel.
    VRELS       m_vrCPVolumeScale;  // Scaling of volume LFO by Channel Pressure.
    PRELS       m_prCPPitchScale;   // Scaling of pitch LFO by Channel Pressure.
	PRELS		m_prCPFilterScale;	// Scaling of filter LFO by Channel Pressure.
    VRELS       m_vrVolumeScale;    // Scaling of straight volume signal from LFO.
    PRELS       m_prPitchScale;     // Scaling of straight pitch signal from LFO.
	PRELS		m_prFilterScale;	// Scaling of straight filter signal from LFO.
};

/*  SourceEG is the file format definition of an Envelope
    generator in an instrument.
*/

class SourceEG
{
public:
                SourceEG();
    void        Init();             // Initializes all parameters.
    void        Verify();           // Verifies valid data.
	TRELS		m_trDelay;			// Initial delay.
    TRELS       m_trAttack;         // Attack rate.
	TRELS		m_trHold;			// Hold time.
    TRELS       m_trDecay;          // Decay rate.
    TRELS       m_trRelease;        // Release rate.
    TRELS       m_trVelAttackScale; // Scaling of attack by note velocity.
    TRELS       m_trKeyDecayScale;  // Scaling of decay by note value.
    PERCENT     m_pcSustain;        // Sustain level.
    PRELS       m_prPitchScale;     // Scaling for pitch signal.
    PRELS       m_prFilterScale;    // Scaling for filter signal.
};

/*  SourceArticulation is the file format definition of
    a complete articulation set: the LFO and two
    envelope generators.
    Since several regions within one Instrument can 
    share one articulation, a counter is used to keep
    track of the usage.
*/

class SourceArticulation

{
public:
                SourceArticulation();
    void        Init();             // Initializes all parameters.
    void        Verify();           // Verifies valid data.
    void        AddRef();
    void        Release();
    HRESULT     Load(BYTE *p, BYTE *pEnd);
    SourceEG    m_ModEG;			// Pitch, filter envelopes.
    SourceEG    m_VolumeEG;			// Volume envelope.
    SourceLFO   m_ModLFO;           // Low frequency oscillator.
	SourceLFO	m_VibratoLFO;		// Second LFO. 
    WORD		m_wUsageCount;      // Keeps track of how many times in use.
    PERCENT     m_pcDefaultPan;     // Default pan position.
    VRELS       m_vrVelToVolScale;  // Velocity to volume scaling.
    PRELS       m_prVelToFilterScale; // Velocity to filter scaling.
	PRELS		m_prKeyNumberToPitch; // Key number to pitch scaling.
    PRELS       m_prTune;           // Tuning offset.
	PRELS		m_prFilterC;		// Filter cutoff.
	PRELS		m_vrFilterQ;		// Filter Q.
	PERCENT		m_pcChorusSend;		// % mix for chorus.
	PERCENT		m_pcReverbSend;		// % mix for reverb.
	PERCENT		m_pcCC91ToChorus;	// CC91 control of chorus.
	PERCENT		m_pcCC93ToReverb;	// CC93 control of reverb.
	PERCENT		m_pcCC10ToPan;		// Range of MIDI pan.
};

/*  Since multiple regions may reference
    the same Wave, a reference count is maintained to
    keep track of how many regions are using the sample.
*/

class Wave : public CListItem
{
public:
                    Wave();
                    ~Wave();
    BOOL            Lock();             // Locks down sample.
    BOOL            UnLock();           // Releases sample.
    void            Verify();           // Verifies that the data is valid.
    void            Release();          // Remove reference.
    void            AddRef();           // Add reference.
    Wave *          GetNext() {return(Wave *)CListItem::GetNext();};
    HRESULT Load(BYTE *p, BYTE *pEnd);
    DWORD           m_dwSampleLength;   // Length of sample.
    DWORD           m_dwSampleRate;
    double *        m_pfWave;			// Pointer to wave for rendering, in double format.
    ULONG           m_ulOffset;         // Pointer to wave data in memory mapped wave pool.
    DWORD           m_dwLoopStart;
    DWORD           m_dwLoopEnd;
    WORD            m_wID;              // ID for matching wave with regions.
    VRELS           m_vrAttenuation;    // Attenuation.
    PRELS           m_prFineTune;       // Fine tune.
    WORD            m_wUsageCount;      // Keeps track of how many times in use.
    WORD            m_wLockCount;       // How many locks on this wave.
	WORD			m_wPlayCount;		// Wave is currently being played.
    BYTE            m_bOneShot;         // One shot flag.
    BYTE            m_bMIDIRootKey;     // Root note.
    BYTE            m_bWSMPLoaded;      // WSMP chunk has been loaded into Wave.
};


class WavePool : public CList
{
public:
    Wave *      GetHead() {return (Wave *)CList::GetHead();};
    Wave *      GetItem(DWORD dwID) {return (Wave *)CList::GetItem((LONG)dwID);};
    Wave *      RemoveHead() {return (Wave *)CList::RemoveHead();};
};


/*  The SourceSample class describes one sample in an
    instrument. The sample is referenced by a SourceRegion
    structure. 
*/

class SourceSample
{
public:
                SourceSample();
                ~SourceSample();
    BOOL        Lock(BOOL fLoadNow);
	BOOL		CopyFromWave();
    BOOL        UnLock();
    void        Verify();           // Verifies that the data is valid.
    Wave *      m_pWave;            // Wave in pool.
    DWORD       m_dwLoopStart;      // Index of start of loop.
    DWORD       m_dwLoopEnd;        // Index of end of loop.
    DWORD       m_dwSampleLength;   // Length of sample.
    DWORD       m_dwSampleRate;     // Sample rate of recording.
    PRELS       m_prFineTune;       // Fine tune to correct pitch.
    WORD        m_wID;              // Wave pool id.
    BYTE        m_bSampleType;      // 16 or 8, compressed or not.
    BYTE        m_bOneShot;         // Is this a one shot sample?
    BYTE		m_bMIDIRootKey;     // MIDI note number for sample.
    BYTE        m_bWSMPLoaded;      // Flag to indicate WSMP loaded in region.
};

/*  The SourceRegion class defines a region within an instrument.
    The sample is managed with a pointer instead of an embedded
    sample. This allows multiple regions to use the same
    sample.
    Each region also has an associated articulation. For drums, there
    is a one to one matching. For melodic instruments, all regions
    share the same articulation. So, to manage this, each region
    points to the articulation.
*/

class SourceRegion : public CListItem
{
public:
                SourceRegion();
                ~SourceRegion();
    SourceRegion *GetNext() {return(SourceRegion *)CListItem::GetNext();};
    void        Verify();           // Verifies that the data is valid.
    SourceSample m_Sample;       // Sample structure.
    SourceArticulation * m_pArticulation; // Pointer to associated articulation.
    VRELS       m_vrAttenuation;    // Volume change to apply to sample.
    HRESULT     Load(BYTE *p, BYTE *pEnd);
    BYTE        m_bAllowOverlap;    // Allow overlapping of note.
    BYTE        m_bKeyHigh;         // Upper note value for region.
    BYTE        m_bKeyLow;          // Lower note value.
    BYTE        m_bVelHigh;         // Upper velocity value for region.
    BYTE        m_bVelLow;          // Lower velocity value for region.
    BYTE        m_bGroup;           // Logical group (for drums.)
};


class SourceRegionList : public CList
{
public:
    SourceRegion *GetHead() {return (SourceRegion *)CList::GetHead();};
    SourceRegion *RemoveHead() {return (SourceRegion *)CList::RemoveHead();};
};


/*  The Instrument class is really the file format definition
    of an instrument.
    The Instrument can be either a Drum or a Melodic instrument.
    If a drum, it has up to 128 pairings of articulations and
    regions. If melodic, all regions share the same articulation.
    ScanForRegion is called by ControlLogic to get the region
    that corresponds to a note.
*/

class Collection;
class InstManager;

class Instrument : public CListItem
{
public:
                    Instrument();
                    ~Instrument();
    void            Verify();           // Verifies that the data is valid.
    Instrument *    GetInstrument(DWORD dwProgram);
    Instrument *    GetNext() {return(Instrument *)CListItem::GetNext();};
    SourceRegion * ScanForRegion(DWORD dwNoteValue, DWORD dwNoteVelocity, DWORD dwLayerIndex);
    SourceRegionList m_RegionList;		// Linked list of regions.
    DWORD           m_dwProgram;        // Which program change it represents.
    Collection *    m_pCollection;      // Collection this belongs to.

    HRESULT LoadRegions( BYTE *p, BYTE *pEnd);
    HRESULT Load( BYTE *p, BYTE *pEnd);
};

class InstrumentList : public CList
{
public:
    Instrument *    GetHead() {return (Instrument *)CList::GetHead();};
    Instrument *    RemoveHead() {return (Instrument *)CList::RemoveHead();};
};


class Collection : public CListItem
{
public:
                    Collection();
                    ~Collection();
    Collection *    GetNext() {return(Collection *)CListItem::GetNext();};
    void            Verify();           // Verifies that the data is valid.
    HRESULT         ResolveConnections();
    HRESULT         Load();
private:
	void			RemoveDuplicateInstrument(DWORD dwProgram);
    HRESULT         Load(BYTE *p, BYTE *pEnd);
    HRESULT         LoadInstruments(BYTE *p, BYTE *pEnd);
    HRESULT         LoadWavePool(BYTE *p, BYTE *pEnd);
    HRESULT         LoadPoolCues(BYTE *p, BYTE *pEnd);
public:
    void            AddInstrument(Instrument *pInstrument);
    Instrument *    GetInstrument(DWORD dwProgram);
    InstrumentList  m_InstrumentList;
    WavePool        m_WavePool;
    DWORD           m_dwLockCount;      // How many locks on this?
    DWORD           m_dwOpenCount;      // How many opens on this?
    BYTE *          m_pData;			// Memory chunk for DLS collection.
	ULONG			m_ulSize;			// Size of memory.
private:
    ULONG           m_ulWavePool;       // Base address of wave pool.
	WORD			m_wWavePoolSize;	// Number of waves in wave pool.
};


class CollectionList : public CList
{
public:
    Collection *GetHead() {return (Collection *)CList::GetHead();};
    void        AddHead(Collection * pC) {CList::AddHead((CListItem *) pC);};
    Collection *RemoveHead() {return (Collection *)CList::RemoveHead();};
};


class InstManager {
public:
                    InstManager();
                    ~InstManager();
    void            Verify();           // Verifies that the data is valid.
	HRESULT			DownloadCollection(BYTE * pData, DWORD dwSize, HANDLE *phCollection );
	HRESULT			UnloadCollection(HANDLE hCollection);
	HRESULT			GetSynthParams(DWORD dwPatch, DWORD dwNote, DWORD dwVelocity, sfData *pParams, DWORD dwLayerIndex);
private:
    Instrument *    GetInstrument(DWORD dwPatch);
    CollectionList  m_CollectionList;   // List of collections.
};

