/*

This software module was originally developed by 

Luke Dahl, Brian Link (E-mu Systems)


in the course of development of the MPEG-4 Audio (ISO/IEC 14496-3) standard. 
This software module is an implementation of a part of one or more 
MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio 
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC 14496-3) 
free license to this software module or modifications thereof for use 
in hardware or software products claiming conformance to the MPEG-4 Audio 
(ISO/IEC 14496-3). Those intending to use this software module in hardware 
or software products are advised that its use may infringe existing patents. 
The original developer of this software module and his/her company, the 
subsequent editors and their companies, and ISO/IEC have no liability for 
use of this software module or modifications thereof in an implementation. 
Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming 
products. E-mu Systems retains full right to use the code for his/her own 
purpose, assign or donate the code to a third party and to inhibit third 
parties from using the code for non MPEG-4 Audio (ISO/IEC 14496-3) 
conforming products. This copyright notice must be included in all copies 
or derivative works. 

Copyright (C) 1997 E-mu Systems, Inc.

*/
/*****************************************************************************
;
;	sf_param_trans.h
;
;	Definitions and prototypes for saol SF wavetable synth
;
*****************************************************************************/


#ifndef SF_PARAM_TRANS_H
#define SF_PARAM_TRANS_H

#include "sf_wave_equ.h"
#include "sfe_enab.h"


/*	Function prototypes */

void sf_xlat(sfData *rawsp, sfStuff *sfbank, struct SynthParams *nativesp, 
	int srate, int krate, SHORT note, SHORT keyvel);
double TimeCentsToSeconds(double tc);
double CentsToHertz(double c);
double CalcPhaseInc(int DiffCents);

#endif /* SF_PARAM_TRANS_H */
