/* Revision 1.1   1999/09/15   19:30  gzoia                          *
 * Added support for MPEG4 level definition profiling                */

/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_interp.c : The main interpreter functions.

   This module contains the code that takes an instrument instance, and 
   interprets it.  The main function is eval_block(), which is called by
   run_itime() and run_katime(), both in this module also.  run_katime()
   is called for each instrument instance that's active by sched_run_kcycle()
   in saol_sched.c, once for the k-pass, and once for the a-passes, each
   kcycle.

   Most of these functions take a HANDLE or a CONTEXT as the main parameter,
   indicating that we're no longer working with the orchestra "as a whole",
   but we're down at the instrument-by-instrument level.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "saol_prec.h"
#include "saol.h"
#include "saol.tab.h"
#include "saol_interp.h"
#include "saol_sched.h"
#include "saol_co_imp.h"

#ifdef _MPEGPROFILER
	#include "profiler.h"
#else
	#define SCHEDP 0
	void increment_counter(int par, int amount, int rate) { }
#endif

#include <malloc.h>

extern void spatialize(context *cx, sa_real *pl, int p_ct);

#ifdef _MPEGPROFILER
extern void calc_factor(int opcode, actparam *pf, int pf_ct, sa_decoder *sa);
extern int core_opcode_index(char *name);
extern int factor[COUNTMAX];
extern int first_ka;
extern int opt_mem;

extern int add_pointer(void *pnt, int bytes);
#endif

void sfsynth(context *cx, int offset, long rate, sa_real note, sa_real vel,
			 sa_real preset, sa_real bank, sa_real *val, int len);

#define WIDTH(p,cx) ((p->width == -1) ? (cx)->instr->inchan : p->width)

block * eval_block(context *cx, block *b, long rate) {
	/* this is where the action is! */
	/* this module evaluates (interprets) the instrument represented
            by the given context and block of code for one pass at RATE */

    /* the return value is not used very often -- it gives the next 
	block to execute in the rare case that blocks don't proceed 
	one after another (most obvious, when we've macro-expanded
	a UDO that contains a RETURN inside an IF -- this turns into
	an assignment followed by a 'jump' that breaks out of the IF   
	in saol_macro.c */

	int ind;
	sa_real pl[256];
	int ct =0,i;
	sa_real val[1024]; /* VIOLATION to have a fixed maximum */
	exprlist *el;
	sa_decoder *sa = cx->sa;
	char s[100];
	
	block *b2,*j;
	
	for (;b;) { /* go through each statement in the block */
		
		j = NULL; /* clear out a possible jump */

		/* this is the most-executed line in saolc */
		switch ((int)b->st->type) {
			
		case EQ:
			/* only need to do this at the rate of the expression (5.8.6.6.2) */

			/* SPECIALOP statements have a call to fft() or downsamp() or 
   			   something else that takes a asig parameter and returns ksig
			   values (5.9.2).  The RHS has to be evaluated at both the k-rate
			   and the a-rate */
			if (rate == b->st->rate || (b->st->rate == SPECIALOP && rate > IVAR)) {

				/* first figure out the lvalue */
				if (b->st->lvalue && b->st->lvalue->op == ARRAYREF) {
					/* it's an array; figure out the array index */ 
					eval_expr(&cx,val,b->st->lvalue->left,rate);
					/* NB eval_expr() puts return values in val[] */
					ind = (int)(val[0] +0.5);
				}
				else {
					ind = 0;
				}
				
				/* now figure out the rhs */
				eval_expr(&cx,val,b->st->expr,rate);
				
				/* for a SPECIALOP, only do the assign at the krate */
				if ( b->st->lvalue && (b->st->rate == rate ||
					(b->st->rate == SPECIALOP && rate == KSIG))) { /* do assign */

					if (WIDTH(b->st->lvalue,cx) != 1) { /* array-valued expression */
						for (i=0;i!=WIDTH(b->st->lvalue,cx);i++) { /* do each channel */
							/* if the rhs is a single-value, assign it to each lhs
							   value; otherwise match values */
							if (WIDTH(b->st->expr,cx) != 1)
								set_var_value(cx,b->st->lvalue,ind+i,val[i]);
							else
								set_var_value(cx,b->st->lvalue,ind+i,val[0]);
						}
					}
					else /* single-valued expression */
						set_var_value(cx,b->st->lvalue,ind,val[0]);
					
				}
			}
			
			break;
			
		case IF:
			/* for SPECIALOP, guard expression must be evaluated at both k-rate and a-rate */
			if (b->st->rate == rate || b->st->rate == SPECIALOP && rate > IVAR) {
				
				eval_expr(&cx,val,b->st->expr,rate);

				increment_counter(IF, 1, SCHEDP);
				/* but code block only gets evaluated at k-rate (5.9.2) */
				if (val[0] && b->st->rate == rate || b->st->rate == SPECIALOP && rate == KSIG) 
					j = eval_block(cx,b->st->b,rate);
				/* J just got set if there was a jump out of the inner block 
					(or any of its child blocks) */
			}
			
			break;
			
		case ELSE:
			
			/* same deal here */
			if (b->st->rate == rate || b->st->rate == SPECIALOP && rate > IVAR) {
				
				eval_expr(&cx,val,b->st->expr,rate);

				increment_counter(ELSE, 1, SCHEDP);
				if (b->st->rate == rate || b->st->rate == SPECIALOP && rate == KSIG) {
					/* only evaluate one block or the other */
					if (val[0])
						j = eval_block(cx,b->st->b,rate);
					else
						j = eval_block(cx,b->st->elseb,rate);
				}
			}
			break;
			
		case WHILE:
			
			/* can't use specialop here */
			if (b->st->rate == rate) {
				while (!j && eval_expr(&cx,val,b->st->expr,rate)) {
					/* there might be a jump out; check that as well as the real WHILE 
  					   guard -- that would be for code like
						while (foo < 25) {
						   foo = foo + 1;
						   if (foo > bar) { return foo; }
						}
					*/
					increment_counter(WHILE, 1, SCHEDP);
					j = eval_block(cx,b->st->b,rate);
				}
			}
			
			break;
			
		case OUTPUT:
			/* only do this at the a-rate  */
			if (rate == ASIG) {
				
				for (el = b->st->params,ct=0;el;el=el->next) { /* go through all the parameters */
					/* evaluate */
					eval_expr(&cx,val,el->p,rate);
					/* add to overall output width */
					for (i=0;i!=WIDTH(el->p,cx);i++)
						pl[ct++] = val[i];
					
				}

				if (cx->sa->is_outputbus && !cx->globalout)
					/* if there is an outputbus, and this isn't the instrument that it's
					    sent to, then put the output on it (5.8.5.4)  */
					bus_output("output_bus",cx,pl,ct);
				else
					/* put in the orchestra output cache (saol_sched.c) -- this isn't exactly
					   the way the spec says, but it does the same thing */
					instr_output(cx,pl,ct);
			}
			break;
			
		case SPATIALIZE:
			/* only at the a-rate */
			if (rate == ASIG) {
				for (el = b->st->params,ct=0;el;el=el->next,ct++) { /* eval all parameters */
					pl[ct] = eval_expr(&cx,val,el->p,rate);
				}
				/* spatialize() does its own output (5.8.6.6.9) */
				spatialize(cx,pl,ct);
				increment_counter(SPATIALIZE, 1, SCHEDP);
			}
			break;
			
			
		case OUTBUS:
			/* put a signal on a bus */
			if (rate == ASIG) { /* only at the a-rate */
					
				ct = 0; /* we're going to count up all the channels of parameter */
				for (el = b->st->params;el;el=el->next) { /* go through parameters */
					eval_expr(&cx,val,el->p,rate); /* evaluate each */
					for (i=0;i!=WIDTH(el->p,cx);i++)
						pl[ct++] = val[i]; /* keep track of all its channels */
				}
				/* now send all the channels to the bus (in saol_sched.c) */
				bus_output(b->st->bus,cx,pl,ct);
				
			}
			break;
			
		case RETURN:
			
			/* there shouldn't be any RETURN statements -- they were supposed to
			   all be removed in saol_macro preprocessing */
			runtime(cx->sa,"Internal compiler error: RETURN left in code.");
			return(0);
			
		case TURNOFF:
			/* just tell the scheduler we want to turn off  */
				
			if (rate == KSIG) {
				instr_turnoff(cx);
			}
			break;
			
		case EXTEND:
			/* add time to the duration of the current instance */

			/* this can't be a-rate (rate-checked away), but it could be either
			   i-rate or k-rate.  If it has a SPECIALOP argument, that's allowed,
 			   and we eval the argument at both the k-rate and the a-rate (5.8.6.6.11) */

			if (rate == b->st->rate || (b->st->rate == SPECIALOP && rate > IVAR)) {
				/* evaluate the argument */
				pl[0] = eval_expr(&cx,val,b->st->expr,rate);
				if (rate == b->st->rate || (b->st->rate == SPECIALOP && rate == KSIG)) {
					/* ask the scheduler to extend the instance */
					instr_extend(cx,pl[0]);
				}
			}
			
			break;
			
		case INSTR:
			/* this is like "instr foo(time,dur,p1,p2,...);" -- we need to spawn
				a new instrument instance.  This can only happen at the i-rate or
				k-rate, but specialop parameters are ok */
			if (b->st->rate == rate || (b->st->rate == SPECIALOP && rate > IVAR)) {
				exprlist *el;
				instr_handle *h;
				sa_real time;
				
				ct = 0;
				el = b->st->params;
				/* the first parameter is the time */
				time = eval_expr(&cx,val,el->p,rate);
				
				/* now evaluate each of the rest (the first one in this
					list is the duration) */
				for (el=el->next;el;el=el->next)
					pl[ct++] = eval_expr(&cx,val,el->p,rate);
				
				/* only spawn at the i-rate or k-rate */
				if (b->st->rate == rate || (b->st->rate == SPECIALOP && rate == KSIG)) {
				
					if (time < 1.0/sa->all->g->krate)
						/* TIME is less than one k-cycle, dispatch right away (5.8.6.6.7) */
						h = new_instr_instance(cx->sa,b->st->iname,pl,0,0);
					else {
						/* schedule event for later */
						event *ev;
						
						/* make an event */
						ev = (event *)malloc(sizeof(event));
						ev->name = NULL;
						ev->label = NULL;
						ev->val = NULL;
						ev->h = NULL;
						ev->numval = ev->type = 0;
						ev->ext = ev->time = ev->dur = (sa_real)0;
						ev->type = INSTR_EVENT;
						ev->name = strdup(b->st->iname);
						ev->time = sa->sched->time * sa->sched->tempo / 60 + time;
						ev->dur = pl[0]; /* dur */
						ev->val = (sa_real *)malloc(sizeof(sa_real) * (ct - 1));
						for (i=1;i!=ct;i++) /* copy all the pfields */
							ev->val[i-1] = pl[i];
						ev->numval = ct - 1;
						ev->ext = 0;
						
						schedule_event(sa,ev); /* in saol_sched.c */
					}
				}
				
				
			}
			break;
		default:
			/* internal error */
			sprintf(s,"Unknown statement type (%d) in eval_block()!\n",b->st->type);
			interror(s);
    }
	
	/* if j didn't get set by a child block above... */
    if (!j) 
		/* set it to the JUMP point of this statement */
		j = b->st->jump;

	/* see if the jump is within this basic block */
    for (b2=b;b2 && b2 != j;b2=b2->next) ;

    if (b2) { /* yes, in this basic block */
		b = b2;  /* skip over the statements in the middle */
		j = NULL;
		continue;
    }
    if (j) { /* no, it's not in this basic block, we have to jump out */
		b2 = NULL;
		break; /* break out of the statement loop */
    }
	b = b->next;  /* just go to next statement */
  }
  if (j) return j;
  else return NULL;
}


sa_real eval_expr(context **cx,sa_real *val,expr *p,long rate) {
	/* evaluate an expression 
	    the instance context is in *CX (we only pass a pointer because we
		   do this a lot and the context struct is pretty big)
	    VAL[] is where the expression values go
		P is the expression to evaluate
		RATE is the rate at which we're running right now

        the return value gets the expression value as well, or just the
		  first one if the expression is array-valued 
	*/
	int i,i1,i2,i3;
	sa_real val1[1024],val2[1024],val3[1024]; /* VIOLATION to have fixed maxima here */
	sa_decoder *sa = (*cx)->sa;
	sa_real bank, note, vel, pre;
	char s[95];
	
	switch (p->op) { /* figure out what kind of expression */
	case IDENT:
		/* just an identifier -- get the value of the variable */
		
		if (WIDTH(p,*cx) == 1) /* single value */
			val[0] = get_var_value(*cx,p,0);
		else { /* array value */
			for (i=0;i != WIDTH(p,*cx);i++) val[i] = get_var_value(*cx,p,i);
		}
		return(val[0]);
	case NUMBER:
		/* a constant */
		return(val[0] = p->d->cval);
	case ARRAYREF:
		/* an array-reference */

		/* the SAOL code itself cannot have an array-valued expression here.
		   but sometimes we need to select subarrays for the macro expansion
		   of user-defined opcodes.  If p->width > 1, we're looking for
		     X[k:k+p->width] 
		   in Matlab notation.  See saol_macro.c */

		for (i=0;i!=WIDTH(p,*cx);i++) {
			/* evaluate the subexpression and use that as the index */
			val[i] = get_var_value(*cx,p,(int)(eval_expr(cx,val1,p->left,rate)+i+0.5));
			increment_counter(ARRAYREF, 1, SCHEDP);
		}
		
		return(val[0]);
		
	case SASBF:
		/* evaluate the subexpressions */
		note = eval_expr(cx,val,p->params->p,rate);
		vel = eval_expr(cx,val,p->params->next->p,rate);
		
		if (p->params->next->next)
			/* if there's a preset expression, get it */
			pre = eval_expr(cx,val,p->params->next->next->p,rate);
		else {
			if ((*cx)->preset != -1) 
				/* it's the preset number of this instance (5.8.6.7.15) */
				pre = (sa_real)(*cx)->preset;
			else {
				if ((*cx)->instr->id->preset)
					/* or the preset number of the instrumnet */
					pre = (sa_real)((int)((*cx)->instr->id->preset->t->cval + 0.5) % 128);
				else
					/* or an error if neither of those is set */
					runtime(sa,"Can't use 'sasbf' without MIDI or instrument preset.");
			}
		}
		if (p->params->next->next && p->params->next->next->next)
			/* if there's a bank expression, get it */
			bank = eval_expr(cx,val,p->params->next->next->next->p,rate);
		else {
			if ((*cx)->preset != -1)
				/* it's the bank number of this instance */
				bank = (sa_real)(*cx)->midibank;
			else
				if ((*cx)->instr->id->preset)
					/* or the bank number of the instrument */
					pre = (sa_real)((int)((*cx)->instr->id->preset->t->cval + 0.5) % 128);
				else
					/* or an error if neither of those is set. */
					runtime(sa,"Can't use 'sasbf' without MIDI or instrument bank number.");
		}	
		/* call the SASBF synthesizer (in saol_sfsynth.c */
		sfsynth(*cx,p->op_offset,rate,note,vel,pre,bank,val,p->width);
		break;

	case OPARRAY:
		/* too complicated to inline here */
		eval_oparray(*cx,val,p,rate);
		return(val[0]);

	case OPCALL:
		eval_opcode(*cx,val,p,rate);
		return(val[0]);

	case NOT: /* !<expr> */
		/* all of these operators are pretty dull -- we evaluate the 
		   subexpressions, then use their values to calculate the new value */
		eval_expr(cx,val1,p->left,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			val[i] = (sa_real)!val1[i];
			increment_counter(NOT, 1, SCHEDP);
		}
		return(val[0]);

	case UMINUS: /* -<expr> */
		eval_expr(cx,val1,p->left,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			val[i] = -val1[i];
			increment_counter(UMINUS, 1, SCHEDP);
		}
		return(val[0]);

	case LP: /* (<expr>) -- don't have to do anything */
		return(val[0] = eval_expr(cx,val,p->left,rate));

	case Q:  /* <expr> ? <expr> : <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		eval_expr(cx,val3,p->extra,rate);
		/* for each subexpression, we use the proper array index if the 
		   expression is array-valued, or the single value if it's not */
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			if (WIDTH(p->extra,*cx) == 1) i3 = 0; else i3 = i;
			val[i] = val1[i1] ? val2[i2] : val3[i3];
			increment_counter(Q, 1, SCHEDP);
		}
		return(val[0]);

	case LEQ: /* <expr> <= <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] <= val2[i2]);
			increment_counter(LEQ, 1, SCHEDP);
		}
		return(val[0]);

	case GEQ: /* <expr> >= <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] >= val2[i2]);
			increment_counter(GEQ, 1, SCHEDP);
		}
		return(val[0]);

	case EQEQ: /* <expr> == <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] == val2[i2]);
			increment_counter(EQEQ, 1, SCHEDP);
		}
		return(val[0]);

	case NEQ: /* <expr> != <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] != val2[i2]);
			increment_counter(NEQ, 1, SCHEDP);
		}
		return(val[0]);

	case GT: /* <expr> > <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] > val2[i2]);
			increment_counter(GT, 1, SCHEDP);
		}
		return(val[0]);

	case LT: /* <expr> < <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] < val2[i2]);
			increment_counter(LT, 1, SCHEDP);
		}
		return(val[0]);

	case AND: /* <expr> && <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] && val2[i1]);
			increment_counter(AND, 1, SCHEDP);
		}
		return(val[0]);

	case OR: /* <expr> || <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = (sa_real)(val1[i1] || val2[i2]);
			increment_counter(OR, 1, SCHEDP);
		}
		return(val[0]);

	case PLUS: /* <expr> + <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = val1[i1] + val2[i2];
			increment_counter(PLUS, 1, SCHEDP);
		}
		return(val[0]);

	case MINUS: /* <expr> - <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = val1[i1] - val2[i2];
			increment_counter(MINUS, 1, SCHEDP);
		}
		return(val[0]);

	case STAR: /* <expr> * <expr> */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			val[i] = val1[i1] * val2[i2];
			increment_counter(STAR, 1, SCHEDP);
		}
		return(val[0]);

	case SLASH: /* <expr> / <expr> (division) */
		eval_expr(cx,val1,p->left,rate);
		eval_expr(cx,val2,p->right,rate);
		for (i=0;i!=WIDTH(p,*cx);i++) {
			if (WIDTH(p->left,*cx) == 1) i1 = 0; else i1 = i;
			if (WIDTH(p->right,*cx) == 1) i2 = 0; else i2 = i;
			if (!val2[i2]) 
				runtime((*cx)->sa,"Divide by zero.\n");
			else {
				val[i] = val1[i1] / val2[i2];
				increment_counter(SLASH, 1, SCHEDP);
			}
		}
		return(val[0]);

	case STRCONST: /* this isn't right. */
		interror("can't evaluate string constant!");
		break;

	default: /* something went wrong */
		sprintf(s,"Unknown expression type (%d) in eval_expr.\n",p->op);
		interror(s);
  }
  
  return 0;			/* never gets reached, just here to prevent warnings */
}

sa_real eval_oparray(context *cx, sa_real *val, expr *opcall,long rate) {
	/* evaluate a call to an oparray.
	 
	   CX is the instrument context we're in
	   VAL is the place to put the values
	   OPCALL is the expression containing the oparray call
	   RATE is the rate at which we're working

	   note that the opcode must be a core opcode, since we removed all
	   the UDOs in saol_macro.c.
	   */
	exprlist *el;
	opval *op;
	actparam param[256]; /* VIOLATION to have a fixed maximum here */
	sa_real rval;
	int ct = 0,i,j;
#ifdef _MPEGPROFILER
	int scf;
#endif
	sa_real idx;
	sa_decoder *sa = cx->sa;
	
	/* evaluate the index expression */
	idx = eval_expr(&cx,val,opcall->left,rate);
	
	/* get the state of the opcode call -- all the states of all the opcode
	   calls are stored in the array COP_STORAGE in the current context.  The 
	   symbol in the symbol table, OPCALL->OPARRAY_DEFN, holds the 
	   offset into the table for this particular oparray call, and
	   we further index that by the value of the index expression */

	op = &(cx->cop_storage[opcall->oparray_defn->offset+(int)(idx + 0.5)]);
	
	/* go through and evaluate all the actual parameters */
	for (i=0,el=opcall->params;i!=opcall->actparam_ct;el=el->next,i++) {

		/* might be just a table */
		if (el->p->op == IDENT && cx->framevals[el->p->d->sym->offset].table) {
			param[ct++].t = cx->framevals[el->p->d->sym->offset].table;
		}
		else if (el->p->op == ARRAYREF && el->p->d->sym->tablemap) {
			/* or a tablemap */
			param[ct++].t = resolve_tablemap(cx,el->p,rate);
		} else {
			/* it's actually a value -- no call-by-ref to core opcodes */
			param[ct].t = NULL;

			/* evaluate it */
			eval_expr(&cx,val,el->p,rate);
			for (j=0;j!=WIDTH(el->p,cx);j++) {
				param[ct++].val = val[j]; /* move it into the param list */
			}
		}
	}
	/* evaluate core opcode -- co_ptr is a function pointer to the right
	   core opcode (we set it up in saol_rates.c.
	   All the core opcodes live in saol_co_imp.c */
	rval = opcall->co_ptr->code(cx->sa,op,param,ct,rate);

#ifdef _MPEGPROFILER
   if(cx->sa->prof) {
   	scf = core_opcode_index(opcall->co_ptr->name);
   	calc_factor(scf, param, ct, cx->sa);
   	increment_counter(OPCALL, scf, SCHEDP);
	}
#endif
		
	/* core opcodes only return single values, not array values */
	val[0] = rval;
	return(rval);
}

table_storage *resolve_tablemap(context *cx, expr *p, long rate) {
	/* we have a tablemap expression tm[<expr] -- we want the table
	   to which this corresponds */
	sa_real val[1024];
	namelist *nl;
	int j,idx;
	char s[342];
	symbol *sym;
	
	/* evaluate the index */
	idx = (int)(eval_expr(&cx,val,p->left,rate) + 0.5); /* round */

	/* count forward through the tablemap list until we find the right ont */
	for (nl = p->d->sym->tablemap, j=0;j < idx && nl && nl->n; nl=nl->next, j++);

	/* if we ran out of names, it's an error */
	if (!nl || !nl->n) {
		sprintf(s,"Tablemap reference out of bounds ('%s', max %d, index %.0f)",
			p->d->sym->name,j-1,idx);
		runtime(cx->sa,s);
	}

	/* get the symbol-table entry of the table from its name */
	sym = get_sym_decl(cx->localvars,nl->n->name);

	/* look up the table in context and return it. */
	return(cx->framevals[sym->offset].table);
}

sa_real eval_opcode(context *cx, sa_real *val, expr *opcall,long rate) {
	/* pretty much the same as eval_oparray(), but without the array index */
	exprlist *el;
	actparam param[256];
	sa_real rval;
	opval *op;
	int ct = 0,i,j;
#ifdef _MPEGPROFILER
	int scf;
#endif
	sa_decoder *sa=cx->sa;
	
	/* look up local context storage */
	
	op = &(cx->cop_storage[opcall->op_offset]);
	
	for (i=0,ct=0,el=opcall->params;i!=opcall->actparam_ct;i++,el=el->next) {
		if ((el->p->op == IDENT || el->p->op == TABLE) && el->p->d->sym->width &&
			cx->framevals[el->p->d->sym->offset].table) {
			param[ct++].t = cx->framevals[el->p->d->sym->offset].table;
		}
		else if (el->p->op == ARRAYREF && el->p->d->sym->tablemap) {
			param[ct++].t = resolve_tablemap(cx,el->p,rate);
		}
		else {
			eval_expr(&cx,val,el->p,rate);
			for (j=0;j!=WIDTH(el->p,cx);j++) {
				param[ct++].val = val[j];
			}
		}
	}
	
	/* call core opcode code */
	rval = opcall->co_ptr->code(cx->sa,op,param,ct,rate);

#ifdef _MPEGPROFILER
	if(cx->sa->prof) {
   	scf = core_opcode_index(opcall->co_ptr->name);
   	calc_factor(scf, param, ct, cx->sa);
   	increment_counter(OPCALL, scf, SCHEDP);
	}
#endif
	
	val[0] = rval;
	return(rval);
}

void set_context_pfields(context *cx, sa_real *pf) {
	/* we do this at instrument startup -- move all the pfields of the
	   instrument event into the context as variable values */
	symtable *t;
	int i=0;
	sa_decoder *sa = cx->sa;
	
	/* standard names come first; skip them */
	for (t=cx->localvars; t && t->s && t->s->binding == STANDARD_NAME; t=t->next) ;
	
	/* go through all the pfields and formal-parameter symbols */
	for (i=1 ; t && t->s && t->s->binding == FORMALPARAM; i++,t=t->next) {
		/* set the frame value that corresponds to the symbol (given by
		   T->S->OFFSET to the right pfield value */
		cx->framevals[t->s->offset].val = pf[i];
	}
}

void push_context(context *cx, long rate) {
	/* this is what we do at the beginning of the i- and k-cycles, to check whether any 
	   global variables or controllers have been updated. */
	symtable *t;
	frameval *fv;
	int i;
	sa_decoder *sa = cx->sa;  
	/* first, any standard names */
	
	for (t=cx->localvars; t && t->s; t=t->next) { /* go through the symbol table */
		/* if it's a standard name at the right rate, */
		if (t->s->binding == STANDARD_NAME && t->s->type == rate
			|| !strcmp(t->s->name,"dur") && t->s->type == KSIG) { /* hack for 'dur' -- 5.8.6.8.7 */
			for (i=0;i < t->s->width;i++) 
				/* and it's been updated */
				if (host_value_changed(cx->instr,t->s,i)) {
					/* set the new value in the context */
					cx->framevals[t->s->offset+i].val = get_host_value(cx->instr,t->s,i);
				}
		}
  }

	/* for each local variable */
	for (t=cx->localvars; t && t->s; t = t->next) {
		/* if it's an imported variable */
		if (t->s->binding == LOCAL) {
			if (t->s->imported &&
				/* and we're at the variable's rate */
				((t->s->type == rate) ||
				/* or the variable is a table */
				(t->s->type == TABLE))) {
				/* then copy in the global variable or controller */
				if (t->s->glink) {	/* global variable */
					for (i=0;i!=t->s->width;i++) {
						fv = &cx->sa->global_cx->framevals[t->s->glink->offset+i];
						cx->framevals[t->s->offset+i].val = fv->val;
						cx->framevals[t->s->offset+i].table = fv->table; /* VIOLATION - this should be a deep copy */
					}
				}
				else			/* controller */ 
					if (t->s->type == TABLE) /* dynamic wavetable */
						cx->framevals[t->s->offset].table =
						get_host_table(cx->instr,t->s);
					else
						for (i=0;i!=t->s->width;i++) {
							if (host_value_changed(cx->instr,t->s,i)) {
								cx->framevals[t->s->offset+i].val =
									get_host_value(cx->instr,t->s,i);
							}
						}
			}
		}
	}
}
  
void pop_context(context *cx, long rate) {
	/* this is what we do after we finish with an instrument in an orch cycle -- we
	   copy out the global variables */
  int i;
  symtable *t;
  frameval *fv;
  sa_decoder *sa = cx->sa;
  
  for (t=cx->localvars; t && t->s && t->s->binding == STANDARD_NAME; t=t->next) {
	  if (!strcmp(t->s->name,"MIDIctrl")) { /* export the MIDIctrl values */
		  for (i=0;i!=128;i++)
			  set_midi_control(sa,cx->channel,i,(int)(cx->framevals[t->s->offset+i].val + 0.5));
	  }
  }
  
  /* don't need to do anything with the formal parameters */
  for (;t && t->s && t->s->binding == FORMALPARAM; t=t->next) ;
  
  
  /* for each local variable */
  for (; t && t->s; t=t->next) {
	  /* if it's an exported variable */
	  if (t->s->exported && (t->s->type == rate)) {
		  if (t->s->glink)		/* global variable */
			  for (i=0;i!=t->s->width;i++) {
				  /* copy each channel */
				  fv = &cx->sa->global_cx->framevals[t->s->glink->offset + i];
				  fv->val = cx->framevals[t->s->offset+i].val;
				  /* VIOLATION - don't need to do tables since they're pointer-copied */
			  }
			  else			/* controller */
				  for (i=0;i!=t->s->width;i++) {
					  set_host_value(cx->instr,t->s->name,i,
						  cx->framevals[t->s->offset+i].val);
				  }
	  }
  }
  
}

context *new_context(sa_decoder *sa, instr_decl *id, int inchan) {
	/* make the variable and opcode space for a new instrument instance */
  int ct = 0; 
  context *cx;

  PROT_MAL(cx,context,new_context);

  /* initialize */
  cx->instr = NULL;
  cx->localvars = id->sym;
  cx->cop_storage = NULL;
  cx->inchan = inchan;
  cx->sa = sa;
  cx->preset = cx->midibank = 0;
  cx->globalout = 0;
  
  /* make space for variables */
  if (id->framesize) { /* otherwise, no variables in this instrument */
    if (!(cx->framevals = (frameval *)calloc(sizeof(frameval), id->framesize)))
      interror("calloc() failure in new_context()\n");
#ifdef _MPEGPROFILER
    else
      add_pointer(cx->framevals, id->framesize * sizeof(float));
#endif
  } else {
	  cx->framevals = NULL;
  }

  /* clear out local variables (5.8.6.5.3) */
  memset(cx->framevals,0,(id->framesize) * sizeof(frameval));
  
  /* make space for core opcodes */
  if (id->opsize) { /* o/w, no core opcodes in this instrument*/
    if (!(cx->cop_storage = (opval *)calloc(sizeof(opval), id->opsize)))
      interror("calloc() failure in new_context()\n");
  }

  /* clear out core opcode data */
  memset(cx->cop_storage,0,id->opsize * sizeof(opval)); 
  
  return(cx);
}

table_storage *make_table(context *cx, tabledef *td) {
	/* make a wavetable by allocating the space and calling the table generator */
  actparam tv[1024];
  sa_real val[1024];
  int ct;
  exprlist *el;
  table_storage *t;
  sa_decoder *sa = cx->sa;
  
  /* go through the parameter list */
  for (el = td->params,ct=0; el; el=el->next,ct++) {
	  el->p->width = 1;
	  if (el->p->op == IDENT &&
		  get_table_decl(cx->localvars,el->p->d->iname)) { /* it's a table name */
		  tv[ct].ref = el->p->d->iname;
		  tv[ct].t = cx->framevals[get_table_decl(cx->localvars,el->p->d->iname)->offset].table;
	  }
	  else if (el->p->op == STRCONST) /* EXTENSION -- allow string parameters */
		  tv[ct].ref = el->p->d->csval;
	  else /* evaluate the parameter and store the value */
		  tv[ct].val = eval_expr(&cx,val,el->p,IVAR);
  }
  
  /* call the table generator (in saol_tables.c) */
  t = gen_table(sa,td->gen,tv,ct);
  t->name = td->name;
  return(t);
}

frameval *get_frameval(context *cx, expr *p, int index) {
	/* get the frame (storage space) corresponding to a symbol from the context 
	     P is an expression containing only a symbol (type TERMINAL)
	*/
  char s[1000];
  symbol *sym;
  int ct=0;
  sa_decoder *sa = cx->sa;
	
  sym = p->d->sym;
  if (!sym) {
	  /* if we didn't catch it before, we were leaving it alone
	     as a future wavetable.  but if it's not here now, it's
		 a problem */
    sprintf(s,"Wavetable '%s' undeclared.\n",p->d->iname);
    runtime(sa,s);
  }
	
  /* check array width */
  if (sym->width <= index || index < 0) {
    sprintf(s,"Array '%s' out of bounds (max %d, index %d)",
	    p->d->iname, sym->width-1, index);
    runtime(sa,s);
  }
  
  /* index into frames is given by symbol and array index */
  return(&(cx->framevals[sym->offset+index]));
}

void set_frameval(context *cx, expr *p, int index, frameval *val) {
	/* associate a new frame with a particular symbol */
  symbol *sym;
  int ct=0;
  char s[1000];
  sa_decoder *sa = cx->sa;
  
  sym = p->d->sym;
  
  /* check array width */
  if (sym->width <= index || index < 0) {
    sprintf(s,"Array '%s' out of bounds (max %d, index %d)",
	    p->d->iname, sym->width-1, index);
    runtime(cx->sa,s);
  }
  else {
	  /* set value */
    cx->framevals[sym->offset+index].val = val->val;
    cx->framevals[sym->offset+index].table = val->table;
  }
}

void set_var_value(context *cx, expr *p, int index, sa_real val) {
	/* set the value of a variable */
  frameval *fv = get_frameval(cx,p,index);  /* get the frame */
  
  /* set it */
  fv->val = val;
}

void set_var_value_byname(context *cx, char *vname, int index, sa_real val) {
  /* only used for the scheduler setting controllers */
  symtable *t;
  char s[800];
	
  /* find the symbol in the symbol table from its name */
  for (t = cx->localvars;t && strcmp(t->s->name,vname);t=t->next);
  if (!t) { /* no such variable */
    sprintf(s,"No such variable '%s' in instrument '%s'.",
	    vname,cx->instr->id->name);
    runtime(cx->sa,s);
  }
	
	/* set the value of the variable */
  else cx->framevals[t->s->offset + index].val = val;
}

sa_real get_var_value(context *cx, expr *p, int index) {
  /* get the value of a variable */
  frameval *fv;
  sa_decoder *sa = cx->sa;

  if (!strcmp(p->d->iname,"input")) { /* input is special */
	  /* get the current input sample (ASAMPLE_PTR tells us which a-cycle this is) */
	  if (index >= cx->instr->inchan) {
		  char s[100];

		  sprintf(s,"Not that many input channels to instrument (index = %d, # channels = %d).",index,cx->instr->inchan);
		  runtime(sa,s);
	  }
    if (cx->instr->input) return cx->instr->input[index][cx->asample_ptr];
    else return 0;
  }
  
	/* get the value from the frame */
  fv = get_frameval(cx,p,index);
  return(fv->val);
}

void add_standard_names(instr_handle *h);
void add_controllers(instr_handle *h);

instr_handle *new_instr_instance(sa_decoder *sa, char *iname, sa_real *pf,int inchan, int preset) {
  /* allocate new context for instr; run i-time; register with scheduler */
  /* NB first value in pf parameter list is the duration */
  symbol *sym;
  instr_decl *id;
  context *cx;
  instr_handle *h;
	
  sym = get_instr_decl(sa->all->g->sym,iname); /* look up instr in symbol table */
  if (!sym) {
	  /* no such instrument */
    printf("Unknown instrument '%s', continuing...\n",iname);
  } else {
		
    id = (instr_decl *)(sym->defn); /* get its declaration */
    cx = new_context(sa,id,inchan); /* make the context */
    set_context_pfields(cx,pf);     /* set the pfield variables */
    cx->localvars = id->sym;        /* hook up the symbol table */
    cx->preset = preset % 128;      /* set MIDI parameters */
    cx->channel = 0; /* gets filled in later */
    cx->midibank = preset / 128;
#ifdef _SASBF
    if (id->sym) {                 /* make a SASBF space for each sasbf instance */
      cx->sfstorage = (struct SynthParams **)calloc(id->sym->sasbf_ct,sizeof(struct SynthParams *));
      for (i=0;i!=id->sym->sasbf_ct;i++) cx->sfstorage[i] = NULL;
    }
    else
      cx->sfstorage = NULL;
   
#endif
		
	/* tell the scheduler about it -- makes the noteoff event*/
    h = register_inst(sa,id,cx,pf[0]); 
    h->origin = ORIGIN_INSTR;  /* as opposed to ORIGIN_SEND or ORIGIN_STARTUP */
    h->inchan = inchan;        /* how many input channels */
    h->pedal_delay = 0;        
    cx->instr = h;		/* save its handle */
		
    add_standard_names(h);     /* add standard names to the controller list */
    add_controllers(h);      /* add imported variables to the controller list */

	/* set standard names */
    set_host_value(h,"time",0,sa->sched->time);
    set_host_value(h,"dur",0,pf[0]);
    
    run_itime(id,cx);	/* run its i-time stuff */
    return(h);  /* return the handle */
  }
  return NULL; /* no such instrument -- no handle */
}


void add_standard_names(instr_handle *h) {
	/* add variables for all the standard names to the controller list */
  int i;
	
  for (i=0;i!=NUM_STD_NAMES;i++)
    new_host_var(h,std_names[i].name,std_names[i].width,std_names[i].type);

  /* set values */
  set_host_value(h,"s_rate",0,(sa_real)h->cx->sa->all->g->srate);
  set_host_value(h,"k_rate",0,(sa_real)h->cx->sa->all->g->krate);
  set_host_value(h,"inchan",0,(sa_real)h->inchan);
  set_host_value(h,"outchan",0,(sa_real)h->cx->sa->all->g->outchan);
  set_host_value(h,"released",0,0);
  set_host_value(h,"cpuload",0,0);
}

void add_controllers(instr_handle *h) {
  /* add host variables declared as 'imported' in this instrument to the 
	  controller list */
  symtable *t;

  /* go through the list of local variables */
  for (t = h->cx->localvars; t && t->s; t=t->next) {
	  if (t->s->imported && !t->s->glink) { /* controller rather than global */
      new_host_var(h,t->s->name,t->s->width, t->s->type);
      set_host_value(h,t->s->name,0,0);
    }
  }
}

void run_itime(instr_decl *id, context *cx) {
  /* run the i-time things in instrument ID */
  int ct=0;
  symtable *t;
	
  /* local time is 0 */
  cx->instr->itime = 0;
  set_host_value(cx->instr,"itime",0,0.0);

  /* get the values of all the global variables */
  push_context(cx,IVAR);

  /* make the wavetables */
  for (t = cx->localvars;t && t->s;t=t->next)
    if (t->s->type == TABLE && t->s->binding == LOCAL && !t->s->imported)
      cx->framevals[t->s->offset].table = make_table(cx,t->s->table);
	
  /* eval the i-time code wrt the new context */
  eval_block(cx,id->code,IVAR);
	
  /* copy out global variables */
	
  pop_context(cx,IVAR);
}

void run_katime(instr_decl *id, context *cx,long rate) {
	/* run a k-cycle or a whole block of a-cycles for an instrument */
  int i;
  sa_decoder *sa = cx->sa;
  
  /* get the values of all the global variables */
  push_context(cx,rate);
	
  if (rate == KSIG) {		/* run once */
    cx->asample_ptr = 0;
#ifdef _MPEGPROFILER
    first_ka = 1;
    opt_mem = 0;
#endif
	/* update the local time */
    cx->instr->itime += (sa_real)1.0 / cx->sa->all->g->krate;
    set_host_value(cx->instr,"itime",0,cx->instr->itime);
	/* evaluate the code block */
    eval_block(cx,id->code,KSIG);
  }
  else { /* run many times; the sample pointer tells
		    get_ and set_var_value where to read/put
		    audio samples */
    zero_instr_output(cx->instr); /* clear the output */
    for (i=0;i!=cx->sa->ksmps;i++) {
      cx->asample_ptr = i; /* update sample pointer */
      eval_block(cx,id->code,ASIG); /* eval code block */
#ifdef _MPEGPROFILER
      if(first_ka) first_ka = 0;  /* memory is considered only at the first cycle */
#endif
    }
  }

  /* copy out global variables */
  pop_context(cx,rate);
}
