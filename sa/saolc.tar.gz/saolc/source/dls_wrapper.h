/* dls_wrapper.h */

#ifndef DLS_WRAPPER_H
#define DLS_WRAPPER_H
#include "sfe_datatype.h"
/* #define SUCCEEDED(status) ((signed long)(status) >= 0) */

BEGINEMUCTYPE
typedef void * PInstrMgr;

typedef struct dls_bank_struct{
	PInstrMgr	instrument;
	unsigned char	*gpData;
	unsigned long	gdwDataSize;
	HANDLE	hCollection;
	HANDLE	ghFile;
	HANDLE  ghMapFile;
}dls_bank;

PInstrMgr CreateInstrMgr();
void	DestroyInstrMgr(PInstrMgr pInstr);
HRESULT	DownloadCollection(dls_bank *bank);
HRESULT UnloadCollection(dls_bank *bank);
HRESULT OpenCollectionFile(dls_bank *bank, char *filename);
void	CloseCollectionFile(dls_bank *bank);
HRESULT	GetSynthParams(dls_bank *bank, DWORD dwPatch, DWORD dwNote, DWORD dwVel, sfData *pParams, DWORD dwLayer);

ENDEMUCTYPE
#endif
