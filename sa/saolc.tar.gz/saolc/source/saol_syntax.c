/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_syntax.c : syntax-check the orchestra and build all the symbol tables */

/* this module is called during the decoder startup, after the parse tree is
   constructed, to check that variables and opcodes have the proper declarations.
   As part of this, we built a SYMBOL TABLE for each opcode and instrument in
   the orchestra.  The symbol table is used to keep track of names that have
   been declared within each context. 

   The most important function here is build_sym_table() -- that's the one
   that is called by main().
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "saol_prec.h"
#include "saol.tab.h"
#include "saol.h"
#include "saol_co_imp.h"

#include <string.h>
#include <malloc.h>

extern int sasbf_width();

orc_global *new_orc_global(void) {
	/* make a new global block for the orchestra */
	orc_global *g;
	
	PROT_MAL(g,orc_global,new_orc_global);
	g->max_actp_ct = 0;
	g->srate = 0;
	g->krate = 0;
	g->inchan = 0;
	g->outchan = 0;
	g->gvars = NULL;
	g->routes = NULL;
	g->sends = NULL;
	g->seqs = NULL;
	g->interp = 0;

	return(g);
}


void sort_global_decls(sa_decoder *sa, orc_global *og, global_block *gl) {
/* sort the global_block parsing into the slots and
	lists for the orchestra global structure.  GL has the line-by-line
	data that associates tags with values ("SRATE 22000"), but hasn't
	organized that data (it's just a list of lines).  
	
	We need to fill in the structure in OG. */
	
	while (gl && gl->d) {
		/* go through each line in the global block */
		switch (gl->d->type) {
		case SEND:
			/* this line is a 'send' -- add it to the list of sends */
			if (!og->sends)
				og->sends = new_send_list(gl->d->senddef);
			else
				add_send_list(og->sends,gl->d->senddef);
			break;
		case ROUTE:
			/* this line is a 'route' -- add it to the list of route */
			if (!og->routes)
				og->routes = new_route_list(gl->d->routedef);
			else
				add_route_list(og->routes,gl->d->routedef);
			break;
		case VARDECL:
			/* this line is a variable declaration -- add it to the list of vardecls */
			if (!og->gvars) 
				og->gvars = new_vardecl_list();
			add_vardecl_list(og->gvars,gl->d->vardecl);  
			break;
		case SEQUENCE:
			/* this line is a sequence definition -- add it to the list of sequences */
			if (!og->seqs)
				og->seqs = new_sequence_list(gl->d->seqdef);
			else
				add_sequence_list(og->seqs,gl->d->seqdef);
			break;
		case KRATE:
			/* keep track of krate */
			if (og->krate) /* already seen one 'krate' value (5.8.5.2.2) */
				parse_error_line("krate value already defined (5.8.5.2.2).",gl->d->lineno);
			og->krate = gl->d->rtparam;
			break;
		case SRATE:
			/* keep track of srate */
			if (og->srate) /* already seen one 'srate' value (5.8.5.2.1) */
				parse_error_line("srate value already defined (5.8.5.2.1).",gl->d->lineno);
			og->srate = gl->d->rtparam;
			break;
		case INCHANNELS:
			/* keep track of #input channels */
			if (og->inchan) /* already seen one 'inchannels' value */
				parse_error_line("inchannels value already defined (5.8.5.2.3).",gl->d->lineno);
			og->inchan = gl->d->rtparam;
			break;
		case OUTCHANNELS:
			/* keeep track of #output channels */
			if (og->outchan) /* already seen one 'outchannels' value */
				parse_error_line("outchannels value already defined (5.8.5.2.4).",gl->d->lineno);
			og->outchan = gl->d->rtparam;
			break;
		case INTERP:
			if (og->interp) /* already seen one 'interp' value */
				parse_error_line("interp value already defined (5.8.5.2.5).",gl->d->lineno);
			if (gl->d->rtparam < 0 || gl->d->rtparam > 1) /* illegal value */
				parse_error_line("interp value must be 0 or 1 (5.8.5.2.5).",gl->d->lineno);
			og->interp = gl->d->rtparam;
			break;	

		default:
			interror("Unknown global type in sort_global_decls()!\n");
		}
		gl = gl->next;
	}
	
	/* maybe dump out the global information */
	if (sa->verbose) print_global(sa);

	/* if the krate is given, but doesn't divide the srate, move up to the next
	   fastest integer krate that does divide the srate (5.8.5.2.2) */

	if (sa->all->g->krate &&
		fabs(floor((sa_real)sa->all->g->srate/sa->all->g->krate) * sa->all->g->krate - sa->all->g->srate)
		> 0.0001) {
		char s[200];
		while (fabs(floor((sa_real)sa->all->g->srate/sa->all->g->krate) * sa->all->g->krate - sa->all->g->srate)
			> 0.0001) sa->all->g->krate++;
		sprintf(s,"Set krate to %d in order to divide srate (5.8.5.2.2).",sa->all->g->krate);
		warn_line(s,0);
	}
	
	if (sa->cmd->interp && og->interp == 0) /* -iq flag used */
		warn_line("-iq flag ignored for interp 0.",0);
				
}


void print_global(sa_decoder *sa) {
	/* just for informative purposes, dump out the global data */
	vardecl_list *vdl;
	namelist *nl;
	route_list *rl;
	send_list *sl;
	sequence_list *seql;
	
	printf("\nGlobal orchestra information: \n");
	printf("        srate: %d\n",sa->all->g->srate);
	printf("        krate: %d\n",sa->all->g->krate);
	printf("   inchannels: %d\n",sa->all->g->inchan);
	printf("  outchannels: %d\n",sa->all->g->outchan);
	printf("       interp: %d\n",sa->all->g->interp);
	printf("         vars: ");
	/* dump out all the global variables */
	for (vdl = sa->all->g->gvars;vdl;vdl=vdl->next) {
		for (nl = vdl->v->nl;nl;nl=nl->next) 
			printf("%s %c",nl->n->name,(vdl->v->imported + vdl->v->exported) ? '+' : 0);
	}
	printf("\n");
	printf("       routes: ");
	/* dump out all the route statements */
	for (rl = sa->all->g->routes;rl;rl=rl->next) {
		for (nl = rl->r->instrs;nl;nl=nl->next)
			printf("%s -> |%s| ",nl->n->name,rl->r->bus);
	}
	printf("\n");
	printf("        sends: ");
	/* dump out all the send statements */
	for (sl = sa->all->g->sends;sl;sl=sl->next)
		printf("%s ",sl->s->instr);
	printf("\n");
	printf("       busses: ");
	/* dump out all the busses */
	for (sl = sa->all->g->sends;sl;sl=sl->next) {
		for (nl = sl->s->busses;nl;nl=nl->next)
			printf("%s ",nl->n->name);
	}
	printf("\n");
				printf("         seqs: ");
				/* dump out all the sequence statements */
				for (seql = sa->all->g->seqs;seql;seql=seql->next) {
					for (nl = seql->s->seqlist;nl;nl=nl->next) {
						printf("%s",nl->n->name);
						if (nl->next)
							printf(" < ");
					}
					if (seql->next)
						printf("; ");
				}
				printf("\n");
}

void determine_bus_widths(sa_decoder *);
void determine_input_widths(sa_decoder *);
void determine_output_widths(sa_decoder *sa);
void setup_route_channels(sa_decoder *sa);

void build_sym_table(sa_decoder *sa) {
/* build and check the symbol and bus tables for each instr, opcode, and the
	global block */
	instr_list *il;
	route_list *rl;
	send_list *sl;
	sequence_list *seql;
	opcode_list *op;
	char s[340];
	int i;
	
	/* clean up input/output values. SA->INCHAN is the number of inputs actuall
	   present on command line or from AudioBIFS.  SA->ALL->G->INCHAN is the
	   number specified in the global block. */
	
	if (!sa->all->g->inchan) /* not specified in global */
		sa->all->g->inchan = sa->inchan; /* same as given (5.8.5.2.3) */
	
	/* Not enough given -- generate warning (5.8.5.2.3) */
	if (sa->all->g->inchan > sa->inchan) {
		sprintf(s,"Orchestra wants %d input channel(s); only %d given.  Rest will be zero (5.8.5.2.3).",sa->all->g->inchan, sa->inchan);
		warn_line(s,0);
	}
	
	/* Too many given -- generate warning (5.8.5.2.3) */
	if (sa->all->g->inchan < sa->inchan) {
		sprintf(s,"%d channels of input given; orchestra only wants %d.\n",
			sa->inchan,sa->all->g->inchan);
		strcat(s,"         Ignoring extra channel(s) (5.8.5.2.3).");
		warn_line(s,0);
	}
	
	if (!sa->all->g->outchan) { /* outchannels not given */
		sa->all->g->outchan = 1;
		sprintf(s,"No outchannels given; defaulting to 1 (5.8.5.2.4).\n");
		warn_line(s,0);
	}  
	
	/* add symbols: global block first */
	
	/* make the global symbol table */
	sa->all->g->sym = new_symtable(0);
	
	/* add all the core opcodes to it */
	add_sym_table_core_opcodes(sa->all->g->sym);
	
	/* add all the global table decls to it */
	add_sym_table_decls(sa,sa->all->g->sym,sa->all->g->gvars);
	
	/* add all the busses to it */
	sa->all->g->bus = make_bus_table(sa,sa->all->g->sends);
	
	/* go through all the instruments */
	for (il=sa->all->il,i=0;il;il=il->next,i++) { 
		/* number them in order */
		il->i->num = i;
		/* add them to the global symbol table */
		add_sym_table_name(sa->all->g->sym,il->i->name,INSTR,il->i);
	}

	/* check that all of the variables used in the global block (like in
	   send statements and global wavetables) are declared */

	check_sym_ref_vardecls(sa,sa->all->g->sym,sa->all->g->gvars);
	
	/* check that all of the instruments used in the sequence lists are
	   declared */

	for (seql=sa->all->g->seqs;seql;seql=seql->next) 
		check_instr_ref_namelist(sa->all->g->sym,seql->s->seqlist);
	
	/* check that all of the variables used in send statements are declared,
	   and that each instrument used in a send statement is defined */
	for (sl=sa->all->g->sends;sl;sl=sl->next) {
		check_sym_ref_exprlist(sa,sa->all->g->sym,sl->s->pfields);
		check_instr_ref_name(sa->all->g->sym,sl->s->instr);
	}
	
	/* check that all of the 'route' statements have a declared bus (busses
	   are declared by 'send' statements (5.8.5.4), that the instruments referenced
	   by 'route's really exist, and then attach the routes to their instruments */
	for (rl = sa->all->g->routes;rl;rl=rl->next) {
		check_bus(sa->all->g->bus,rl->r->bus);
		check_instr_ref_namelist(sa->all->g->sym,rl->r->instrs);
		attach_route(sa,sa->all->g->sym,rl->r->bus,rl->r->instrs);
	}
	
	/* now we can make the overall sequence of instruments (5.8.5.6) */
	make_sequence(sa);  /* in saol_sequence.c */


	/* now add symbols for each instr */
	for (il=sa->all->il;il;il=il->next) { /* go through each instrument */
		/* make a symbol table for it */
		il->i->sym = new_symtable(1);
		/* add all of its p-fields */
		add_sym_table_namelist(sa,il->i->sym,il->i->params,IVAR,NOTAG,FORMALPARAM);
		/* add all of its local variables */
		add_sym_table_decls(sa,il->i->sym,il->i->localvars);
	}
	
	/* and now each opcode */
	for (op=sa->all->op;op;op=op->next) { /* go through all of the opcodes */
		/* make a symbol table for it */
		op->o->sym = new_symtable(1);
		/* add the opcode to the global symbol table */
		add_sym_table_name(sa->all->g->sym,op->o->name,op->o->type,op->o);
		/* add the formal parameters of the opcode to the opcode symtable */
		add_sym_table_fplist(op->o->sym,op->o->params);
		/* add the local variables of the opcode to the symtable */
		add_sym_table_decls(sa,op->o->sym,op->o->localvars);
	}
	
	/* now check each instrument's code */

	for (il=sa->all->il;il;il=il->next) {
		/* check that all of the symbols used in the variable declarations
		   (for example, in table initializers) have actually been declared */
		check_sym_ref_vardecls(sa,il->i->sym,il->i->localvars);
		/* check that all of the variables used in the code block have
		   been declared  -- this also figures out and checks the width of
		   each expression, and marks all the symbols that are used */
		check_sym_ref_block(sa,il->i->sym,il->i->code);
	}
		
	
	/* now figure out the number of input and output channels for each 
	   instrument (5.7.3.3.5.2) */

	determine_output_widths(sa);
	determine_bus_widths(sa);
	determine_input_widths(sa);
	setup_route_channels(sa);

	/* now check each opcode's code */
	for (op=sa->all->op;op;op=op->next) {
		/* make sure all the variables used in the variable declarations
		   have been declared */
		check_sym_ref_vardecls(sa,op->o->sym,op->o->localvars);
		/* make sure all the variables used in the code have been declared */
		check_sym_ref_block(sa,op->o->sym,op->o->code);
	}


	/* remove unused global variables */
	sa->all->g->sym = remove_unused_symbols(sa,NULL,sa->all->g->sym);     

	for (il=sa->all->il;il;il=il->next)
	  /* remove any symbols that are declared, but not actually used anywhere
	  in the instrument, from the symbol table */
	  il->i->sym = remove_unused_symbols(sa,il->i,il->i->sym);
	
}

struct std_name_struct std_names[] = { 
	/* these are all of the standard names in SAOL (5.8.6.8) -- we need this
	   to add standard names to the symbol tables when they're used */
	{ "input", -1, ASIG},  /* these have to go first for frame sizes to work */
	{ "inGroup", -1, IVAR},
	{ "k_rate", 1, IVAR },
	{ "s_rate", 1, IVAR },
	{ "inchan", 1, IVAR },
	{ "outchan", 1, IVAR },
	{ "time", 1, IVAR },
	{ "dur", 1, IVAR },
	{ "itime", 1, KSIG },
	{ "MIDIctrl", 128, KSIG},
	{ "MIDItouch", 1, KSIG},
	{ "MIDIbend", 1, KSIG},
	{ "channel", 1, IVAR},
	{ "preset", 1, IVAR},
	{ "released", 1, KSIG},
	{ "cpuload", 1, KSIG} ,
	{ "position", 3, KSIG},
	{ "direction", 3, KSIG},
	{ "listenerPosition", 3, KSIG},
	{ "listenerDirection", 3, KSIG},
	{ "minFront", 3, KSIG},
	{ "minBack", 3, KSIG},
	{ "maxFront", 3, KSIG},
	{ "maxBack", 3, KSIG},
	{ "params", 128, KSIG}
};

symtable *new_symtable(int use_std_names) {
	/* make a new symbol table.  If USE_STD_NAMES is set, put all the
	   standard names in it */
	int i;
	symtable *s;
	symbol *sym;
	
	PROT_MAL(s,symtable,new_symtable);
	s->s = NULL;
	s->next = NULL;
	s->sasbf_ct = 0;
	
	if (use_std_names) {
		for (i=0;i!=NUM_STD_NAMES;i++) {
			sym = add_sym_table_name(s,std_names[i].name,std_names[i].type, NULL);
			sym->binding = STANDARD_NAME;
			sym->width = std_names[i].width;
			
		}
	}
	return(s);
}

symbol *add_sym_table_name(symtable *t, char *name, long type, void *dref) {
	/* add a name to a symbol table.  
	    NAME is the new variable name, TYPE is its rate, DREF is a pointer
		to its declaration.
    */
	symbol *s;
	symtable *newt,*last,*t2;
	
	/* if the symbol is already in the symbol table, just return the
	   existing entry */
	for (t2 = t;t2 && t2->s;t2=t2->next) {
		if (!strcmp(t2->s->name,name))
			return t2->s;
	}
	
	/* make space */
	PROT_MAL(s,symbol,add_sym_table_name);
	s->name = strdup(name);
	s->width = 0;
	s->type = type;
	s->imported = 0;
	s->exported = 0;
	s->symtable_ref = t;
	s->defn = dref;
	s->glink = NULL;
	s->table = NULL;
	s->binding = 0;
	s->mark = 0;
	s->tablemap = NULL;
	
	/* if there's already symbols in the table */
	if (t && t->s) {
		PROT_MAL(newt,symtable,add_sym_table_name);
		for (;t;last=t,t=t->next) ; /* add this one to the end */
		newt->next = NULL;
		newt->s = s;
		last->next = newt;
	}
	else {
		if (!t)
			t = new_symtable(0);
		t->s = s; /* this is the first symbol */
	}
	return s;
}

bustable *make_bus_table(sa_decoder *sa, send_list *sl) {
	/* put all the busses in the orchestra into a nice list */
	bustable *bt,*first=NULL,*last;
	namelist *nl;
	
	/* if there's no send statements, there's no bus table */
	if (!sl || !sl->s) return NULL;
	
	/* go through all the sends */
	for (;sl;sl=sl->next) {
		/* each send has several busses */
		for (nl=sl->s->busses;nl;nl=nl->next) {
			/* if the bus isn't already in the table */
			if (!get_bus(first,nl->n->name)) {
				/* make space and initialize */
				PROT_MAL(bt,bustable,make_bus_table);
				bt->name = strdup(nl->n->name);
				if(nl->n->det) {  /* a value for bus width was included in brackets */
					bt->width = nl->n->width;
					bt->detwidth = bt->width;
				} else {
					bt->width = 0;  /* need to do later, when we check outputs */
					bt->detwidth = -1;
				}
				/* if this is the input bus, mark it in the main decoder structure */
				if (!strcmp(bt->name,"input_bus")) {
					sa->inbus = bt;
					bt->width = sa->inchan;
				}
				/* if this is the output bus, use that to set its width */
				if (!strcmp(bt->name,"output_bus")) {
					bt->width = sa->all->g->outchan;
				}
				bt->next = NULL;
				bt->send = sl->s;
				/* add to the list */
				if (!first) { first = bt; last = first; }
				else { last->next = bt; last = bt; }
			}
		}
	}
	
	/* keep track of whether or not there is an 'output_bus' (it matters
	   when we do orchestra output) */
	if (!get_bus(bt,"output_bus"))
		sa->is_outputbus = 0;
	else
		sa->is_outputbus = 1;
	return first;
}

void set_bus_width(bustable *bt, int width) {
	bt->width = width;
}

void add_sym_table_decls(sa_decoder *sa,symtable *t, vardecl_list *vdl) {
	/* add all of the variable declarations in an instrument to the symbol table.
	   VDL has a linked list, where each element is one line of declarations
	     (and so might have many names in it).
	   we have to sort those names out into the symbol table */
	symbol *newsym;
	char s[1000];
	
	for (; vdl; vdl =vdl->next) { /* go through variable declarations */
		/* otherwise, no declarations on this line */
		if (vdl->v) {
			if (!vdl->v->tablemap_name) 
				/* anything other than a tablemap (although this doesn't actually
				   do anything for a table, either) */
				/* add all the names to the symbol table */
				add_sym_table_namelist(sa,t,vdl->v->nl,vdl->v->type,
				MAKE_IMPEXP_TAG(vdl->v->imported,vdl->v->exported),
				LOCAL);
			if (vdl->v->t) { /* table definition */
				if (get_sym_decl(t,vdl->v->t->name)) { /* table already exists */
					sprintf(s,"Repeat declaration of table %s.",vdl->v->t->name);
					parse_error(s);
				}
				/* add the table name to the symbol table */
				newsym = add_sym_table_name(t,vdl->v->t->name,TABLE,vdl->v);
				newsym->binding = LOCAL;
				newsym->table = vdl->v->t; /* keep track of the table declaration */
				newsym->width = 1;
			}
			if (vdl->v->tablemap_name) { /* tablemap definition */
				/* just add it as a tablemap symbol */
				newsym = add_sym_table_name(t,vdl->v->tablemap_name,TABLEMAP,vdl->v);
				newsym->tablemap = vdl->v->nl; /* but keep track of the declaration */
			}
		} 
	}
}

void add_sym_table_namelist(sa_decoder *sa,symtable *t, namelist *nl, long type, long gtag,
							int binding) {
	/* add all the names in a namelist to a symbol table.
	    T is the symtable we're adding to
		NL is the list of names
		TYPE is the rate type of each of the names in the list (they all
		   must have the same type)
	    GTAG is the imports/exports tag for the names
		BINDING tells whether they're LOCAL variables, FORMALPARAMS, or what */
	char s[1000];
	symbol *newsym,*sym,*newsym2;
	
	for ( ; nl && nl->n ; nl=nl->next) { /* for each name declared in this defn */
		
		/* can't declare a variable more than once */
		if (get_sym_decl(t,nl->n->name)) {
			sprintf(s,"Repeat declaration of '%s'",nl->n->name);
			parse_error_line(s,nl->lineno);
			break;
		}
		
		/* make a new symbol for the name */
		newsym = add_sym_table_name(t,nl->n->name,type,nl);

		/* figure out its width */
		if (nl->n->width >= 0) 
			newsym->width = nl->n->width;
		else if (nl->n->width == -1) /* inchannels */
			newsym->width = -1;
		else if (nl->n->width == -2) /* outchannels */
			newsym->width = sa->all->g->outchan;

		/* set import/export tags */
		newsym->imported = (gtag == IMPEXP || gtag == IMPORTS) ;
		newsym->exported = (gtag == IMPEXP || gtag == EXPORTS) ;
		newsym->glink = NULL;
		newsym->binding = binding;
		
		/* now check some things about global binding -- 
		   make sure global variable rate matches global declaration 
		   make global symbols for future wavetables
		   make sure only ksig variables are globally exported/imported
		   make sure asigs are not global
		   make sure imp/exp ivars have global declaration 

		   imp ksigs don't need to have global declaration (although it's
		     allowed); if they don't, they're controllers */

		if (gtag != NOTAG) {      /* if we're importing/exporting, and */
			if (t != sa->all->g->sym) { /*    we're not in the global block, and */
				if (sym = get_sym_decl(sa->all->g->sym,nl->n->name)) { /* we find name match */
		
					/* rate of global variable must match global definition (5.8.6.5.3) */
					if (sym->type != type) { 
						sprintf(s,"Imports/exports definition of '%s' doesn't match global type (5.8.6.5.3).",nl->n->name);
						parse_error_line(s,nl->lineno);
					}
					/* hook up local variable to global variable */
					else newsym->glink = sym;
					
				} else  { /* no match in global context */
					if (newsym->exported) {
						sprintf(s,"Exported variable '%s' must be globally declared.\n",newsym->name);
						parse_error_line(s,nl->lineno);
					}
					switch (type) {
					case TABLE: /* must be a future wavetable (5.8.6.5.4.) */
						sprintf(s,"No global declaration for table placeholder '%s', assumed dynamic:",
							nl->n->name);
						warn_line(s,nl->lineno);
						
						/* add a symbol for it in the global context */
						newsym2 = add_sym_table_name(sa->all->g->sym,nl->n->name,type,nl);
						newsym2->binding = FUTURE_WAVETABLE;
						newsym2->imported = 1;
						newsym2->exported = 0;
						newsym2->width = 1;
						break;
					case IVAR: /* must share with global block */
						sprintf(s,"No global declaration for ivar '%s' (5.8.6.5.3).",
							nl->n->name);
						parse_error_line(s,nl->lineno);
						break;
					case ASIG: /* cannot be global */
						sprintf(s,"asig variable '%s' cannot be global (5.8.6.5.3).",nl->n->name);
						parse_error_line(s,nl->lineno);
						break;
					default: /* must be a controller  */
						break;
					}
				}
			} 
		} else { /* gtag == NOTAG; this is not an imp/exp variable */
			if (type == TABLE) {
				/* this declaration is like "table k;" */
				if (t == sa->all->g->sym) { /* if we're in the global block */
					/* have to have real definition */
					sprintf(s,"Table placeholder '%s' not allowed in global block.",
						nl->n->name);
					parse_error_line(s,nl->lineno);
				}
				else {
					/* have to get the definition from the global context */
					sprintf(s,"Table placeholder '%s' must be declared with 'imports' or 'exports'.",
						nl->n->name);
					parse_error_line(s,nl->lineno);
				}
			}
		}
	}
}

void add_sym_table_fplist(symtable *t, formalparam_list *fpl) {
	symbol *sym;
	/* add all of the formal parameters for an opcode to that opcode's 
	   symbol table */

		for (; fpl && fpl->fp; fpl=fpl->next) { /* go through all symbols */
			/* add to symtable */
			sym = add_sym_table_name(t,fpl->fp->n->name,fpl->fp->type,fpl);
			sym->binding = FORMALPARAM;
			/*sym->imported = 1;*/  /* because tables are always call-by-ref,
								   we need to treat them as imported for
			                       releasing a context frame YYY*/
			sym->width = fpl->fp->n->width;
			sym->mark = 1; /* mark as seen, don't ever clean up formalparams */
		}
}

void check_sym_ref_vardecls(sa_decoder *sa, symtable *t, vardecl_list *vdl) {
	/* check all of the symbol references in a variable declaration list */
	symbol *sym;
	namelist *nl;
	char s[800];
	
	/* symbols only occur in a vardecl_list in table decls or tablemap decls */
	for (; vdl && vdl->v; vdl=vdl->next) { /* go through all the vardecls */
		if (vdl->v->t) /* table -- check the parameters */
			check_sym_ref_exprlist(sa,t,vdl->v->t->params); 
		if (vdl->v->tablemap_name) { /* tablemap */
			for (nl=vdl->v->nl;nl && nl->n; nl=nl->next) { /* go through each name -- make sure it's a table */
				if (!(sym = get_sym_decl(t,nl->n->name)) || (sym->type != TABLE)) {
					sprintf(s,"'%s' is not a wavetable.",nl->n->name);
					parse_error_line(s,vdl->v->lineno);
				}
				else /* we've seen the table */
					sym->mark = 1;
			}
		}
	}
}
int determine_temp_bus_width(sa_decoder *, bustable *);
void set_instr_output_width(sa_decoder *, instr_decl *, int);
int instr_block_output_width(block *, int );
bustable *find_input_bus(sa_decoder *,instr_decl *);

void determine_output_widths(sa_decoder *sa) {
	int i,num=0,w;
	instr_list *il;
	instr_decl *id;
	bustable *bus;

	/* count instruments */
	for (il=sa->all->il;il && il->i;il=il->next) num++;

	/* go through all instruments in order */
	for (i=0;i!=num;i++) {
		for (il=sa->all->il; il && il->i && sa->seq[il->i->num] != i; il=il->next) ;
		if (sa->seq[il->i->num] != i) 
			interror("Couldn't find instrument in determine_output_width()");
		id = il->i;

		bus = find_input_bus(sa,id);
		if (bus && bus->detwidth == -1) /* don't have width yet */
			w = determine_temp_bus_width(sa,bus);
		else
			if (bus) w = bus->detwidth;
		if (!bus || !w) /* no input channels */
			id->indetwidth = 1;
		else 
			id->indetwidth = w; /* NB not necessarily the real input width */

		set_instr_output_width(sa,id,id->indetwidth);
	}
}

bustable *find_input_bus(sa_decoder *sa,instr_decl *id) {
	bustable *bus;

	for (bus=sa->all->g->bus;bus;bus = bus->next) {
		if (!strcmp(bus->send->instr,id->name))
			return bus;
	}
	return NULL;
}


int determine_temp_bus_width(sa_decoder *sa,bustable *bus) {
	route_list *rl;
	instr_decl *id;
	namelist *nl;
	int ct, found;

	if (!strcmp(bus->name,"input_bus")) {
		bus->detwidth = sa->all->g->inchan;
		return sa->all->g->inchan;
	}

	/* if the bus is declared with its width, detwidth is already set */

	found = 0;
	for (rl=sa->all->g->routes;rl && rl->r;rl=rl->next) { /* go through all routes */
		if (get_bus(sa->all->g->bus,rl->r->bus) == bus) { /* find routes to this bus */
			ct = 0;
			/* look for the first route to this bus with more than 1 channel */
			for (nl=rl->r->instrs;nl && nl->n;nl=nl->next) {
				id = get_instr_decl(sa->all->g->sym,nl->n->name)->defn;
				ct = ct+id->width;
			}
			if (ct > 1) {
				bus->detwidth = ct;
				return ct;
			}
			if (ct)
				found = 1;
		}
	}
	if (found) {
		bus->detwidth = 1;
		return 1;
	}
	bus->detwidth = 0;
	return 0;
}

void set_instr_output_width(sa_decoder *sa, instr_decl *id, int inwidth) {
	/* inwidth is the temporary width */
	id->width = instr_block_output_width(id->code,inwidth);
}

int instr_block_output_width(block *b, int inwidth) {
	exprlist *el;
	int found, ct;

	found = 0;
	/* look for the first 'output' with more than one channel */
	for (b;b && b->st; b=b->next) {
		if (b->st->type == OUTPUT) {
			ct = 0;
			for (el=b->st->params; el && el->p; el = el->next) {
				if (el->p->width == -1)
					ct += inwidth;
				else
					ct += el->p->width;
			}
			if (ct > 1) return ct; /* we check that they all match later */
			else if (ct) found = 1; /* at least remember we found one */
		}
		if (b->st->type == IF || b->st->type == ELSE) {
			ct = instr_block_output_width(b->st->b,inwidth);
			if (ct > 1) return ct;
			else if (ct) found = 1;
		}
		if (b->st->type == ELSE) {
			ct = instr_block_output_width(b->st->elseb,inwidth);
			if (ct > 1) return ct;
			else if (ct) found = 1;
		}
	}

	if (found) return 1;
	else return 0;  /* no return in this block */
}

void determine_bus_widths(sa_decoder *sa) {
	route_list *rl;
	instr_decl *id;
	namelist *nl;
	bustable *bus;
	int found, ct;

	for (bus=sa->all->g->bus;bus;bus=bus->next)  {
		
		if(!strcmp(bus->name, "input_bus")) {
			bus->width = sa->inchan;
			continue;
		}
		if(bus->width > 0)  /* it has been set in the send statement */
			continue;

		bus->width = 0;
		found = 0;
		for (rl=sa->all->g->routes; rl && rl->r; rl = rl ->next) {
			if (get_bus(sa->all->g->bus,rl->r->bus) == bus) {
				ct = 0;	
				/* look	for the first route to this bus with more than 1 channel */
				for (nl=rl->r->instrs;nl && nl->n;nl=nl->next) {
					id = get_instr_decl(sa->all->g->sym,nl->n->name)->defn;
					ct = ct+id->width;
				}
				if (ct > 1) {
					bus->width = ct;
					break;
				}
				if (ct)
					found = 1;
			}
		}
		if (!bus->width && found) 
			bus->width = 1;
	}

	/* now check all the routes to make sure they're right */
	for (rl=sa->all->g->routes; rl && rl->r; rl = rl ->next) {
		ct = 0;
		for (nl=rl->r->instrs;nl && nl->n;nl=nl->next) {
			id = get_instr_decl(sa->all->g->sym,nl->n->name)->defn;
			ct = ct+id->width;
		}
		if (ct != 1 && ct != get_bus(sa->all->g->bus,rl->r->bus)->width) {
			char s[200];

			sprintf(s,"Widths of 'route' statements to bus '%s' don't match.",
				rl->r->bus);
			parse_error(s);
		}
	}
}

void determine_input_widths(sa_decoder *sa) {
	instr_list *il;
	instr_decl *id;
	int ct;
	symtable *t;
	send_list *sl;
	namelist *nl;

	
	for (il=sa->all->il;il && il->i;il=il->next) { il->i->inchan = 0; }

	for (sl=sa->all->g->sends;sl && sl->s; sl=sl->next) {
		ct = 0;
		for (nl=sl->s->busses;nl && nl->n;nl=nl->next)
			ct += get_bus(sa->all->g->bus,nl->n->name)->width;
		
		id = get_instr_decl(sa->all->g->sym,sl->s->instr)->defn;
		if (id->inchan && id->inchan != ct)  {
			char s[200];
			sprintf(s,"All 'send' instances of instrument '%s' must have the same number of input channels.",
				il->i->name);
			parse_error(s);
		}
		else {
			
			id->inchan = ct;
		}
	}
	
	for (il=sa->all->il;il && il->i;il=il->next) {
		for (t=il->i->sym;t && t->s;t = t->next) {
			/* fix up input widths */
			if (t->s->width == -1) 
				t->s->width = il->i->inchan;
		}
	}
}

void setup_route_channels(sa_decoder *sa) {
	instr_list *il,*route_il;
	instr_route_list *irl;
	int ct,tot;

	/* for each instrument, if it's routed, we figure out which channels of which bus it
	   goes onto */

	for (il=sa->all->il;il && il->i;il=il->next) {
		for (irl=il->i->irl;irl; irl=irl->next) {
			
			
			/* figure out the first channel of the bus for the instrument */
			ct = 0;
			
			for (route_il=irl->il; route_il->i != il->i; route_il=route_il->next)
				ct = ct + route_il->i->width;
			tot = ct;
			for (; route_il && route_il->i;route_il=route_il->next) tot += route_il->i->width;
			
			/* if the route statement produces one channel and the bus is multichannel */
			if (tot == 1 && irl->bus->width > 1) {
				irl->allchan = 1;
				irl->startchan = 0;
			}
			else {
				irl->allchan = 0;
				irl->startchan = ct;
			}
		}
	}
}
			


void check_sym_ref_exprlist(sa_decoder *sa,symtable *t, exprlist *el) {
	/* check all of the names in a list of expressions against the symbol table t */
	if (!el->p) return;
	for (;el;el = el->next)
		check_sym_ref_expr(sa,t,el->p);
}

void check_sym_ref_expr(sa_decoder *sa,symtable *t, expr *p) {
	/* check all of the names in an expression P against the symbol table T */
	/* also figure out and check the widths of expressions */
	/* also counts up total calls to SASBF() in each instrument */
	char s[500];
	symbol *sym;
	opcode_decl *op;
	exprlist *el;
	int ct;
	
	if (!p) return;
	switch (p->op) {
	case IDENT:
		/* found a symbol - make sure its there */
		if (!(sym = get_sym_decl(t,p->d->iname))) {
			sprintf(s,"Unknown symbol '%s'.",p->d->iname);
			parse_error_line(s,p->lineno);
		}
		else {
			sym->mark = 1; /* now we've seen that name */
			p->d->sym = sym; /* link the expression to the symbol table */
			p->width = sym->width;
		}
		break;
	case NUMBER:
	case STRCONST:
		p->width = 1;
		break;
	case ARRAYREF:
		/* make sure the array exists -- this could be a tablemap too */
		if (!(sym = get_sym_decl(t,p->d->iname))) {
			sprintf(s,"Unknown array or tablemap '%s'.",p->d->iname);
			parse_error_line(s,p->lineno);
		} else {
			sym->mark = 1; /* we've seen the array name */
			p->d->sym = sym;
		}
		check_sym_ref_expr(sa,t,p->left); /* bracketed expr */
		if (p->left->width != 1) {
			/* 5.8.6.7.5 */
			sprintf(s,"Index expression must be single-valued (5.8.6.7.5).\n");
			parse_error_line(s,p->lineno);
		}
		p->width = 1;
		break;
		
	case SASBF:
		/* check all of the epxressions */
		for (el=p->params,ct=0;el && el->p;el=el->next,ct++)
			check_sym_ref_expr(sa,t,el->p);
		
		p->op_offset = t->sasbf_ct++; /* count up sasbf()'s in each instrument */
		
		if (ct < 2)
			parse_error_line("Call to 'sasbf' requires at least two parameters.",p->lineno);
		
		/* any width is okay */
		p->width = sasbf_width(sa);
		
		break;
		
	case OPARRAY:
		/* make sure the oparray has been declared (5.8.6.7.7) */
		if (!(sym = get_sym_decl(t,p->d->iname))) {
			sprintf(s,"Opcode array '%s' requires definition.",p->d->iname);
			parse_error_line(s,p->lineno);
		}
		
		/* mark the definition */
		p->oparray_defn = sym;
		sym->mark = 1; /* we've seen the oparray */

		/* make sure the opcode really exists */
		if (!(sym = get_opcode_decl(sa->all->g->sym,p->d->iname))) {
			sprintf(s,"Unknown opcode '%s'.",p->d->iname);
			parse_error_line(s,p->lineno);
		}
		op = (opcode_decl *)sym->defn;

		/* make a link to the core opcode definition */
		p->co_ptr = is_core_opcode(sym->name);

		/* check the actual parameters to the opcode against the formal parameters
		   and count them */
		p->actparam_ct = check_opcode_paramlist(sa,t, p->params,
			((opcode_decl *)sym->defn)->params,
			p->d->iname,p->lineno);

		/* keep track (just bookkeeping) of the maximum length of any opcode call */
		if (p->actparam_ct > sa->all->g->max_actp_ct)
			sa->all->g->max_actp_ct = p->actparam_ct;

		/* check the symbols in the actual parameter list */
		check_sym_ref_exprlist(sa,t,p->params);

		/* this is an oparray - check the symbols in the bracketed expression */
		check_sym_ref_expr(sa,t,p->left);
		
		/* figure out the return width of the opcode */
		if (op->width == -1) {
			if (p->co_ptr)
				op->width = 1; /* all core opcodes are one channel */
			else
				check_opcode_width(sa,op);
		}
		
		p->defn = sym;

		if (p->left->width != 1) {
			sprintf(s,"Index expression must be single-valued (5.8.6.7.7).\n");
			parse_error_line(s,p->lineno);
		}

		/* the width of the expression is the return width of the opcode */
		p->width = op->width;
		
		break;
		
	case OPCALL:
		/* same as above, but without the index */
		if (!(sym = get_opcode_decl(sa->all->g->sym,p->d->iname))) {
			sprintf(s,"Unknown opcode '%s'.",p->d->iname);
			parse_error_line(s,p->lineno);
			break;
		}
		op = (opcode_decl *)sym->defn;
		p->co_ptr = is_core_opcode(sym->name);
		p->actparam_ct = check_opcode_paramlist(sa,t, p->params,((opcode_decl *)sym->defn)->params,
			p->d->iname,p->lineno);
		if (p->actparam_ct > sa->all->g->max_actp_ct)
			sa->all->g->max_actp_ct = p->actparam_ct;
		check_sym_ref_exprlist(sa,t,p->params);
		if (op->width == -1) {
			if (p->co_ptr)
				op->width = 1;
			else
				check_opcode_width(sa,op);
		}
		p->width = op->width;
		p->defn = sym;
		break;
		
	case NOT:
	case UMINUS:
	case LP:
		check_sym_ref_expr(sa,t,p->left);
		p->width = p->left->width;
		break;
	case Q: /* left ? right : extra */
		check_sym_ref_expr(sa,t,p->left);
		check_sym_ref_expr(sa,t,p->right);
		check_sym_ref_expr(sa,t,p->extra);
		if (((p->extra->width != p->left->width)
			&& p->extra->width != 1 && p->left->width != 1) ||
			((p->left->width != p->right->width)
			&& p->left->width != 1 && p->right->width != 1)) { 
			sprintf(s,"All subexpressions must be same width, or scalar (5.8.6.7.9).\n");
			parse_error_line(s,p->lineno);
		}
		p->width = MAX(MAX(p->left->width,p->right->width),p->extra->width);
		break;
	case LEQ:
	case GEQ:
	case EQEQ:
	case NEQ:
	case GT:
	case LT:
	case AND:
	case OR:
	case PLUS:
	case MINUS:
	case STAR:
	case SLASH:
		check_sym_ref_expr(sa,t,p->left);
		check_sym_ref_expr(sa,t,p->right);
		if (p->left->width != p->right->width && p->left->width != 1
			&& p->right->width != 1 
			&& p->left->width != -1 && p->right->width != -1
			) {
			sprintf(s,"Both subexpressions must be same width, or scalar (5.8.6.7.12). \n");
			parse_error_line(s,p->lineno);
		}
		p->width = MAX(p->left->width,p->right->width);
		break;
	default:
		sprintf(s,"Unknown expr type in check_sym_ref_expr (%d)!",p->op);
		interror(s);
  }
}

void check_sym_ref_block(sa_decoder *sa,symtable *t, block *b) {
	/* check all the variable reference in a block of code */
	if (!b->st) return;
	for (;b;b=b->next)
		check_sym_ref_statement(sa,t,b->st);
}

int check_opcode_width_block(sa_decoder *sa, symtable *t, block *b);

void check_opcode_width(sa_decoder *sa,opcode_decl *op) {
	/* figure out the width of an opcode */
	op->width = check_opcode_width_block(sa, op->sym, op->code);
}

int check_opcode_width_block(sa_decoder *sa, symtable *t, block *b) {
	/* figure out the width of an opcode from looking for RETURN 
	   statements in its code block.  We check that all the returns
	   are the same width in YYY. */
	int ct,width=0;
	exprlist *el;
	
	/* go through all the statements */
	for (;b && b->st;b = b->next) {
		if (b->st->type == RETURN) {
			/* count up all the expression widths that are parameters to the RETURN */
			ct = 0; for (el=b->st->params;el && el->p;el=el->next) {
				check_sym_ref_expr(sa,t,el->p);
				ct += el->p->width;
			}
			return(ct);
		}
		/* look for a RETURN in a guarded block */
		if (b->st->type == IF || b->st->type == WHILE || b->st->type == ELSE) {
			width = check_opcode_width_block(sa, t, b->st->b);
			if (width) return(width); /* found a return from here */
		}
		if (b->st->type == ELSE) {
			width = check_opcode_width_block(sa, t, b->st->elseb);
			if (width) return(width);
		}
	}
	
	/* didn't find any RETURN in this block -- width is 0 */
	return(0);
}


symtable *remove_unused_symbols(sa_decoder *sa,instr_decl *id, symtable *t) {
	/* remove all the symbols that don't have the MARK field set from a 
	   symbol table.  The MARK field is set as we check the symbol references
	   in check_sym_refs_block() */
	symtable *first, *cur, *last;
	int ct = 0;
	
	first = t;
	
	cur=first; last = NULL;
	
	while (cur && cur->s) {
		if (cur->s->width == -1) /* variable with inchannels width */
			cur->s->width = id->inchan; /* now it's been set correctly */
		
		if (!cur->s->mark && !(t == sa->all->g->sym) &&
			cur->s->binding != FORMALPARAM) { /* unused - remove*/
			first = remove_sym_table(first,last,&cur); 
		}
		else if (cur->s->type != OPARRAY) {  /* variable is used */
			cur->s->offset = ct;  /* set its new offset */
			ct += cur->s->width;  
			last = cur;
			cur = cur->next;
		}
		else { /* don't need offset for an oparray */
			last = cur;
			cur = cur->next;
		}
	}
	/* if this is an instrument decl, mark the total framesize (amount of
	   storage the instrument needs) in the decl */
	if (id) id->framesize = ct;

	/* if this is the global context, mark the total framesize there */
	if (t == sa->all->g->sym)
		sa->all->g->framesize = ct;

	/* return the new symbol table (might have removed the first one */
	return(first);
}

symtable *remove_sym_table(symtable *first, symtable *last, symtable **cur) {
	/* remove a symbol from a symbol table:
	   FIRST is the start of the symbol table
	   CUR is the one to remove
	   LAST is the one before CUR if CUR isn't first 
	
	   return the updated symbol table and move CUR to the next symbol */
	symtable *hold;
	
	/* remove the first symbol */
	if (*cur == first) {
		first = (*cur)->next;
		if (first)
			first->sasbf_ct = (*cur)->sasbf_ct;
		if (!first) /* removed the only symbol */
			first = new_symtable(0);
	}
	else if (last)
		last->next = (*cur)->next;
	
	/* free the data */
	hold = (*cur)->next;
	free((*cur)->s->name);
	free((*cur)->s);
	free((*cur));
	
	*cur = hold;
	return first;
}


void check_sym_ref_statement(sa_decoder *sa, symtable *t, statement *st) {
	/* check all the symbol (name/bus/opcode/instr) references in a statement.
	   also check the widths */
	char s[500];
	bustable *bd;
	symbol *sym;
	int ct,pct;
	exprlist *el;
	namelist *nl;
	instr_decl *id;
    
	if (!st) return;
	switch (st->type) {
	case EQ:
		if (st->lvalue && st->lvalue->op == ARRAYREF) {
			/* lhs is an array, check the whole expression */
			check_sym_ref_expr(sa,t,st->lvalue);
		} else if (st->lvalue && st->lvalue->op == IDENT) {
			/* lhs is a symbol */
			if (!(sym = get_var_decl(t,st->lvalue->d->iname))) {
				sprintf(s,"Unknown symbol or illegal lvalue '%s'", st->lvalue->d->iname);
				parse_error_line(s,st->lineno);
			}
			/* you can only assign to the 'MIDIctrl' standard name (5.8.6.6.2) */
			else if (is_std_name(st->lvalue->d->iname) &&
				strcmp(st->lvalue->d->iname,"MIDIctrl")) {
				sprintf(s,"Standard name '%s' cannot be an lvalue (5.8.6.6.2).",st->lvalue->d->iname);
				parse_error_line(s,st->lineno);
			}
			/* everythins is okay */
			else {
				sym->mark = 1; /* we've seen the lhs symbol */
				st->lvalue->d->sym = sym;
				st->lvalue->width = sym->width;
			}
			
		} else if (st->lvalue) {
			/* some weird expression as an lvalue */
			parse_error_line("Illegal lvalue.",st->lineno);
		}
		/* check the rhs */
		check_sym_ref_expr(sa,t,st->expr);

		/* check the widths */
		if (st->lvalue && st->lvalue->width != st->expr->width && st->expr->width != 1) {
			parse_error_line("Lvalue and expression must have equal width (5.8.6.6.2).\n",st->lineno);
		}
		break;
	case IF:
		check_sym_ref_expr(sa,t,st->expr);
		if (st->expr->width != 1) {
			sprintf(s,"Guard expression must be single-valued.\n");
			parse_error_line(s,st->lineno);
		}
		
		check_sym_ref_block(sa,t,st->b);
		break;
	case ELSE:
		check_sym_ref_expr(sa,t,st->expr);
		if (st->expr->width != 1) {
			sprintf(s,"Guard expression must be single-valued.\n");
			parse_error_line(s,st->lineno);
		}
		
		check_sym_ref_block(sa,t,st->b);
		check_sym_ref_block(sa,t,st->elseb);
		break;
	case WHILE:
		
		check_sym_ref_expr(sa,t,st->expr);
		if (st->expr->width != 1) {
			sprintf(s,"Guard expression must be single-valued.\n");
			parse_error_line(s,st->lineno);
		}
		check_sym_ref_block(sa,t,st->b);
		break;
	case OUTPUT:
		
		/* check number of channels here YYY? */
		for (ct=0,el=st->params;el;el=el->next,ct++) ;
		
		check_sym_ref_exprlist(sa,t,st->params);
		break;

	case SPATIALIZE:
		for (ct=0,el=st->params;el;el=el->next,ct++) ;
		
		if (ct != 4) /* has to have four parameters */
			parse_error_line("bad call: spatialize(aexp, azim, elev, dist)",st->lineno);
		
		check_sym_ref_exprlist(sa,t,st->params);
		for (el=st->params;el;el=el->next)
			if (el->p->width != 1)
				parse_error_line("Spatialize expressions must be single-valued (5.8.6.6.9).\n",st->lineno);
			
			break;

	case OUTBUS:
		if (!(bd = get_bus(sa->all->g->bus,st->bus))) {
			sprintf(s,"Unknown bus: '%s'.",st->bus);
			parse_error_line(s,st->lineno);
		} else {
			check_sym_ref_exprlist(sa,t,st->params);
			
			/* check the number of channels */
			/* count number of channels in this call to outbus */
			for (ct=0,el = st->params;el;ct+=el->p->width,el=el->next) ;
			
			if (bd->width != 0 && ct != 1 && bd->width != ct) {
				sprintf(s,"Number of channels in bus '%s' routings don't match.",
					st->bus);
				parse_error_line(s,st->lineno);
			}
			if (bd->width == 0 || bd->width == 1)
				set_bus_width(bd,ct);
		}
		break;

	case RETURN:
		check_sym_ref_exprlist(sa,t,st->params);
		break;

	case TURNOFF:
		/* no parameters to turnoff */
		break;

	case EXTEND:
		check_sym_ref_expr(sa,t,st->expr);
		if (st->expr->width != 1)
			parse_error_line("Extend expression must be single-valued.\n",st->lineno);
		break;

	case INSTR:
		/* make sure the instrument really exists */
		if (!(sym = get_instr_decl(sa->all->g->sym,st->iname))) {
			sprintf(s,"Undeclared instrument '%s'.",st->iname);
			parse_error_line(s,st->lineno);
		}
		id = (instr_decl *)sym->defn;

		/* count the p-fields */
		pct = 0; for (nl = id->params; nl && nl->n; pct++, nl=nl->next) ;
		
		/* check the actual parameters */
		check_sym_ref_exprlist(sa,t,st->params);

		/* count the actual parameters */
		for (el = st->params,ct=0; el && el->p; ct++,el=el->next) {
			if (el->p->width != 1)
				parse_error_line("Instr expressions must be single-valued.\n",st->lineno);
		}
		
		/* instr(time,dur,p1,p2,...) */
		if (ct != pct+2) /* make sure the number of p-fields matches the number of actual 
						    paramters */
			parse_error_line("Expression list in instr mismatched with instrument definition.",
			st->lineno);
		break;
	default:
		interror("bad statement type in check_sym_ref_statement()");
  }
}

int check_opcode_paramlist(sa_decoder *sa,symtable *t, exprlist *el,
						   formalparam_list *fpl, char *opname, int lineno) {
	/* check an actual-parameter list (EL) against the formal parameter 
	     list of an opcode (FPL).  T is the symbol table of the caller,
		 OPNAME is the name of the callee 
	   need to check expr by expr to allow for dynamic wavetables
	   need to match up number of parameters except for varargs & optional CO's */

	char s[1000];
	int ct = 0;
	int paramct = 0;
	symbol *sym;
	
	/* go through all the actual parameters */
	while (el && el->p) {
		paramct++;
		if (!fpl) { /* ran out of formal before actual parameters */
			/* see if its a built-in varargs */
			if (!opcode_is_varargs(opname)) {
				/* no, this isn't varargs, so it should have matched */
				sprintf(s,"Opcode '%s' expects only %d parameters.",opname,ct);
				parse_error_line(s,lineno);
			}
		}
		if (el->p->op == IDENT) { /* actual parameter is just an indentifier */
			if (!(sym = get_sym_decl(t,el->p->d->iname))) {
				/* unknown identifier in opcode call */
				if (fpl && fpl->fp && fpl->fp->type == TABLE) { /* okay YYY */
					sprintf(s,"Unknown identifier '%s' assumed dynamic wavetable.",
						el->p->d->iname);
					warn_line(s,lineno);
					el->p->d->sym = NULL;
				} else { /* not okay */
					sprintf(s,"'%s': Unknown identifier.",el->p->d->iname);
					parse_error_line(s,lineno);
				}
			}
			else {
				/* found the identifier */
				sym->mark = 1;
				el->p->d->sym = sym;
				el->p->width = sym->width;
			}
		}
		else check_sym_ref_expr(sa,t,el->p); /* actual parameter is a full expression */

		/* check actparam width against formalparam (5.8.6.7.6) */
		if (el && el->p && fpl && fpl->fp && el->p->width != -1 && el->p->width != fpl->fp->n->width)
			parse_error_line("Mismatch in array width for opcode call (5.8.6.7.6).\n",lineno);
		el = el->next; if (fpl) fpl = fpl->next; ct++;
	}
	if (fpl && fpl->fp && fpl->fp->type > 0) {
		/* still have formal parameters left over - 
		   if fpl->fp->type < 0 they're optional parameters to a core opcode
		   so its okay.  Otherwise it's not.  */
		
		int xct = ct;
		while (fpl && fpl->fp) { fpl = fpl->next; xct++; }
		
		sprintf(s,"Call to opcode '%s' with only %d parameters (%d expected).",
			opname,ct,xct);
		parse_error_line(s,lineno);
	}
	return(paramct);
}

void check_instr_ref_namelist(symtable *t, namelist *nl) {
	/* make sure all the names in a list are really instrument 
	   names (for 'route', 'sequence') */
	char s[800];
	
	if (!nl->n) return;
	
	for (;nl;nl=nl->next)
		if (!get_instr_decl(t,nl->n->name)) {
			sprintf(s,"'%s': unknown instrument for route/sequence.",nl->n->name);
			parse_error_line(s,nl->lineno);
		}
}

void check_instr_ref_name(symtable *t, char *name) {
	/* make sure a name is really an instrument name */
	char s[800];
	
	if (!name) return;
	
	if (!get_instr_decl(t,name)) {
		sprintf(s,"'%s': unknown instrument.",name);
		parse_error(s);
	}
}

void check_bus(bustable *bt, char *name) {
	/* make sure a name is really the name of some bus */
	char s[800];
	
	if (!get_bus(bt,name)) {
		sprintf(s,"'%s': unknown bus.",name);
		parse_error(s);
	}
}

int is_std_name(char *s) {
	/* see if S is a standard name */
	int i;
	
	for (i=0;i!=NUM_STD_NAMES;i++) {
		if (!strcmp(std_names[i].name,s)) return 1;
		}
		
	return 0;
}

void add_instr_route_list(instr_decl *id, instr_list *il, bustable *bus) {
	instr_route_list *irl;

	/* order doesn't matter; adding at beginning is easiest */

	irl = (instr_route_list *)malloc(sizeof(instr_route_list));
	irl->il = il;
	irl->bus = bus;
	irl->startchan = -1; /* fix these when we check channels */
	irl->allchan = 0;
	irl->next = id->irl;
	id->irl = irl;
}

void attach_route(sa_decoder *sa,symtable *t, char *busname, namelist *nl) {
	/* attach the bus given in BUSNAME to the instruments given in NL */
	bustable *bus;
	instr_decl *id;
	instr_list *il,*p;
	int ct = 0;
	namelist *first = nl;
	
	bus = get_bus(sa->all->g->bus,busname);
	
	if (!nl->n) return; /* no instruments */
	
	/* first, make a list of all the instruments in this 'route' */

	il=new_instr_list();

	for (;nl;nl=nl->next) {
		id = (instr_decl *)(get_instr_decl(t,nl->n->name)->defn);
		add_instr_list(il,id);
	}

	/* now go through each, and add the bus onto the list of routes
	   for that instrument */

    for (p=il; p && p->i;p=p->next) {
		id = p->i;

		add_instr_route_list(id,il,bus);
	}    
}

symbol *get_sym_decl(symtable *t, char *name) {
	/* find a symbol in a symbol table */
	if (!t || !t->s) return NULL;
	
	for (;t;t=t->next)
		if (!strcmp(t->s->name,name)) return t->s;
		return NULL;
}

symbol *get_sym_decl_last(symtable *t, char *name) {
	/* find the symbol that precedes a given symbol in a symbol table */
	symbol *hold = NULL;
	
	if (!t || !t->s) return NULL;
	
	for (;t;t=t->next)
		if (!strcmp(t->s->name,name)) hold = t->s;
		return hold;
}

symbol *get_var_decl(symtable *t, char *name) {
	/* get the variable symbol for a name if that name is a variable */
	symbol *s;
	
	s = get_sym_decl(t,name);
	if (s && (s->type == XSIG || s->type == ASIG || s->type == KSIG ||
		s->type == IVAR))
		return s;
	else return NULL;
}

symbol *get_opcode_decl(symtable *t, char *name) {
	/* get the opcode symbol for a name if that name is an opcode */
	symbol *s;
	
	s = get_sym_decl(t,name);
	if (s && (s->type == OPCODE || s->type == AOPCODE || s->type == KOPCODE ||
		s->type == IOPCODE || s->type == SPECIALOP))
		return s;
	else return NULL;
}

symbol *get_instr_decl(symtable *t, char *name) {
	/* get the instrument symbol for a name if that name is an instrument */
	symbol *s;
	
	s = get_sym_decl(t,name);
	if (s && (s->type == INSTR))
		return s;
	else return NULL;
}

symbol *get_table_decl(symtable *t, char *name) {
	/* get table symbol for a name if that name is a table */
	symbol *s;
	
	s = get_sym_decl(t,name);
	if (s && (s->type == TABLE || s->type == TABLEMAP))
		return s;
	else return NULL;
}

bustable *get_bus(bustable *bt, char *name) {
	/* get a bus from a bus table */
	if (!bt || !bt->name) return NULL;
	
	for (;bt;bt=bt->next)
		if (!strcmp(bt->name,name)) return bt;
		return NULL;
}


void dump_sym_table(symtable *t) {
	/* print out a whole symbol table */
	for (;t;t=t->next) {
		switch(t->s->type) {
		case IVAR: printf("ivar "); break;
		case KSIG: printf("ksig "); break;
		case ASIG: printf("asig "); break;
		case XSIG: printf("xsig "); break;
		case TABLE: printf("table "); break;
		case OPARRAY: printf("oparray "); break;
		}
		printf("%s [%d] --> %d\n",t->s->name,t->s->width,t->s->offset);
	}
}
