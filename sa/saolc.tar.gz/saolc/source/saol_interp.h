/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#ifndef _SAOL_INTERP_H

#define _SAOL_INTERP_H

#include "saol.h"

typedef sa_real asig_frame;

typedef struct {
  sa_real *d;
  char *name;
  long size;
  int srate;
  long loop, loopend;
  sa_real base;
} table_storage;

typedef struct {
  sa_real val;
  table_storage *table;
  /*  asig_frame *asig; */
} frameval;

typedef struct actparam_struct {
  sa_real val;
  char *ref;
  table_storage *t;
} actparam;

typedef struct context_struct {
  frameval *framevals;     /* the values and/or pointers for this frame */
#ifdef _SASBF
  struct SynthParams **sfstorage;  /* storage for the sasbf() expressions */
#endif
  symtable *localvars;      /* the local symbol table */
  sa_real *outval;           /* output values */
  struct instr_handle_struct *instr;      /* the instance handle for this context */
  struct opval_struct *cop_storage;        /* extra storage for a core opcode */
  int sfVoiceCnt;					/* number of sf voices running */
  int asample_ptr; 
  int inchan;
  int channel, preset, midibank;
  int globalout;     /* set iff this is the instance to which 'output_bus' is sent */
  sa_decoder *sa;    /* the decoder this context is a part of */
} context;

typedef struct opval_struct {
  void *local;
  void *dyn;
} opval;

void runtime(sa_decoder *,char *s);
block * eval_block(context *cx,block *b, long rate);
sa_real eval_expr(context **cx, sa_real *val, expr *p, long rate);
sa_real eval_opcode(context *cx, sa_real *val, expr *p, long rate);
sa_real eval_oparray(context *cx, sa_real *val, expr *p, long rate);

void push_context(context *cx, long rate);
void pop_context(context *cx, long rate);

context *new_context(sa_decoder *sa,instr_decl *id, int inchan);
context *get_child_context(context *cx, expr *p); 
context *new_child_context(context *cx, expr *p); 
frameval *new_frameval(sa_real val, table_storage *table, asig_frame *asig); 
frameval *get_frameval(context *cx, expr *p, int index); 
void set_frameval(context *cx, expr *p, int index, frameval *val); 
table_storage *resolve_tablemap(context *cx, expr *p, long rate);

table_storage *make_table(context *cx, tabledef *td);
/* actparam *make_varargs_list(actparam_list *p, context *cx);*/
asig_frame *make_asig_frame(int ksmps);
void set_var_value(context *cx, expr *p, int index, sa_real val);
void set_var_value_byname(context *cx, char *vname, int index, sa_real val);
sa_real get_var_value(context *cx, expr *p, int index); 

void free_table(table_storage *t);
table_storage *gen_table(sa_decoder *sa,char *gen,actparam *pf,int);

struct instr_handle_struct 
    *new_instr_instance(sa_decoder *sa,
		char *iname, sa_real *pf,
		int inchan, int channel);
void add_default_host_vars(struct instr_handle_struct *h);
void add_imported_host_vars(struct instr_handle_struct *h);
void run_itime(instr_decl *id, context *cx);
void run_katime(instr_decl *id, context *cx, long rate);
void set_asample_ptr(context *cx, int i); 

extern int ksmps;

#endif
