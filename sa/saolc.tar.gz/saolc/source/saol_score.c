/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_score.c : Parse a textual score file and create an event for each line.
    The public interface is parse_score(), which is called from main.cpp during
    the decoder configuration. */

#include <stdio.h>
#include <stdlib.h>
#ifdef _WIN32
#include "string.h"
#else
#include "strings.h"
#endif
#include "saol_prec.h"
#include "saol_sched.h"


char *getline(FILE *fp);
int split(char *s, char ***words);

int parse_score(sa_decoder *sa,char *fn) {
	/* read and make events for all the lines in the file named FN */
  FILE *fp;
  
  char *s,**s2;
  char err[1000];
  event *ev;
  int ct=0,num;
	
  /* open the file */
  if (!(fp = fopen(fn,"r"))) {
    sprintf(err,"Couldn't open score file '%s' for read.",fn);
    runtime(sa,err);
  }
	
  /* go through the whole file */
  while (!feof(fp)) {
    ct++; /* count the lines */
    s = getline(fp);  /* get a line */
    num = split(s,&s2); /* split it into a bunch of fields */
    if (num > 1) { /* if there are fields */
      ev = new_event(s2,num); /* make an event */

      schedule_event(sa,ev); /* send it to the scheduler */
    }
  }
  /* report results */
  printf("Read %d score events.\n",ct);
  return(ct);
}

event *new_event(char **words,int num) {
	/* make a new event from a score line.  WORDS is an array of strings, one for each
	   field on the line.  NUM is the length of WORDS */

  event *ev;
  int base,i;
	
  /* make the space and initialize it */
  ev = (event *)malloc(sizeof(event));
  ev->name = NULL;
  ev->label = NULL;
  ev->val = NULL;
  ev->h = NULL;
  ev->ext = ev->time = ev->dur = (sa_real)0;
  ev->numval = ev->type = 0;
	
  if (num > 2 && (!strcmp(words[1],"control") || !strcmp(words[2],"control"))) {
    /* control event: <time> [<label>] control <varname> <value> */
    ev->type = CONTROL_EVENT;
	/* time is the first word */
    ev->time = (sa_real)atof(words[0]);

	/* if "control" is the second word, there's no label */
    if (!strcmp(words[1],"control")) {
      ev->label = NULL;
      base = 2;
    }
    else { /* otherwise, the label is the second word */
      ev->label = strdup(words[1]);
      base = 3;
    }
	/* the word after "control" is the controller */
    ev->name = strdup(words[base]);
	/* the word after the controller is the new value -- make a val array for it */
    ev->val = (sa_real *)malloc(sizeof(sa_real));
    ev->val[0] = (sa_real)atof(words[base+1]);
    ev->numval = 1; /* only one value per controller */
    ev->ext = 0;
  }
  else if (!strcmp(words[1],"tempo")) {
    /* tempo event: <time> tempo <val> */
    ev->type = TEMPO_EVENT;
    ev->time = (sa_real)atof(words[0]);
    ev->val = (sa_real *)malloc(sizeof(sa_real));
    ev->val[0] = (sa_real)atof(words[2]);
    ev->ext = 0;
  }
  else if (!strcmp(words[1],"table")) {
	  char *end = NULL;
    /* table event: <time> table <name> <gen> <val1> <val2> <val3> ... */
    ev->type = TABLE_EVENT;
    ev->name = words[2]; /* name of table */
    ev->time = (sa_real)atof(words[0]);
    ev->label = strdup(words[3]); /* generator */
	/* the rest of the words are values -- allocate space to hold them */
    ev->val = (sa_real *)malloc(sizeof(sa_real) * (num-4));
    for (i=4;i!=num;i++) {
      ev->val[i-4] = (sa_real)strtod(words[i],&end); /* scan them all in */
	  if (end == words[i]) { /* couldn't make number */
		  if (i != 5)
			  runtime(NULL,"Bad numeric value in score.");
		  else /* must be a sample */
			  ev->sampname = strdup(words[i]);
		  }
	}
    ev->numval = num-4;
    ev->ext = 0;
  }
  else if (!strcmp(words[1],"end")) {
    /* end event: <time> end */
    ev->type = END_EVENT;
    ev->time = (sa_real)atof(words[0]);
    ev->ext = 0;
  }
  else {
    /* must be an instrument event: [label]: <time> <instr> <dur> <val1> <val2> ... */
    ev->type = INSTR_EVENT;
			
    base = 0;
    if (words[0][strlen(words[0])-1] == ':') { /* there's a label */
      words[0][strlen(words[0])-1] = 0;
      ev->label = strdup(words[0]);
      base = 1;
    }
    ev->name = strdup(words[base+1]);
    ev->time = (sa_real)atof(words[base]);
    ev->dur = (sa_real)atof(words[base+2]);

	/* allocate space for all the pfields */
    ev->val = (sa_real *)malloc(sizeof(sa_real) * (num - 3 - base));
    for (i=base+3;i!=num;i++)
      ev->val[i-3-base] = (sa_real)atof(words[i]); /* scan them all in */
    ev->numval = num-3-base;
    ev->ext = 0;
  }
  return ev;
}

char *getline(FILE *fp) {
	/* get a line of text, up to the newline */
  char buf[10000],c; /* VIOLATION to have a maximum buffer length */
  int i=0;

  buf[0] = 0;
  while (!feof(fp) && (c = getc(fp))) {
    if (c == '\n' || c == '\r') break;
    buf[i++] = c;
    buf[i] = 0;
  }
  if (feof(fp))
    buf[i-1] = 0;
  return(strdup(buf));
}

int split(char *s, char ***w) {
	/* split a line of text into words, separated by whitespace.
	   also remove comments.  ignore the priority * marker 

       S is the string to split
	   change W to point to an array of strings, one for each word 
	
	   Return the number of words. */

  unsigned int i=0,ct=0,first = 0,l=0,j;
  char **words,**nwords;
  char buf[32767];

  words = NULL;

  l = 0;  /* L holds the current position in the word-in-progress */
  ct = 0; /* CT holds the number of words */
  /* go through the string */
  while (i < strlen(s)) {
	  if (i < strlen(s)-1 && s[i] == '/' && s[i+1] == '/') /* comment, ignore the rest of the line */
		  break;
	  if (s[i] == ' ' || s[i] == '\t' || s[i] == '*') { /* just ignore priority bit */
		  if (l) { /* end the last word */
			  /* realloc more space (why is this not realloc()?) */
			  nwords = (char **)malloc((ct+1) * sizeof(char *));
			  for (j=0;j<ct;j++)
				  nwords[j] = words[j];
			  nwords[ct++] = strdup(buf); /* copy in the last word */
			  if (words) free(words);
			  words = nwords; 
			  l = 0; /* start the current word over */
		  }
	  } else { /* add the current character to the current word */
		  buf[l++] = s[i];
		  buf[l] = 0;
	  }
	  i++; /* next character */
  }

  if (l) { /* finish the current word */
	  nwords = (char **)malloc((ct+1) * sizeof(char *));
	  for (j=0;j<ct;j++)
		  nwords[j] = words[j];
	  nwords[ct++] = strdup(buf); /* save it in the array */
	  if (words) free(words);
	  words = nwords;
	  l = 0;
  }
  
  *w = words; /* copy to caller */
  return ct;
}


