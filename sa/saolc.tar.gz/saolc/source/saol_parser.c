/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_parser.c : routines for building a parse tree.

    Most of these functions are called by the yacc parser (saol.yacc / y.tab.c)
	to dynamically construct a parse tree from the textual SAOL code.  The
	data structures for this are defined and commented in saol.h.

    This code (and the parse tree data structure as a whole) is ugly since 
	there's a lot of repetition.  It would be much more elegant to use C++ vectors
	or other template structures to hold all of the different kinds of linked lists,
	for example.  The standard template library wasn't yet widely available when 
	this code was begun!

    There is also not a "method" for changing and reading every field of every data 
	structure, as there should be for proper data encapsulation.  Most times, the caller 
	simply does the direct assignment itself, which should (in some thinking) be a private 
	operation.
*/

#include <stdio.h>
#include <stdlib.h>
#ifdef _WIN32
#include <string.h>
#else
#include <strings.h>
#endif
#include "saol.tab.h"
#include "saol.h"
#include <malloc.h>

extern int yyline;

void interror(char *s) {
  printf("\nInternal compiler error: %s\n",s);
}


orc *new_orc(void) {
/* make a new orchestra structure */
  orc *o;

  /* this macro (saol.h) allocates memory and checks the return value for errors */
  PROT_MAL(o,orc,new_orc);
  o->g = NULL;
  o->il = NULL;
  o->op = NULL;

  return o;
}

global_block *new_gblock(void) {
	/* make a new global-block structure (a global block is a linked
	   list of global declarations) */
  global_block *gb;

  PROT_MAL(gb,global_block,new_gblock);
  gb->d = NULL;
  gb->next = NULL;
  return(gb);
}

void add_gblock(global_block *gb, global_decl *d) {
	/* add a global declaration to the global block */
  global_block *newb,*last;
  if (!gb->d) /* first decl */
    gb->d = d;
  else {
    PROT_MAL(newb,global_block,add_gblock);
    newb->d = d;
    newb->next = NULL;
	/* find the last declaration and add to the end */
    for (; gb; last = gb,gb = gb->next) ;
    last->next = newb;
  }
}

global_decl *new_global(long type) {
	/* make a new global declaration */
  global_decl *g;

  PROT_MAL(g,global_decl,new_global);
  g->type = type;
  g->rtparam = 0;
  g->vardecl = NULL;
  g->senddef = NULL;
  g->routedef = NULL;
  g->seqdef = NULL;
  g->lineno = yyline;
  return(g);
}

void set_global_rtparam(global_decl *g, long param) {
  g->rtparam = param;
}

void set_global_senddef(global_decl *g, senddef *s) {
  g->senddef = s;
}

void set_global_routedef(global_decl *g, routedef *r) {
  g->routedef = r;
}

void set_global_seqdef(global_decl *g, seqdef *s) {
  g->seqdef = s;
}

void set_global_vardecl(global_decl *g, vardecl *v) {
  g->vardecl = v;
}

instr_list *new_instr_list(void) {
	/* make a new list of instruments */
  instr_list *il;

  PROT_MAL(il,instr_list,new_instr_list);
  il->i = NULL;
  il->next = NULL;
  return(il);
}

void add_instr_list(instr_list *il, instr_decl *i) {
	/* add an instrument to the list */
  instr_list *newp,*last;

  if (!il->i) /* first instrument */
    il->i = i;
  else {
    PROT_MAL(newp,instr_list,add_instr_list);
    newp->next = NULL;
    newp->i = i;
	/* find last and add there */
    for (; il; last=il, il = il->next);
    last->next = newp;
  }
}

opcode_list *new_opcode_list(void) {
	/* make a new list of opcodes */
  opcode_list *op;

  PROT_MAL(op,opcode_list,new_opcode_list);
  op->o = NULL;
  op->next = NULL;
  return(op);
}

void add_opcode_list(opcode_list *op, opcode_decl *o) {
	/* add an opcode to the list */
  opcode_list *newp,*last;
  if (!op->o)
    op->o = o;
  else {
    PROT_MAL(newp,opcode_list,add_opcode_list);
    newp->next = NULL;
    newp->o = o;
    for (; op; last=op, op = op->next);
    last->next = newp;
  }
}

instr_decl *new_instr_decl(char *name, namelist *pf,
			   vardecl_list *local,
			   block *code, terminal_list *ptag) {
	/* make a new instrument declaration */
  instr_decl *il;

  PROT_MAL(il,instr_decl,new_instr_decl);
  il->name = name;
  il->max_output_width = 0;
  il->width = 0;
  il->params = pf;
  il->localvars = local;
  il->code = code;
  il->irl = NULL;
  il->n_opcodes = 0;
  il->preset = ptag;
  il->sym = NULL;
  il->framesize = 0;
  il->opsize = 0;
  il->inchan = 0;
  il->num = 0;

  return(il);
}

opcode_decl *new_opcode_decl(char *name, formalparam_list *fp,
			     vardecl_list *local, block *code, long type) {
	/* make a new opcode declaration */
  opcode_decl *op;

  PROT_MAL(op,opcode_decl,new_opcode_decl);
  op->name = name;
  op->params = fp;
  op->localvars = local;
  op->code = code;
  op->type = type;
  op->rate = 0;
  op->minxsigrate = 0;
  op->width = -1;
  op->sym = NULL;
  
  return(op);
}

template_decl *new_template_decl(namelist *names, namelist *params,
				 namelist *tvars, mapblock *map,
				 vardecl_list *local, block *code, mapblock *preset) {
	/* make a new template declaration */
  template_decl *t;

  PROT_MAL(t,template_decl,new_template_decl);
  t->names = names;
  t->params = params;
  t->tvars = tvars;
  t->mapping = map;
  t->localvars = local;
  t->code = code;
  t->preset = preset;
  return(t);
}

mapblock *new_mapblock(terminal_list *tl) {
	/* make a new template mapblock structure (a mapblock is just a list
	   of terminal lists */
  mapblock *m;

  PROT_MAL(m,mapblock, new_mapblock);
  m->tl = tl; /* parameter is the first element */
  return(m);
}

void add_mapblock(mapblock *m, terminal_list *tl) {
	/* add a terminal list to the mapblock */
  mapblock *newp, *last;

  PROT_MAL(newp, mapblock, add_mapblock);
  newp->tl = tl;
  newp->next = NULL;

  /* find the last element and add the new one as the next */
  for (; m; last=m,m=m->next);
  last->next = newp;
}

terminal_list *new_terminal_list(terminal *t) {
	/* make a new list of terminals, with the parameter as the first one */
  terminal_list *tl;

  PROT_MAL(tl,terminal_list,new_terminal_list);
  tl->t = t;
  tl->next = NULL;
  return(tl);
}
  
void add_terminal_list(terminal_list *tl, terminal *t) {
	/* add a terminal to the list of terminals */
  terminal_list *newp,*last;

  PROT_MAL(newp,terminal_list,new_terminal_list);
  newp->t = t;
  newp->next = NULL;

  for (; tl; last=tl, tl=tl->next);
  last->next = newp;
} 

vardecl_list *new_vardecl_list(void) {
	/* make a new list of variable declarations */
  vardecl_list *vdl;

  PROT_MAL(vdl,vardecl_list,new_vardecl_list);
  vdl->v = NULL;
  vdl->next = NULL;
  return(vdl);
}

vardecl *new_vardecl(long type, long taglist, namelist *nl) {
	/* make a new variable declaration */
  vardecl *v;
  
  PROT_MAL(v,vardecl,new_vardecl);
  v->type = type;
  v->imported = (taglist == IMPORTS || taglist == IMPEXP);
  v->exported = (taglist == EXPORTS || taglist == IMPEXP);
  v->nl = nl;
  v->tablemap_name = NULL;
  v->t = NULL;
  v->lineno = yyline;
  return(v);
}

void set_vardecl_tabledef(vardecl *v, tabledef *t) {
  v->t = t;
}

tabledef *new_tabledef(char *ident, char *gen, exprlist *params) {
	/* make a new table definition */
  tabledef *t;

  PROT_MAL(t,tabledef,new_tabledec);
  t->name = ident;
  t->gen = gen;
  t->params = params;
  t->lineno = yyline;
  return(t);
}

namelist *new_namelist(name *v) {
	/* make a new list of names, with the parameter as the first one */
  namelist *nl;

  PROT_MAL(nl,namelist,new_namelist);
  nl->next = NULL;
  nl->n = v;
  nl->lineno = yyline;
  return(nl);
}

void add_namelist(namelist *nl, name *v) {
	/* add a name to the namelist */
  namelist *newnl,*last;

  if (!nl->n)
    nl->n = v;
  else {
    PROT_MAL(newnl,namelist,add_namelist);
    newnl->next = NULL;
    newnl->n = v;
    newnl->lineno = yyline;
    for (; nl; last = nl,nl=nl->next);
    last->next = newnl;
  }
}

name *new_name(char *ident,int width) {
	/* make a new name (pointer copy the parameter) */
  name *v;

  PROT_MAL(v,name,add_namelist);
  v->name = ident;
  v->width = width;
  v->det = 0;
  return(v);
}

formalparam_list *new_formalparam_list(void) {
	/* make a new list of formal parameters */
  formalparam_list *fpl;

  PROT_MAL(fpl,formalparam_list,new_formalparam_list);
  fpl->fp = NULL;
  fpl->next = NULL;
  return(fpl);
}

void add_formalparam_list(formalparam_list *fpl, formalparam *fp) {
	/* add a formal parameter to the list */
  formalparam_list *newp, *last;

  if (!fpl->fp)
    fpl->fp = fp;
  else {
    PROT_MAL(newp,formalparam_list,add_formalparam_list);
    newp->next = NULL;
    newp->fp = fp;
    for (; fpl; last = fpl, fpl = fpl->next);
    last->next = newp;
  }
}

formalparam *new_formalparam(long type, name *v) {
	/* make a new formal parameter */
  formalparam *fp;

  PROT_MAL(fp,formalparam,new_formalparam);
  fp->type = type;
  fp->lineno = yyline;
  fp->n = v;
  return(fp);
}

routedef *new_routedef(char *bus, namelist *instrs) {
	/* make a new 'route' definition */
  routedef *r;
  
  PROT_MAL(r, routedef,new_routedef);
  r->bus = bus;
  r->instrs = instrs;
  return(r);
}
   
senddef *new_senddef(char *instr,exprlist *pfields,namelist *busses) {
	/* make a new 'send' definition */
  senddef *s;

  PROT_MAL(s,senddef,new_senddef);
  s->instr= instr;
  s->pfields = pfields;
  s->busses = busses;
  s->h = NULL;
  return(s);
}

seqdef *new_seqdef(namelist *seqlist) {
	/* make a new 'sequence' statement */
  seqdef *s;

  PROT_MAL(s,seqdef,new_seqdef);
  s->seqlist = seqlist;
  return(s);
}

block *new_block(void) {
	/* make a new code block (a block is just a linked list of statements */
  block *b;

  if (!(b = (block *)malloc(sizeof(block)))) {
    interror("malloc() failure in new_block()\n");
  }
  b->st = NULL;
  b->next = NULL;
  
  return(b);
}

void add_block(block *b, statement *st) {
	/* add a statement to a block */
  block *last,*newb;
  
  if (!b->st) { /* null block */
    b->st = st;
  } else {
    if (!(newb = (block *)malloc(sizeof(block)))) {
      interror("malloc() failure in add_block()\n");
    }
    newb->st = st;
    newb->next = NULL;
    for (; b; last=b,b=b->next);
    last->next = newb;
  }
}

statement *new_statement(long type, expr *e, block *b) {
	/* make a new statement */
  statement *st;
  
  if (!(st = (statement *)malloc(sizeof(statement)))) {
    interror("malloc() failure in add_block()\n");
  }
  st->type = type;
  st->rate = 0;
  st->expr = e;
  st->b = b;
  st->elseb = NULL;
  st->lvalue = NULL;
  st->params = NULL;
  st->bus = NULL;
  st->iname = NULL;
  st->lineno = yyline;
  st->jump = NULL;

  return(st);
}

void set_statement_params(statement *st, exprlist *el) {
  st->params = el;
}

void set_statement_lvalue(statement *st, expr *l) {
  st->lvalue = l;
}

void set_statement_iname(statement *st, char *iname) {
  st->iname = iname;
}

void set_statement_else(statement *st, block *b) {
  st->elseb = b;
}

void set_statement_bus(statement *st, char *t) {
  st->bus = t;
}
    
expr *new_expr(expr *left, expr *right, expr *extra, int type) {
	/* make a new expression */
  expr *p;

  if (!(p = (expr *)malloc(sizeof(expr)))) {
    interror("malloc() failure in new_expr()\n");
  }
  p->op = type;
  p->d = NULL;
  p->params = NULL;
  p->left = left;
  p->right = right;
  p->extra = extra;
  p->lineno = yyline;
  p->defn = NULL;
  p->opdummy = NULL;
  p->oparray_defn = NULL;
  p->op_offset = 0;
  p->width = 0;
  p->rate = 0;
  p->actparam_ct = 0;
  p->co_ptr = NULL;
  return(p);
}

void set_expr_data(expr *p, terminal *d) {
  p->d = d;
}

void set_expr_params(expr *p, exprlist *l) {
  p->params = l;
}

terminal *new_terminal(int type, char *cont) {
	/* make a new terminal */
  terminal *t;

  if (!(t = (terminal *)malloc(sizeof(terminal)))) {
    interror("malloc() failure in new_terminal()\n");
  }
  t->type = type;
  t->cval = 0;
  t->iname = t->csval = NULL;
	t->sym = NULL;
  
  switch (type) {
  case IDENT: /* just the string */
    t->iname = cont;
    break;
  case NUMBER: /* read number out of string */
    t->cval = (sa_real)atof(cont);
    break;
  case STRCONST:
    t->csval = cont;
    break;
  }
  return t;
}

exprlist *new_exprlist(expr *p) {
	/* make a new list of expressions */
  exprlist *e;

  if (!(e = (exprlist *)malloc(sizeof(exprlist)))) {
    interror("malloc() failure in new_exprlist");
  }

  e->p = p;
  e->next = NULL;
  return(e);
}

void add_exprlist(exprlist *e, expr *p) {
	/* add an expression to the list */
  exprlist *last,*new;

  if (!(new = (exprlist *)malloc(sizeof(exprlist)))) {
    interror("malloc() failure in add_exprlist");
  }

  new->p = p;
  new->next = NULL;
  for (; e ; last = e, e=e->next) ;
  last->next = new;
}
    
vardecl_list *copy_vardecl_list(vardecl_list *vdl) {
	/* make a deep copy of a list of variable declarations */
  vardecl_list *newl,*vdlp;

  if (!vdl) return NULL;
  newl = new_vardecl_list(); 
  for (vdlp=vdl;vdlp;vdlp=vdlp->next)
    add_vardecl_list(newl,copy_vardecl(vdlp->v));
  return(newl);
}

namelist *copy_namelist(namelist *nl) {
	/* make a deep copy of a namelist */
  namelist *newl, *nlp;

  if (!nl) return NULL;
  newl = new_namelist(copy_name(nl->n));
  
  for (nlp=nl->next; nlp; nlp=nlp->next) 
    add_namelist(newl,copy_name(nlp->n));
  return(newl);
}

vardecl *copy_vardecl(vardecl *vd) {
	/* make a deep copy of a variable declaration */
  vardecl *newvd;
  long tag;

  if (!vd) return NULL;
  if (vd->exported) 
    if (vd->imported)
      tag = IMPEXP;
    else
      tag = EXPORTS;
  else
    if (vd->imported)
      tag = IMPORTS;
    else
      tag = NOTAG;
  
  newvd = new_vardecl(vd->type, tag, copy_namelist(vd->nl));
  set_vardecl_tabledef(newvd,copy_tabledef(vd->t));
  return(newvd);
}

name *copy_name(name *v) {
	/* make a deep copy of a name */
  name *newv;

  if (!v) return NULL;
  newv = new_name(strdup(v->name),v->width);
  return(newv);
}

block *copy_block(block *b) {
	/* make a deep copy of a block */
  block *newb, *bp;
  statement *news;

  if (!b) return NULL;
  
  newb = new_block();
  for (bp = b; bp; bp = bp->next) {
    news = copy_statement(bp->st);
    add_block(newb,news);
  }
  return(newb);
}

tabledef *copy_tabledef(tabledef *t) {
	/* make a deep copy of a table definition */
  tabledef *newt;

  if (!t) return NULL;
  
  newt = new_tabledef(strdup(t->name),strdup(t->gen),copy_exprlist(t->params));
  return(newt);
}

statement *copy_statement(statement *st) {
	/* make a deep copy of a statement */
  statement *newst;

  if (!st) return NULL;
  
  newst = new_statement(st->type,copy_expr(st->expr),copy_block(st->b));
  set_statement_params(newst,copy_exprlist(st->params));
  if (st->iname) set_statement_iname(newst,strdup(st->iname));
  set_statement_lvalue(newst,copy_expr(st->lvalue));
  set_statement_else(newst,copy_block(st->elseb));
  if (st->bus) set_statement_bus(newst,strdup(st->bus));
  newst->rate = st->rate;
  return (newst);
}

expr *copy_expr(expr *e) {
	/* make a deep copy of an expression */
  expr *newe;

  if (!e) return NULL;
  newe = new_expr(copy_expr(e->left),copy_expr(e->right),copy_expr(e->extra),
		 e->op);
  set_expr_data(newe,copy_terminal(e->d));
  set_expr_params(newe,copy_exprlist(e->params));
  newe->defn = e->defn;
  newe->oparray_defn = e->oparray_defn;
  newe->op_offset = e->op_offset;
  newe->co_ptr = e->co_ptr;
  newe->rate = e->rate;
  newe->actparam_ct = e->actparam_ct;
  newe->width = e->width;
  return(newe);
}

exprlist *copy_exprlist(exprlist *el) {
	/* make a deep copy of a list of expressions */
  exprlist *newel, *ep;

  if (!el) return NULL;
  newel = new_exprlist(copy_expr(el->p));
  for (ep=el->next;ep;ep=ep->next)
    add_exprlist(newel,copy_expr(ep->p));
  return (newel);
}

terminal *copy_terminal(terminal *t) {
	/* make a deep copy of a terminal */
  terminal *newt;
  char *s,buf[80];

  if (!t) return NULL;
  switch ((int)t->type) {
  case STRCONST:
    s = strdup(t->csval);
    break;
  case IDENT:
    s = strdup(t->iname);
    break;
  case NUMBER:
    sprintf(buf,"%.16lf",t->cval);
    s = strdup(buf);
    break;
  }
  newt = new_terminal(t->type,s);
  newt->sym = t->sym;
  return (newt);
}

route_list *new_route_list(routedef *r) {
	/* make a new list of route definitions */
  route_list *rl;

  PROT_MAL(rl,route_list,new_route_list);
  rl->r = r;
  rl->next = NULL;
  return(rl);
}

send_list *new_send_list(senddef *s) {
	/* make a new list of send definitions */
  send_list *sl;

  PROT_MAL(sl,send_list,new_send_list);
  sl->s = s;
  sl->next = NULL;
  return(sl);
}

sequence_list *new_sequence_list(seqdef *s) {
	/* make a new list of sequence definitions */
  sequence_list *seql;

  PROT_MAL(seql,sequence_list,new_sequence_list);
  seql->s = s;
  seql->next = NULL;
  return(seql);
}

void add_vardecl_list(vardecl_list *pl,vardecl *p) {
	/* add a variable declaration to a list */
  vardecl_list *newp,*last;

  if (!pl->v)
    pl->v = p;
  else {
    PROT_MAL(newp,vardecl_list,add_vardecl_list);
    newp->v = p;
    newp->next = NULL;
    for (;pl;last=pl,pl=pl->next);
    last->next = newp;
  }
}

void add_route_list(route_list *rl, routedef *r) {
	/* add a route to a list */
  route_list *newp, *last;

  PROT_MAL(newp,route_list,add_route_list);
  newp->r = r;
  newp->next = NULL;
  for (;rl;last=rl,rl=rl->next);
  last->next = newp;
}

void add_send_list(send_list *pl,senddef *p) {
	/* add a send to a list */
  send_list *newp,*last;

  PROT_MAL(newp,send_list,add_send_list);

  newp->s = p;
  newp->next = NULL;
  for (;pl;last=pl,pl=pl->next);
  last->next = newp;
}

void add_sequence_list(sequence_list *pl,seqdef *p) {
	/* add a sequence to a list */
  sequence_list *newp,*last;

  PROT_MAL(newp,sequence_list,add_sequence_list);

  newp->s = p;
  newp->next = NULL;
  for (;pl;last=pl,pl=pl->next);
  last->next = newp;
}
  
extern sa_decoder *cur_sa; /* for parsing only */

/* the yacc code is happiest if it can pass around longs as the return values
   for each parsing block.  But the real result of parsing a piece of code is a 
   structure of one of the types declared above.  These two functions keep track 
   of all the pointers to structures by keeping them in a numbered list. */

void *ptr_index(long i) {
	/* return the pointer with index #I */
  ptr_index_list *p = cur_sa->all_ptrs;

  while (p && (p->index != i)) p=p->next;
  if (p)
    return(p->ptr);
	/* this should never happen */
  else interror("Pointer index not found!");
  return NULL;
}

long add_ptr_index(void *ptr) {
	/* add the pointer PTR to the list and return the next index */
  ptr_index_list *p = cur_sa->all_ptrs,*last = NULL,*newp;

  for (;p;last = p,p=p->next);
  if (!(newp = (ptr_index_list *)malloc(sizeof(ptr_index_list))))
    interror("malloc() failure in add_ptr_index()\n");
  newp->next = NULL;

  if (last) {
    last->next = newp;
    newp->index = last->index + 1;
  }
  else {
    cur_sa->all_ptrs = newp;
    newp->index = 0;
  }
  
  newp->ptr = ptr;
  return(newp->index);
}

void print_block(block *b) {
  if (!b->st) {
    printf("<null block>\n");
  } else {
    for (; b; b=b->next) 
      print_statement(b->st);
  }
}

/* debugging routinges from here down */
void print_statement(statement *st) {

  switch((int)st->rate) {
  case IVAR:
    printf("{IVAR} ");
    break;
  case KSIG:
    printf("{KSIG} ");
    break;
  case ASIG:
    printf("{ASIG} ");
    break;
  case XSIG:
    printf("{XSIG} ");
    break;
  case SPECIALOP:
    printf("{SPECIALOP} ");
    break;
  }
  
  if (!st)
    printf("<NULL> ");
  else switch((int)st->type) {
  case EQ: /* assignment */
    print_expr(st->lvalue);
    printf(":= ");
    print_expr(st->expr);
    break;
  case IF:
    printf("if ( ");
    print_expr(st->expr);
    printf(") { \n");
    print_block(st->b);
    printf("}");
    break;
  case ELSE:
    printf("if-else ( ");
    print_expr(st->expr);
    printf(") { \n");
    print_block(st->b);
    printf("} else {\n");
    print_block(st->elseb);
    printf("}");    
    break;
  case WHILE:
    printf("while ( ");
    print_expr(st->expr);
    printf(") { \n");
    print_block(st->b);
    printf("}");
    break;
  case OUTPUT:
    printf("output ( ");
    print_exprlist(st->params);
    printf(")");
    break;
  case SPATIALIZE:
    printf("spatialize ( ");
    print_exprlist(st->params);
    printf(")");
    break;
  case OUTBUS:
    printf("outbus [%s] ( ",st->bus);
    print_exprlist(st->params);
    printf(")");
    break;
  case EXTEND:
    printf("extend (");
    print_expr(st->expr);
    printf(")");
    break;
  case INSTR:
    printf("start instr [%s] (",st->iname);
    print_exprlist(st->params);
    printf(")");
    break;
  case RETURN:
    printf("return ( ");
    print_exprlist(st->params);
    printf(")");
    break;
  case TURNOFF:
    printf("turnoff");
    break;
  default:
    interror("<unknown statement>");
  }
  if (st->jump) printf(" (then JUMP)");
  printf("\n");
}
    
void print_terminal(terminal *t) {
  if (!t)
    printf("<null>");
  else switch((int)t->type) {
  case IDENT:
    printf("%s ",t->iname);
    break;
  case NUMBER:
    printf("%lf ",t->cval);
    break;
  case STRCONST:
    printf("""%s"" ",t->csval);
    break;
  }
}
  
void print_expr(expr *p) {

  if (!p)
    printf("<NULL> ");
  else switch (p->op) {
  case IDENT:
    printf("%s (%d) ",p->d->iname,p->width);
    
    break;
  case NUMBER:
    printf("%.2lf ",p->d->cval);
    break;
  case STRCONST:
    printf("""%s"" ",p->d->csval);
    break;
  case ARRAYREF:
    printf("%s[",p->d->iname);
    print_expr(p->left);
    printf("] (%d) ",p->width);
    break;
  case OPARRAY:
    printf("%s[",p->d->iname);
    print_expr(p->left);
    printf("] (");
    print_exprlist(p->params);
    printf(") ");
    break;
  case SASBF:
    printf("sasbf(");
    print_exprlist(p->params);
    printf(") ");
    break;
  case OPCALL:
    printf("%s(",p->d->iname);
    print_exprlist(p->params);
    printf(") ");
    break;
  case NOT:
    printf("!");
    print_expr(p->left);
    break;
  case Q:
    printf("(");
    print_expr(p->left);
    printf(" ? ");
    print_expr(p->right);
    printf(" : ");
    print_expr(p->extra);
    printf(") ");
    break;
  case LEQ:
    printf("<= ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case GEQ:
    printf(">= ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case NEQ:
    printf("!= ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case EQEQ:
    printf("== ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case GT:
    printf("> ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case LT:
    printf("< ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case AND:
    printf("&& ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case OR:
    printf("|| ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case PLUS:
    printf("+ ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case MINUS:
    printf("- ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case STAR:
    printf("* ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case SLASH:
    printf("/ ");
    print_expr(p->left);
    print_expr(p->right);
    break;
  case UMINUS:
    printf("u- ");
    print_expr(p->left);
    break;
  case LP:
    print_expr(p->left);
    break;
  default:
    printf("<unknown expression> ");
  }
}

void pen(expr *p) {
  /* print expression and newline */
  print_expr(p);
  printf("\n");
}

void print_exprlist(exprlist *e) {
  if (!e->p) {
    printf("<null list> ");
    return; /* null list */
  }
  for (; e; e=e->next) {
    print_expr(e->p);
    if (e->next) printf(", ");
  }
}

