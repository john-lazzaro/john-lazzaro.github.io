/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#ifndef _SAOL_SCHED_H

#define _SAOL_SCHED_H

#include "saol_interp.h"
#include "saol.h"

typedef struct instr_handle_struct {
  char *label;
  context *cx;
  instr_decl *id;
  sa_real **input;
  sa_real **output;
  sa_real itime;
  struct hostvar_list_struct *hvl;
  int turnoff_notified;
  int make_sound;
  int origin;
  int inchan;
  int channel, midion;
  int pedal_delay;  /* TRUE when note is waiting for pedal to go off */
} instr_handle;

#define ORIGIN_SEND 1
#define ORIGIN_SCORE 2
#define ORIGIN_INSTR 3
#define ORIGIN_STARTUP 4

typedef struct hostvar_list_struct {
  char *name;
  symbol *sym;
  sa_real *val;
  asig_frame **asig;
  struct hostvar_list_struct *next;
  int width;
  int changed;
} hostvar_list;

typedef struct handle_list_struct {
  instr_handle *h;
  struct handle_list_struct *next;
} handle_list;

typedef struct scheduler_struct {
  sa_real time;
  handle_list *active;
  struct event_list_struct *pending;
  struct event_list_struct *last_ev;
  int running;
  sa_real tempo;
  sa_real last_score_tempo;
  sa_real last_tempo_time;
} scheduler;

typedef struct {
  char *name;
  char *label;
  char *sampname;
  sa_real time;
  sa_real dur;
  sa_real *val;
  instr_handle *h;
  int numval;
  int type;
  sa_real ext;  /* for external tempo control */
} event;

typedef struct event_list_struct {
  event *ev;
  struct event_list_struct *next;
} event_list;

instr_handle *register_inst(sa_decoder *sa,instr_decl *id, context *cx, sa_real dur);
void instr_output(context *cx, sa_real *pf, int pf_ct);
void finish_output(sa_decoder *sa);
void bus_output(char *busname, context *cx, sa_real *pf, int pf_ct);
void clear_busses(sa_decoder *sa);
void instr_turnoff(context *cx); 
void instr_extend(context *cx, sa_real time);
int host_value_changed(instr_handle *h, symbol *sym, int idx);
sa_real get_host_value(instr_handle *id, symbol *sym, int idx);
table_storage *get_host_table(instr_handle *id, symbol *sym);
void set_host_value(instr_handle *id, char *varname, int idx, sa_real val);
asig_frame *get_host_asig(instr_handle *id, symbol *sym, int idx);
void set_host_asig(instr_handle *id, symbol *sym,
		    int idx, asig_frame *asig);
void new_host_var(instr_handle *h, char *name, int width, int type);
int has_host_var(instr_handle *h, char *varname);

void start_scheduler(sa_decoder *sa);
void start_send_instrs(sa_decoder *sa,int numch);
void sched_add_events(sa_decoder *sa,event events[],int num);
struct comp_buffer_struct *sched_run_kcycle(sa_decoder *sa, struct decoder_struct *d);
void schedule_event(sa_decoder *sa,event *event);

sa_real *event_actparam_list(event *ev);
void free_actparam_list(sa_real *);
void remove_event(scheduler *, event_list *);
void zero_instr_output(instr_handle *h);
void set_midi_control(sa_decoder *sa, int chan, int cc, int val);
struct comp_buffer_struct *output_sound(sa_decoder *sa);

event_list *find_event_handle(instr_handle *h,int type);
event *make_event(int type, sa_real time);
void free_event(event *);

void make_global_context(sa_decoder *sa);
void add_global_table(context *cx, event *ev);
void destroy_global_table(context *cx, char *name);
void destroy_inst(sa_decoder *sa,instr_handle *h);
void free_context(context *cx);

int parse_score(sa_decoder *sa,char *fn);
event *new_event(char **words, int num);
void scale_event(scheduler *sched, event *event);
void scale_sched_events(sa_decoder *sa, event_list *pending); 


/* in order according to 5.7.3.3.6 */

#define INSTR_EVENT 2
#define CONTROL_EVENT 4
#define TURNOFF_EVENT 3
#define TABLE_EVENT 5
#define TEMPO_EVENT 14
#define END_EVENT 1
#define MIDI_ON_EVENT 6
#define MIDI_OFF_EVENT 7
#define MIDI_CONTROL_EVENT 8
#define PROGRAM_CHANGE_EVENT 9
#define MIDI_TEMPO_EVENT 10
#define MIDI_PITCH_EVENT 12
#define MIDI_TOUCH_EVENT 13
#define MIDI_CTOUCH_EVENT 11

#endif
