/*

loadicol.cpp

This software module was developed by Todor Fay & David Maymudes (Microsoft Corp)
in the course of development of the MPEG-4 Audio (ISO/IEC 14496-3) standard. 
This software module is an implementation of a part of one or more 
MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio 
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC 14496-3) 
free license to this software module or modifications thereof for use 
in hardware or software products claiming conformance to the MPEG-4 Audio 
(ISO/IEC 14496-3). Those intending to use this software module in hardware 
or software products are advised that its use may infringe existing patents. 
The original developer of this software module and his/her company, the 
subsequent editors and their companies, and ISO/IEC have no liability for 
use of this software module or modifications thereof in an implementation. 
Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming 
products. Microsoft retains full right to use the code for its own 
purpose, assign or donate the code to a third party and to inhibit third 
parties from using the code for non MPEG-4 Audio (ISO/IEC 14496-3) 
conforming products. This copyright notice must be included in all copies 
or derivative works. 

Copyright (c) Microsoft Corporation 1996, 1998
*/

#define INITGUID

#ifndef _WIN32
#include <stdio.h>
#include <string.h>
#include "sfe_datatype.h"
#endif

#include "dlsparse.h"

#ifdef __BYTE_INCOHERENT

static void _inline Swap2(unsigned short * punShort)
{
    unsigned char ucTemp;
    unsigned char *pucBuff;
    pucBuff = (unsigned char *) punShort;
    ucTemp = pucBuff[0];
    pucBuff[0] = pucBuff[1];
    pucBuff[1] = ucTemp;
}

static void _inline Swap4(unsigned long *pulLong)
{
    unsigned short unTemp;
    unsigned short *punBuff;
    punBuff = (unsigned short *) pulLong;
    unTemp = punBuff[0];
    punBuff[0] = punBuff[1];
    punBuff[1] = unTemp;
    Swap2(&punBuff[0]);
    Swap2(&punBuff[1]);
}

static void _inline SwapDLSID(DLSID *pDLSID)
{
	Swap4(&pDLSID->ulData1);
 	Swap2(&pDLSID->usData2);
 	Swap2(&pDLSID->usData3);
}

static void _inline SwapRIFFLIST(RIFFLIST *pRIFFLIST)

{
    Swap4(&pRIFFLIST->ckid);
    Swap4(&pRIFFLIST->cksize);
    Swap4(&pRIFFLIST->fccType);
}

static void _inline SwapWAVEFORMATEX(WAVEFORMATEX *pWaveFormatEx) {
    Swap2(&pWaveFormatEx->wFormatTag);
    Swap2(&pWaveFormatEx->nChannels); 
    Swap4(&pWaveFormatEx->nSamplesPerSec); 
    Swap4(&pWaveFormatEx->nAvgBytesPerSec);
    Swap2(&pWaveFormatEx->nBlockAlign);   
    Swap2(&pWaveFormatEx->wBitsPerSample); 
    Swap2(&pWaveFormatEx->cbSize); 
}

static void _inline SwapWSMPL(WSMPL * pWSMPL)

{
    Swap4(&pWSMPL->cbSize);
    Swap2(&pWSMPL->usUnityNote);
    Swap2((unsigned short*)&pWSMPL->sFineTune); 
    Swap4((unsigned long*)&pWSMPL->lAttenuation); 
    Swap4(&pWSMPL->fulOptions);       
    Swap4(&pWSMPL->cSampleLoops);
}

static void _inline SwapWLOOP(WLOOP * pWLOOP)

{
    Swap4(&pWLOOP->cbSize);
    Swap4(&pWLOOP->ulType);
    Swap4(&pWLOOP->ulStart);  
    Swap4(&pWLOOP->ulLength); 
}

static void _inline SwapCONNECTIONLIST(CONNECTIONLIST *pCONNECTIONLIST)

{
    Swap4(&pCONNECTIONLIST->cbSize);
    Swap4(&pCONNECTIONLIST->cConnections);
}

static void _inline SwapCONNECTION(CONNECTION *pCONNECTION)

{
    Swap2(&pCONNECTION->usSource);
    Swap2(&pCONNECTION->usControl);
    Swap2(&pCONNECTION->usDestination);
    Swap2(&pCONNECTION->usTransform);
    Swap4((unsigned long *)&pCONNECTION->lScale);
}

static void _inline SwapRGNRANGE(RGNRANGE *pRGNRANGE)

{
    Swap2(&pRGNRANGE->usLow);
    Swap2(&pRGNRANGE->usHigh);
}

static void _inline SwapRGNHEADER(RGNHEADER *pRGNHEADER)

{
    SwapRGNRANGE(&pRGNHEADER->RangeKey);
    SwapRGNRANGE(&pRGNHEADER->RangeVelocity);
    Swap2(&pRGNHEADER->fusOptions);
    Swap2(&pRGNHEADER->usKeyGroup);
}

static void _inline SwapWAVELINK(WAVELINK *pWAVELINK)

{
    Swap2(&pWAVELINK->fusOptions);
    Swap2(&pWAVELINK->usPhaseGroup);
    Swap4(&pWAVELINK->ulChannel);
    Swap4(&pWAVELINK->ulTableIndex);
}

static void _inline SwapINSTHEADER(INSTHEADER *pINSTHEADER)

{
    Swap4(&pINSTHEADER->cRegions);
    Swap4(&pINSTHEADER->Locale.ulBank);
    Swap4(&pINSTHEADER->Locale.ulInstrument);
}

static void _inline SwapPOOLCUE(POOLCUE *pPOOLCUE)

{
    Swap4(&pPOOLCUE->ulOffset);
}

static void _inline SwapDLSHEADER(DLSHEADER *pDLSHEADER)

{
    Swap4(&pDLSHEADER->cInstruments);
}

#else

static void _inline Swap2(unsigned short * punShort)
{
}

static void _inline Swap4(unsigned long *pulLong)
{
}

static void _inline SwapDLSID(DLSID *pDLSID)
{
}

static void _inline SwapRIFFLIST(RIFFLIST *pRIFFLIST)

{
}

static void _inline SwapWAVEFORMATEX(WAVEFORMATEX *pWaveFormatEx)

{
}

static void _inline SwapWSMPL(WSMPL * pWSMPL)

{
}

static void _inline SwapWLOOP(WLOOP * pWLOOP)

{
}

static void _inline SwapCONNECTIONLIST(CONNECTIONLIST *pCONNECTIONLIST)

{
}

static void _inline SwapCONNECTION(CONNECTION *pCONNECTION)

{
}

static void _inline SwapRGNRANGE(RGNRANGE *pRGNRANGE)

{
}

static void _inline SwapRGNHEADER(RGNHEADER *pRGNHEADER)

{
}

static void _inline SwapWAVELINK(WAVELINK *pWAVELINK)

{
}

static void _inline SwapINSTHEADER(INSTHEADER *pINSTHEADER)

{
}

static void _inline SwapPOOLCUE(POOLCUE *pPOOLCUE)

{
}

static void _inline SwapDLSHEADER(DLSHEADER *pDLSHEADER)

{
}
#endif

BOOL Stack::Push(long lData)

{
    if (m_dwIndex >= STACK_DEPTH) return FALSE;
    m_lStack[m_dwIndex++] = lData;
    return TRUE;
}

long Stack::Pop()

{
    if (m_dwIndex > 0)
    {
        return m_lStack[--m_dwIndex];
    }
    return 0;
}

void Stack::Init()

{
    m_dwIndex = 0;
}

long CDLEvaluator::QueryID(DLSID dlsid)

{
#ifdef _WIN32
    if (!memcmp(&dlsid,&DLSID_GMInHardware,sizeof(DLSID))) return 0;
    if (!memcmp(&dlsid,&DLSID_GSInHardware,sizeof(DLSID))) return 0;
    if (!memcmp(&dlsid,&DLSID_XGInHardware,sizeof(DLSID))) return 0;
    if (!memcmp(&dlsid,&DLSID_SupportsDLS1,sizeof(DLSID))) return 1;
    if (!memcmp(&dlsid,&DLSID_SupportsDLS2,sizeof(DLSID))) return 1;
    if (!memcmp(&dlsid,&DLSID_SampleMemorySize,sizeof(DLSID))) return 0x7FFFFFFF; // System memory?
#endif
    return 0;
}

BOOL CDLEvaluator::Evaluate(BYTE *p, BYTE *pEnd)

{
    BOOL fResult = FALSE;
    m_Stack.Init();
    while (p < pEnd)
    {
        USHORT usToken;
        long lTemp;
        DLSID dlsid;
        memcpy(&usToken,p,sizeof(USHORT));
        Swap2(&usToken);
        p += sizeof(USHORT);
        switch (usToken)
        {
        case DLS_CDL_AND :
            m_Stack.Push(m_Stack.Pop() && m_Stack.Pop());
            break;
        case DLS_CDL_OR	: 
            m_Stack.Push(m_Stack.Pop() || m_Stack.Pop());
            break;
        case DLS_CDL_XOR :
            m_Stack.Push(!m_Stack.Pop() ^ !m_Stack.Pop());
            break;
        case DLS_CDL_LT	:
            m_Stack.Push(m_Stack.Pop() < m_Stack.Pop());
            break;
        case DLS_CDL_LE :
            m_Stack.Push(m_Stack.Pop() <= m_Stack.Pop());
            break;
        case DLS_CDL_GT :
            m_Stack.Push(m_Stack.Pop() > m_Stack.Pop());
            break;
        case DLS_CDL_GE	:
            m_Stack.Push(m_Stack.Pop() >= m_Stack.Pop());
            break;
        case DLS_CDL_EQ :
            m_Stack.Push(m_Stack.Pop() == m_Stack.Pop());
            break;
        case DLS_CDL_NOT :
            m_Stack.Push(!m_Stack.Pop());
            break;
        case DLS_CDL_CONST :
            memcpy(&lTemp,p,sizeof(long));
            Swap4((unsigned long *)&lTemp);
            p += sizeof(long);
            m_Stack.Push(lTemp);
            break;
        case DLS_CDL_QUERY :
            memcpy(&dlsid,p,sizeof(DLSID));
            SwapDLSID(&dlsid);
            p += sizeof(DLSID);
            m_Stack.Push(QueryID(dlsid));
            break;
        }
    }
    return (BOOL) m_Stack.Pop();
}


HRESULT Wave::Load(BYTE *p, BYTE *pEnd)
{
    BOOL            fFormatRead = FALSE;
    WAVEFORMATEX    WaveFormatEx;
    long            fulOptions = 0;
    
    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));
        SwapRIFFLIST(&ck);
        switch (ck.ckid) 
        {
	  
        case LIST_TAG :
            switch (ck.fccType)
            {
                case mmioFOURCC('I','N','F','O') :
                    // !!! ignore info
                    break;
            }
            break;
        case mmioFOURCC('f','m','t',' ') :
	  
            if (fFormatRead)
            {
                return E_FAIL;
            }
            
            if( ck.cksize < 16 )  /* sizeof(PCMWAVEFORMAT */
            {
                return E_FAIL;
            }
            
            memcpy((void *)&WaveFormatEx,(p + sizeof(RIFF)),sizeof(WaveFormatEx));
            SwapWAVEFORMATEX(&WaveFormatEx);
            if (WaveFormatEx.wFormatTag != WAVE_FORMAT_PCM)
            {
                return E_FAIL;
            }
            
            if (WaveFormatEx.nChannels != 1)
            {
                return E_FAIL;
            }
            
            m_dwSampleRate = WaveFormatEx.nSamplesPerSec;
            fFormatRead = TRUE;
            break;
        case FOURCC_WSMP :
            if (ck.cksize < (sizeof(WSMPL)))
            {
                return E_FAIL;
            }
            {
                WSMPL ws;
				memcpy(&ws,p + sizeof(RIFF),sizeof(WSMPL));
                SwapWSMPL(&ws);
                WLOOP wl;
				memcpy(&wl,p + sizeof(RIFF) + sizeof(WSMPL),sizeof(WLOOP));
                SwapWLOOP(&wl);
                m_vrAttenuation = (VRELS) ((long) ws.lAttenuation >> 16);
                m_prFineTune = ws.sFineTune;
                m_bMIDIRootKey = (BYTE) ws.usUnityNote;
                m_bWSMPLoaded = TRUE;
                fulOptions = ws.fulOptions;

                if (ws.cSampleLoops == 0)
                {
                    m_bOneShot = TRUE;
                }
                else
                {
                    if (ck.cksize < sizeof(WSMPL) +
                            ws.cSampleLoops * sizeof(WLOOP)) {
                        return E_FAIL;
                    }

                    if (wl.cbSize < sizeof(WLOOP))
                    {
                        return E_FAIL;
                    }

                    if (wl.ulType != WLOOP_TYPE_FORWARD)
                    {
                        return E_FAIL;
                    }
                    m_dwLoopStart = wl.ulStart;
                    m_dwLoopEnd = wl.ulStart + wl.ulLength;
                    m_bOneShot = FALSE;
                }
            }
            break;
        case mmioFOURCC('d','a','t','a') :
            if (!fFormatRead)
            {
                return E_FAIL;
            }

            if (m_pfWave)
            {
                delete m_pfWave;
				m_pfWave = NULL;
            }
            if (WaveFormatEx.wBitsPerSample == 8)
            {
				m_dwSampleLength = ck.cksize + 1;
                m_pfWave = new double[m_dwSampleLength];
				BYTE *pSource = (BYTE *) (p + sizeof(RIFF));
                DWORD dwIndex;
                for (dwIndex = 0;dwIndex < ck.cksize;dwIndex++)
                {
                    m_pfWave[dwIndex] = (pSource[dwIndex] - 128.0) / 128.0;
                }
            }
            else
            {
                m_dwSampleLength = ck.cksize / 2;
                m_dwSampleLength++;
                m_pfWave = new double[m_dwSampleLength];
				short *pSource = (short *) (p + sizeof(RIFF));
                DWORD dwIndex;
				for (dwIndex = 0;dwIndex < (ck.cksize / 2);dwIndex++)
                {
                    Swap2((unsigned short *) &pSource[dwIndex]);
                    m_pfWave[dwIndex] = pSource[dwIndex] / 32568.0;
                }
            }
            break;
        }
        p += ck.cksize + sizeof(RIFF);
    }
    if (m_pfWave == NULL)
    {
        return E_FAIL;
    }
    Verify();
    return S_OK;
}

HRESULT SourceArticulation::Load(BYTE *p, BYTE *pEnd)
{
    CONNECTIONLIST  ConChunk;
    CONNECTION      Connection;
    DWORD           dwIndex;
	BOOL            fArt1Loaded = FALSE;
    BOOL            fArt2Loaded = FALSE;
    BOOL            fKeepThis = TRUE;
    CDLEvaluator    CDLE;   // Used to evaluate conditional chunks.

    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));   
        SwapRIFFLIST(&ck);
        switch (ck.ckid) 
        {
        case FOURCC_CDL :
            fKeepThis = CDLE.Evaluate(p + sizeof(RIFF),p + sizeof(RIFF) + ck.cksize);
            break;
        case FOURCC_ART1 :
            if (fArt2Loaded) break;
            fArt1Loaded = TRUE;
		case FOURCC_ART2 :
            if (fArt1Loaded && (ck.ckid == FOURCC_ART2))
            {
                fArt1Loaded = FALSE;
                fArt2Loaded = TRUE;
            }
            Init(); // Initialize all parameters.
			memcpy(&ConChunk,p + sizeof(RIFF),sizeof(ConChunk));
            SwapCONNECTIONLIST(&ConChunk);
			if (ConChunk.cbSize < sizeof(CONNECTIONLIST))
			{
				return E_FAIL;
			}
        
			if (ck.cksize != ConChunk.cbSize +
								   ConChunk.cConnections * sizeof(CONNECTION))
			{
				return E_FAIL;
			}
            for (dwIndex = 0;dwIndex < ConChunk.cConnections;dwIndex++)
            {
                memcpy(&Connection,p + sizeof(RIFF) + sizeof(CONNECTIONLIST) +
                                            dwIndex * sizeof(CONNECTION),sizeof(Connection));
                SwapCONNECTION(&Connection);
                switch (Connection.usSource)
                {
                case CONN_SRC_NONE :
                    switch (Connection.usDestination)
                    {
                    case CONN_DST_LFO_FREQUENCY :
                        m_ModLFO.m_trFrequency = 
                            (TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_LFO_STARTDELAY :
                        m_ModLFO.m_trDelay = 
							(TRELS) ((long)(Connection.lScale >> 16));
                         break;
                    case CONN_DST_VIB_FREQUENCY :
                        m_VibratoLFO.m_trFrequency = 
                            (TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_VIB_STARTDELAY :
                        m_VibratoLFO.m_trDelay = 
							(TRELS) ((long)(Connection.lScale >> 16));
                         break;
                    case CONN_DST_EG1_DELAYTIME :
                        m_VolumeEG.m_trDelay =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG1_ATTACKTIME :
                        m_VolumeEG.m_trAttack =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG1_HOLDTIME :
                        m_VolumeEG.m_trHold =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG1_DECAYTIME :
                        m_VolumeEG.m_trDecay =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG1_SUSTAINLEVEL :
                        m_VolumeEG.m_pcSustain =
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG1_RELEASETIME :
                        m_VolumeEG.m_trRelease =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_DELAYTIME :
                        m_ModEG.m_trDelay =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_ATTACKTIME :
                        m_ModEG.m_trAttack =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_HOLDTIME :
                        m_ModEG.m_trHold =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_DECAYTIME :
                        m_ModEG.m_trDecay =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_SUSTAINLEVEL :
                        m_ModEG.m_pcSustain =
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_RELEASETIME :
                        m_ModEG.m_trRelease =
        					(TRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_FILTER_CUTOFF :
                        m_prFilterC = 
                            (PRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_FILTER_Q :
                        m_vrFilterQ = 
                            (VRELS) ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_PITCH :
                        m_prTune = 
                            (PRELS) ((long)(Connection.lScale >> 16));
                        break;
                    case CONN_DST_PAN :
                        m_pcDefaultPan =
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_REVERB :
                        m_pcReverbSend =
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_CHORUS :
                        m_pcChorusSend =
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    default:
                        break;
                    }
                    break;
                case CONN_SRC_LFO :
                    switch (Connection.usControl)
                    {
                    case CONN_SRC_NONE :
                        switch (Connection.usDestination)
                        {
                        case CONN_DST_FILTER_CUTOFF :
                            m_ModLFO.m_prFilterScale = 
                                (PRELS) ((long)(Connection.lScale >> 16));
                            break;
                        case CONN_DST_GAIN :
                            m_ModLFO.m_vrVolumeScale = (VRELS)
                                ((long) (Connection.lScale >> 16));
                            break;
                        case CONN_DST_PITCH :
                            m_ModLFO.m_prPitchScale = (PRELS)
								(PRELS) ((long) (Connection.lScale >> 16)); 
                            break;
                        }
                        break;
                    case CONN_SRC_CC1 :
                        switch (Connection.usDestination)
                        {
                        case CONN_DST_FILTER_CUTOFF :
                            m_ModLFO.m_prMWFilterScale = 
                                (PRELS) ((long)(Connection.lScale >> 16));
                            break;
                        case CONN_DST_GAIN :
                            m_ModLFO.m_vrMWVolumeScale = (VRELS)
                                ((long) (Connection.lScale >> 16)); 
                            break;
                        case CONN_DST_PITCH :
                            m_ModLFO.m_prMWPitchScale = (PRELS)
								((long) (Connection.lScale >> 16)); 
                            break;
                        }
                        break;
                    case CONN_SRC_MONOPRESSURE :
                        switch (Connection.usDestination)
                        {
                        case CONN_DST_FILTER_CUTOFF :
                            m_ModLFO.m_prCPFilterScale = 
                                (PRELS) ((long)(Connection.lScale >> 16));
                            break;
                        case CONN_DST_GAIN :
                            m_ModLFO.m_vrCPVolumeScale = (VRELS)
                                ((long) (Connection.lScale >> 16)); 
                            break;
                        case CONN_DST_PITCH :
                            m_ModLFO.m_prCPPitchScale = (PRELS)
								((long) (Connection.lScale >> 16)); 
                            break;
                        }
                        break;
                    }
                    break;
                case CONN_SRC_VIBRATO :
                    switch (Connection.usControl)
                    {
                    case CONN_SRC_NONE :
                        switch (Connection.usDestination)
                        {
                        case CONN_DST_PITCH :
                            m_VibratoLFO.m_prPitchScale = (PRELS)
								(PRELS) ((long) (Connection.lScale >> 16)); 
                            break;
                        }
                        break;
                    case CONN_SRC_CC1 :
                        switch (Connection.usDestination)
                        {
                        case CONN_DST_PITCH :
                            m_VibratoLFO.m_prMWPitchScale = (PRELS)
								((long) (Connection.lScale >> 16)); 
                            break;
                        }
                        break;
                    case CONN_SRC_MONOPRESSURE :
                        switch (Connection.usDestination)
                        {
                        case CONN_DST_PITCH :
                            m_VibratoLFO.m_prCPPitchScale = (PRELS)
								((long) (Connection.lScale >> 16)); 
                            break;
                        }
                        break;
                    }
                    break;
                case CONN_SRC_KEYONVELOCITY :
                    switch (Connection.usDestination)
                    {
                    case CONN_DST_EG1_ATTACKTIME :
                        m_VolumeEG.m_trVelAttackScale = (TRELS)
							((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_ATTACKTIME :
                        m_ModEG.m_trVelAttackScale = (TRELS)
                            ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_GAIN :
                        if (Connection.lScale == 0x80000000)
                        {
                            m_vrVelToVolScale = -960;
                        }
                        else
                        {
                            m_vrVelToVolScale = (short)
								((long) (Connection.lScale >> 16));
                        }
                        break;
                    case CONN_DST_FILTER_CUTOFF :
                        m_prVelToFilterScale = (PRELS)
                            ((long) (Connection.lScale >> 16));
                        break;
                    }
                    break;
                case CONN_SRC_KEYNUMBER :
                    switch (Connection.usDestination)
                    {
                    case CONN_DST_EG1_DECAYTIME :
                        m_VolumeEG.m_trKeyDecayScale = (TRELS)
                            ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_EG2_DECAYTIME :
                        m_ModEG.m_trKeyDecayScale = (TRELS)
                            ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_PITCH :
                        m_prKeyNumberToPitch = (PRELS)
                            ((long) (Connection.lScale >> 16));
                        break;
                    }
                    break;
                case CONN_SRC_EG2 :
                    switch (Connection.usDestination)
                    {
                    case CONN_DST_PITCH :
                        m_ModEG.m_prPitchScale = (short)
                            ((long) (Connection.lScale >> 16));
                        break;
                    case CONN_DST_FILTER_CUTOFF :
                        m_ModEG.m_prFilterScale = (short)
                            ((long) (Connection.lScale >> 16));
                        break;
                    }
                    break;
                case CONN_SRC_CC10 :
                    switch (Connection.usDestination)
                    {
                    case CONN_DST_PAN :
                        m_pcCC10ToPan = 
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    }
                    break;
                case CONN_SRC_CC91 :
                    switch (Connection.usDestination)
                    {
                    case CONN_DST_CHORUS :
                        m_pcCC91ToChorus = 
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    }
                    break;
                case CONN_SRC_CC93 :
                    switch (Connection.usDestination)
                    {
                    case CONN_DST_REVERB :
                        m_pcCC93ToReverb = 
                            (PERCENT) ((long) (Connection.lScale >> 16));
                        break;
                    }
                    break;
                }
            }
        }
        p += ck.cksize + sizeof(RIFF);
    }
	Verify();
    if (fKeepThis) return S_OK;
    return S_FALSE;
}


HRESULT SourceRegion::Load(BYTE *p, BYTE *pEnd)
{
    HRESULT hr;  
    BOOL fKeepThis = TRUE;
    CDLEvaluator CDLE;
    SourceArticulation *pArticulation;
    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));
        SwapRIFFLIST(&ck);
        switch (ck.ckid) {
        case FOURCC_CDL :
            fKeepThis = CDLE.Evaluate(p + sizeof(RIFF),p + sizeof(RIFF) + ck.cksize);
            break;
        case FOURCC_RGNH :
            if( ck.cksize < sizeof(RGNHEADER) )
            {
                return E_FAIL;
            }
            {
                RGNHEADER rh;
				memcpy(&rh,p + sizeof(RIFF),sizeof(rh));
                SwapRGNHEADER(&rh);
                m_bKeyHigh = (BYTE) rh.RangeKey.usHigh;
                m_bKeyLow = (BYTE) rh.RangeKey.usLow;
                m_bVelHigh = (BYTE) rh.RangeVelocity.usHigh;
                m_bVelLow = (BYTE) rh.RangeVelocity.usLow;
                if (rh.fusOptions & F_RGN_OPTION_SELFNONEXCLUSIVE)
				{
					m_bAllowOverlap = TRUE;
				}
				else
				{
					m_bAllowOverlap = FALSE;
				}
                m_bGroup = (BYTE) rh.usKeyGroup;
            }
            break;
        case FOURCC_WSMP :
            if (ck.cksize < (sizeof(WSMPL)))
            {
                return E_FAIL;
            }
            {
                WSMPL ws;
				memcpy(&ws,p + sizeof(RIFF),sizeof(ws));
                SwapWSMPL(&ws);
                WLOOP wl;
				memcpy(&wl,p + sizeof(RIFF) + sizeof(WSMPL),sizeof(wl));
                SwapWLOOP(&wl);
                m_vrAttenuation = (VRELS) ((long)ws.lAttenuation >> 16);
                m_Sample.m_prFineTune = ws.sFineTune;
                m_Sample.m_bMIDIRootKey = (BYTE) ws.usUnityNote;
                m_Sample.m_bWSMPLoaded = TRUE;
					
                if (ws.cSampleLoops == 0)
                {
                    m_Sample.m_bOneShot = TRUE;
                }
                else
                {
                    if (ck.cksize < sizeof(WSMPL) +
                            ws.cSampleLoops * sizeof(WLOOP)) {
                        return E_FAIL;
                    }

                    if (ws.cSampleLoops > 1)
                    {
                        return E_FAIL;
                    }

                    // !!! these shouldn't be asserts, obviously.
                    if (wl.cbSize < sizeof(WLOOP))
                    {
                        return E_FAIL;
                    }

                    m_Sample.m_dwLoopStart = wl.ulStart;
                    m_Sample.m_dwLoopEnd = wl.ulStart + wl.ulLength;
                    m_Sample.m_bOneShot = FALSE;
                }
            }
            break;

        case FOURCC_WLNK :
            if( ck.cksize < sizeof(WAVELINK) )
            {
                return E_FAIL;
            }
            {
                WAVELINK wvl;
				memcpy(&wvl,p + sizeof(RIFF),sizeof(wvl));
                SwapWAVELINK(&wvl);
                if (wvl.ulChannel != WAVELINK_CHANNEL_LEFT)
                {
                    return E_FAIL;
                }

                m_Sample.m_wID = (WORD) wvl.ulTableIndex;
            }
            break;
        case LIST_TAG :
            switch (ck.fccType)
            {
                case FOURCC_LART :
                case FOURCC_LAR2 :
                    pArticulation = new SourceArticulation;

                    if (!pArticulation)
                    {
                        return E_OUTOFMEMORY;
                    }

                    hr = pArticulation->Load(p + sizeof(RIFFLIST),
                                            p + sizeof(RIFF) + ck.cksize);

                    if (FAILED(hr))
                    {
                        delete pArticulation;
                        return hr;
                    }
                    if (hr == S_OK)
                    {
                        if (m_pArticulation)
                        {
                            m_pArticulation->Release();
                        }
                        m_pArticulation = pArticulation;
                        pArticulation->AddRef();
                    }
                    else
                    {
                        pArticulation->Release();
                    }
                    break;
            }
            break;
        }
        p += ck.cksize + sizeof(RIFF);
    }
    if (fKeepThis) return S_OK;
    else return S_FALSE; // No error, but we don't want to keep region.
}


HRESULT Instrument::LoadRegions(BYTE *p, BYTE *pEnd)
{
    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));
        SwapRIFFLIST(&ck);
        switch (ck.ckid) {
        case LIST_TAG :
            switch (ck.fccType)
            {
	        case FOURCC_RGN2 :
            case FOURCC_RGN :
                SourceRegion *pRegion = NULL;

                pRegion = new SourceRegion;

                // !!! delay creating these?  do this more efficiently?

                if (!pRegion)
                {
                    return E_OUTOFMEMORY;
                }

                HRESULT hr = pRegion->Load(p + sizeof(RIFFLIST),
                                           p + sizeof(RIFF) + ck.cksize);
                if (FAILED(hr))
                {
                    delete pRegion;
                    return hr;
                }
                if (hr == S_FALSE) // Failed a conditional chunk!
                {
                    delete pRegion;
                }
                else
                {
                    m_RegionList.AddHead(pRegion);
                }
                break;
            }
        }
        p += ck.cksize + sizeof(RIFF);
    }

    return S_OK;
}

HRESULT Instrument::Load( BYTE *p, BYTE *pEnd)
{
    HRESULT hr;
    SourceArticulation *pArticulation = NULL;
    SourceArticulation *pGlobalArticulation = NULL;
    BOOL fIsDrum = FALSE;

    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));
        SwapRIFFLIST(&ck);
        switch (ck.ckid) {
        case FOURCC_INSH :
            if( ck.cksize < sizeof(INSTHEADER) )
            {
                // !!!
                return E_FAIL;
            }
            {
                INSTHEADER InstHeader;
				memcpy(&InstHeader,p + sizeof(RIFF),sizeof(InstHeader));
                SwapINSTHEADER(&InstHeader);
                if (InstHeader.Locale.ulBank & F_INSTRUMENT_DRUMS)    // Drum Bank?
                {
                    fIsDrum = TRUE;
                }

                m_dwProgram = InstHeader.Locale.ulInstrument;
                m_dwProgram |= ((InstHeader.Locale.ulBank & 0x7F7F) << 8);

		printf("%d ",m_dwProgram);
                                         
                if (fIsDrum)
                {
                    m_dwProgram |= F_INSTRUMENT_DRUMS;
                }
            }
            break;
        case LIST_TAG :
            switch (ck.fccType)
            {
                case FOURCC_LRGN :
					// First, get rid of previous list of regions.
					while (!m_RegionList.IsEmpty())
					{
						SourceRegion *pRegion = m_RegionList.RemoveHead();
						delete pRegion;
					}
                    hr = LoadRegions(p + sizeof(RIFFLIST),
                                     p + sizeof(RIFF) + ck.cksize);

                    if (FAILED(hr))
                    {
                        return hr; 
                    }
                    break;
                case mmioFOURCC('I','N','F','O') :
                    // load info, not.
                    break;
                case FOURCC_LART :
                case FOURCC_LAR2 :
                   
                    pArticulation = new SourceArticulation;

                    if (!pArticulation)
                    {
                        return E_OUTOFMEMORY;
                    }
                    pArticulation->AddRef(); // Will Release when done.

                    hr = pArticulation->Load(p + sizeof(RIFFLIST),
                                            p + sizeof(RIFF) + ck.cksize);
                    if (FAILED(hr))
                    {
                        pArticulation->Release();
                        return hr;
                    }
                    if ( hr == S_OK)
                    {
                        if (pGlobalArticulation)
                        {
                            // !!! already had one?
                            pGlobalArticulation->Release();
                        }
                        pGlobalArticulation = pArticulation;
                    }
                    else
                    {
                        pArticulation->Release();
                    }
                    break;
            }
            break;
        }
        p += ck.cksize + sizeof(RIFF);
    }

    if (!pGlobalArticulation)
    {
        pGlobalArticulation = new SourceArticulation;
        if ( pGlobalArticulation )
            pGlobalArticulation->AddRef();
    }

    if (pGlobalArticulation)
    {
    
        for (SourceRegion *pr = m_RegionList.GetHead();
             pr != NULL;
             pr = pr->GetNext())
        {
            if (pr->m_pArticulation == NULL)
            {
				pr->m_pArticulation = pGlobalArticulation;
				pGlobalArticulation->AddRef();    
			}
        }
        pGlobalArticulation->Release();   // Release initial AddRef();
    }
    else
    {
        for (SourceRegion *pr = m_RegionList.GetHead();
             pr != NULL;
             pr = pr->GetNext())
        {
            if (pr->m_pArticulation == NULL)
            {
                return E_FAIL;
            }
        }
    }
    
    return S_OK;
}


HRESULT Collection::LoadInstruments(BYTE *p, BYTE *pEnd)
{
    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));
        SwapRIFFLIST(&ck);
        switch (ck.ckid) {
        case LIST_TAG :
            switch (ck.fccType)
            {
            case FOURCC_INS :
                Instrument *pInstrument = NULL;

                pInstrument = new Instrument;
                if (!pInstrument)
                {
                    return E_OUTOFMEMORY;
                }

                HRESULT hr = pInstrument->Load(p + sizeof(RIFFLIST),
                                               p + ck.cksize + sizeof(RIFF));

                if (FAILED(hr))
                {
                    delete pInstrument;
                    // !!! OK, so this instrument failed; should we try to go on?
                    return hr;
                }
				RemoveDuplicateInstrument(pInstrument->m_dwProgram);
                m_InstrumentList.AddTail(pInstrument);
                break;
            }
        }
        p += ck.cksize + sizeof(RIFF);
    }

    // !!! check whether we found the right # of instruments
    return S_OK;
}

HRESULT Collection::LoadWavePool(BYTE *p, BYTE *pEnd)
{
    DWORD entry = 0;
    Wave *pWave;
    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));
        SwapRIFFLIST(&ck);
        switch (ck.ckid) {
        case LIST_TAG :
            switch (ck.fccType)
            {
            case mmioFOURCC('W','A','V','E') :
            case mmioFOURCC('w','a','v','e') :
                pWave = new Wave;
                if (pWave == NULL)
                {
                    return E_OUTOFMEMORY;
                }
                m_WavePool.AddTail(pWave);
				pWave->AddRef();
                entry++;    // Need to change this to scan around the wave, just grab the offset.
                HRESULT hr = pWave->Load(p + sizeof(RIFFLIST),
                                              p + sizeof(RIFF) + ck.cksize);

                if (FAILED(hr))
                {
                    return hr;
                }
                break;
            }
        }
        p += ck.cksize + sizeof(RIFF);
    }

    return S_OK;
}

HRESULT Collection::LoadPoolCues(BYTE *p, BYTE *pEnd)
{
    DWORD dwIndex;
    POOLTABLE Header,*pHeader = &Header;

    memcpy(&Header,p,sizeof(Header));

    Swap4((unsigned long *)(&pHeader->cbSize));
    Swap4((unsigned long *)(&pHeader->cCues));
    p += pHeader->cbSize;
	while (!m_WavePool.IsEmpty()) 
	{
        Wave *pWave = m_WavePool.RemoveHead();
        pWave->Release();
	}
    for (dwIndex = 0; dwIndex < pHeader->cCues; dwIndex++)
    {
        POOLCUE Cue;
        if (p >= pEnd) break;
		memcpy(&Cue,p,sizeof(Cue));
        SwapPOOLCUE(&Cue);
        Wave *pWave = new Wave;
        if (pWave != NULL)
        {
            pWave->m_wID = (WORD) dwIndex;
            pWave->m_ulOffset = Cue.ulOffset;
            m_WavePool.AddTail(pWave);
			pWave->AddRef();
        }
        p += sizeof(POOLCUE);
    }
	if (dwIndex > 65535)
	{
		return E_FAIL;
	}
	m_wWavePoolSize = (WORD) dwIndex;
    return (S_OK);
}

HRESULT Collection::ResolveConnections()

{
	HRESULT hr = S_OK;
	Wave** pArray = new Wave*[m_wWavePoolSize];
	if (pArray != NULL)
	{
		Wave *pWave;
		DWORD dwIndex = 0;
		pWave = m_WavePool.GetHead();
		for (;pWave != NULL;pWave = pWave->GetNext())
		{
			if (dwIndex >= m_wWavePoolSize)
			{
				hr = E_FAIL;
				break;	// Should never happen.
			}
			pArray[dwIndex] = pWave;
			if (pWave->m_wID != dwIndex)
			{
				hr = E_FAIL;
				break;	// Should never happen.
			}
			dwIndex++;
		}
		for (Instrument *pInstrument = m_InstrumentList.GetHead();
			 pInstrument != NULL;
			 pInstrument = pInstrument->GetNext())
		{
			SourceRegion *pRegion = pInstrument->m_RegionList.GetHead();
			for (;pRegion != NULL;pRegion = pRegion->GetNext())
			{
				if (pRegion->m_Sample.m_wID < m_wWavePoolSize)
				{
					pWave = pArray[pRegion->m_Sample.m_wID];
					if (pRegion->m_Sample.m_pWave != NULL)
					{
						pRegion->m_Sample.m_pWave->Release();
					}
					pRegion->m_Sample.m_pWave = pWave;
					if (pWave)
					{
						pWave->AddRef(); 
						pRegion->m_Sample.Lock(TRUE);
					}
					else
					{
						hr = E_FAIL;
						break;
					}
				}
				else
				{
					hr = E_FAIL;
					break;
				}
			}
		}
		delete[] pArray;
	}
	else
	{
		hr = E_OUTOFMEMORY;
	}
    return hr;
}

HRESULT Collection::Load(BYTE *p, BYTE *pEnd)
{
    DLSHEADER DlsHeader;
    HRESULT hr;
    BOOL fCuesLoaded = FALSE;

    while (p < pEnd)
    {
        RIFFLIST ck;
		memcpy(&ck,p,sizeof(RIFFLIST));
        SwapRIFFLIST(&ck);
        switch (ck.ckid) {
        case FOURCC_COLH :
            if( ck.cksize < sizeof(DLSHEADER) )
            {
                return E_FAIL;
            }
            memcpy(&DlsHeader,p + sizeof(RIFF),sizeof(DlsHeader));
            SwapDLSHEADER(&DlsHeader);
            break;
        case FOURCC_PTBL :
            hr = LoadPoolCues(p + sizeof(RIFF),
                              p + sizeof(RIFF) + ck.cksize); 
            if (FAILED(hr))
            {
                return hr;
            }
            fCuesLoaded = TRUE;
            break;
        case LIST_TAG :
            switch (ck.fccType)
            {
                case FOURCC_LINS :
                    hr = LoadInstruments(p + sizeof(RIFFLIST),
                                         p + sizeof(RIFF) + ck.cksize);
                    if (FAILED(hr))
                    {
                        return hr;
                    }
                    break;
                case FOURCC_WVPL :
                    if (fCuesLoaded)
                    {
                        m_ulWavePool = (ULONG) p + sizeof(RIFFLIST);
                        Wave * pWave = m_WavePool.GetHead();
                        for (;pWave != NULL;pWave = pWave->GetNext())
                        {
                            pWave->m_ulOffset += m_ulWavePool;
                        }
                    }
                    else
                    {
                        hr = LoadWavePool(p + sizeof(RIFFLIST),
                                          p + sizeof(RIFF) + ck.cksize);
                        if (FAILED(hr))
                        {
                            return hr;
                        }
                    }
                    break;
            }
            break;
        }
        p += ck.cksize + sizeof(RIFF);
    }
    ResolveConnections();
    return S_OK;
}


HRESULT Collection::Load()
{
    BYTE *p = m_pData;
    RIFFLIST ck;
	memcpy(&ck,p,sizeof(RIFFLIST));
    SwapRIFFLIST(&ck);
    if (p == NULL) return E_FAIL;  // This should NEVER happen.
    if (ck.fccType != FOURCC_DLS)
    {
        return E_FAIL;
    }
    return Load(p + sizeof(RIFFLIST), p + m_ulSize);
}

HRESULT InstManager::DownloadCollection(BYTE * pData, DWORD dwSize, HANDLE *phCollection )
{
    HRESULT hr = S_OK;
    if (pData == NULL)
    {
        return E_FAIL;
    }
    Collection *pCollection = new Collection;
    if (pCollection == NULL)
    {
        return E_OUTOFMEMORY;
    }
	pCollection->m_pData = pData;
	pCollection->m_ulSize = dwSize;
    hr = pCollection->Load();
    if (SUCCEEDED(hr))
    {
        pCollection->m_dwOpenCount++;
		*phCollection = (HANDLE) pCollection;
        m_CollectionList.AddHead(pCollection);
    }
    else
    {
		*phCollection = NULL;
        delete pCollection;
    }
    
    return (hr);
}


HRESULT InstManager::UnloadCollection(HANDLE hCollection)

{
    HRESULT hr = E_HANDLE;
    Collection *pCollection = (Collection *) hCollection;
    if (m_CollectionList.IsMember(pCollection))
    {
        pCollection->m_dwOpenCount--;
        if (pCollection->m_dwOpenCount == 0)
        {
            m_CollectionList.Remove(pCollection);
            delete pCollection;
        }
        hr = S_OK;
    }
    return hr;
}
