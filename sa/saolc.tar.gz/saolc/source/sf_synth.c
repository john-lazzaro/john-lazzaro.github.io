/*

This software module was originally developed by 

Luke Dahl, Brian Link (E-mu Systems)


in the course of development of the MPEG-4 Audio (ISO/IEC 14496-3) standard. 
This software module is an implementation of a part of one or more 
MPEG-4 Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio 
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC 14496-3) 
free license to this software module or modifications thereof for use 
in hardware or software products claiming conformance to the MPEG-4 Audio 
(ISO/IEC 14496-3). Those intending to use this software module in hardware 
or software products are advised that its use may infringe existing patents. 
The original developer of this software module and his/her company, the 
subsequent editors and their companies, and ISO/IEC have no liability for 
use of this software module or modifications thereof in an implementation. 
Copyright is not released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming 
products. E-mu Systems retains full right to use the code for his/her own 
purpose, assign or donate the code to a third party and to inhibit third 
parties from using the code for non MPEG-4 Audio (ISO/IEC 14496-3) 
conforming products. This copyright notice must be included in all copies 
or derivative works. 

Copyright (C) 1998 E-mu Systems, Inc.

*//*****************************************************************************
;
;	sf_synth.c
;
;	Audio processing for SF Synth.
;
;****************************************************************************/


#define PREINTERPOLATE /* needed to do preinterpolation -- this must come before including sf_wave_equ.h  */
#ifndef _WIN32
#include "stdio.h"
#endif
#include "sf_wave_equ.h"
#include "sf_wave_def.h"
#include "sf_param_trans.h"
/*#include "sfe_enab.h" */
#include "saol.h"

extern struct cmdinfo cmd;		/* to get SF bank name form cmd line */

#include <math.h>	/* so far used only in testing functions */

#define MAXSFBANKNAMECHARS 30	/* max number of characters in a sf bank name */
#define MAXEXPECTEDSFVOICES	4	/* maximum number of sf wavetable voices expected
									to be playing at once.  Used for normalizing mixer.*/
#define DEFAULT_PB_SENS	200	/* default pitchbend sensitivity in cents. */
#define PB_CONT_NUM		128	/* PitchBend is stored in midicc[][128] */

#define VOL7_CONT_NUM		7   /* Midi volume controller 7 -- this one isn't reset by reset all controllers */
#define VOL11_CONT_NUM		11  /* Midi volume controller 11 -- this one is reset by reset all controllers */

#define MAXLAYERS	64  /* this is the maximum number of layers for one voice.  not really an inherent limit,
							just one way to get it done without changing too much code. */


void sf_bank_load(sa_decoder *sa, char *bankname, int banknum)
{

	
  /* DLS Code */
	sa->dlsbanks[banknum].instrument = CreateInstrMgr();
	if(!SUCCEEDED(OpenCollectionFile(&sa->dlsbanks[banknum],bankname))){
		runtime(sa,"ERROR: Could not open DLS Bank.");
	}
	else
		if (sa->verbose) printf("DLS Bank Opened.\n");	
	if(!SUCCEEDED(DownloadCollection(&sa->dlsbanks[banknum]))){
		runtime(sa,"ERROR: Could not download DLS Bank.");
	}
	else
		printf("DLS Bank Downloaded.\n");

}

#ifndef _WIN32
#define S_OK 1
#endif
void sf_synth_top(context *cx, int offset,
		  double *Left, double *Right, double *Rev, double *Chor,
	long rate, double sfbanknum, double chan, double midibank, double midipreset,
	double midinote, double keyvel)
{
	static int SFPARAMINIT = FALSE;
	double	samp, pan, panR, panL;	
	sfData* arraysynthparams[MAXLAYERS];
	sfData* currsynthparams;
	WORD voicecnt;
	int framesz, i, srate, krate, extendnote, sfbank;
	DWORD dlspatch;
	DWORD midibankLSB, midibankMSB, midibankFlag, midibankPreset;
	DWORD dwLayer;
	HRESULT hr;
	sfData testsynthparams;

	sfbank = (int)sfbanknum;
	srate = cx->sa->all->g->srate;
	krate = cx->sa->all->g->krate;

	/* if this is a new note */
	if (rate == IVAR)
	{
		/* get DLS params; */
		midibankLSB = 0;	/*  Change this later when saolc handles midibank select correctly */
		midibankFlag = 0;
		if (midibank > 127){
			midibankFlag = 0x80000000;	/* set percussion flag */
			midibankMSB = 0x007f0000;
		}
		else
			midibankMSB = ((DWORD)(midibank) << 16) & 0x0000ff00;
		midibankPreset = (DWORD)(midipreset) & 0x000000ff;
		dlspatch = midibankFlag | midibankMSB | midibankLSB | midibankPreset;

		hr = S_OK;
		voicecnt = 0;
		for (dwLayer = 0;hr == S_OK; dwLayer++)
		{
			hr = GetSynthParams(&cx->sa->dlsbanks[sfbank], dlspatch, (DWORD)midinote, (DWORD)keyvel, &testsynthparams, dwLayer);
      if(!SUCCEEDED(hr)){ /* !SUCCEEDED */
			}
			else if(dwLayer <= MAXLAYERS){
				arraysynthparams[voicecnt] = &testsynthparams;
				++voicecnt;
			}
		}

		/* Allocate synthparam storage */	
		if(!(cx->sfstorage[offset] = (struct SynthParams *)calloc(voicecnt, sizeof(struct SynthParams))))
			interror("Couldn't allocate SynthParam space in sf_synth!!");
		cx->sfVoiceCnt = voicecnt;
		
		/* find voices and fill up cx->sfstorage */
		for (i = 0; i < (int)voicecnt; i++)
		{
			sf_init_sp(&(cx->sfstorage[offset][i]));
			
			currsynthparams = arraysynthparams[i];
			sf_xlat(currsynthparams, &cx->sa->sfbanks[sfbank], &(cx->sfstorage[offset][i]), srate, krate, (SHORT)midinote, (SHORT)keyvel);
			cx->sfstorage[offset][i].Chan = (int)chan;
			cx->sfstorage[offset][i].Note = (int)midinote;

			/* some parameter inits from StartVoice. Keep These. */
			cx->sfstorage[offset][i].EnvMessage = ENV_START;
			cx->sfstorage[offset][i].Lfo1.value = .5;
			cx->sfstorage[offset][i].Lfo2.value = .5;
			cx->sfstorage[offset][i].Lfo1.count = cx->sfstorage[offset][i].Lfo1.delay;
			cx->sfstorage[offset][i].Lfo2.count = cx->sfstorage[offset][i].Lfo2.delay;
			cx->sfstorage[offset][i].curSamp = cx->sfstorage[offset][i].Start;
			cx->sfstorage[offset][i].curFract = 0;
			if (cx->sfstorage[offset][i].InstantAttack == TRUE)
				cx->sfstorage[offset][i].Vol = pow(10., -cx->sfstorage[offset][i].Attenuation/200.0);
		}
	}

	if (rate == KSIG)
	{	
		framesz = srate/krate;
		extendnote = 0;
		
		/* update synth params */
		for (i = 0;i < cx->sfVoiceCnt; i++)
		{

		  if(cx->instr->turnoff_notified)
			{
				/* if any voices are still on */
				if(cx->sfstorage[offset][i].VolEnv.state != OFF)
				{
					/* and not yet in release */
					if(cx->sfstorage[offset][i].VolEnv.state != RELEASE)
					{
						cx->sfstorage[offset][i].EnvMessage = ENV_STOP;
						extendnote = 1;		/* set flag to extend note */
					}
					else
					{
						extendnote = 1;
					}
				}
				
			}

			/* update envelopes and other synthparams */
			env_gen(cx, offset,i, framesz);
		}
		if(extendnote)
		{
			instr_extend(cx,(double)2/krate);
		}
	}
	
	if (rate == ASIG)
	{		
		*Left = 0;
		*Right = 0;
		*Rev = 0;
		*Chor = 0;

		for (i = 0;i < cx->sfVoiceCnt; i++)
		{	
			if (cx->sfstorage[offset][i].VolEnv.state != OFF)
			{
				sf_osc(cx->sfstorage[offset], i, &samp); 	 
				sf_lpf(cx->sfstorage[offset], i, &samp, srate);

				/* increment Fc and Vol*/
				cx->sfstorage[offset][i].FilterFc += cx->sfstorage[offset][i].FilterFcInc;
				cx->sfstorage[offset][i].Vol += cx->sfstorage[offset][i].VolInc;

				/* Mix into four output samples */
				pan = cx->sa->midicc[cx->sfstorage[offset][i].Chan][10];
				pan = (pan - 64.0)/127.0;
				panR = cx->sfstorage[offset][i].RSend + pan;
				panR = (panR > 1)?1:panR;
				panR = (panR < 0)?0:panR;
				panL = cx->sfstorage[offset][i].LSend - pan;
				panL = (panL > 1)?1:panL;
				panL = (panL < 0)?0:panL;
				*Left += panL * samp;
				*Right += panR * samp;
				*Rev += cx->sfstorage[offset][i].RvbSend * samp;
				*Chor += cx->sfstorage[offset][i].ChsSend * samp;
			}
		}
		/* Normalize to prevent overflow */
		*Left /= MAXEXPECTEDSFVOICES;
		*Right /= MAXEXPECTEDSFVOICES;
		*Rev /= MAXEXPECTEDSFVOICES;
		*Chor /= MAXEXPECTEDSFVOICES;
	}
}

/* Oscillator that does sample interpolation from sample table */
void sf_osc(struct SynthParams *sp, int voice, double *buf)
{
	int	intpart;
	double	samp1, samp2;

	if (sp[voice].VolEnv.state != OFF)
	{
		/*	Check for end of data */
		if (sp[voice].curSamp >= sp[voice].End)
		{
			sp[voice].VolEnv.state = OFF;
			sp[voice].VolEnv.value = 0;
			sp[voice].VolEnv.count = 0;
			sp[voice].Vol = 0;
		}

		/*	Linear interpolation */
		samp1 = *(sp[voice].curSamp);
		samp2 = *(sp[voice].curSamp + 1);
		*buf = samp1 * (1 - sp[voice].curFract) + samp2 * sp[voice].curFract;

		/*	Apply volume */
		*buf *= sp[voice].Vol;
		
		/*	Pointer update */
		sp[voice].curFract += sp[voice].PhaseInc;
		intpart = (int) sp[voice].curFract;
		sp[voice].curSamp += intpart;
		sp[voice].curFract -= intpart;

		/* Check for end of loop if looping is enabled */
		if (sp[voice].SampleMode != LOOP_NONE) {
			/* Don't check for end of loop if key is up and mode is LOOP_HOLD */	
			if (!(sp[voice].SampleMode == LOOP_HOLD && sp[voice].VolEnv.state == RELEASE))
			if (sp[voice].curSamp >= sp[voice].Endloop)
			{
				sp[voice].curSamp -= (sp[voice].Endloop - sp[voice].Startloop);
			}
		}

		if (sp[voice].VolEnv.state != DELAY && sp[voice].VolEnv.state != ATTACK && 
			sp[voice].VolEnv.value < 1./65536)
		{							/* this ensures that decay does not last forever */
			sp[voice].VolEnv.state = OFF;	
			sp[voice].VolEnv.value = 0;
			sp[voice].VolEnv.count = 0;
			sp[voice].Vol = 0;
		}
	} /* (sp[voice].VolEnv.state != OFF) */
}


/* low pass filter */
void sf_lpf(struct SynthParams *sp, int voice, double *samp, int srate)
{
	double Fc;
	double Res;
	double Z1, Z2;
	double A1, A2, B;
	double Phi, P2, R;

	Fc = CentsToHertz(sp[voice].FilterFc);
	Res = sp[voice].FilterQ / 10.;
	Z1 = sp[voice].FilterZ1;
	Z2 = sp[voice].FilterZ2;

	if (Fc > (double)srate/3.)
		Fc = (double)srate/3.;
	if (Fc < 200)
		Fc = 200;

	if (Res < 0)
		Res = 0;
	if (Res > 22.5)
		Res = 22.5;

	Phi = 2*PI*Fc/(double)srate;
	P2 = -2 * cos(Phi);
	R = (cos(Phi)+sin(Phi)*sqrt(pow(10.,(Res/10.)) - 1.))/(pow(10.,(Res/20.))*sin(Phi)+1);

	A1 = R * P2;
	A2 = R * R;

	B = 1. + A1 + A2;
	B = B * pow(10.,(-Res/40.));
	
	*samp=*samp * B - A1*Z1 - A2*Z2;		/* Filter it */
	Z2=Z1;									/* update the state */
	Z1=*samp;
	sp[voice].FilterZ1=Z1;
	sp[voice].FilterZ2=Z2;
}


/* function updates envelopes and other synthparameters */
void env_gen(context *cx, int offset, int voice, int framesz)
{
	double VolTarget,  Gain, Atten, tempLfo1, tempLfo2;
	double PitchMod, FcMod, PitchBend;
	int ccVol7, ccVol11;	

	env_val(&(cx->sfstorage[offset][voice].VolEnv), cx->sfstorage[offset][voice].EnvMessage);

	if (cx->sfstorage[offset][voice].VolEnv.state != OFF)
	{
		env_val(&(cx->sfstorage[offset][voice].PitchEnv), cx->sfstorage[offset][voice].EnvMessage);
		cx->sfstorage[offset][voice].EnvMessage = ENV_NONE;
		lfo_val(&(cx->sfstorage[offset][voice].Lfo1));
		lfo_val(&(cx->sfstorage[offset][voice].Lfo2));

/*	Apply Tremolo */
		if (cx->sfstorage[offset][voice].Lfo1.value < 0)   /* turn sawtooth into triangle */
			tempLfo1 = -cx->sfstorage[offset][voice].Lfo1.value;
		else
			tempLfo1 = cx->sfstorage[offset][voice].Lfo1.value;
		tempLfo1 = 2. * (tempLfo1 - .5);

/*	Compute Target Volume */
		ccVol7 = cx->sa->midicc[cx->sfstorage[offset][voice].Chan][VOL7_CONT_NUM];
		ccVol11 = cx->sa->midicc[cx->sfstorage[offset][voice].Chan][VOL11_CONT_NUM];

		if (ccVol7 == 0 || ccVol11 == 0) 
		{
			Gain = 0;
		}
		else {
			Atten = cx->sfstorage[offset][voice].Attenuation + cx->sfstorage[offset][voice].Tremolo * tempLfo1 + 
				400.0 * log10(ccVol7 / 127.0) + 400.0 * log10(ccVol11 / 127.0) ;	
			Gain = pow(10.0, Atten/200.0);
			if (Gain < 0)
				Gain = 0.0;
			if (Gain > 1)
				Gain = 1.0;
		}

		VolTarget = Gain * cx->sfstorage[offset][voice].VolEnv.value;

		if (VolTarget > 1.0)
			VolTarget = 1.0;		
		cx->sfstorage[offset][voice].VolInc = (VolTarget - cx->sfstorage[offset][voice].Vol) / framesz;

/*	Compute Phase Increment */
		if (cx->sfstorage[offset][voice].Lfo2.value < 0)   /* turn sawtooth into triangle */
			tempLfo2 = -cx->sfstorage[offset][voice].Lfo2.value;
		else
			tempLfo2 = cx->sfstorage[offset][voice].Lfo2.value;
		tempLfo2 = 2. * (tempLfo2 - .5);

		PitchBend = cx->sa->midicc[cx->sfstorage[offset][voice].Chan][PB_CONT_NUM];
		PitchBend = (PitchBend - 8192)/8192;

		PitchMod = cx->sfstorage[offset][voice].PitchEnvToPitch * cx->sfstorage[offset][voice].PitchEnv.value + 
					cx->sfstorage[offset][voice].Lfo1ToPitch * tempLfo1 + 
					cx->sfstorage[offset][voice].Lfo2ToPitch * tempLfo2 +
					PitchBend * DEFAULT_PB_SENS;

		cx->sfstorage[offset][voice].PhaseInc = CalcPhaseInc(cx->sfstorage[offset][voice].InitPitch + PitchMod);

/*  Compute Fc Increment */
		FcMod = cx->sfstorage[offset][voice].PitchEnvToFilterFc * cx->sfstorage[offset][voice].PitchEnv.value +
				cx->sfstorage[offset][voice].Lfo1ToFilterFc * tempLfo1;
		cx->sfstorage[offset][voice].FilterFcInc = (cx->sfstorage[offset][voice].InitFilterFc + FcMod - cx->sfstorage[offset][voice].FilterFc)/framesz;

	} /* !(cx->sfstorage[offset][voice].VolEnv.state != OFF) */
	else
	{
		cx->sfstorage[offset][voice].VolInc = 0;
	}
}

void lfo_val(struct Lfo *l)
{
/* 2/freq gives the duration of one period since this sawtooth gets converted */
/* to triangle waveform. */
	if (l->count > 0)
	{
		l->count--;
	}
	else
	{
		l->value += l->freq;
		if (l->value >=1.0)
			l->value -= 2.0;
	}
}

void env_val(struct Env *e, EnvMessageType msg)
{

/*	Act on message */

	switch(msg)
	{
		case ENV_NONE:
			break;
			
		case ENV_START:			/* assumes start will not be sent for channel */
			e->state = DELAY;	/* that is still on */
			e->count = e->delay;
			break;
			
		case ENV_STOP:			/* note-off */
			e->state = RELEASE;
			e->count = 0;
			break;
		
		case ENV_ABORT:			/* rip-off */
			e->state = RELEASE;
			e->value = 0;
			e->count = 0;
			return;
			
		default:
			printf("ERROR: env_val: illegal envelope message %d\n", msg);
			exit(1);
			break;
	}
	
/*	Determine which state to use */

	switch(e->state)
	{
		case OFF:
			break;

		case DELAY:
			if (e->count == 0)
			{
				e->state = ATTACK;
			}
			else
				break;

		case ATTACK:
			if (e->attack + e->value >= 1.0)
			{
				e->state = HOLD;
				e->value = 1.0;
				e->count = e->hold;
			}
			else
				break;

		case HOLD:
			if (e->count == 0)
			{
				e->state = DECAY;
			}
			else
				break;

		case DECAY:
			if (e->decay * e->value <= e->sustain)
			{
				e->state = SUSTAIN;
				e->value = e->sustain;
			}
			else
				break;

		case SUSTAIN:
			if (msg == ENV_STOP)
			{
				e->state = RELEASE;
			}
			else
				break;

		case RELEASE:
			break;

		default:
			printf("ERROR: env_val: illegal envelope state\n");
			exit(1);
			break;
	}

/*	Act on current state */

	switch(e->state)
	{
		case OFF:				/* value and count zeroed already */
			break;

		case DELAY:				/* value already zero */
			e->count--;
			break;

		case ATTACK:
			e->value += e->attack;	/* linear attack */
			break;

		case HOLD:				/* value remains 1.0 */
			e->count--;
			break;

		case DECAY:
			e->value *= e->decay;	/* exponential decay */
			break;

		case SUSTAIN:				/* value remains constant */
			break;

		case RELEASE:
			e->value *= e->release;	/* exponential release */
			break;

		default:
			printf("ERROR: env_val: illegal envelope state\n");
			exit(1);
			break;
	}
}


void sf_init_sp(struct SynthParams *p)
{
	p->Start = NULL;
	p->End = NULL;
	p->Startloop = NULL;
	p->Endloop = NULL;

	p->curSamp = NULL;
	p->curFract = 0;
	p->InitPitch = 0;
	p->PhaseInc = 0;
	p->PitchEnvToPitch = 0;
	p->Lfo1ToPitch = 0;
	p->Lfo2ToPitch = 0;
	p->SFLfo1ToPitchVal = 0;
	p->SFLfo2ToPitchVal = 0;

	sf_init_env(&(p->PitchEnv));
	sf_init_env(&(p->VolEnv));
	sf_init_lfo(&(p->Lfo1));
	sf_init_lfo(&(p->Lfo2));

	p->EnvMessage = ENV_NONE;
	p->SFVolValue = 0;
	p->InstantAttack = 0;
	p->Vol = 0;
	p->VolInc = 0;
	p->Tremolo = 0;
	p->Attenuation = 0;

	p->InitFilterFc = 0;
	p->FilterFc = 0;
	p->FilterFcInc = 0;
	p->FilterQ = 0;
	p->Lfo1ToFilterFc = 0;
	p->PitchEnvToFilterFc = 0;
	p->FilterZ1 = 0;
	p->FilterZ2 = 0;

	p->SFPanValue = 0;
	p->LSend = 0;
	p->RSend = 0;
	p->RvbSend = 0;
	p->ChsSend = 0;
	
	p->Chan = -1;
	p->Note = -1;
	p->InSustain = 0;
	p->Pending = 0;
}

void sf_init_env(struct Env *e)
{
	e->state = OFF;
	e->value = 0;
	e->count = 0;
	e->delay = 0;
	e->attack = 0;
	e->hold = 0;
	e->decay = 0;
	e->sustain = 0;
	e->release = 0;
}

void sf_init_lfo(struct Lfo *l)
{
	l->value = 0.5;		/* -1 to 1 saw is mapped into 0 to 1 tri so .5 -> 0 */
	l->count = 0;
	l->freq = 0;
	l->delay = 0;
}


