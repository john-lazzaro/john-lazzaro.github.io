/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

#include "saol_prec.h"
#include "saol.h"
#include "saol_sched.h"
#include "saol_interp.h"



void spatialize(context *cx, sa_real *pl, int p_ct) {
  /* pl[0] is the signal stream to spatialize;
     pl[1] is the azimuth;
     pl[2] is the elevation;
     pl[3] is the distance.

     cx->sa->all->g->outchan is the number of output channels
       (1-channel "spatialization" is easy!) */
  int i;
  
  /* .
     .
     . */

  for (i=0;i!=cx->sa->all->g->outchan;i++)
    cx->instr->output[i][cx->asample_ptr] += 0;  /* add output here */
}
