/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_rates.c : rate check the orchestra.

   This module checks all of the orchestra code to make sure that rate semantics
   rules are respected.  We're looking for problems like these:

    ivar i;
	ksig k;

    i = k * 2;

    This is illegal, because the lvalue of an assignment must be equal or faster
	than the rhs (5.8.6.6.2).  The rules for rate-semantics are spread throughout
	the descriptions of statements, expressions, and user-defined opcodes in
	Subclauses 5.8.6 and 5.8.7. */

#include <string.h>
#include <stdio.h>
#include <math.h>
#include "saol.h"
#include "saol_co_imp.h"
#include "saol.tab.h"
#include <malloc.h>

#define ratestr(r) (r == ASIG) ? "asig" : ((r == KSIG) ? "ksig" : ((r == IVAR) ? "ivar" : "xsig"))

#ifndef MAX
#define MAX(x,y) ((x > y) ? x : y)
#endif

void max_rate_check_exprlist(sa_decoder *sa, symtable *t, exprlist *el, long maxrate);
long block_rate(sa_decoder *sa, symtable *t, block *b, long guardrate, long oprate,
				long xsigminrate);
long statement_rate(sa_decoder *sa, symtable *t, statement *st, long maxrate,
					long xsigminrate, long guardrate);
long expr_rate(sa_decoder *,symtable *t, expr *p, long guardrate, long xsigminrate);
long opcode_rate(sa_decoder *sa, symtable *t, exprlist *el, opcode_decl *op, expr *p,
				 int line,
				 long guardrate, long xsigminrate);
void check_table_def(sa_decoder *sa, symtable *t,tabledef *td);

void rate_checking(sa_decoder *sa) {
	/* make sure all the rates in the orchestra are correct */
	
	vardecl_list *vdl;
	opcode_list *op;
	instr_list *il;
	send_list *sl;
	formalparam_list *fpl;
	char s[1000];
	
	/* first, assign tentative rates to each opcode */
	for (op = sa->all->op; op; op=op->next) {
		op->o->rate = 0;
		op->o->minxsigrate = 0;
		
		/* can't use 'xsig' unless opcode type is OPCODE */
		
		if (op->o->type != OPCODE) {
			/* check all the formal parameters */
			for (fpl=op->o->params;fpl && fpl->fp;fpl=fpl->next) {
				if (fpl->fp->type == XSIG) {
					sprintf(s,"Variable '%s' cannot be 'xsig' if opcode rate is fixed (5.8.7.7.2).",fpl->fp->n->name);
					parse_error(s);
				}
			}
			/* and the local variables */
			for (vdl=op->o->localvars;vdl && vdl->v; vdl=vdl->next) 
				if (vdl->v->type == XSIG) {
					sprintf(s,"Variable '%s' cannot be 'xsig' if opcode rate is fixed (5.8.7.7.2).",vdl->v->nl->n->name);
					parse_error(s);
				}
		}
		
		switch (op->o->type) {
		case AOPCODE:
			op->o->rate = ASIG;
			op->o->minxsigrate = ASIG;
			break;
		case KOPCODE:
			op->o->rate = KSIG;
			op->o->minxsigrate = KSIG;
			break;
		case IOPCODE:
			op->o->rate = IVAR;
			op->o->minxsigrate = IVAR;
			break;
		case SPECIALOP:
			op->o->rate = SPECIALOP;
			op->o->minxsigrate = SPECIALOP;
		case OPCODE:
			/* use the rate of the fastest formal parameter */

			fpl = op->o->params;
			if (!fpl || !fpl->fp) { /* no formal parameters */
				op->o->rate = XSIG;
				op->o->minxsigrate = IVAR;
			}

			for (fpl=op->o->params;fpl;fpl=fpl->next) {
				
				/* figure out minimum rate for all xsigs in this opcode 
				   (tables are like ivars) -- the real rate could be faster
		           depending on the context of the call, but it can't be 
				   any slower. */
				
				if (fpl->fp && fpl->fp->type != XSIG &&
					fpl->fp->type > op->o->minxsigrate) {
					if (fpl->fp->type == TABLE) {
						if (IVAR > op->o->minxsigrate)
							op->o->minxsigrate = IVAR;
					}
					else op->o->minxsigrate = fpl->fp->type;
				}
				/* and rate for opcode overall -- include XSIG as a possibility
				   (use XSIG if any formalparamars are XSIG).  same deal here */
				if (fpl->fp && fpl->fp->type > op->o->rate)
					if (fpl->fp->type == TABLE && IVAR > op->o->rate)
						op->o->rate = IVAR;
					else op->o->rate = fpl->fp->type;  
			}
			break;
			
		default:
			printf("Bad opcode type (%d) in rate_checking()!",op->o->type);
		}
	}
	
	/* check rates of any global table initializers */
	for (vdl = sa->all->g->gvars; vdl && vdl->v; vdl=vdl->next) {
		if (vdl->v->type == TABLE)
			check_table_def(sa,sa->all->g->sym,vdl->v->t);
	}
		
	/* check rates of parameters to sends -- they have to be IVAR (5.8.5.5)*/
	for (sl = sa->all->g->sends; sl; sl = sl->next)
		max_rate_check_exprlist(sa,sa->all->g->sym,sl->s->pfields,IVAR);
	
	/* check each instrument */
	for (il = sa->all->il; il; il=il->next) {
		
		/* table initializers in the instrument*/
		for (vdl = il->i->localvars; vdl; vdl=vdl->next) {
			if (vdl->v && vdl->v->t)
				check_table_def(sa,il->i->sym,vdl->v->t);
		}
		
		/* don't have to check vardecls, since any vardecl is rate-legal
		   in an instrument */

		/* code of the instrument */
		block_rate(sa,il->i->sym, il->i->code, 0, ASIG, ASIG);
		
	}
	
	/* NB that when we compare the rate symbols directly, we have
	     IVAR < KSIG < ASIG < SPECIALOP < TABLE < XSIG, so we often have to include
		 a special case for TABLE and XSIG */

	/* check each opcode */
	for (op = sa->all->op; op; op=op->next) {
		
		/* check parameters */
		for (fpl = op->o->params; fpl && fpl->fp; fpl=fpl->next)  {
			/* if the parameter is faster than the opcode rate, and the opcode isn't
			   OPCODE, then ... */
			if (fpl->fp->type > op->o->rate && fpl->fp->type != TABLE &&
				op->o->rate != ASIG && op->o->type != OPCODE) {
				/* if the fp is an XSIG, it could be too fast (since the
				   opcode is neither AOPCODE nor OPCODE) */
				if (fpl->fp->type == XSIG)
					sprintf(s,"Formal parameter '%s' might be faster than opcode (5.8.7.4.1).",
					fpl->fp->n->name);
				/* if the fp isn't an XSIG, we know it's too fast */
				else
					sprintf(s,"Formal parameter '%s' is declared faster than opcode (5.8.7.4.1).",
					fpl->fp->n->name);
				parse_error_line(s,fpl->fp->lineno);
			}
		}
		
		/* local variables & table initializers */
		for (vdl = op->o->localvars; vdl && vdl->v; vdl=vdl->next) {
			if (vdl->v->t) /* it's a local table in the opcode */
				check_table_def(sa,op->o->sym,vdl->v->t);
			else {
				/* if the variable is not an xsig, table, or oparray */
				if (vdl->v->type != XSIG && vdl->v->type != TABLE && vdl->v->type != OPARRAY){
					/* if it's too fast */
					if (vdl->v->type > op->o->rate)
						parse_error_line("Variable declared faster than opcode (5.8.7.5.1).",
						vdl->v->nl->lineno);
					
					/* if it might be too fast */
					if (op->o->rate == XSIG && vdl->v->type > op->o->minxsigrate)
						parse_error_line("Variable might be faster than opcode (5.8.7.5.1).",
						vdl->v->nl->lineno);
				}
			}
			
		}
		
		/* check the code of the opcode */
		block_rate(sa,op->o->sym, op->o->code, 0, op->o->rate, op->o->minxsigrate);
	}
}

long block_rate(sa_decoder *sa, symtable *t, block *b, long guardrate, long oprate,
				long xsigminrate) {
				/* check the rate of each statement in a block of code
				T is the symbol table of the instrument or UDO containing the block
				B is the block
				GUARDRATE is the rate of an expression guarding this block, if any
				OPRATE is the rate of the opcode (ASIG for an instrument)
				XSIGMINRATE is a minimum rate of the xsigs in the opcode (ASIG for an instrument,
	although this doesn't occur) */
	long r,fastest =0;
	
	/* go through each statement */
	for (;b;b=b->next) {
		if (b->st) {
			/* get the rate of the statement */
			r = statement_rate(sa, t,b->st,oprate,xsigminrate,guardrate);
			
			b->st->rate = r; /* mark it down */
			
			if (b->st->rate > oprate) { /* statement too fast for opcode */
				
										/* if the statement rate is not XSIG, and not a SPECIALOP with
				a fast opcode, then it's definitely too fast */
				if (b->st->rate != XSIG &&
					!(b->st->rate == SPECIALOP && oprate != IVAR))
					parse_error_line("Statement too fast for opcode (5.8.7.6.1).",b->st->lineno);
				
					/* if the statement rate is an XSIG and the opcode rate is slow, might
				be too fast depending on calling context */
				else if (b->st->rate == XSIG && oprate != ASIG)
					parse_error_line("Statement might be too fast for opcode (5.8.7.6.1).",
					b->st->lineno);
				
			}
			
			if (b->st->rate < guardrate) { /* statement too slow for guard (5.8.6.6.4-6) */
				/* if the guardrate is known, the statement is definitely too fast */
				if (guardrate != XSIG)
					parse_error_line("Statement too slow for enclosing guard (5.8.6.6.4-6).",
					b->st->lineno);
					/* if the guardrate is not known, if the statement is
					not at least as fast as the xsig minimum, it still might
				be too slow depending on calling context */
				else if (b->st->rate < xsigminrate)
					parse_error_line("Statement might be too slow for enclosing guard (5.8.6.6.4-6).",
					b->st->lineno);
			}
			
			/* if the statement is at the xsig rate, and the xsig rate is not known to 
			be at least as fast as the guard rate, then the statement might be too
			slow. */
			if (b->st->rate == XSIG && guardrate != XSIG && xsigminrate < guardrate)
				parse_error_line("Statement might be too slow for enclosing guard (5.8.6.6.4-6).",
				b->st->lineno);
			
			/* keep track of the fastest statement in the block */
			if (b->st->rate > fastest) fastest = b->st->rate;
		}
	}
	return(fastest);

}

long statement_rate(sa_decoder *sa, symtable *t, statement *st, long maxrate,
					long xsigminrate, long guardrate) {
	/* calculate the rate of a statement 
	   MAXRATE is the rate of the fastest thing enclosing this statement --
	    either the rate of the opcode or the guarding block */
	long rate1, rate2, rate3;
	exprlist *el;
		
	if (!st) return 0;
	
	switch (st->type) {
	case EQ:
		if (st->lvalue) {
			/* figure out the rate of the lvalue */
			rate1 = expr_rate(sa,t,st->lvalue,xsigminrate,guardrate);
			/* and of the rhs */
			rate2 = expr_rate(sa,t,st->expr,xsigminrate,guardrate);
			
			/* check assignment rates */
			if (rate1 < rate2 && rate2 != XSIG && rate2 != SPECIALOP) 
				parse_error_line("Assigned expression is faster than lvalue (5.8.6.6.2).",
				st->lineno);
			if (rate2 == XSIG && rate1 < ASIG)
				parse_error_line("Assigned expression might be faster than lvalue (5.8.6.6.2).",
				st->lineno);
			/* if the lvalue is an xsig, and the xsig rate is not known to be as fast
			   as the rhs */
			if (xsigminrate && rate1 == XSIG && rate2 != XSIG && xsigminrate < rate2)
				parse_error_line("Assigned expression might be faster than lvalue (5.8.6.6.2).",
				st->lineno);
			
			/* assignment is okay; overall rate is lvalue rate */
			if (rate2 == SPECIALOP)
				return SPECIALOP;
			else return(rate1);
		}
		else {
			/* no lvalue -- null assignment (5.8.6.6.3) */
			rate1 = expr_rate(sa,t,st->expr,xsigminrate,guardrate);
			return(rate1);
		}

	case IF: 
		/* get rate of guard expression */
		rate1 = expr_rate(sa,t,st->expr,xsigminrate,guardrate);
		
		/* get the rate of the block -- the guardrate passed down 
		   is KSIG if the guard rate is SPECIALOP, otherwise the
		   actual guardrate */
		rate2 = block_rate(sa,t, st->b, rate1 == SPECIALOP ? KSIG : rate1, maxrate, xsigminrate);
		if (rate2 > rate1)
			/* have to run again */
			block_rate(sa,t,st->b,rate2,maxrate,xsigminrate);
		
		if (rate2 == SPECIALOP && rate1 != SPECIALOP)
			parse_error_line("Can only use 'specialop' opcodes with a 'specialop' rate 'if' guard (5.9.2).",
			st->lineno);

		/* if the guardrate is SPECIALOP, then the whole statement is SPECIALOP, otherwise
		   it's the rate of the fastest statement in the block */

		return(rate1 == SPECIALOP ? SPECIALOP : rate2);

	case WHILE:
		/* get rate of guard expression */

		rate1 = expr_rate(sa,t,st->expr,xsigminrate,guardrate);
		
		/* check again to make sure none of the opcodes in the guard are too slow */
		rate1 = expr_rate(sa,t,st->expr,xsigminrate,rate1);

		if (rate1 == SPECIALOP)
			parse_error_line("Cannot use 'specialop' opcodes in 'while' guard (5.9.2).",st->lineno);

		/* get the rate of the fastest statement in the block */
		rate2 = block_rate(sa,t, st->b, rate1, maxrate, xsigminrate);
		
		return(rate2);

	case ELSE:
		/* same as the if expression */
		rate1 = expr_rate(sa,t,st->expr,xsigminrate,guardrate);
		
		rate2 = block_rate(sa,t, st->b, rate1 == SPECIALOP ? KSIG : rate1, maxrate, xsigminrate);
		rate3 = block_rate(sa,t, st->elseb, rate1 == SPECIALOP ? KSIG : rate1, maxrate, xsigminrate);
		if (MAX(rate2,rate3) > rate1)  {
			/* have to run again */
			block_rate(sa,t, st->b, MAX(rate2,rate3), maxrate, xsigminrate);
			block_rate(sa,t, st->elseb, MAX(rate2,rate3), maxrate, xsigminrate);	
		}

		if (MAX(rate2,rate2) == SPECIALOP && rate1 != SPECIALOP)
			parse_error_line("Can only use 'specialop' opcodes with a 'specialop' rate 'if' guard (5.9.2).",
			st->lineno);  
		return(rate1 == SPECIALOP ? SPECIALOP : MAX(rate2,rate3));

	case SPATIALIZE:
		/* do each of the four expressions */
		expr_rate(sa,t,st->params->p,xsigminrate,guardrate);
		
		rate1 = expr_rate(sa,t,st->params->next->p,xsigminrate,guardrate);
		if (rate1 > KSIG && rate1 != SPECIALOP)
			parse_error_line("Spatialize azimuth must be ksig or slower (5.8.6.6.9).",st->lineno);

		rate1 = expr_rate(sa,t,st->params->next->next->p,xsigminrate,guardrate);
		if (rate1 > KSIG && rate1 != SPECIALOP)
			parse_error_line("Spatialize elevation cannot be a-rate (5.8.6.6.9).",st->lineno);

		rate1 = expr_rate(sa,t,st->params->next->next->next->p,xsigminrate,guardrate);
		if (rate1 > KSIG && rate1 != SPECIALOP)
			parse_error_line("Spatialize distance cannot be a-rate (5.8.6.6.9).",st->lineno);

		/* rate is always ASIG */
		return(ASIG);

	case OUTPUT:
	case OUTBUS: /* no rules here */
		for (el = st->params;el;el=el->next)
			expr_rate(sa,t,el->p,xsigminrate,guardrate);
        return(ASIG); /* always ASIG */

	case RETURN: /* doesn't matter, since we remove this later */
		expr_rate(sa,t,st->expr,xsigminrate,guardrate);
		return(maxrate); /* return the rate of the opcode */

	case TURNOFF:
		return(KSIG);

	case EXTEND:
		/* check expression */
		rate1 = expr_rate(sa,t,st->expr,xsigminrate,guardrate);
		if (rate1 > KSIG && rate1 != SPECIALOP)
			parse_error_line("Extend expression must be k-rate or slower.",
			st->lineno);
		return(KSIG);

	case INSTR:
		/* keep track of fastest rate */
		if (guardrate) rate1 = guardrate; else rate1 = IVAR;

		for (el = st->params;el;el=el->next) {
			/* get rate of parameter */
			rate2 = expr_rate(sa,t,el->p,xsigminrate,guardrate);
			if (rate2 > rate1) rate1 = rate2; /* keep track of fastest */
		}
		if (rate1 > KSIG)
			parse_error_line("Instr parameters must be k-rate or slower.",
			st->lineno);
		return(rate1); /* rate is fastest rate */

	default:
		interror("bad statement type in statement_rate");
	}
	return 0;
}

long expr_rate(sa_decoder *sa, symtable *t, expr *p,long xsigminrate, long guardrate) {
	/* figure out the rate of an expression */
	symbol *sym;
	char s[1000];
	long r1, r2;
	exprlist *el;
	
	if (!p) return 0;
	
	switch(p->op) {
	case IDENT: /* it's a name -- find it in the symbol table (5.8.6.7.3) */
		sym = get_sym_decl(t,p->d->iname);
		if (!sym || sym->type == TABLE) /* if !sym it's a dynamic wavetable */
			return(p->rate = IVAR);
		else return(p->rate = sym->type);
	case NUMBER: /* it's constant -- always i-rate (5.8.6.7.4) */
	case STRCONST:
		return(p->rate = IVAR);
	case ARRAYREF: /* it's an array reference */
		/* get the rate of the array index expression */
		r1 = expr_rate(sa,t,p->left,xsigminrate,guardrate);
		/* get the declaration of the array name */
		sym = get_sym_decl(t,p->d->iname);
		
		/* rate is the faster of the declaration and the index */
		if (sym->type == TABLEMAP)
			return(p->rate = r1);
		else return(p->rate = MAX(r1,sym->type));

	case SASBF:
		/* check each parameter */
		for (el=p->params;el && el->p;el=el->next) {
			r1 = expr_rate(sa,t,el->p,xsigminrate,guardrate);
			if (r1 != IVAR)
				parse_error_line("Parameters to 'sasbf' must be ivar (5.8.6.7.15).",p->lineno);
		}
		/* rate is always a-rate */
		return(p->rate = ASIG);

	case OPCALL:
		/* opcode call -- find the opcode declaration */
		sym = get_opcode_decl(sa->all->g->sym,p->d->iname);
		p->defn = sym; /* link into the expression */

		/* get the rate of the opcode */
		p->rate = opcode_rate(sa,t,p->params,(opcode_decl *)sym->defn,p,p->lineno,
			xsigminrate,guardrate);
		
		/* the opcode must be at least the rate of the guard */
		if (p->rate < guardrate) {
			if (guardrate != XSIG) {
				sprintf(s,"Opcode '%s' too slow for enclosing guard (5.8.6.6.4-5).",p->d->iname);
				parse_error_line(s,
					p->lineno);
			}
			else if (p->rate < xsigminrate)
				parse_error_line("Opcode might be too slow for enclosing guard (5.8.6.6.4-6).",
				p->lineno);
		}
		if (p->rate == XSIG && guardrate != XSIG && xsigminrate < guardrate)
			parse_error_line("Opcode might be too slow for enclosing guard (5.8.6.6.4-6).",
			p->lineno);
		
		return(p->rate);

	case OPARRAY:
		/* same as OPCODE, but with an index */
		sym = get_opcode_decl(sa->all->g->sym,p->d->iname);
		p->defn = sym;

		/* get the rate of the index */
		r1 = expr_rate(sa,t,p->left,xsigminrate,guardrate);
		r2 = opcode_rate(sa,t,p->params,(opcode_decl *)sym->defn,p,p->lineno,
			xsigminrate,guardrate);
		
		/* index too fast? */
		if (r1 > r2) {
			parse_error_line("Oparray index faster than opcode rate (5.8.6.7.7).",p->lineno);
		}
		if (r1 == XSIG && r2 < ASIG) {
			parse_error_line("Oparray index might be faster than opcode rate (5.8.6.7.7).",p->lineno);
		}
		
		/* check opcode against guard */
		if (r2 < guardrate) {
			if (guardrate != XSIG)
				parse_error_line("Oparray too slow for enclosing guard (5.8.6.6.4-6).",
				p->lineno);
			else if (r2 < xsigminrate)
				parse_error_line("Oparray might be too slow for enclosing guard (5.8.6.6.4-6).",
				p->lineno);
		}
		if (r2 == XSIG && guardrate != XSIG && xsigminrate < guardrate)
			parse_error_line("Oparray might be too slow for enclosing guard (5.8.6.6.4-6).",
			p->lineno);
		
		/* rate is the rate of the opcode */
		p->rate = r2;
		return(p->rate);
		
	case NOT:
	case UMINUS:
	case LP:
		/* same as the rate of the subexpression */
		return(p->rate = expr_rate(sa,t,p->left,xsigminrate,guardrate));
	case Q:
		/* fastest of the subexpressions */
		r1 = expr_rate(sa,t,p->left,xsigminrate,guardrate);
		r2 = expr_rate(sa,t,p->right,xsigminrate,guardrate);
		r1 = MAX(r1,r2);
		r2 = expr_rate(sa,t,p->extra,xsigminrate,guardrate);
		return(p->rate = MAX(r1,r2));
	case LEQ:
	case GEQ:
	case EQEQ:
	case NEQ:
	case GT:
	case LT:
	case AND:
	case OR:
	case PLUS:
	case MINUS:
	case STAR:
	case SLASH:
		r1 = expr_rate(sa,t,p->left,xsigminrate,guardrate);
		r2 = expr_rate(sa,t,p->right,xsigminrate,guardrate);
		return(p->rate = MAX(r1,r2));
	default:
		interror("Bad type in expr_rate()!");
	}
	return 0;
}

long opcode_rate(sa_decoder *sa,symtable *t, exprlist *el, opcode_decl *op, expr *p,
				 int line, long xsigminrate, long guardrate) {
	/* figure out the rate of an opcode call 
	   EL is the list of actual parameters 
	   OP is the opcode declaration
	   P is the opcode-call or oparray expression
	*/
	formalparam_list *fpl;
	long rate,fastest = 0,ct=0;
	char s[1000];
	
	fastest = guardrate;
	/* go through formal and actual parameters */
	for (fpl = op->params; fpl && fpl->fp && el && el->p; fpl=fpl->next) {
	
		el->p->rate = rate = expr_rate(sa,t,el->p,xsigminrate,guardrate);
	
		/* tables must match up with formalparams */
		if (fpl->fp->type == TABLE &&
			((el->p->op != ARRAYREF && el->p->op != IDENT) ||
			!get_table_decl(t,el->p->d->iname))) {
			sprintf(s,"Argument #%d must be a wavetable.",ct+1);
			parse_error_line(s,line);
		}

		/* if formalparam isn't a table, actparam cannot be either */
		else if ((el->p->op == ARRAYREF || el->p->op == IDENT)
			&& get_table_decl(t,el->p->d->iname)) {
			if (abs(fpl->fp->type) != TABLE) {
				sprintf(s,"Argument #%d cannot be a wavetable.",ct+1);
				parse_error_line(s,line);
			}
		}

		/* rate of actual parameter can't be faster than formal parameter */
		else if (rate != XSIG && rate > labs(fpl->fp->type)) {
			sprintf(s,"Argument #%d faster than formal parameter.",ct+1);
			parse_error_line(s,line);
		}
		/* keep track of fastest actual parameter */
		if (rate > fastest) fastest = rate;
		el = el->next;
		ct++;
	}
	if (el && el->p) { /* more actual parameters; check against varargs */
		/* get varargs rate */
		long varate = opcode_is_varargs(op->name);
		while (el && el->p) { /* go through the rest of the parameters */
			el->p->rate = rate = expr_rate(sa,t,el->p,xsigminrate,guardrate);
			if (rate > varate) {
				sprintf(s,"Argument #%d faster than varargs rate.",ct+1);
				parse_error_line(s,line);
			}
			if (rate > fastest) fastest = rate;
			el = el->next; ct++;
		}
	}
	
	if (op->type == OPCODE)
		return(fastest);
	else switch(op->type) {
		/* might need special type for downsampling core opcodes? */
  case AOPCODE:
	  return ASIG;
  case KOPCODE:
	  return KSIG;
  case IOPCODE:
	  return IVAR;
  case SPECIALOP:
	  return SPECIALOP;
  default:
	  return 0;
	}
}

void max_rate_check_exprlist(sa_decoder *sa,symtable *t, exprlist *el, long maxrate) {
	/* make sure none of the parameters (to a table generator or send statement)
	   are too fast */
	   
	for (;el;el=el->next)
		if (expr_rate(sa,t,el->p,IVAR, IVAR) > maxrate)
			parse_error("Parameter rate is too fast; only i-rate allowed.");
}

extern int is_core_tablegen(char *); /* in saol_tables.c */

void check_table_def(sa_decoder *sa,symtable *t,tabledef *td) {
	/* check the rates of the expressions to a table generator */
	exprlist *e;
	char err[100];
	long r;

	/* check gen against list */
	if (!is_core_tablegen(td->gen)) {
		sprintf(err,"Unknown table generator '%s'.",td->gen);
		parse_error_line(err,td->lineno);
	}

	/* make sure each expression is an IVAR */
	for (e=td->params;e && e->p;e=e->next) {
		r = expr_rate(sa,t,e->p,IVAR,IVAR);
		if (r != IVAR) {
			parse_error_line("Only i-rate expressions may be used as parameters to table generators (5.8.6.5.2).",e->p->lineno);
		}
	}
}
