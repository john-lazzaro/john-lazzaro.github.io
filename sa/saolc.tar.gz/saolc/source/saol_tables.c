/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_tables.c: Table utilities and core table generators.  All of the implementations
of the core table generators are in this file.  These are the primary functions here. 
other functions are utilities that help the syntax-checker deal with table declarations. */

#include <string.h>
#include "saol_interp.h"
#include <math.h>
#include <stdlib.h>
#include "aifif.h"
#include "saol_prec.h"
#include "saol.h"

#ifdef _WIN32
#define DIRSEP '\\'
#else
#define DIRSEP '/'
#endif

sa_real i0(sa_real x);
#ifdef _MPEGPROFILER
	extern int tables_mem;
#endif
extern double drand48(void);

struct core_tg_struct {
	char *name;			/* the name of the generator */
	table_storage *(*func)(sa_decoder *,struct actparam_struct *, int); /* the code which implements it */
};

table_storage *ctg_sample(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_data(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_random(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_step(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_lineseg(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_expseg(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_cubicseg(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_spline(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_polynomial(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_window(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_harm(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_harm_phase(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_periodic(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_buzz(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_concat(sa_decoder *sa, actparam *pf, int);
table_storage *ctg_empty(sa_decoder *sa, actparam *pf, int);

/* this is the table of all the core table generators in SAOL. Each
line is just the name of the table and the function that implements
the generator */

struct core_tg_struct core_tablegens[NUM_CORE_TABLEGEN] = {
	{"sample",ctg_sample},
	{"data",ctg_data},
	{"random",ctg_random},
	{"step",ctg_step},
	{"lineseg",ctg_lineseg},
	{"expseg",ctg_expseg},
	{"cubicseg",ctg_cubicseg},
	{"spline",ctg_spline},
	{"polynomial",ctg_polynomial},
	{"window",ctg_window},
	{"harm",ctg_harm},
	{"harm_phase",ctg_harm_phase},
	{"periodic",ctg_periodic},
	{"buzz",ctg_buzz},
	{"concat",ctg_concat},
	{"empty",ctg_empty}
};

int get_table_size(table_storage *t) {
	/* return the size of a table */
	return(t->size);
}

int is_core_tablegen(char *s) {
	/* return 1 iff S is the name of some table generator */
	int i;
	
	for (i=0;i!=NUM_CORE_TABLEGEN;i++)
		if (!strcmp(core_tablegens[i].name,s)) return 1;
		
		return 0;
}

sa_real get_table_value(table_storage *t, int idx) {
	/* get the value of a table at an integer point */
	char s[234];
	if (idx >= t->size || idx < 0) {
		sprintf(s,"Table index out of bounds: '%s', index %d, max %d.",
			t->name,idx,t->size);
		runtime(NULL,s);
	}
	return(t->d[idx]);
}

void set_table_value(table_storage *t, int idx, sa_real val) {
	/* set the value of a table at a point */
	char s[234];
	
	if (idx >= t->size || idx < 0) {
		sprintf(s,"Table index out of bounds: '%s', index %d, max %d.",
			t->name,idx,t->size);
		runtime(NULL,s);
	}
	t->d[idx] = val;
}



table_storage *gen_table(sa_decoder *sa,char *gen, actparam *pf, int pf_ct) {
/* generate table data.
GEN is the name of the generator to use.
PF is the list of parameters
PF_CT is the number of parameters 
	*/
	int i;
	char s[854];
	
	for (i=0;i!=NUM_CORE_TABLEGEN;i++)
		if (!strcmp(gen,core_tablegens[i].name)) /* if this is the right one */
			/* call (through function pointer) the generator function */
			return(core_tablegens[i].func(sa,pf,pf_ct));
		
		sprintf(s,"Unknown table generator '%s'",gen);
		runtime(NULL,s);
		return NULL;
}

void free_table(table_storage *t) {
	/* delete a table */
#ifdef _MPEGPROFILER
	tables_mem -= ((t->size)+4)*sizeof(float);
#endif
	free(t->d);
	free(t);
}

table_storage *new_table(int size) {
	/* make space for a new table */
	
	table_storage *t;
	
	PROT_MAL(t,table_storage,new_table);
	
	/* the dataspace */
	if (!(t->d=(sa_real *)calloc(sizeof(sa_real),size))) 
		runtime(NULL,"Couldn't allocate space in new_table().");
	
	t->size = size;
	t->srate = 0;
	t->loop = 0;
	t->loopend = 0;
	t->base = 0;

#ifdef _MPEGPROFILER
	tables_mem += ((t->size)+4)*sizeof(float);
#endif

	return(t);
}

sa_real bufval(char *,int,int,int,int);

table_storage *ctg_sample(sa_decoder *sa, actparam *pf, int pf_ct) {
/* the "sample" table generator:
table t(sample, <size>, <name>[ ,<skip>, <chan>]);

  <name> is a string constant pointing to a file
	*/
	int size;
	char fn[800],s[800];
	AIF_STRUCT *aifin = aifNew();
	table_storage *t;
	int skip=0, chan=0, nchan, nbits, ct, done = 0, retct, i, j;
	sa_real samp,scale;
	char *buf;
	long param[24];
	
	if (pf_ct < 2) {
		runtime(NULL,"Bad call to 'sample' tablegen.\n");
	}
	
	/* make the filename */
	sprintf(fn,"%s%c%s",sa->cmd->temp,DIRSEP,pf[1].ref);
	
	/* open the AIFF file */
	if (aifOpenRead(aifin,fn)) {
		sprintf(s,"Couldn't open '%s' for table read.",fn);
		runtime(NULL,s);
	}
	
	/* if there's optional parameters, figure them out */
	if (pf_ct > 2) {
		skip = ((int)(pf[2].val + 0.5)); /* round XXX */
		if (pf_ct > 3)
			chan = ((int)(pf[3].val + 0.5));
	}
	
	if (pf[0].val == -1) { /* size is -1 */
		param[0] = AIF_P_NFRAMES;
		aifGetParams(aifin,param,2); /* get the size of the AIFF file */
		size = param[1] - skip; /* table size depends on length of sample */
	}
	else /* size as given */
		size = ((int)(pf[0].val +0.5));
	
	/* make a new table */
	t = new_table(size);
	t->size = size;
	
	/* read in the AIFF file -- first, get the parameters */
	param[0] = AIF_P_CHANNELS;
	param[2] = AIF_P_SAMPSIZE;
	param[4] = AIF_P_SAMPRATE;
	aifGetParams(aifin,param,6);
	nchan = param[1];
	nbits = param[3];
	
	/* mark the sampling rate of the file */
	t->srate = (int)*(float *)&param[5];
	
	scale = (sa_real)(2 << (nbits-2));
	
	buf = (char *)malloc(nchan * nbits/8 * 1024); /* 1K frame buffer */
	
	/* skip some samples, according to the 'skip' parameter */
	aifFrameSeek(aifin, skip);
	
	ct = 0;
	while (!done) {
		/* try to read 1024 sample frames */
		retct = aifReadFrames(aifin,buf,1024); /* returns the number actually read */
		
		if (retct < 1024 || ct+retct >= size) { /* look for EOF or if we've done enough */
			done = 1;
		}
		for (i=0;i!=retct && ct < size;i++,ct++) {
		/* if there's multiple channels of data, either average them or select
			one, according to CHAN */
			if (!chan) {		/* average all channels */
				samp = 0;
				for (j=0;j!=nchan;j++)
					samp += bufval(buf,i,j,nchan,nbits);
				samp = samp/nchan;
			}
			else
				samp = bufval(buf,i,chan,nchan,nbits);
			
			/* put the value in the table */
			set_table_value(t,ct,samp/scale);
		}
	}
	
	/* close and destroy the AIFF file */
	aifClose(aifin);
	aifFree(aifin);
	
	/* report results */
	if (sa->verbose)
		printf("Read %d samples from sample '%s'\n",ct,fn);
	return(t);
}

sa_real bufval(char *buf,int frame,int chan,int nchan,int nbits) {
	/* return a sample value from the byte buffer for 8/16/24/32-bit files */
	/* fractional bit widths not supported */
	if (nbits == 16)
		return((sa_real)*(short *)&buf[frame * nchan * 2 + chan * 2]);
	
	if (nbits == 32)
		return((sa_real)*(int *)&buf[frame * nchan * 2 + chan * 2]);
	
	if (nbits == 8)
		return((sa_real)*(char *)&buf[frame * nchan *2 + chan * 2]);
	
	return 0;
}

table_storage *ctg_data(sa_decoder *sa, actparam *pf, int pf_ct) {
/* the DATA generator: just put a bunch of values in a table 

  table t(data,size,p1,p2,p3...)
	*/
	
	table_storage *t;
	int i = 0;
	
	if (!pf[0].val) 
		runtime(NULL,"Invalid size for generator 'data'.");
	
	if (pf[0].val == -1) /* if size not given */
		pf[0].val = (sa_real)pf_ct-1; /* just the number of parameters */
	
	/* make the table */
	t = new_table((int)(pf[0].val + 0.5));
	
	/* copy the data values */
	for(i=1;i<=pf[0].val;i++)
		set_table_value(t,i-1,pf[i].val);
	
	return(t);
}

table_storage *ctg_random(sa_decoder *sa, actparam *pf, int pf_ct) {
/* RANDOM table gen : put noise in a table

  table t(random,size,type[,p1,p2])
  
	several different types, depending on TYPE.
	*/
	
	table_storage *t;
	int i = 0;
	int which = 0,ct;
	sa_real x, y, p1, p2;
	
	/* need to have a size */
	if (pf[0].val <= 0)
		runtime(NULL,"Invalid size for generator 'random'.");
	
	/* make the table */
	t = new_table((int)(pf[0].val + 0.5));
	/* figure out which type */
	which = (int)(pf[1].val + 0.5);
	
	switch (which) {
	case 1:			/* uniform in range [p1,p2] */
		if (pf_ct < 4)
			runtime(NULL,"Need min and max for uniform random tablegen.");
		p1 = pf[2].val;
		p2 = pf[3].val;
		
		/* calculate random values */
		for (i=0;i!=t->size;i++) {
			x = (sa_real)drand48();
			
			set_table_value(t,i,x * (p2-p1)+p1);
		}
		
		break;
		
	case 2:			/* linear -- pdf goes from 0 at p1 to max at p2 linearly */
		if (pf_ct < 4)
			runtime(NULL,"Need min and max for linear random tablegen.");
		p1 = pf[2].val;
		p2 = pf[3].val;
		
		/* calculate random values */
		for (i=0;i!=t->size;i++) {
			x = (sa_real)drand48();
			y = (sa_real)drand48();
			
			/* pdf of a maximum has the right shape */
			set_table_value(t,i,MAX(x,y) * (p2-p1) + p1);
		}
		break;
		
	case 3:			/* exp: p1 is mean */
		if (pf_ct < 3)
			runtime(NULL,"Need mean for exponential random tablegen.");
		p1 = pf[2].val;
		
		/* calculate random values */
		for (i=0;i!=t->size;i++) {
			x = (sa_real)drand48();
			
			/* is this right? XXX */
			set_table_value(t,i,-(sa_real)log(x)*p1);
		}
		break;
		
	case 4:  /* Gaussian noise: p1 is mean, p2 is var */
		if (pf_ct < 4)
			runtime(NULL,"Need mean and var for Gaussian random tablegen.");
		p1 = pf[2].val;
		p2 = pf[3].val;
		
		/* calculate values */
		for (i=0;i!=t->size;i++) {
			x = (sa_real)drand48();
			y = (sa_real)drand48();
			
			/* see Num. Rec. p. XXX */
			set_table_value(t,i,(sa_real)(sqrt(-2 * log(x)) * cos(2 * PI * y) * sqrt(p1) + p2));
		}
		
		break;
		
	case 5: /* Poisson 0/1 noise */
		if (pf_ct < 3)
			runtime(NULL,"Need mean for Poisson random tablegen.");
		p1 = pf[2].val;
		
		/* note loop is different here */
		for (i=0;i<t->size;) {
			/* make run length */
			x = (sa_real)floor(-log((sa_real)drand48()) * p1);
			/* now put X zeros in the table */
			for (ct=0;i<t->size && ct < x;ct++,i++)
				set_table_value(t,i,0);
			/* followed by a 1 */
			set_table_value(t,i++,1);
		}
		break;
		
	default:
		runtime(NULL,"Unknown random tablegen.");
	}
	
	return t;
}

table_storage *ctg_step(sa_decoder *sa, actparam *pf, int pf_ct) {
/* STEP generator : put a step function in the table.

  table t(step,size,a1,x2,a2,x3,a3...);
  
	put a1 from 0 to x2-1; a2 from x2 to x3-2; etc. 
    */
	table_storage *t;
	int ct = 0,i;
	int lastxval,xval;
	sa_real yval;
	
	if (!pf[0].val)
		runtime(NULL,"Invalid size for generator 'step'.");
	
	/* if size isn't given */
	if (pf[0].val == -1)
		/* it's the maximum x-value */
		pf[0].val = pf[pf_ct-1].val+1;
	
	/* make the table */
	t = new_table((int)(pf[0].val + 0.5));
	
	lastxval = 0; /* first x-val is 0 */
	
	if (pf_ct < 3)
		runtime(NULL,"Not enough y-values for generator 'step'.");
	
	for (i=2;i!=pf_ct;i++) { /* start with first y-value */
		yval = pf[i].val;
		
		if (++i == pf_ct) 
			runtime(NULL,"Not enough x-values for generator 'step'.");
		
		xval = (int)(pf[i].val + 0.5); /* get end of range */
		if (xval > get_table_size(t))
			runtime(NULL,"Index out-of-bounds for generator 'step'.");
		if (xval < lastxval)
			runtime(NULL,"'step' x-values must be non-decreasing.");
		
		/* set all the values in the range */
		for (ct=lastxval;ct!=xval;ct++)
			set_table_value(t,ct,yval);
		
		/* end of this range is the beginning of the next */
		lastxval = xval;
	}
	
	return(t);
}

table_storage *ctg_lineseg(sa_decoder *sa, actparam *pf, int pf_ct) {
    /* LINESEG generator : put breakpoint function in table
	 
	     table t(lineseg,size,y1,x2,y2,x3,y4,...);

       put a line from 0 to y1 in [0..x2], from y1 to y2 in [x2..x3],
	   and so on */

	table_storage *t;
	int i,ct = 0;
	int lastxval,xval;
	sa_real yval,lastyval;
	
	if (!pf[0].val)
		runtime(NULL,"Invalid size for generator 'lineseg'.");
	
	/* if the size isn't given */
	if (pf[0].val == -1)
		pf[0].val = pf[pf_ct-1].val+1; /* it's the biggest xvalue */
	
	/* make the table space */
	t = new_table((int)(pf[0].val + 0.5));
	
	if (pf_ct < 4)
		runtime(NULL,"Need at least two x-y pairs for generator 'lineseg'");
	
	/* the starting xvalue and yvalue */
	lastxval = 0;
	lastyval = pf[2].val;
	
	for (i=3;i!=pf_ct;i++) { /* start with second x-value */
		xval = (int)(pf[i].val + 0.5);
		if (++i == pf_ct)
			runtime(NULL,"Not enough y-values for generator 'lineseg'");
		yval = pf[i].val;
		if (xval > get_table_size(t))
			runtime(NULL,"Index out-of-bounds for generator 'lineseg'.");
		if (xval < lastxval)
			runtime(NULL,"'lineseg' x-values must be non-decreasing.");

		/* for everything in [last..xval] */
		for (ct=lastxval;ct!=xval;ct++)
			/* make the line segment */
			set_table_value(t,ct,((yval-lastyval)/(xval-lastxval) * (ct-lastxval) +
			lastyval));

		/* end of this range is beginning of the next */
		lastxval = xval;
		lastyval = yval;
	}
	
	return(t);
	
}

table_storage *ctg_expseg(sa_decoder *sa, actparam *pf, int pf_ct) {
	/* EXPSEG : just like LINESEG, except curvy exponential segments instead
	    of lines 
	
	   table t(expseg,size,y1,x2,y2,x3,y3,...)
	*/
	table_storage *t;
	int i,ct = 0;
	int lastxval,xval;
	sa_real yval,lastyval;
	
	if (!pf[0].val)
		runtime(NULL,"Invalid size for generator 'expseg'.");
	
	if (pf[0].val == -1)
		pf[0].val = pf[pf_ct-1].val+1;
	
	t = new_table((int)(pf[0].val + 0.5));
	
	if (pf_ct < 4)
		runtime(NULL,"Need at least two x-y pairs for generator 'expseg'");
	
	lastxval = 0;
	lastyval = pf[2].val;
	
	for (i=3;i!=pf_ct;i++) { /* start with second x-value */
		xval = (int)(pf[i].val + 0.5);
		if (++i == pf_ct)
			runtime(NULL,"Not enough y-values for generator 'expseg'");
		yval = pf[i].val;
		if (xval > get_table_size(t))
			runtime(NULL,"Index out-of-bounds for generator 'expseg'.");
		if (xval < lastxval)
			runtime(NULL,"'expseg' x-values must be non-decreasing.");
		if (yval * lastyval <= 0)
			runtime(NULL,"'expseg' y-values must all be the same sign.");
		/* make exponential segment */
		for (ct=lastxval;ct!=xval;ct++)
			set_table_value(t,ct,lastyval * (sa_real)pow((yval / lastyval),((sa_real)(ct-lastxval))/(xval-lastxval)));
		lastxval = xval;
		lastyval = yval;
	}
	
	return(t);
}

table_storage *ctg_cubicseg(sa_decoder *sa, actparam *pf, int pf_ct) {
	table_storage *t;
	sa_real i1,i2,x1,y1,y2,y3,lastx,a,b,c,d;
	int size,i,x;

	if (pf[0].val < 1) {
		size = (int)floor(pf[pf_ct-2].val + 0.5);
	}
	else {
		size = (int)floor(pf[0].val);
	}

	t = new_table(size);

	if (pf[1].val != 0)
		runtime(sa,"infl1 must be 0 for generator 'cubicseg' (5.10.8).");
	if (pf_ct < 9)
		runtime(sa,"At least two x-values needed for generator 'cubicseg' (5.10.8).");
	if (pf_ct % 4 != 3)
		runtime(sa,"Last value for generator 'cubicseg' must be a y-value (5.10.8).");

	lastx = -1;
	for (i=1;i+5<pf_ct;i+=4) {

		/* go through one section at a time */
		i1 = (sa_real)floor(pf[i].val + 0.5);
		i2 = (sa_real)floor(pf[i+4].val + 0.5);
		x1 = (sa_real)floor(pf[i+2].val + 0.5);
		y1 = pf[i+1].val;
		y2 = pf[i+3].val;
		y3 = pf[i+5].val;

		if (i1 <= lastx || x1 >= i2)
			runtime(sa,"infl-values must be strictly between x-values in generator 'cubicseg' (5.10.8).");
			
		if (x1 < lastx)
			runtime(sa,"x-values must be non-decreading in generatory 'cubicseg' (5.10.8).");

		/* maple is your friend -- whee! */
		b = (3*i1*x1*x1*y2-i1*i1*i1*y2+i1*i1*i1*y3+2*x1*x1*x1*y3+
			  y2*i2*i2*i2-y1*i2*i2*i2-2*y1*x1*x1*x1-
			  3*i1*x1*x1*y3-3*y2*i2*x1*x1+3*y1*i2*x1*x1)/((x1-i2)*(x1-i2))/
			  (i1-i2)/((i1-x1)*(i1-x1));
		a = -(-x1*x1*y1+x1*x1*y3+2*x1*i1*y2-2*x1*i1*y3-2*x1*y2*i2+2*x1*y1*i2+y3*i1*i1-
			  y2*i1*i1+i2*i2*y2-i2*i2*y1)/((x1-i2)*(x1-i2))/(i1-i2)/((i1-x1)*(i1-x1));
		d = (x1*x1*i1*i1*i1*y3+i2*i2*i1*i1*i1*y2-2*i2*x1*i1*i1*i1*y2+3*y2*i1*i1*i2*x1*x1-
			  2*y3*i1*i1*x1*x1*x1-y2*i1*i1*i2*i2*i2+2*y2*i1*x1*i2*i2*i2+x1*x1*x1*x1*i1*y3-
			  3*i2*i2*i1*x1*x1*y2-
			  i2*i2*i2*y1*x1*x1+2*i2*i2*y1*x1*x1*x1-i2*x1*x1*x1*x1*y1)/
			  ((x1-i2)*(x1-i2))/(i1-i2)/((i1-x1)*(i1-x1));
		c = -x1*(-2*i1*i1*i1*y2+2*i1*i1*i1*y3+3*x1*y2*i1*i1-3*x1*y3*i1*i1-2*y1*i2*i2*i2+
			  2*y2*i2*i2*i2-y1*x1*x1*x1+x1*x1*x1*y3-3*i2*i2*y2*x1+3*x1*y1*i2*i2)/
			  ((x1-i2)*(x1-i2))/(i1-i2)/((i1-x1)*(i1-x1));

		for (x = (int)(i1+0.5);x!=i2;x++)
			if (x < size) set_table_value(t,x,a*x*x*x + b*x*x + c*x + d);

		lastx = x1;
	}	

	return(t);
}

table_storage *ctg_spline(sa_decoder *sa, actparam *pf, int pf_ct) {
	
	table_storage *t;
	sa_real x1,y1,x2,y2,a,b,c,d,k;
	int size,i,x;

	if (pf[0].val < 0) {
		size = (int)floor(pf[pf_ct-2].val + 0.5);
	}
	else {
		size = (int)floor(pf[0].val);
	}

	t = new_table(size);

	if (pf[1].val != 0)
		runtime(sa,"x1 must be 0 for generator 'spline' (5.10.9).");
	if (pf_ct < 4)
		runtime(sa,"At least two x-values needed for generator 'spline' (5.10.9).");
	if (pf_ct % 2 == 0) 
		runtime(sa,"Last value for generator 'spline' must be a y-value (5.10.9).");

	k = 0; /* last derivative */

	for (i=1;i+3 < pf_ct;i+=2) {

		/* go through one section at a time */
		x1 = (sa_real)floor(pf[i].val + 0.5);
		x2 = (sa_real)floor(pf[i+2].val + 0.5);

		if (x2 < x1)
			runtime(sa,"x-values must be non-decreasing in generator 'spline' (5.10.9).");

		y1 = pf[i+1].val;
		y2 = pf[i+3].val;

		a = -(x1*k-x2*k+y2-y1)/((x1-x2)*(x1-x2)*(x1-x2));
		d = (2*x2*k*x1*x1*x1+x1*x1*x1*y2-3*x2*x2*k*x1*x1+x2*x2*x2*x1*k-3*y1*x2*x1*x1+
			3*y1*x1*x2*x2-x2*x2*x2*y1)/((x1-x2)*(x1-x2)*(x1-x2));
		c = -(2*k*x1*x1*x1+3*x1*x1*y2-3*x1*x1*y1-3*k*x1*x2*x2+x2*x2*x2*k)/
			((x1-x2)*(x1-x2)*(x1-x2));
		b = 3*(x1*k-x2*k+y2-y1)*x1/((x1-x2)*(x1-x2)*(x1-x2));
		
		for (x=(int)(x1+0.5);x<x2;x++)
			if ( x < size) 
				set_table_value(t,x,a*x*x*x + b*x*x + c*x + d);
		
		k = 3*a*x2*x2 + 2*b*x2 + c; /* derivative at right endpoint */
	}

	return t;
}


table_storage *ctg_polynomial(sa_decoder *sa, actparam *pf, int pf_ct) {
	table_storage *t;

	sa_real tot, exp, y;
	int x,size,i;

	size = (int)(pf[0].val + 0.5);
	if (size < 1)
		runtime(sa,"size must be given for generator 'polynomial' (5.10.10).");
	if (pf_ct < 4)
		runtime(sa,"At least three parameters needed for generator 'polynomial' (5.10.10).");
	if (pf[1].val == pf[2].val) 
		runtime(sa,"Cannot use xmin = xmax in generator 'polynomial' (5.10.10.");

	t = new_table(size);

	for (x=0; x < size; x++) {
		y = pf[1].val + (size - (sa_real)x) / size * (pf[2].val - pf[1].val);
		tot = 0; exp = 1;
		for (i=0;i!=pf_ct - 3;i++) {
			tot += exp * pf[i+3].val;
			exp *= y;
		}
		set_table_value(t,x,tot);
	}

	return t;
}

table_storage *ctg_window(sa_decoder *sa, actparam *pf, int pf_ct) {
	/* WINDOW: put a window function in a table 

       table t(window,size,type[,p1]);

      different types of windows, depending on TYPE */
	table_storage *t;
	int i;
	sa_real p1,alpha,std,var;
	
	if (pf[0].val <= 0) /* have to provide size */
		runtime(NULL,"Invalid size for generator 'window'.");

	/* make the table */
	t = new_table((int)(pf[0].val + 0.5));
	
	if (pf_ct < 2)
		runtime(NULL,"Must provide window type for generator 'window'.");
	
	switch ((int)(pf[1].val + 0.5)) {

	case 1:			/* hamming */
		for (i=0;i!=t->size;i++) 
			set_table_value(t,i,(sa_real)(.52 - .46*cos(2*PI*i/(t->size-1))));
		break;
		
	case 2:			/* hanning */
		for (i=0;i!=t->size;i++)
			set_table_value(t,i,(sa_real)(.5*(1-cos(2*PI*(i+1)/(t->size+1)))));
		break;
		
	case 3:			/* bartlett (triangle) */
		if (t->size == (t->size/2)*2) { /* even length */
			for (i=0;i!=t->size/2;i++)
				set_table_value(t,i,(sa_real)(2.0*i/(t->size-1.0)));
			for (;i!=t->size;i++)
				set_table_value(t,i,(sa_real)(2.0*((sa_real)t->size-i)/(t->size-1.0)));
		}
		else {
			for (i=0;i!=(int)ceil(t->size/2.0);i++)
				set_table_value(t,i,(sa_real)(2*i/(t->size-1)));
			for (;i!=t->size;i++)
				set_table_value(t,i,(sa_real)(2.0*(t->size-i-1.0)/(t->size-1.0)));
		}
		break;
		
	case 4:			/* gaussian -- parametrization is weird in the standard */
		std = (sa_real)(t->size/6.0);
		var = std*std;
		for (i=0;i!=t->size;i++)
			set_table_value(t,i,(sa_real)exp(-(i-t->size/2.0)*(i-t->size/2.0) / 2.0 / var));
		break;
		
	case 5:			/* kaiser (see XXX) */
		if (pf_ct < 3)
			runtime(NULL,"Must provide parameter for Kaiser window.");
		p1 = pf[2].val;	/* == "beta" parameter */
		alpha = (sa_real)((t->size - 1)/2.0);
		for (i=0;i!=t->size;i++)
			set_table_value(t,i,(sa_real)(i0((sa_real)(p1 * sqrt(alpha*alpha - (i-alpha)*(i-alpha)))) / i0(p1 * alpha)));
		break;
		
		
	case 6:			/* rectangular */
		for (i=0;i!=t->size;i++)
			set_table_value(t,i,1);
		break;
	}
	
	
	return(t);
}

table_storage *ctg_harm(sa_decoder *sa, actparam *pf, int pf_ct) {
	/* HARM generator: zero-phase harmonic waveshape 
	
	   table t(harm,size,p0,p1,p2,p3...) 
	
	   The p-values are the weights of overtones in a zero-phase harmonic series. */

	table_storage *t;
	int harm,i;
	sa_real val;
	
	if (pf[0].val <= 0) /* have to provide size */
		runtime(NULL,"Invalid size for generator 'harm'.");
	
	/* make the table */
	t = new_table((int)(pf[0].val +0.5));
	
	for (i=0;i!=get_table_size(t);i++) {
		val = 0; /* just sum up a bunch of harmonic oscillators */
		for (harm=1;harm < pf_ct;harm++)
			/* we are putting one cycle into the table, regardless of the table size, so
			   we calculate the phase offset relative to the length of the table */
			val += (sa_real)sin((sa_real)i/get_table_size(t) * 2 * PI * harm) * pf[harm].val;

		/* set the value to the sum of the oscillators */
		set_table_value(t,i,val);
	}
	return t;
}

table_storage *ctg_harm_phase(sa_decoder *sa, actparam *pf, int pf_ct) {
	/* HARM_PHASE generator: just like HARM, except the oscillators are not zero-phase 

	   table t(harm_phase,size,wt0,ph0,wt1,ph1,...);
	*/

	table_storage *t;
	sa_real val,wt,ph;
	int harm,i,ct;
	
	if (!pf[0].val)
		runtime(NULL,"Invalid size for generator 'harm_phase'.");
	
	t = new_table((int)(pf[0].val +0.5));
	
	for (i=0;i!=get_table_size(t);i++) {
		val = 0;
		for (harm=1,ct=1;ct < pf_ct;harm++,ct++) {
			wt = pf[ct].val;
			if (++ct == pf_ct)
				runtime(NULL,"Not enough phase values for generator 'harm_phase'.");
			ph = pf[ct].val;
			/* note that phase offset is the position in the table plus the phase parameter */
			val += (sa_real)sin(((sa_real)i/get_table_size(t)+(ph/2/PI)) * 2 * PI * harm) * wt;
		}
		set_table_value(t,i,val);
	}
	return t;
}

table_storage *ctg_periodic(sa_decoder *sa, actparam *pf, int pf_ct) {
	table_storage *t;
	sa_real val,harm,wt,ph,dc;
	int i,ct;
	
	if (!pf[0].val)
		runtime(NULL,"Invalid size for generator 'periodic'.");
	
	t = new_table((int)(pf[0].val +0.5));
	
	for (i=0;i!=get_table_size(t);i++) {
		val = 0;
		for (ct=1;ct < pf_ct;ct++) {
			harm = pf[ct].val;
			if (++ct == pf_ct )
				runtime(NULL,"Not enough values (4 per partial) for generator 'periodic'.");
			wt = pf[ct].val;
			
			if (++ct == pf_ct)
				runtime(NULL,"Not enough values (4 per partial) for generator 'periodic'.");
			ph = pf[ct].val;
			
			if (++ct == pf_ct)
				runtime(NULL,"Not enough values (4 per partial) for generator 'periodic'.");
			dc = pf[ct].val;
			
			val += (sa_real)sin(((sa_real)i/get_table_size(t)+ph/2/PI) * 2 * PI * harm) * wt + dc;
		}
		set_table_value(t,i,val);
	}
	return t;
}

table_storage *ctg_buzz(sa_decoder *sa, actparam *pf, int pf_ct) {
	table_storage *t;
	int size,nharm,lowharm;
	sa_real rolloff,val,scale;
	int i,f;

	if (pf_ct < 4) 
		runtime(sa,"Not enough values for generator 'buzz'.");

	size = (int)floor(pf[0].val+0.5); nharm = (int)floor(pf[1].val + 0.5);
	lowharm = (int)floor(pf[2].val + 0.5); rolloff = pf[3].val;
	
	if (nharm < 1 && size < 1)
		runtime(sa,"In generator 'harm', either nharm or size must be given (5.10.15).");

	if (size < 1)
		size = 2 * (lowharm + nharm);
	if (nharm < 1)
		nharm = (int)floor(size / 2 - lowharm);

	t = new_table(size);

	if (fabs(rolloff - 1) < 1e-6) 
		scale = 1;
	else
		scale = (1-(sa_real)fabs(rolloff)) / (1-(sa_real)fabs(pow(rolloff,nharm)));

	for (i=0;i!=size;i++) {
		val = 0;
		for (f=lowharm;f<lowharm+nharm;f++)
			val = val + (sa_real)pow(rolloff,f-lowharm) * (sa_real)cos(2*PI*(f+1)*(sa_real)i/(sa_real)size);

		set_table_value(t,i,val*scale);
	}
	return t;
}

table_storage *ctg_concat(sa_decoder *sa, actparam *pf, int pf_ct) {
	/* CONCAT generator: the parameters are tables that get concatenated together.

       table t(concat,size,t1,t2,t3...);
	*/
	table_storage *t;
	int i,size=0,ix=0,j;
	
	if (pf[0].val <= 0) { /* size not given */
		for (i=1;i!=pf_ct;i++) /* count up the sizes of the component tables */
			size += get_table_size(pf[i].t);
	}
	else
		size = (int)(pf[0].val+0.5);
		
	/* make the table */
	t = new_table(size);
	ix = 0;

	/* fill up the table with the values of the parameter tables */
	for (i=1;i!=pf_ct && ix < size;i++) {
		for (j=0;j!=get_table_size(pf[i].t);j++)
			set_table_value(t,ix++,get_table_value(pf[i].t,j));
	}
	
	/* if there'; extra space in the table, clear it */
	for (;ix < size;ix++) 
		set_table_value(t,ix,0);

	return t;
}

table_storage *ctg_empty(sa_decoder *sa, actparam *pf, int pf_ct) {
	/* EMPTY generator: don't put anything in the table */
	table_storage *t;
	int k,i;
	
	/* have to give a size */
	if (pf[0].val <= 0)
		runtime(NULL,"Invalid size for generator 'empty'.");
	
	k = (int)(pf[0].val + 0.5);
	/* make the table */
	t = new_table(k);

	/* just set it all to zeros */
	for (i=0;i<k;i++)
		set_table_value(t,i,0);
	
	return t;
}

sa_real i0(sa_real x) { /* bessel function needed for the kaiser window */
	/* Opp/Schaefer p. 457 */
	
	sa_real ds = 1, d = 0, s = 1;
	
	while (fabs(ds)> 1e-12) {
		d += 2;
		ds *= x*x/d/d;
		s += ds;
	}
	return s;
}
