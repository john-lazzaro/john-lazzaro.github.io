/* ISO_HEADER_START */

/*********************************************************************

  This software module was originally developed by
  
	Eric D. Scheirer (MIT Media Laboratory)
	
  in the course of development of the MPEG-4 standard.
  This software module is an implementation of a part of one or more
  MPEG-4 tools as specified by the MPEG-4 standard.  ISO/IEC gives users
  of the MPEG-4 standard free license to this software module or
  modifications thereof for use in hardware or software products
  claiming conformance to MPEG-4.  Those intending to use this software
  module in hardware or software products are advised that its use may
  infringe existing patents.  The original developer of this software
  module and his/her company, the subsequent editors and their
  companies, and ISO/IEC have no liability for use of this software
  module or modifications thereof in an implementation.  Copyright is
  not released for non MPEG-4 conforming products. The MIT Media
  Laboratory retains full right to use the code for its own purpose,
  assign or donate the code to a third party and to inhibit third
  parties from using the code for non MPEG-4 conforming products.  This
  copyright notice must be included in all copies or derivative
  works. Copyright (c) 1998.
	 
***********************************************************************/

/* ISO_HEADER_END */

/* saol_sched.c : Implementation of the Structured Audio scheduler. 

  The main routine in this module is sched_run_kcycle(), which executes
  the orchestra for one k-cycle (ie, 1/KR seconds).  The tasks it
  performs correspond roughly to subclause 5.7.3.3; this is the main runtime
  routine of the implementation. 
  
  sched_run_kcycle() is called by main() in saol_main.cpp repeatedly until
  the decoding process is completed.

  Giorgio Zoia: added support for PCM 32-bit output (MPEG-4 compatibility)
*/

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "saol_prec.h"
#include "saol.h"
#include "bifs_nodes.h"
#include "ac.h"
#include "saol_interp.h"
#include "saol_sched.h"
#include "saol.tab.h"
#ifdef _MPEGPROFILER
	#include "profiler.h"
#else
	#define SCHEDP 0
	#define CO_PLUS 0
	extern void increment_counter(int par, int amount, int rate);
#endif
#include "aifif.h"
#include <malloc.h>

extern void receive_au(sa_decoder *sa);

#define SGN(x) (x < 0 ? -1 : x == 0 ? 0 : 1) 

extern void free_table(table_storage *t);
#ifdef _MPEGPROFILER
  extern int add_pointer(void *pnt, int bytes);
  extern int remove_pointer(void *pnt);
#endif

void do_input(sa_decoder *sa);

#ifdef _32BITOUT
int soundOutQueue(int *t);
#else
int soundOutQueue(short *t);
#endif
int soundOutClose(int t);
int soundOutOpen(int sr, int ch, int sz);

comp_buffer *sched_run_kcycle(sa_decoder *sa, decoder *d) {
	
/* this is the top-level function for the Structured Audio scheduler.
The scheduler, described in subclause 5.7.3.3, is responsible for keeping
track of all the synthesis that we're currently doing, receiving
and processing events, communicating with the systems layer, and 
	managing time in the decoder */
	
	int active_ev=0, /* are there any active instruments? */
		files_open = 0, /* are there input files open? */
		i,chan,val,cc,pedal;
	instr_decl *inst;
	handle_list *hl;
	sa_real *pf;
	instr_handle *h;
	event_list *pending,*old;
	sa_real oldtime;
	comp_buffer *cb;

	receive_au(sa); /* talk to the systems layer and deal with all the AUs that
	have come down the stream since the last kcycle (sa_decode.cpp) */
	
	/* see if there's any active instruments.  Don't count instances of 'startup'
	or of 'send' instruments, because we don't want to wait for them to finish */
	
	for (hl = sa->sched->active; hl && !active_ev; hl=hl->next) {
		if (hl->h->origin != ORIGIN_SEND && hl->h->origin != ORIGIN_STARTUP)
			active_ev = 1;
	}
	
	/* see if there's open input files that still have sound to process */
	
	for (i = 0;i!=sa->inct;i++) {
		if (!sa->in[i].done) files_open = 1;
	}
	
	/* we're done if there's no active instruments, pending events, active
	files, or AUs coming later.  In a live streaming implementation, we
	wouldn't know if there were AUs coming later, so we'd have to stay 
	running until the session closed. */
	
	if (!active_ev && !sa->sched->pending && !files_open && !sa->cached_au) {
		sa->sched->running = 0;
		sa->ended = 1;
		return NULL;
	}
	
	clear_busses(sa);

#ifdef _FX_SPEEDC	
	/* if we're applying speed control (5.9.14.4) to the input bus, clear out the speed  
	control buffer */
	
	for(i=0;i<sa->inchan;i++) {
		for(j=0;j<sa->ksmps*2;j++) sa->spc_buf[i][j] = 0.;
	}
#endif	

	do_input(sa); /* get global input data from AudioBIFS */
	
	/* deal with any pending events */
	
	pending = sa->sched->pending;  /* the list of pending events */
	
	while (pending && pending->ev->time <= sa->sched->time) {
		
	/* the list of pending events is sorted by time.  Go through all
		the events that are ready to dispatch.  We know the events are
		in order by time, and also by the order of event-type dispatch when
		two events have the same time -- they were inserted that way 
		by schedule_event().  
		
	   there is a VIOLATION here - the event times should be "quantized" to the
		control rate before deciding which event comes first.  That is,
		if there are pending a control event with timestamp 0.9998 and an instrument
		event with timestamp 1.0000, the k-cycle at time 1.0000 should
		execute the instrument event first per the instructions in 5.7.3.3.6.
		This only makes a difference in rare cases and can be worked around
		by adding small offsets to the timestamps of events.
	*/
		
		switch (pending->ev->type) {
			
		case INSTR_EVENT: /* start a new instrument instance */
			
			/* get its parameters */
			pf = event_actparam_list(pending->ev);
			
			/* start it up (saol_interp.c) */
			h = new_instr_instance(sa,pending->ev->name,pf,0,-1);
			
			if (h) { /* o/w, no such instrument */
				/* give it a label if it needs one*/
				if (pending->ev->label)
					h->label = strdup(pending->ev->label);
				
				/* no MIDI control since this is a score event (MIDI below) */
				h->channel = 0;
				h->midion = 0;
			}
			free_actparam_list(pf); /* clear temporary storage */
			break;
			
		case CONTROL_EVENT: /* deal with a control event */
			
			if (pending->ev->label) { /* labeled controller */
									  /* a labeled controller changes the value of a variable
				in each active instance that was tagged with the same label. */
				
				for (hl = sa->sched->active;hl;hl=hl->next) /* go through active instances */
					if (hl->h->label && !strcmp(hl->h->label,pending->ev->label))
					/* if the instance has a label and it matches the control,
					make the change */
					set_host_value(hl->h,pending->ev->name,0,pending->ev->val[0]);
					
			} else {	/* global variable change */
				/* an unlabeled controller changes the value of a global variable */
				set_var_value_byname(sa->global_cx,pending->ev->name,0,pending->ev->val[0]);
			}
			
			break;
			
		case TEMPO_EVENT:
		case MIDI_TEMPO_EVENT:  /* these events do the same thing */
			/* update scheduler variables */
			sa->sched->last_score_tempo = sa->sched->tempo; /* the previous tempo */
			sa->sched->tempo = pending->ev->val[0];         /* the new tempo */
			sa->sched->last_tempo_time = sa->sched->time;   /* the time of the tempo change */
			
			/* go through the pending list and change the scheduled times */
			scale_sched_events(sa, pending->next);
			break;
			
		case TURNOFF_EVENT:   /* a turnoff (note release) event */
			
			/* the turnoff event doesn't do anything right away -- it "notifies" 
			the instrument that it's about to be released with the "released"
			standard name (5.8.6.8.16).  If the instrument hasn't saved itself with
			'extend' by the end of the k-cycle, then we kill it */
			
			set_host_value(pending->ev->h,"released",0,1);
			pending->ev->h->turnoff_notified = 1;
			
			break;
			
		case TABLE_EVENT:    /* a new table event */
			
			/* add, destroy, or replace a global wavetable as needed. */
			
			if (!strcmp(pending->ev->name,"destroy")) /* destroy table */
				destroy_global_table(sa->global_cx,pending->ev->name);
			add_global_table(sa->global_cx,pending->ev);
			break;
			
		case END_EVENT:     /* end the session right now */
			
			sa->sched->running = 0;
			sa->ended = 1;
			break;
			
		case MIDI_ON_EVENT: {
			
		/* the MIDI noteon event instantiates whatever instrument is on the channel 
			of the event */
			
			int found = 0,chan;
			char s[80];
			
			chan = (int)floor(pending->ev->val[0]+0.5);  /* val[0] is the channel */
			
			inst = sa->channels[chan];  
			/* this is the instrument declaration that corresponds
			to the selected channel */
			
			if (inst) {  /* there might not be one.  But if there is... */

				pf = (sa_real *)calloc(3,sizeof(sa_real));
				pf[0] = -1; /* unknown duration */
				pf[1] = pending->ev->val[1]; /* val[1] is the pitch */
				pf[2] = pending->ev->val[2]; /* val[2] is the velocity */
															 
				/* make a new active instance */
				h = new_instr_instance(sa,inst->name,pf,(int)0,(int)pending->ev->val[0]);
				/* assign the MIDI parameters */
				h->channel = chan;
				h->cx->channel = chan;
				h->midion = (int)pf[1];  /* what pitch number is this note? (for aftertouch, noteoff) */

				for (i=0;i!=128;i++)     /* set all the controllers to their current values */
					set_host_value(h,"MIDIctrl",i,(sa_real)sa->midicc[h->channel][i]);
			} 
			
			else { /* there's no instrument on this MIDI channel.  
					   It's not a run-time error, but maybe worth a warning... */
				sprintf(s,"No instrument on channel %d.",(int)pending->ev->val[0]);
				warn_line(s,0);
			}
			}
			break;
			
		case MIDI_OFF_EVENT: 
			
			/* release all the MIDI notes on the given channel with the given pitch number */
			
			chan = (int)(pending->ev->val[0] + 0.5); /* val[0] is the channel */
			
			/* first check pedal -- if controller #64 is on, then sustain () */
			if (sa->midicc[chan][64] > 0) pedal = 1; else pedal = 0;
			
			/* now go through all the active instances */
			for (hl=sa->sched->active;hl;hl=hl->next) {
				
				/* if it's on the right channel and has the right pitch */
				if (hl->h->channel == chan && hl->h->midion == pending->ev->val[1])
					
					if (!pedal) { /* release now -- same as note turnoff above */
						set_host_value(hl->h,"released",0,1);
						hl->h->turnoff_notified = 1;
					}
					else {
						/* this flag means the note is waiting for pedal to go off */
						hl->h->pedal_delay = 1;
					}
			}
			
			break;
			
		case MIDI_CONTROL_EVENT:
			
			/* set a midi control value */
			
			chan = (int)(pending->ev->val[0] + 0.5);  /* val[0] is the channel */
			cc = (int)(pending->ev->val[1] + 0.5);    /* val[1] is the controller number */
			val = (int)(pending->ev->val[2] + 0.5);   /* val[2] is the new value */
			
			if (sa->verbose) { printf("MIDIcc: %d %d %d\n",chan,cc,val); }
			
			set_midi_control(sa,chan,cc,val); /* below */
			break;
			
		case MIDI_TOUCH_EVENT:
			
		/* set the MIDItouch standard name (5.8.6.8.10) for every instance on the channel 
			with the right pitch */
			
			for (hl=sa->sched->active;hl;hl=hl->next) {
				if (hl->h->channel == (int)(pending->ev->val[0] + 0.5) && hl->h->midion == pending->ev->val[1]) {
					set_host_value(hl->h,"MIDItouch",0,pending->ev->val[2]);
				}
			}
			break;
			
		case MIDI_CTOUCH_EVENT:
			
		/* set the MIDItouch standard name (5.8.6.8.10) for every instance on the channel
			regardless of pitch */
			
			for (hl=sa->sched->active;hl;hl=hl->next) {
				if (hl->h->channel == (int)(pending->ev->val[0] +0.5)) {
					set_host_value(hl->h,"MIDItouch",0,pending->ev->val[1]);
				}
			}
			break;
			
		case PROGRAM_CHANGE_EVENT: {
			int found = 0;
			char s[100];
			instr_list *il;
			terminal_list *tl;
			
			/* change the program (instrument) assigned to a particular MIDI channel */
			
			for (il=sa->all->il;il && il->i;il=il->next) { /* go through all the instruments */
				
				/* go through all of the preset values for this instrument */
				
				for (tl=il->i->preset;tl && tl->t; tl=tl->next) {
					
					/* compare (val[1] is the desired preset) */
					
					if ((int)(tl->t->cval + 0.5) == (int)(pending->ev->val[1]+0.5)) {
						found = 1;
						sa->channels[(int)(pending->ev->val[0] + 0.5)] = il->i;
					}
					
					/* Only one instrument can have a particular preset (5.8.6.4) */
				}
			}
			
			if (!found) {
				sprintf(s,"No program number %d (requested for channel %d)\n",
					(int)pending->ev->val[1],(int)pending->ev->val[0]);
				warn_line(s,0);
			}
			else {
				if (sa->verbose) {
					printf("Changed channel %d to program %d.\n",
						(int)(pending->ev->val[0]+0.5),(int)(pending->ev->val[1]+0.5));
				}
			}
								   }
			break;
			
		case MIDI_PITCH_EVENT:
			
		/* MIDI pitch bend -- set the MIDIbend standard name (5.8.6.8.11) for every instance
      			   on the channel regardless of pitch */
			
			for (hl=sa->sched->active;hl;hl=hl->next) {
				if (hl->h->channel == pending->ev->val[0]) {
					set_host_value(hl->h,"MIDIbend",0,pending->ev->val[1]);
				}
			}
			break;
			} /* switch */
			
		old = pending;
		pending=pending->next;  /* done with this event, go to next */
		remove_event(sa->sched,old);  /* remove the event we just processed from the scheduler */
			
	} /* while (there's still pending events to deal with now */
	
	  /* run through each instance in the list of active instances.  Execute
	  the k-cycle, then all the a-cycles, for each instance.
	  NB that the events in the active instrument list are in order by
	  their sequence numbers (see saol_sequence.c), so that we know we're
	  doing the synthesis in the proper order. */
	  
	  for (hl=sa->sched->active;hl;hl=hl->next) {
		  run_katime(hl->h->id,hl->h->cx,KSIG);  /* in saol_interp.c */
		  run_katime(hl->h->id,hl->h->cx,ASIG);
	  }
	  
	  /* at this point, all of the sound output from the instruments has been placed
	  on the output bus.  So make overall sound output, maybe dump it to a file or
	  to the DAC, and create a Composition Buffer to return to the compositor. */
	  
	  cb = output_sound(sa);
	  
	  /* delete any turned-off instances -- in the event-dispatch loop, we "marked" all the
	  instances that were ready to be turned off with the turnoff_notified flag.  If they
	  called 'extend' this k-cycle, the flag was cleared.  So any instances with the flag
	  still set are really done and need to be destroyed. */
	  
	  for (hl=sa->sched->active;hl;hl=hl->next) {
		  if (hl->h->turnoff_notified)
			  destroy_inst(sa,hl->h);
	  }
	  
	  
	  oldtime = sa->sched->time;
	  sa->sched->time += 1/(sa_real)sa->all->g->krate;  /* advance the time by one k-period */

#ifdef _MPEGPROFILER
	if(sa->prof) {
		 prof_print(0, sa->all->g->krate);
		 increment_counter(COUNTLEN, -1, TIMEP);
	}
#endif
	  
	  if ((int)sa->sched->time - (int)oldtime) {  /* decoding progress meter -- 1 sec */
		  printf("*");
#ifdef _MPEGPROFILER
    	  	if(sa->prof) {
      		prof_print(1, 1);
      		increment_counter(COUNTLEN, -1, GLOBALP);
    		}
#endif

	  }
	  else if ((int)(sa->sched->time*10) - (int)(oldtime*10)) {  /* 1/10 sec */
		  printf(".");
	  }
	  fflush(stdout);
	  
	  return(cb);  /* the CB is the output from this decoder in this frame. */
}


void start_scheduler(sa_decoder *sa) {
	/* This is all the initialization to do at scheduler startup (5.7.3.3.5).  Clear
	   out variables, open output files, open the DAC if we're live, run the
	   'startup' instrument, make global wavetables, start the bus 'send' 
	   instruments. */
	sa_real pf[5];
	instr_handle *h;
	int ct;
	symtable *t;
	
	PROT_MAL(sa->sched,scheduler,start_scheduler);
	sa->sched->active = NULL;
	sa->sched->pending = NULL;
	sa->sched->last_ev = NULL;
	sa->sched->time = 0;
	sa->sched->running = 1;
	sa->sched->last_tempo_time = 0;
	sa->sched->tempo = 60;
	sa->sched->last_score_tempo = 60;
	sa->totalsamps = 0;
	
	if (sa->audioout) { /* live audio output */
		sa->bufsize = sa->ksmps;
		if (!soundOutOpen(sa->all->g->srate,sa->all->g->outchan,sa->bufsize))
			exit(1);
	}
	
	if (sa->outfile) { /* output to file */

#ifdef _32BITOUT
		sa->bufsize = sa->ksmps * MIN(2,sa->all->g->outchan);
		sa->pcmout = fopen(sa->outfile, "wb");
		if(!sa->pcmout) {
			char s[100];

			sprintf(s,"Fatal error: couldn't open output file '%s'.",sa->outfile);
			runtime(sa,s);
		}
#else
		long pvb[16];
		int pvl = 0;
		
		sa->bufsize = sa->ksmps * MIN(2,sa->all->g->outchan);
		sa->aifout = aifNew(); 
		pvb[pvl++] = AIF_P_SAMPRATE;  pvb[pvl++] = sa->all->g->srate;
		pvb[pvl++] = AIF_P_CHANNELS;  pvb[pvl++] = sa->all->g->outchan;
		pvb[pvl++] = AIF_P_SAMPSIZE;  pvb[pvl++] = 16;
		pvb[pvl++] = AIF_P_FILETYPE;  pvb[pvl++] = AIF_FT_AIFF;
		aifSetParams(sa->aifout,pvb,pvl);
		
		/* make output file */
		if (aifOpenWrite(sa->aifout,sa->outfile,UNK_LEN)) { /* error on open */
			char s[100];

			sprintf(s,"Fatal error: couldn't open output file '%s'.",sa->outfile);
			runtime(sa,s);
		}
#endif
	}
	
	/* if there's a 'startup' instrument, start it up (5.7.3.3.5.3) */
	if (get_instr_decl(sa->all->g->sym,"startup")) {
		pf[0] = -1;
		h = new_instr_instance(sa,"startup",pf,0,0);
		h->origin = ORIGIN_STARTUP;
	}
	
	/* make all the global wavetables (5.7.3.3.5.3) */
	for (ct=0,t=sa->all->g->sym;t;ct+=t->s->width,t=t->next) {
		if (t->s->type == TABLE && t->s->binding != FUTURE_WAVETABLE)
			sa->global_cx->framevals[ct].table = make_table(sa->global_cx,t->s->table);
	}
	
	/* initialize file where access units may be dumped */
	sa->dump_au = NULL;
	
	/* start up all an instance of each 'send' instrument (5.7.3.3.5.4) */
	start_send_instrs(sa,sa->all->g->inchan);
	
}

comp_buffer *output_sound(sa_decoder *sa) {
    /* do the actual sound output */
	handle_list *hl;
	sa_real **sound = NULL;
	int i,j,nsamps;
	
#ifdef _FX_SPEEDC	
	/* how many samples are we going to output? */
	if (sa->fx_speedc) nsamps = sa->num_spc_samples; else nsamps = sa->ksmps;
#else
	nsamps = sa->ksmps;
#endif

	/* this is the first time -- we haven't made the buffers yet */
#ifdef _32BITOUT
	if (!sa->outbuf) sa->outbuf = (int *)calloc(sizeof(int),sa->bufsize * sa->all->g->outchan);
#else
	if (!sa->outbuf) sa->outbuf = (short *)calloc(sizeof(short),sa->bufsize * sa->all->g->outchan);
#endif
	if (!sa->sound) {
		sa->sound = (sa_real **)calloc(sa->all->g->outchan,sizeof(sa_real *));
		for (i=0;i!=sa->all->g->outchan;i++) {
			sa->sound[i] = (sa_real *)calloc(sa->ksmps,sizeof(sa_real));
		}
	}
	
	/* keep track of how much sound we've output */
	sa->totalsamps += nsamps;

#ifdef _FX_SPEEDC	
	/* things are a little different if this is a speed control orchestra --
	we read directly from the speed control buffer and output that (5.9.14.4) */
	
	if (sa->fx_speedc) {
		for (j=0;j!=sa->ksmps;j++) {
			for (i=0;i!=sa->all->g->outchan;i++)
				sa->sound[i][j] = sa->spc_buf[i][j];
		}
	} 
	
	else {
#endif
		/* add up all the sound output from the active instruments */
		hl = sa->sched->active;
		
		if (hl) {
			for (i=0;i!=sa->all->g->outchan;i++) {
				for (j=0;j!=nsamps;j++)
					sa->sound[i][j] = hl->h->output[i][j];
			}
			
			
			for (hl=hl->next;hl;hl=hl->next) {
				for (i=0;i!=sa->all->g->outchan;i++)  {
					for (j=0;j!=nsamps;j++)
						sa->sound[i][j] += hl->h->output[i][j];
					increment_counter(CO_PLUS, sa->ksmps, SCHEDP);  /* the profiler increments adds */
				}
			}
		}
		else { /* there's no active instruments */
			for (i=0;i!=sa->all->g->outchan;i++) {
				for (j=0;j!=nsamps;j++)
					sa->sound[i][j] = 0;
			}
		}
#ifdef _FX_SPEEDC
	}
#endif
	
	if (sa->textout) { /* we're dumping values to stdout for debugging */
		printf("--------------\n");
		for (i=0;i!=nsamps;i++) {
			printf("Time %.4f: ",sa->sched->time + (sa_real)1./(sa_real)sa->all->g->srate * i);
			for (j =0 ;j!=sa->all->g->outchan;j++) 
				printf("%.4f ",sa->sound[j][i]);
			printf("\n");
		}
	}
	
	/* we're making real-time sound */
	if (sa->audioout)  {
		for (i=0;i!=nsamps;i++) 
			for (j=0;j!=MIN(sa->all->g->outchan,2);j++) {
				sa->outbuf[sa->outbuf_ct++] = (short)(fabs(sa->sound[j][i]) < 1 ?
					(short)(sa->sound[j][i] * 32767) : 32767 * SGN(sa->sound[j][i]));
				if (sa->outbuf_ct == sa->bufsize) {
					soundOutQueue(sa->outbuf);
					sa->outbuf_ct = 0;
				}
			}
	}
	
	/* we're dumping sound to a file */
	if (sa->outfile) {
		for (i=0;i!=nsamps;i++) 
			for (j=0;j!=MIN(sa->all->g->outchan,2);j++) {
#ifdef _32BITOUT
				sa->outbuf[sa->outbuf_ct++] = ((fabs(sa->sound[j][i]) < 1.0) ?
					(int)(sa->sound[j][i] * 2147438647) : 2147438647 * SGN(sa->sound[j][i]));
				if (sa->outbuf_ct == sa->bufsize) {
					fwrite(sa->outbuf, sizeof(int), sa->bufsize, sa->pcmout);
					sa->outbuf_ct = 0;
				}
#else
				sa->outbuf[sa->outbuf_ct++] = ((fabs(sa->sound[j][i]) < 1.0) ?
					(short)(sa->sound[j][i] * 32767) : 32767 * SGN(sa->sound[j][i]));
				if (sa->outbuf_ct == sa->bufsize) {
					aifWriteFrames(sa->aifout,sa->outbuf,nsamps);
					aifMark(sa->aifout);
					sa->outbuf_ct = 0;
				}
#endif
			}
	}
	
#ifdef _AC
	if (sa->d && !sa->inct)
	/* if we're integrated with the compositor, and this is
	a decoder and not an AudioFX, make a CB with the output */
	   return(add_samples_cb(sa->sound,sa->d,sa->sched->time,nsamps));
	else
#endif
		return NULL;
	
}

void finish_output(sa_decoder *sa) {
	
/* this is what we do when the decoder finishes.  We close any active files, write any active output,
and unload and close SASBF banks.  Depending on whether or not DAC and file buffers are synchronized
	to the k-rate of the orchestra, we might need to flush buffers. */

	/* here should close the file where we dump access units */
	
	if (sa->audioout) {  /* flush the real-time output buffer */
		while (sa->outbuf_ct < sa->bufsize)
			sa->outbuf[sa->outbuf_ct++] = 0;
		soundOutQueue(sa->outbuf);
		soundOutClose(1); /* close the DAC */
	}

	if(sa->dump_au) {
		fflush(sa->dump_au);
		fclose(sa->dump_au);
	}

	if (sa->outfile) {   /* flush the file buffer */
#ifdef _32BITOUT
		fwrite(sa->outbuf, sizeof(int), sa->outbuf_ct, sa->pcmout);
		fclose(sa->pcmout);
#else
		aifWriteFrames(sa->aifout,sa->outbuf,sa->outbuf_ct);
		aifClose(sa->aifout); /* close the output file */
#endif
	}
	
#ifdef _FX_SPEEDC
	/* clean up speed control buffers */
	for(i=0;i<sa->inchan;i++) free(sa->spc_buf[i]);
	if (sa->spc_buf)
		free(sa->spc_buf);
#endif
	
	/* we're probably not as good about freeing other memory as we really should be here */
	
#ifdef _SASBF
	/* unload and close SASF banks */
	
	for (i = 0; i< MAXLOADEDBANKS; i++){
		if(sa->dlsbankflag[i]){
			UnloadCollection(&sa->dlsbanks[i]);
			CloseCollectionFile(&sa->dlsbanks[i]);
			printf("DLS Bank %d Unloaded and closed.\n", i);
		}
	}  
#endif
	
}

instr_handle *register_inst(sa_decoder *sa,instr_decl *id, context *cx, sa_real dur) {
	
/* register a new instrument instance with the scheduler 
(called by new_instr_inst() in saol_interp.c).  The caller has created a new
context and is in the midst of initializing it; this function makes sure the
scheduler is keeping track of it properly.  We put it in the right place
in the active list, schedule a turnoff event, and allocate it an output 
	   buffer */
	
	instr_handle *h;
	handle_list *new_hl,*hl,*last;
	event *ev;
	int i;
	
	PROT_MAL(h,instr_handle,register_instr); /* make a handle */

	h->origin = 0;  /* the caller fills many of these in */
	h->label = NULL;
	h->cx = cx;
	h->id = id;
	h->turnoff_notified = 0;
	h->input = NULL;		/* attach input here */
	h->hvl = NULL;
	h->channel = 0;
	
	/* allocate the output buffer -- enough data for one multichannel k-period of audio */
	
	if (!(h->output = (asig_frame **)calloc(sizeof(asig_frame *), cx->sa->all->g->outchan))) {
		runtime(sa,"Couldn't allocate space for output buffer in register_inst.");
	}
	
	for (i=0;i!=cx->sa->all->g->outchan;i++) {
		if (!(h->output[i] = (asig_frame *)calloc(sizeof(asig_frame),cx->sa->ksmps))) {
			runtime(sa,"Couldn't allocate space for output buffer in register_inst.");
		}
	}
	
	/* create a new handle list node to hold this handle in the active instance list */
	
	PROT_MAL(new_hl,handle_list,register_instr);
	new_hl->h = h;
	
	
	if (!cx->sa->sched->active) {
		/* this is the only active instrument in the orchestra */
		sa->sched->active = new_hl;
		new_hl->next = NULL;
	}
	else {
		/* We have to keep the active instance list in order by sequence number. */
		
		hl = cx->sa->sched->active; last = NULL;
		
		/* we chase down the active instance list until we find the right place for it.
		the sequence numbers in sa->seq[] were set in make_sequence() in saol_sequence.c
		at orchestra startup time.  */
		
		while (hl && sa->seq[hl->h->id->num] < sa->seq[id->num]) last=hl, hl=hl->next;
		
		if (!last) { /* the new instance is the first one in the list */
			new_hl->next = cx->sa->sched->active;
			cx->sa->sched->active = new_hl;
		} else {
			new_hl->next = hl;
			last->next = new_hl;
		}
	}
	
	/* make a turnoff event */
	if (dur >= 0) {  /* the duration might be negative, indicating that the duration is not
		known at startup time -- for example, for MIDI noteon events */
		
		/* the time of the turnoff event is YYY */
		ev = make_event(TURNOFF_EVENT,sa->sched->time+(dur-(sa_real)0.0001)-1/(sa_real)cx->sa->all->g->krate);
		ev->h = h;
		
		/* schedule the turnoff event with the scheduler */
		schedule_event(sa,ev);
	}
	
	/* return the new handle we created */
	return(h);
}


void resample(sa_decoder *sa,sa_real **old, sa_real ***last, sa_real **new, int oldct, int newct, int nchan, int q) {
	
/* resample a buffer as it comes in to a new sampling rate.  We assume that the frame sizes of the
   incoming and outgoing processes correspond to the same amount of time.  We delay the "old"
   (unresampled data) by a little bit (less than a frame) to allow for interpolation filter. We
   make no assumptions about the relationship of the input SR to output SR; the 'interp()' function
   in saol_co_imp.c is used to do the interpolation.

For normative decoding, this isn't used.  It's only used in the nonnormative extension to 
process input files on the command-line.  For AudioFX operation, the data are resampled before
we ever see them. Called by bufconvert(), below. */
	
/* OLD is the current frame of unresampled data.  LAST is the last frame of unresampled data.
   NEW is where the resampled data goes (caller must allocate).  OLDCT is the number of samples in
   a frame with the unresampled SR; NEWCT is the number of samples in a frame with the resampled
   SR (we have to turn OLDCT samples into NEWCT samples).  NCHAN is the number of channels
   (must be the same for input and output).  Q is the length of the interpolation filter, to
   be passed to interp(). 
   
   LAST is a triple pointer because we're doing call-by-reference, to give the current frame
   back to the caller as the last frame.
*/
	
	sa_real **buf2;  /* holds the frame-overlapping data for interpolation */
	int i,j;
	
	/* make buf2.  The beginning of the buffer is the last bit of data from the last frame (the exact
	amount depends on the interpolation quality Q.  The rest comes from the current frame:
	
	  | x x x x x x | x x x x x x x x x x x x x x x x x |
	  end of               current frame
	     last frame
		 (LAST)                  (OLD)
	*/
	
	buf2 = (sa_real **)calloc(nchan,sizeof(sa_real *));
	for (i=0;i!=nchan;i++) {
		buf2[i] = (sa_real *)malloc((oldct+q*2+1) * sizeof(sa_real));
		
		if (*last) {
			for (j=0;j!=q*2+1;j++) {
				buf2[i][j] = (*last)[i][oldct-q*2-1+j]; /* first samples are end of last buf */
			}
		} else {  /* this is the first frame; the beginning of the buffer is 0's */
			for (j=0;j!=q*2+1;j++) {
				buf2[i][j] = 0;
			}
		}
		
		for (j=0;j!=oldct;j++) {
			buf2[i][j+q*2+1] = old[i][j];  /* the rest of the samples come from the current frame */
		}
	}
	
	/* grab samples and interpolate.  The first sample of NEW is the value interpolated from
	the beginning of BUF2, depending again on the value of Q :
	
	  in    | x x x x x x | x x x x x x x x x x x x x x x x x |
	  
		out          | x x x x x x x x x x x x x x x x x x |
		
	*/
	
	for (i=0;i!=nchan;i++) {
		for (j=0;j!=newct;j++) {
			new[i][j] = interp(sa,buf2[i],oldct+q*2+1,  /* interp() in saol_co_imp.c */
				j * (sa_real)oldct/(sa_real)newct + q,
				q);
		}
	}
	
	if (*last) {  /* free the old data if this isn't the first frame*/
		for (i=0;i!=nchan;i++)
			free((*last)[i]);
		free(*last);
	}
	
	for (i=0;i!=nchan;i++) /* free the temporary buffer */
		free(buf2[i]);
	free(buf2);
	
	*last = old;   /* save the current frame so we can use it again next time */
}

sa_real bufval2(sa_decoder *sa, char *buf, int input, int frame, int chan) {
	
/* get the value of frame #frame, chan #chan, from the char * buffer that
corresponds to input #input of the current decoder.  The input 
might has come from a file with some word size,
	so deal with that. called by buf_convert()*/
	
	int nbits, nchan;
	
	nchan = sa->in[input].nchan;
	nbits= sa->in[input].nbits;
	
	if (nbits == 16)
		return((sa_real)*(short *)&buf[frame * nchan * 2 + chan * 2]);
	
	if (nbits == 32)
		return((sa_real)*(int *)&buf[frame * nchan * 2 + chan * 2]);
	
	if (nbits == 8)
		return((sa_real)*(char *)&buf[frame * nchan *2 + chan * 2]);
	
	runtime(sa,"Unsupported input word size in bufval2().");	
	return 0;
}

int buf_convert(char *buf, sa_real **newbuf, sa_real ***last, int ct, int framect,
				sa_decoder *sa, int input) {
				/* turn the CT values in buf into KSMPS values in newbuf
				by processing the input data and interpolating/decimating
				if FRAMECT > CT, this is only a partial frame
				
				  LAST has the values from the last (un-resampled) frame.
				  
	   called by do_input() */
	
	sa_real **temp;
	int i,j,cvtct;
	sa_real scale;
	
	/* first get values out of char * buffer: */
	
	/* how many samples at SR correspond to the number of unresampled samples 
	   at the input SR? */
	cvtct = (int)(sa->ksmps * ct/framect + 0.001);
	
	/* allocate a buffer to hold the input data */
	temp = (sa_real **)calloc(sa->in[input].nchan,sizeof(sa_real *));
	for (i=0;i!=sa->in[input].nchan;i++) {
		temp[i] = (sa_real *)malloc(ct * sizeof(sa_real));
		scale = (sa_real)(2 << (sa->in[input].nbits-2));
		/* get the data out of the input buffer and scale it */
		for (j=0;j!=ct;j++) {
			temp[i][j] = bufval2(sa,buf,input,j,i)/scale;
		}
	}
	
	/* resample the scaled input data to the right SR */
	resample(sa,temp,last,newbuf,ct,cvtct,sa->in[input].nchan,sa->interp_q);
	
	return(cvtct);
}

void do_input(sa_decoder *sa) {
	
/* deal with input data, either from AudioFX (normative behavior) or from audio files on
	   the command line (nonnormative behavior) */
	
	int i,j,k;
	int mx,numsamps,ct,mxbits,cvtct,size;
	char *buf = NULL;
	
	if (!sa->inct || !sa->inbus) return; /* no input data */
	
	mx = 0;
	if (!sa->inbuf) { /* first time we've been called; allocate enough for widest input */
		for (i=0;i!=sa->inct;i++) {
			if (sa->in[i].nchan > mx)
				mx = sa->in[i].nchan;
		}
		sa->inbuf = (sa_real **)calloc(mx,sizeof(sa_real *));
		for (i=0;i!=mx;i++)
			sa->inbuf[i] = (sa_real *)calloc(sa->ksmps,sizeof(sa_real));
	}
	
	
	if (sa->d) /* direct decoding; must be an AudioFX node */ {
		/* All we have to do is move the input data from the node buffer onto the input bus. */
		for (i=0;i!=sa->inct;i++) {
			for (j=0;j!=sa->ksmps;j++)
				sa->inbus->val[i][j] = ((struct AudioFX *)(sa->d->node))->fxinbuf[i][j];
		}
		return;
	}
	
	/* everything from here down is nonnormative */
	
	for (i=0;i!=sa->inct;i++) { 
		/* each input file has a 'delay time' that tells us when to start using it. */		
		if (sa->in[i].delay <= sa->sched->time && !sa->in[i].running &&
			!sa->in[i].done)
			sa->in[i].running = 1; /* mark as active */
	}
	
	mxbits = 0; /* what's the biggest buffer among all of the input files that are active? */
	for (i=0;i!=sa->inct;i++) {
		size = sa->in[i].nchan * sa->in[i].nbits * sa->in[i].srate;
		if (sa->in[i].running && size > mxbits)
			mxbits = size;
	}
	
	if (mxbits) /* otherwise, no input is active */
		/* make a buffer big enough to hold one frame of any input file */
		buf = (char *)malloc(mxbits/8 * sa->ksmps / sa->all->g->srate);
	
	for (i=0;i!=sa->inct;i++) { /* for each input */
		if (sa->in[i].running) {  /* if it's running */
			numsamps = (int)(sa->ksmps * sa->in[i].srate / sa->all->g->srate+0.5);
			ct = aifReadFrames(sa->in[i].aif_in,buf,numsamps); /* get data */
			
			if (ct < numsamps) {  /* if the file ended, mark the input as inactive */
				sa->in[i].done = 1;  
				sa->in[i].running = 0;
			}
			
			/* convert the input buffer, which is char * at some weird SR, to 
			floats at the orchestra SR. */
			cvtct = buf_convert(buf,sa->inbuf,&sa->in[i].last,ct,numsamps,sa,i);
			
		}
		else
			cvtct = 0;                 /* not started, or done */
		
		for (j=0;j!=cvtct;j++) {      /* copy any data we got into input bus */
			
			for (k=0;k!=sa->in[i].nchan;k++) {  /* for each channel of this input */
				
				if (sa->in[i].busch+k < sa->all->g->inchan) /* only copy up to INCHANNELS */
					sa->inbus->val[sa->in[i].busch+k][j] = sa->inbuf[k][j];
				/* put it in the right place */
			}
		}
		
		for (j=j;j!=sa->ksmps;j++)   /* fill the rest with zeros */
			for (k=0;k!=sa->in[i].nchan;k++)
				sa->inbus->val[sa->in[i].busch+k][j] = 0;
			
	}
	if (buf) free(buf);
}      

void zero_instr_output(instr_handle *h) {
	/* clear out the output buffer for an instrument */
	int i,j;
	sa_decoder *sa = h->cx->sa;
	
	for (i=0;i!=h->cx->sa->all->g->outchan;i++)
		for (j=0;j!=h->cx->sa->ksmps;j++)
			h->output[i][j] = 0;
}

void instr_output(context *cx, sa_real *pf, int pf_ct) { 
	/* this is called when an instrument calls 'output' */
	int i;
	bustable *bus;
	sa_decoder *sa = cx->sa;
	instr_route_list *irl;
	
	/* YYY */
	if (cx->instr->id->irl) { /* routed onto busses */

		for (irl = cx->instr->id->irl; irl; irl = irl->next) {
			bus = irl->bus;
			if (irl->allchan) {
				for (i=0;i!=bus->width;i++)
					bus->val[i][cx->asample_ptr] += pf[0];
			}
			else
				for (i=0;i!=pf_ct;i++)
					bus->val[irl->startchan + i][cx->asample_ptr] += pf[i];
		}
	}

	else {
		if (pf_ct == 1) {
			for (i=0;i!=cx->sa->all->g->outchan;i++)
				cx->instr->output[i][cx->asample_ptr] += pf[0];
		}
		else
			for (i=0;i!=cx->sa->all->g->outchan;i++)
				cx->instr->output[i][cx->asample_ptr] += pf[i];
	}
	PROF(0,1,0,0,sa->all->g->outchan,sa->all->g->outchan,2);
}

void bus_output(char *busname,context *cx, sa_real *pf, int pf_ct) {
	/* this is called when an instrument calls 'outbus' */
	int i;
	bustable *bus;
	sa_decoder *sa = cx->sa;
	
	bus = get_bus(cx->sa->all->g->bus,busname);
	
	if (pf_ct == 1) { /* only one parameter -- add this value to each channel of the bus */
		for (i=0;i!=bus->width;i++)
			bus->val[i][cx->asample_ptr] += pf[0];
	} 
	else {  /* N parameters -- add to corresponding channels of bus */
		for (i=0;i!=pf_ct;i++)
			bus->val[i][cx->asample_ptr] += pf[i];
	}	
}

void clear_busses(sa_decoder *sa) {
	/* set all channels of all busses to 0 */
	bustable *bus;
	int i,j;
	
	for (bus=sa->all->g->bus;bus;bus=bus->next)
		if (bus->val) /* some busses turn out to be zero-channels */
			for (i=0;i!=bus->width;i++)
				for (j=0;j!=sa->ksmps;j++)
					bus->val[i][j] = 0;
}

void set_midi_control(sa_decoder *sa, int chan, int cc, int val) {
	/* set the MIDIctrl standard name (5.8.6.8.9) for each instrument on the specified	
	channel.  If it's controller 64 and it's gone off, then release all of the
	   notes on the channel that were waiting for the pedal release */
	
	handle_list *hl;
	int pedal;
	
	if (cc == 64 && val == 0) pedal = 1; else pedal = 0;
	
	for (hl=sa->sched->active;hl;hl=hl->next) {
		if (hl->h->channel == chan) {
			set_host_value(hl->h,"MIDIctrl",cc,(sa_real)val);
			if (pedal && hl->h->pedal_delay) { 
				/* release now -- just like TURNOFF_EVENT in sched_run_kcycle() */
				set_host_value(hl->h,"released",0,1);
				hl->h->turnoff_notified = 1;
			}
		}
		
	}
	
	/* keep track of all the controller values */
	sa->midicc[chan][cc] = val;
}

void instr_turnoff(context *cx) {
	/* called when an instrument calls 'turnoff' */
	event_list *evl;
	event *ev;
	
	if (cx->instr->turnoff_notified) /* already turning off */
		return;
	
	/* find turnoff event for this note and remove it*/
	if (evl = find_event_handle(cx->instr,TURNOFF_EVENT)) {
		remove_event(cx->sa->sched, evl);
	}
	
	/* make a new turnoff event for the next kcycle and schedule it. */
	ev = make_event(TURNOFF_EVENT,cx->sa->sched->time + (sa_real)1./cx->sa->all->g->krate);
	ev->h = cx->instr;
	schedule_event(cx->sa,ev);
	/* cx->instr->turnoff_notified = 1; */
}

void instr_extend(context *cx, sa_real time) {
	/* called when an instrument calls 'extend' */
	event_list *evl;
	event *ev;
	sa_real newdur,oldext;
	symbol *sym;
	
	/* find turnoff event for this note */
	if (evl = find_event_handle(cx->instr,TURNOFF_EVENT)) {
		/* remove it and make a new one */
		oldext = evl->ev->ext;
		ev = make_event(TURNOFF_EVENT,evl->ev->time + time);
		remove_event(cx->sa->sched, evl);
	}
	else	{ /* none scheduled or already deleted */
		/* just make a new one */
		ev = make_event(TURNOFF_EVENT,cx->sa->sched->time + time);
		oldext = 0;
	}
	
	ev->h = cx->instr;
	ev->ext = oldext + time;  /* we need to keep track of this for tempo-change */
	
	/* if the instrument was about to be terminated, it might have just
	   saved itself. */
	if (time > 1/cx->sa->all->g->krate && cx->instr->turnoff_notified)
		cx->instr->turnoff_notified = 0; /* saved itself */
	
	/* reset the value of 'dur' */
	if (sym = get_sym_decl(cx->localvars,"dur")) {
		newdur = get_host_value(cx->instr,sym,0) + time;
		set_host_value(cx->instr,"dur",0,newdur);
		set_var_value_byname(cx,"dur",0,newdur);
		
	}

	/* NB 'released' is *not* updated by EXTEND (since the text doesn't say
	    anything about that) */

	/* schedule the new turnoff event */
	schedule_event(cx->sa,ev);
}

int host_value_changed(instr_handle *h, symbol *sym, int idx) {
/* check to see if a particular exposed variable changed values since the last
	   time we read it. */
	hostvar_list *hvl;
	char s[1000];
	
	/* h->hvl is the "host variable list" -- the list of all the exposed 
	variables in the particular instrument instance */
	for (hvl = h->hvl; hvl && hvl->sym != sym; hvl=hvl->next);
	if (!hvl) for (hvl = h->hvl; hvl && strcmp(hvl->name,sym->name); hvl=hvl->next);
	if (!hvl) {
		sprintf(s,"No such host variable '%s'",sym->name);
		runtime(NULL,s);
	}
	return hvl->changed;
}

sa_real get_host_value(instr_handle *h, symbol *sym, int idx) {
	/* get the current value of an exposed variable */
	hostvar_list *hvl;
	char s[1000];
	
	for (hvl = h->hvl; hvl && hvl->sym != sym; hvl=hvl->next);
	if (!hvl) for (hvl = h->hvl; hvl && strcmp(hvl->name,sym->name); hvl=hvl->next);
	if (!hvl) {
		sprintf(s,"No such host variable '%s'",sym->name);
		runtime(NULL,s);
	}
	
	hvl->changed = 0;
	return(hvl->val[idx]);
}

table_storage *get_host_table(instr_handle *h, symbol *sym) {
	/* get a table exposed by an instrument -- this means it must also be a global table. */
	symbol *s;
	hostvar_list *hvl;
	
	s = get_sym_decl(h->cx->sa->all->g->sym,sym->name);
	
	for (hvl = h->hvl; hvl && hvl->sym != sym; hvl=hvl->next);
	if (!hvl) for (hvl = h->hvl; hvl && strcmp(hvl->name,sym->name); hvl=hvl->next);
	hvl->changed = 0;
	
	return(h->cx->sa->global_cx->framevals[s->offset].table);
}

int has_host_var(instr_handle *h, char *varname) {
	/* check to see if an instrument exposes a particular controller */
	hostvar_list *hvl;
	symbol *sym;
	
	/* look up the symbol by name in the instrument's symbol table */
	sym = get_sym_decl(h->id->sym,varname);
	if (!sym) return(0);
	
	/* if there is a symbol, see if it's exposed. (it could have been removed
	   as unused in remove_unused_symbols). */
	for (hvl = h->hvl; hvl && hvl->sym != sym; hvl=hvl->next);
	return (hvl != NULL);
}

void set_host_value(instr_handle *h, char *varname, int idx, sa_real val) {
/* set the value of an exposed variable, by name.  We use this funny interface
to guarantee we only change exposed variables, and to do all of them at
	   the same time. */
	hostvar_list *hvl = NULL;
	symbol *sym;
	
	/* get the symbol by its name */
	sym = get_sym_decl(h->id->sym,varname);
	
	/* get the exposed interface by the symbol */
	if (sym) for (hvl = h->hvl; hvl && hvl->sym != sym; hvl=hvl->next);
	/* or by its name (YYY when is this used?) */
	else for (hvl = h->hvl; hvl && strcmp(varname,hvl->name); hvl=hvl->next);
	
	if (!hvl) {
		printf("\nWarning: no such control '%s', or unused in instrument.\n",varname);
	}
	
	else {
		hvl->val[idx] = val;
		hvl->changed = 1;
	}
}


void new_host_var(instr_handle *h, char *name, int width, int type) {
	/* make a new exposed variable by adding it to the 'host variable list' */
	hostvar_list *hvl;
	int i;
	
	if (width == -1) width = h->inchan;
	PROT_MAL(hvl,hostvar_list,new_host_var);
	hvl->name = strdup(name);
	hvl->sym = get_sym_decl(h->id->sym,name);
	hvl->width = width;
	hvl->changed = 0;
	if (type != ASIG) {
		hvl->val = (sa_real *)calloc(sizeof(sa_real),width);
		hvl->asig = NULL;
	}
	else  {
		hvl->asig = (asig_frame **)calloc(sizeof(asig_frame *),width);
		for (i=0;i!=width;i++)
			hvl->asig[i] = NULL;
		hvl->val = NULL;
	}
	
	hvl->next = h->hvl; /* just attach it to the beginning of the list */
	h->hvl = hvl;
}

int event_precedes(event *ev1, event *ev2) ;

void schedule_event(sa_decoder *sa, event *ev) {
	/* add one event to the list of pending events in the scheduler */
	event_list *evl = sa->sched->pending,*new,*last;
	
	/* make wrapper that goes in linked list */
	PROT_MAL(new,event_list,schedule_event);
	new->ev = ev;
	new->next = NULL;
	
	/* the new event is the first one */
	if (!evl || event_precedes(ev,evl->ev)) {
		new->next = sa->sched->pending;
		sa->sched->pending = new;
		if (!sa->sched->last_ev) /* must be the only event since it's also the last one */
			sa->sched->last_ev = new;
		return;
	}
	
	/* we keep a 'last' pointer for speed, since we often add an event to the
	   end of the list */
	
	if (sa->sched->last_ev && event_precedes(sa->sched->last_ev->ev,ev)) {
		/* the new event is the last one */
		sa->sched->last_ev->next = new;
		sa->sched->last_ev = new;
		return;
	}
    
	/* somewhere in the middle; find and insert */
	while (evl && event_precedes(evl->ev,ev)) {
		last = evl;
		evl=evl->next;
	}
	new->next = evl;
	last->next = new;
}

int event_precedes(event *ev1, event *ev2) {
	if (ev1->time < ev2->time) return 1;
	if (ev1->time > ev2->time) return 0;

	/* otherwise depends on the event types */
	return (ev1->type <= ev2->type);
}

void sched_add_events(sa_decoder *sa, event events[],int num) {
	/* add a bunch of events */
	int i;
	
	for (i=0;i!=num;i++) {
		events[i].time -= (sa_real)0.0001;
		schedule_event(sa, &(events[i]));
	}
}

void open_inputs(sa_decoder *sa, struct cmdinfo *cmd) {
	/* called at orchestra startup time -- get ready to process input data. */
	int i;
	char s[562];
	long pvb[16];
	int pvl = 0,chanct=0;
	
	if (sa->d) {
		/* this is the only normative behavior -- we're an AudioFX node */
		sa->inchan = sa->inct;
		sa->maxinsr = cmd->insr;
		return;
	}
	
	/* the rest is nonnormative */
	if (sa->inct) {		/* open all the input files */
		sa->inchan = 0;
		sa->maxinsr = 0;
		for (i=0;i!=sa->inct;i++) {
			/* open the file */
			sa->in[i].aif_in = aifNew();
			
			if (aifOpenRead(sa->in[i].aif_in,sa->in[i].fn)) {
				sprintf(s,"Couldn't open '%s' for read.",sa->in[i].fn);
				runtime(sa,s);
			}
			sa->in[i].running = 0;
			sa->in[i].done = 0;
			pvb[0] = AIF_P_CHANNELS;
			pvb[2] = AIF_P_SAMPSIZE;
			pvb[4] = AIF_P_SAMPRATE;
			aifGetParams(sa->in[i].aif_in,pvb,6);
			sa->in[i].nchan = pvb[1]; 
			sa->inchan += sa->in[i].nchan;  /* add up total input channels */
			sa->in[i].busch = chanct;
			chanct += pvb[1];
			sa->in[i].nbits = pvb[3];
			sa->in[i].srate = (int)*(float *)&pvb[5];
			sa->in[i].last = NULL;
			if (sa->maxinsr < sa->in[i].srate) /* keep track of fastest input */
				sa->maxinsr = sa->in[i].srate;
		}
	}
}

void start_send_instrs(sa_decoder *sa,int inchan) {
/* for each bus, make the storage space for it, and 
	   start an instrument instance of the instrument its 'send' goes to. */
	bustable *bus;
	instr_handle *h;
	int ct=0,i;
	send_list *sl;
	exprlist *el;
	namelist *nl;
	sa_real pf[256],val[1024];
	instr_decl *id;
	
	for (bus = sa->all->g->bus;bus;bus=bus->next) {
		/* for each bus, make its storage space */
		if (!strcmp(bus->name,"input_bus"))
			bus->width = inchan; /* the width of the 'input' bus is special */
		bus->val = (sa_real **)calloc(sizeof(sa_real *),bus->width);
		for (i=0;i!=bus->width;i++)
			bus->val[i] = (sa_real *)calloc(sizeof(sa_real),sa->ksmps);
	}
	for (sl = sa->all->g->sends;sl && sl->s;sl=sl->next) {
		
		/* start instrument for each bus */
		
		pf[0] = -1;
		
		/* calculate the parameters */
		for (ct=1,el = sl->s->pfields;el && el->p;ct++,el=el->next)
			pf[ct] = eval_expr(&sa->global_cx,val,el->p,IVAR);
		
		/* figure out the number of channels in the bus (YYY) */
		ct = 0;
		for (nl = sl->s->busses,ct=0;nl && nl->n; nl=nl->next)
			ct += get_bus(sa->all->g->bus,nl->n->name)->width;

		id = (instr_decl *)(get_instr_decl(sa->all->g->sym,sl->s->instr)->defn);
		ct = id->inchan;
		
		/* startup the instrument */
		h = new_instr_instance(sa,sl->s->instr,pf,ct,0);
		sl->s->h = h;
		h->origin = ORIGIN_SEND;
		
		/* attach input channels to instrument */
		
		h->input = (sa_real **)calloc(sizeof(sa_real *),ct);
		
		for (nl = sl->s->busses,ct=0;nl && nl->n; nl=nl->next) {
		/* NB we don't make new storage space for instrument inputs --
			we just hook them up to the right busses with pointers */
			for (i=0;i!=get_bus(sa->all->g->bus,nl->n->name)->width;i++,ct++)
				h->input[ct] = get_bus(sa->all->g->bus,nl->n->name)->val[i];
		}
		
		for (nl = sl->s->busses,ct=0;nl && nl->n; nl=nl->next) {
		/* if the bus is the 'output_bus', then the output of its
			send instrument is the output of the orchestra (5.7.3.3.6 #11). */
			if (!strcmp(nl->n->name,"output_bus"))
				h->cx->globalout = 1; 
		}
		
		
	}
	
}


void make_global_context(sa_decoder *sa) {
/* make the context containing all the global variables and
wavetables.  Also figure out the real sampling rate and
	control rate if they're not given in the SAOL code. */
	context *cx;
	char s[300];
	
	/* allocate space */
	PROT_MAL(sa->global_cx,context,make_global_context);
	cx = sa->global_cx;
	
	cx->instr = NULL;
	/* attach global symbol table */
	cx->localvars = sa->all->g->sym;
	cx->cop_storage = NULL;
	cx->sa = sa;
	
	/* allocate space to hold variables */
	if (sa->all->g->framesize) { /* otherwise, no vars */
		if (!(cx->framevals = (frameval *)calloc(sizeof(frameval), sa->all->g->framesize)))
			interror("calloc() failure in new_context()\n");
#ifdef _MPEGPROFILER
		else
			add_pointer(cx->framevals, sa->all->g->framesize * sizeof(float)); /* profiler */
#endif
		memset(cx->framevals,0,(sa->all->g->framesize) * sizeof(frameval));
	}
	
	/* make default srate if needed */
	if (!sa->all->g->srate) {
		if (sa->inchan) {
			sa->all->g->srate = sa->maxinsr; /* 5.8.5.2.1 */
			sprintf(s,"No srate given, taking maximum input rate %d.",sa->maxinsr);
			warn_line(s,0);
		}
		else {
			sa->all->g->srate = 32000;
			warn_line("No sampling rate or input specified, using 32000 Hz.",0);
		}
	}
	
	/* make krate if needed */
	if (!sa->all->g->krate) {
		sa->all->g->krate = 100;  /* 5.8.5.2.2 */
		while (fabs(floor(sa->all->g->srate / (sa_real)sa->all->g->krate) *
			sa->all->g->krate - (sa_real)sa->all->g->srate) > 0.001)
			sa->all->g->krate++;
		sprintf(s,"No krate given, defaulting to %d.",sa->all->g->krate);
		warn_line(s,0);
	}
	
	sa->ksmps = sa->all->g->srate/sa->all->g->krate;
	
	
}

sa_real *event_actparam_list(event *ev) {
/* make an actual-parameter list out of an event.  Just
copy the duration into the first field, and the p-fields
	of the event into the rest. */
	sa_real *p=NULL;
	int i;
	
	p = (sa_real *)calloc(ev->numval+1,sizeof(sa_real));
	p[0] = ev->dur;
	for (i=0;i!=ev->numval;i++)
		p[i+1] = ev->val[i];
	
	return(p);
}

void free_actparam_list(sa_real *p) {
	free(p);
}

void remove_event(scheduler *sched, event_list *r) {
/* remove an event from the list of scheduled events. 
could be anywhere in the list -- we sometimes have to remove
events from the middle (when 'extend' is called, we remove
the existing note-off event.  We might have to update the
start of the list, and maybe the tail-pointer, too.  

		assumes that the event is actually in the list 
	*/
	event_list *hold,*p,*last;
	
	last = NULL;
    for (p=sched->pending;p && p->next;last=p,p=p->next);
	if (p && !last) { /* there's only one event in the list; remove it*/
		free_event(p->ev);
		free(p);
		sched->pending = NULL;
		sched->last_ev = NULL;
		return;
	}
	
	if (p == r) { /* we're removing the last event; update last_ev */
		sched->last_ev = last;
	}
	
	if (sched->pending == r) { /* we're removing the first event */
		hold = sched->pending->next;
		free_event(sched->pending->ev);
		free(sched->pending);
		sched->pending = hold;
		return;
	}
	
	/* we're removing an event somewhere from the middle of the list */
	
	for (hold=p=sched->pending;p != r;hold=p,p=p->next) ;
	hold->next = p->next;
	if (p->ev) free_event(p->ev);
	free(p);
}

event_list *find_event_handle(instr_handle *h, int type) {
/* find an event tagged to a particular instrument instance
(typically a note-off).  Match TYPE if it's non-zero, otherwise
	   match any type */
	event_list *evl;
	
	evl = h->cx->sa->sched->pending;
	
	while (evl && (evl->ev->h != h || (type && evl->ev->type != type)))
		evl=evl->next;
	
	return evl;
}

event *make_event(int type, sa_real time) {
	/* make a new event with the given TYPE */
	event *ev;
	
	PROT_MAL(ev,event,make_event);
	
	ev->name = NULL;
	ev->label = NULL;
	ev->time = time;
	ev->dur = -1;
	ev->val = (sa_real *)malloc(sizeof(sa_real));
	ev->val[0] = 0;
	ev->numval = 0;
	ev->h = NULL;
	ev->type = type;
	ev->ext = 0;
	ev->sampname = NULL;
	
	return(ev);
}

void free_event(event *ev) {
	if (ev->val)
		free(ev->val);
	free(ev);
}

void add_global_table(context *cx, event *ev) {
	/* add a table to the global context, based on an event */
	table_storage *t;
	handle_list *hl;
	actparam *actl;
	int i;
	symbol *sym;
	frameval *fv;
	hostvar_list *hvl;
	
	/* make the parameters for the table -- just copy from the event */

	actl = (actparam *)calloc(ev->numval,sizeof(actparam));
	for (i=0;i!=ev->numval;i++)
		actl[i].val = ev->val[i];

	if (ev->sampname) actl[1].ref = ev->sampname;
	
	/* call the table generator (saol_tables.c) */
	t = gen_table(cx->sa,ev->label,actl,ev->numval);
	
	/* release the parameter list */
	free(actl);
	
	/* name the table */
	t->name = ev->name;
	
	/* get the symbol-table entry for the wavetable */
	sym = get_sym_decl(cx->sa->all->g->sym,t->name);
	
	if (!sym) {
		char s[200];

		sprintf(s,"No such table '%s' in global context.\n",t->name);
		runtime(cx->sa,s);
	}

	/* figure out the frame in the global context that holds this table */
	fv = &cx->sa->global_cx->framevals[sym->offset];
	
	/* if there was already a table there, clear it */
	if (fv->table) free_table(fv->table);
	
	/* link the table into the global context */
	fv->table = t;
	
	/* go through all the active instrs and see if they're using this table */
	
	for (hl=cx->sa->sched->active;hl && hl->h;hl=hl->next) {
		for (hvl = hl->h->hvl; hvl; hvl=hvl->next)
			if (!strcmp(hvl->name,t->name))
				/* mark the table as changed; it gets noted in the next k-execution */
				hvl->changed = 1;
	}
}

void destroy_global_table(context *cx, char *name) {
	/* this is what we do when we call 'destroy' for a global wavetable in the score */
}

void destroy_inst(sa_decoder *sa, instr_handle *h) {
	/* this is how to shut down an instrument instance. */
	int i;
	hostvar_list *hvl,*last;
	handle_list *hl,*lasthl = NULL;
	event_list *evl;
	
	/* find the instance in the active list */
	for (hl=sa->sched->active; hl && (hl->h != h); lasthl = hl,hl=hl->next) ;
	if (!hl) return; /* not found */
	
	/* relink the active list */
	if (lasthl)
		lasthl->next = hl->next;
	else
		sa->sched->active = hl->next;
	
	/* free the name, context, and input buffer */
	if (h->label) free(h->label);
	free_context(h->cx);
	if (h->input) free(h->input);
	
	/* free the output buffers */
	for (i=0;i!=sa->all->g->outchan;i++)
		free(h->output[i]);
	
	free(h->output);
	
	/* free the controller list */
	for (last = NULL,hvl=h->hvl;hvl;last=hvl,hvl=hvl->next) {
		if (last) free(last);
		if (hvl->name)
			free(hvl->name);
		if (hvl->val)
			free(hvl->val);
		if (hvl->asig) {
			for (i=0;i!=hvl->width;i++)
				free(hvl->asig[i]);
			free(hvl->asig);
		}
	}
	free(last);
	
	/* see if any pending events point to this event, and remove 
	   them if so */
	
	for (evl = sa->sched->pending; evl && evl->ev; evl=evl->next)
		if (evl->ev->h == h) {
			remove_event(sa->sched,evl); 
			if (evl == sa->sched->last_ev) sa->sched->last_ev = NULL;
		}
		
		free(h);
}


void free_context(context *cx) {
	/* free the context of an instrument instance */
	int ct;
	symtable *t;
	
	/* free local variables and non-global tables */
	for (ct=0,t=cx->localvars;t;t=t->next)  {
		if(t->s) {  // check if at least one variable really is present
			if (t->s->type == TABLE && (!(t->s->imported || t->s->exported)))
				free_table(cx->framevals[ct].table);
			ct+=t->s->width;
		}
	}

	if(cx->framevals) {
#ifdef _MPEGPROFILER
		remove_pointer(cx->framevals);      /* profiler */
#endif
		/* free the variable storage table */
		free(cx->framevals);
	}
	
	/* free all the opcode instances attached to this instance */
	for (ct=0;ct!=cx->instr->id->opsize;ct++) {
		if (cx->cop_storage[ct].local)
			free(cx->cop_storage[ct].local);
		if (cx->cop_storage[ct].dyn)  {
#ifdef _MPEGPROFILER
			remove_pointer(cx->cop_storage[ct].dyn);
#endif
			free(cx->cop_storage[ct].dyn);
		}
	}
	
	if (cx->cop_storage) free(cx->cop_storage);
	
	/* free the context itself */
	free(cx);
}

void scale_sched_events(sa_decoder *sa, event_list *pending) {
/* this is the functionality of a tempo change.  go through the
pending event list and re-time all of the events based on the
	   ratio between the previous tempo and the new tempo */
	event_list *temp = pending, *old;
	handle_list *hl;
	sa_real actime = sa->sched->time;
	sa_real scale_factor;
	
	
	old = temp;
	scale_factor = (sa_real)1.0 * sa->sched->last_score_tempo / sa->sched->tempo;
	while (temp) {
		temp->ev->time = actime + temp->ev->ext +
			(temp->ev->time - temp->ev->ext - actime)*scale_factor;
		if(temp->ev->dur > 0)
			temp->ev->dur = temp->ev->dur*scale_factor;
		if(temp->ev->time < old->ev->time) {  /* extend can affect the correct order */
			old->next = temp->next;    /* cut off the current event ... */
			schedule_event(sa, temp->ev);  /* ...and re-schedule it */
			temp = old;
		}
		old = temp;
		temp = temp->next;
	}
	
	for (hl = sa->sched->active; hl && hl->h; hl=hl->next) {
		/* go through the active instruments and change 'dur' */
		symbol *s = get_sym_decl(hl->h->id->sym,"dur");
		sa_real olddur, sofar, rem, newdur;
		
		if (s) {
			olddur = get_host_value(hl->h,s,0);
			sofar = hl->h->itime;
			if (olddur != -1) {
				rem = olddur - sofar;
				newdur = sofar + rem * scale_factor;
				set_host_value(hl->h,"dur",0,newdur);
			}
		}
	}
	

}     

/* these are the functions to implement for real-time audio output.  not
currently implemented; they should be machine-dependent.  */
#ifdef _32BITOUT
int soundOutQueue(int *t) {
	return 0;
}
#else
int soundOutQueue(short *t) {
	return 0;
}
#endif

int soundOutClose(int t) {
	return 0;
}

int soundOutOpen(int sr, int ch, int sz) {
	return 0;
}
