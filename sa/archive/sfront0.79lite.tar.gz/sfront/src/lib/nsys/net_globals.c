
/*
#    Sfront, a SAOL to C translator    
#    This file: Network library -- global variables
#    Copyright (C) 1999  Regents of the University of California
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License (Version 2) as
#    published by the Free Software Foundation.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    Maintainer: John Lazzaro, lazzaro@cs.berkeley.edu
*/

#ifndef NSYS_NET
#include "net_include.h"
#endif


/*************************/
/* rtp and rtcp: network */
/*************************/

int nsys_rtp_fd;                  /* fd for rtp           */
int nsys_rtcp_fd;                 /* fd for rtcp          */
int nsys_max_fd;                  /* fd for select        */

unsigned short nsys_rtp_port;     /* actual rtp port     */ 
unsigned short nsys_rtcp_port;    /* actual rtcp port    */ 

unsigned long nsys_rtp_cseq;      /* rtp cseq number      */
unsigned long nsys_rtcp_cseq;     /* rtcp cseq number     */

/*************************/
/* rtp and rtcp: packets */
/*************************/

unsigned char nsys_netout_rtp_packet[NSYS_UDPMAXSIZE];  /* rtp packet out */

unsigned char * netout_rtcp_packet_rrempty;
unsigned char * netout_rtcp_packet_rr;
unsigned char * netout_rtcp_packet_srempty;
unsigned char * netout_rtcp_packet_sr;
unsigned char * netout_rtcp_packet_bye;

int netout_rtcp_len_rrempty;
int netout_rtcp_len_rr;
int netout_rtcp_len_srempty;
int netout_rtcp_len_sr;
int netout_rtcp_len_bye;


unsigned char nsys_netout_rtcp_packet[NSYS_UDPMAXSIZE]; /* rtcp packet out */
int nsys_netout_rtcp_size;                              /* rtcp packet size*/

char * sdes_typename[NSYS_RTCPVAL_SDES_SIZE] = {       /* rtcp debug array */
  "ILLEGAL", "Cname", "Name", "Email", "Phone", 
  "Loc", "Tool", "Note", "Priv" };

unsigned long nsys_netout_seqnum;  /* rtp output sequence number */
unsigned long nsys_netout_tstamp;  /* rtp output timestamp */
unsigned char nsys_netout_markbit; /* for setting markerbit */

/************************/
/* rtp payload support  */
/************************/

#if 0
/* when adding new codecs, follow this sample  */
/* remember to increment NSYS_RTP_PAYSIZE, and */
/* get ordering correct.                       */

struct payinfo nsys_payload_types[NSYS_RTP_PAYSIZE] = 
{ 
  {0, 97, "X-MP4SA-1", (int)(ARATE + 0.5F)},
  {1, 96, "X-MP4SA-0", (int)(ARATE + 0.5F)}
};
#endif

struct payinfo nsys_payload_types[NSYS_RTP_PAYSIZE] = 
{ 
  {0, 96, "X-MP4SA-0", (int)(ARATE + 0.5F)}
};

/**************/
/* rtcp timer */
/**************/

int nsys_sent_last;       /* a packet was sent last RTCP period */
int nsys_sent_this;       /* a packet was sent this RTCP period */

unsigned long nsys_sent_packets;  /* number of packets sent */
unsigned long nsys_sent_octets;   /* number of octets sent */

time_t nsys_nexttime;     /* time for next RTCP check           */
int nsys_rtcp_ex;         /* status flags to check at RTCP time */

/******************/
/* identification */
/******************/

unsigned long nsys_myssrc;        /*  SSRC -- hostorder  */
unsigned long nsys_myssrc_net;    /*  SSRC -- netorder   */

#ifndef NSYS_NET
char * nsys_sessionname;   
char * nsys_sessionkey;   
int nsys_feclevel = NSYS_SM_FEC_STANDARD;
int nsys_lateplay;
float nsys_latetime = NSYS_SM_LATETIME;
#endif

unsigned char nsys_keydigest[NSYS_MD5_LENGTH];
unsigned char nsys_session_base64[NSYS_BASE64_LENGTH];
int nsys_msession;
int nsys_msessionmirror;

char nsys_clientname[NSYS_HOSTNAMESIZE];
char nsys_clientip[16];
char * nsys_username;

char nsys_cname[NSYS_CNAMESIZE];
unsigned char nsys_cname_len;
int nsys_powerup_mset; 

/***********/
/* logging */
/***********/

int nsys_stderr_size;

/*********************/
/* MIDI input buffer */
/*********************/

unsigned char nsys_buff[NSYS_BUFFSIZE];
long nsys_bufflen;
long nsys_buffcnt;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/* mpeg4-samidi: recovery journal sender state */
/*_____________________________________________*/

/*************************/
/* checkpoint management */
/*************************/

unsigned long netout_jsend_checkpoint_seqnum; /* current checkpoint */
unsigned long netout_jsend_checkpoint_changed; /* 1 if changed */

/*********************/
/* S-list management */
/*********************/

unsigned char * netout_jsend_slist[NSYS_SM_SLISTLEN];
int netout_jsend_slist_size;

/*******************************/
/* guard journal state machine */
/*******************************/

int netout_jsend_guard_send;    /* flag variable: send a guard packet */
int netout_jsend_guard_time;    /* guard packet timer state */
int netout_jsend_guard_next;    /* reload value for timer */
int netout_jsend_guard_ontime;  /* minimum delay time for noteon */ 
int netout_jsend_guard_mintime; /* minimum delay time for (!noteon) */
int netout_jsend_guard_maxtime; /* maximum delay time */ 

/***************************/
/* recovery journal header */
/***************************/

unsigned char netout_jsend_header[NSYS_SM_JH_SIZE];   /* journal header */

/**************************/
/* channel journal record */
/**************************/

unsigned char netout_jsend_channel[CSYS_MIDI_NUMCHAN];
unsigned char netout_jsend_channel_size;

/************************/
/* sender channel state */
/************************/

netout_jsend_state netout_jsend[CSYS_MIDI_NUMCHAN];

/**************************/
/* receiver channel state */
/**************************/

netout_jrecv_state * nsys_recvfree;  
  

/*******/
/* SIP */
/*******/

unsigned char nsys_rtp_invite[NSYS_UDPMAXSIZE+1];
unsigned char nsys_rtcp_invite[NSYS_UDPMAXSIZE+1];

int nsys_rtp_sipretry;      /* sip server retry counter */
int nsys_rtcp_sipretry;                 

int nsys_rtp_authretry;     /* reauthorization counter  */
int nsys_rtcp_authretry;

struct sockaddr_in nsys_sip_rtp_addr;   /* current SIP RTP channel */
char nsys_sip_rtp_ip[16];
unsigned long nsys_sip_rtp_inet_addr;
unsigned short nsys_sip_rtp_port;
unsigned short nsys_sip_rtp_sin_port;

struct sockaddr_in nsys_sip_rtcp_addr;  /* current SIP RTCP channel */
char nsys_sip_rtcp_ip[16];
unsigned long nsys_sip_rtcp_inet_addr;
unsigned short nsys_sip_rtcp_port;
unsigned short nsys_sip_rtcp_sin_port;

int nsys_graceful_exit;                 /* requests termination      */

unsigned char nsys_rtp_info[NSYS_UDPMAXSIZE+1];  /* SIP INFO packets */
unsigned char nsys_rtcp_info[NSYS_UDPMAXSIZE+1];

int nsys_behind_nat;                      /* 1 if behind a nat        */
int nsys_sipinfo_count;                   /* INFO sending timer       */
int nsys_sipinfo_toggle;                  /* RTP/RTCP toggle          */

/***************/
/* SSRC stack  */
/***************/

struct source * nsys_srcfree = NULL;       /* mset ssrc tokens */
struct source * nsys_ssrc[NSYS_HASHSIZE];  /* SSRC hash table  */
struct source * nsys_srcroot = NULL;       /* points into nsys_ssrc */

/* end Network library -- global variables */
