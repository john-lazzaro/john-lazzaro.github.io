
/*
#    Sfront, a SAOL to C translator
#    This file: Include file for shared variables
#    Copyright (C) 1999  Regents of the University of California
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License (Version 2) as
#    published by the Free Software Foundation.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    Maintainer: John Lazzaro, lazzaro@cs.berkeley.edu
*/

#ifndef _LIBMAKER_H
#define _LIBMAKER_H 1

#define IDSTRING "--IDSTRING--"

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/* should match ZSIZE in tree.h */

#define ZSIZE        4096

/* number of libraries in a directory */

#define NAMESIZE 128

#define CSRC 0
#define ASYS 1
#define CSYS 2
#define NSYS 3
#define PSYS 4
#define DIRSIZE 5

extern FILE * infile;
extern FILE * outfile;

extern int libtype;       /* library directory to process */
extern char * libdirs[];  /* name of library directories */
extern char * libnames[]; /* library file names in a directory */
extern int numnames;      /* number of files in a directory */


#endif




