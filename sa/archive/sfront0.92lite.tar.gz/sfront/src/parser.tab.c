
/*  A Bison parser, made from parser.y
    by GNU Bison version 1.28  */

#define YYBISON 1  /* Identify Bison output.  */

#define	STRCONST	257
#define	IDENT	258
#define	INTGR	259
#define	NUMBER	260
#define	AOPCODE	261
#define	ASIG	262
#define	ELSE	263
#define	EXPORTS	264
#define	EXTEND	265
#define	GLOBAL	266
#define	IF	267
#define	IMPORTS	268
#define	INCHANNELS	269
#define	INSTR	270
#define	INTERP	271
#define	IOPCODE	272
#define	IVAR	273
#define	KOPCODE	274
#define	KRATE	275
#define	KSIG	276
#define	MAP	277
#define	OPARRAY	278
#define	OPCODE	279
#define	OUTBUS	280
#define	OUTCHANNELS	281
#define	OUTPUT	282
#define	PRINTF	283
#define	RETURN	284
#define	ROUTE	285
#define	SASBF	286
#define	SEND	287
#define	SEQUENCE	288
#define	SPATIALIZE	289
#define	SRATE	290
#define	TABLE	291
#define	TABLEMAP	292
#define	TEMPLATE	293
#define	TURNOFF	294
#define	WHILE	295
#define	WITH	296
#define	XSIG	297
#define	AND	298
#define	OR	299
#define	GEQ	300
#define	LEQ	301
#define	NEQ	302
#define	EQEQ	303
#define	MINUS	304
#define	STAR	305
#define	SLASH	306
#define	PLUS	307
#define	GT	308
#define	LT	309
#define	Q	310
#define	COL	311
#define	LP	312
#define	RP	313
#define	LC	314
#define	RC	315
#define	LB	316
#define	RB	317
#define	SEM	318
#define	COM	319
#define	EQ	320
#define	NOT	321
#define	BADCHAR	322
#define	BADNUMBER	323
#define	LTT	324
#define	GTT	325
#define	UNOT	326
#define	UMINUS	327
#define	HIGHEST	328

#line 41 "parser.y"


#include "tree.h"

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		330
#define	YYFLAG		-32768
#define	YYNTBASE	75

#define YYTRANSLATE(x) ((unsigned)(x) <= 328 ? yytranslate[x] : 119)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     3,     4,     5,     6,
     7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
    17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
    27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
    37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    71,    72,    73,    74
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     5,     8,    11,    14,    15,    16,    28,    31,
    32,    35,    37,    38,    49,    50,    56,    57,    58,    80,
    81,    82,    83,   108,   114,   118,   119,   122,   123,   125,
   127,   129,   131,   133,   137,   141,   145,   149,   153,   161,
   171,   177,   180,   181,   186,   189,   197,   209,   217,   224,
   230,   236,   244,   250,   253,   259,   265,   267,   272,   276,
   278,   279,   283,   285,   286,   289,   290,   295,   299,   302,
   309,   312,   313,   318,   322,   325,   332,   335,   339,   341,
   343,   348,   353,   358,   360,   362,   364,   366,   368,   370,
   372,   380,   382,   384,   387,   390,   392,   394,   396,   398,
   400,   402,   407,   412,   417,   425,   431,   435,   439,   443,
   447,   451,   455,   459,   463,   467,   471,   475,   479,   482,
   485,   489,   493,   495,   496,   500,   504,   506,   508,   510
};

static const short yyrhs[] = {    76,
     0,    76,    77,     0,    76,    81,     0,    76,    83,     0,
    76,    85,     0,     0,     0,    16,     4,    58,   101,    78,
    59,    79,    60,   103,    98,    61,     0,     4,    80,     0,
     0,    80,     5,     0,     5,     0,     0,   114,     4,    82,
    58,   102,    59,    60,   105,    98,    61,     0,     0,    12,
    84,    60,    92,    61,     0,     0,     0,    39,    55,   101,
    54,    58,   101,    59,    86,    23,    60,   101,    61,    42,
    60,    91,    61,    87,    60,   103,    98,    61,     0,     0,
     0,     0,    39,    55,   101,    54,     4,    88,    91,    58,
   101,    59,    89,    23,    60,   101,    61,    42,    60,    91,
    61,    90,    60,   103,    98,    61,     0,    91,    65,    70,
   116,    71,     0,    70,   116,    71,     0,     0,    92,    93,
     0,     0,    94,     0,   104,     0,    95,     0,    96,     0,
    97,     0,    36,     5,    64,     0,    21,     5,    64,     0,
    15,     5,    64,     0,    27,     5,    64,     0,    17,     5,
    64,     0,    31,    58,     4,    65,   101,    59,    64,     0,
    33,    58,     4,    64,   116,    64,   108,    59,    64,     0,
    34,    58,   101,    59,    64,     0,    98,    99,     0,     0,
   100,    66,   115,    64,     0,   115,    64,     0,    13,    58,
   115,    59,    60,    98,    61,     0,    13,    58,   115,    59,
    60,    98,    61,     9,    60,    98,    61,     0,    41,    58,
   115,    59,    60,    98,    61,     0,    16,     4,    58,   116,
    59,    64,     0,    28,    58,   116,    59,    64,     0,    35,
    58,   116,    59,    64,     0,    26,    58,     4,    65,   116,
    59,    64,     0,    11,    58,   115,    59,    64,     0,    40,
    64,     0,    30,    58,   116,    59,    64,     0,    29,    58,
   117,    59,    64,     0,     4,     0,     4,    62,   115,    63,
     0,   101,    65,     4,     0,     4,     0,     0,   102,    65,
   107,     0,   107,     0,     0,   103,   104,     0,     0,   113,
   110,   108,    64,     0,   110,   108,    64,     0,   112,    64,
     0,    38,     4,    58,   101,    59,    64,     0,   105,   106,
     0,     0,   113,   111,   108,    64,     0,   111,   108,    64,
     0,   112,    64,     0,    38,     4,    58,   101,    59,    64,
     0,   111,   109,     0,   108,    65,   109,     0,   109,     0,
     4,     0,     4,    62,     5,    63,     0,     4,    62,    15,
    63,     0,     4,    62,    27,    63,     0,    19,     0,    22,
     0,     8,     0,    37,     0,    24,     0,    43,     0,   110,
     0,    37,     4,    58,     4,    65,   117,    59,     0,    14,
     0,    10,     0,    14,    10,     0,    10,    14,     0,     7,
     0,    20,     0,    18,     0,    25,     0,     4,     0,   118,
     0,     4,    62,   115,    63,     0,    32,    58,   116,    59,
     0,     4,    58,   116,    59,     0,     4,    62,   115,    63,
    58,   116,    59,     0,   115,    56,   115,    57,   115,     0,
   115,    47,   115,     0,   115,    46,   115,     0,   115,    48,
   115,     0,   115,    49,   115,     0,   115,    54,   115,     0,
   115,    55,   115,     0,   115,    44,   115,     0,   115,    45,
   115,     0,   115,    53,   115,     0,   115,    50,   115,     0,
   115,    51,   115,     0,   115,    52,   115,     0,    67,   115,
     0,    50,   115,     0,    58,   115,    59,     0,   116,    65,
   115,     0,   115,     0,     0,   117,    65,   115,     0,   117,
    65,     3,     0,     3,     0,   115,     0,     5,     0,     6,
     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   133,   136,   137,   138,   139,   140,   143,   144,   148,   149,
   152,   153,   157,   158,   162,   162,   166,   168,   171,   173,
   174,   176,   179,   184,   185,   186,   189,   190,   193,   194,
   195,   196,   197,   200,   201,   202,   203,   204,   207,   211,
   215,   219,   220,   223,   226,   229,   232,   235,   238,   241,
   244,   247,   250,   253,   256,   259,   264,   265,   268,   269,
   270,   273,   274,   275,   278,   279,   282,   284,   286,   288,
   292,   293,   296,   298,   300,   302,   306,   309,   310,   313,
   314,   315,   316,   319,   320,   321,   322,   323,   326,   327,
   331,   335,   337,   339,   341,   345,   346,   347,   348,   351,
   353,   355,   357,   359,   361,   363,   365,   367,   369,   371,
   373,   375,   377,   379,   381,   383,   385,   387,   389,   391,
   393,   397,   398,   399,   402,   403,   404,   405,   408,   409
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","STRCONST",
"IDENT","INTGR","NUMBER","AOPCODE","ASIG","ELSE","EXPORTS","EXTEND","GLOBAL",
"IF","IMPORTS","INCHANNELS","INSTR","INTERP","IOPCODE","IVAR","KOPCODE","KRATE",
"KSIG","MAP","OPARRAY","OPCODE","OUTBUS","OUTCHANNELS","OUTPUT","PRINTF","RETURN",
"ROUTE","SASBF","SEND","SEQUENCE","SPATIALIZE","SRATE","TABLE","TABLEMAP","TEMPLATE",
"TURNOFF","WHILE","WITH","XSIG","AND","OR","GEQ","LEQ","NEQ","EQEQ","MINUS",
"STAR","SLASH","PLUS","GT","LT","Q","COL","LP","RP","LC","RC","LB","RB","SEM",
"COM","EQ","NOT","BADCHAR","BADNUMBER","LTT","GTT","UNOT","UMINUS","HIGHEST",
"orcfile","proclist","instrdecl","@1","miditag","int_list","opcodedecl","@2",
"globaldecl","@3","templatedecl","@4","@5","@6","@7","@8","mapblock","globalblock",
"globaldef","rtparam","routedef","senddef","seqdef","block","statement","lvalue",
"identlist","paramlist","vardecls","vardecl","opvardecls","opvardecl","paramdecl",
"namelist","name","stype","otype","tabledecl","taglist","optype","expr","exprlist",
"exprstrlist","const", NULL
};
#endif

static const short yyr1[] = {     0,
    75,    76,    76,    76,    76,    76,    78,    77,    79,    79,
    80,    80,    82,    81,    84,    83,    86,    87,    85,    88,
    89,    90,    85,    91,    91,    91,    92,    92,    93,    93,
    93,    93,    93,    94,    94,    94,    94,    94,    95,    96,
    97,    98,    98,    99,    99,    99,    99,    99,    99,    99,
    99,    99,    99,    99,    99,    99,   100,   100,   101,   101,
   101,   102,   102,   102,   103,   103,   104,   104,   104,   104,
   105,   105,   106,   106,   106,   106,   107,   108,   108,   109,
   109,   109,   109,   110,   110,   110,   110,   110,   111,   111,
   112,   113,   113,   113,   113,   114,   114,   114,   114,   115,
   115,   115,   115,   115,   115,   115,   115,   115,   115,   115,
   115,   115,   115,   115,   115,   115,   115,   115,   115,   115,
   115,   116,   116,   116,   117,   117,   117,   117,   118,   118
};

static const short yyr2[] = {     0,
     1,     2,     2,     2,     2,     0,     0,    11,     2,     0,
     2,     1,     0,    10,     0,     5,     0,     0,    21,     0,
     0,     0,    24,     5,     3,     0,     2,     0,     1,     1,
     1,     1,     1,     3,     3,     3,     3,     3,     7,     9,
     5,     2,     0,     4,     2,     7,    11,     7,     6,     5,
     5,     7,     5,     2,     5,     5,     1,     4,     3,     1,
     0,     3,     1,     0,     2,     0,     4,     3,     2,     6,
     2,     0,     4,     3,     2,     6,     2,     3,     1,     1,
     4,     4,     4,     1,     1,     1,     1,     1,     1,     1,
     7,     1,     1,     2,     2,     1,     1,     1,     1,     1,
     1,     4,     4,     4,     7,     5,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     2,     2,
     3,     3,     1,     0,     3,     3,     1,     1,     1,     1
};

static const short yydefact[] = {     6,
     1,    96,    15,     0,    98,    97,    99,     0,     2,     3,
     4,     5,     0,     0,     0,    61,    13,    28,    61,    60,
     0,     0,     0,     7,     0,     0,    64,    86,    93,    92,
     0,     0,    84,     0,    85,    88,     0,     0,     0,     0,
     0,     0,     0,    16,    27,    29,    31,    32,    33,    30,
     0,     0,     0,     0,    20,    61,    59,    87,    89,     0,
    63,    90,     0,    95,    94,     0,     0,     0,     0,     0,
     0,    61,     0,     0,     0,    80,     0,    79,    69,     0,
    10,    26,     0,     0,     0,    77,    36,    38,    35,    37,
     0,     0,     0,    34,     0,    61,     0,    68,     0,     0,
     0,     0,   124,     0,    17,    72,    62,    61,   124,     0,
     0,     0,     0,     0,     0,    78,    67,    12,     9,    66,
   100,   129,   130,     0,     0,     0,     0,   123,     0,   101,
    61,     0,     0,    43,     0,     0,    41,     0,     0,    81,
    82,    83,    11,    43,   124,     0,   124,   120,     0,   119,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,    25,     0,   124,     0,     0,     0,
    71,     0,     0,     0,     0,     0,   127,   128,     0,    70,
     0,    65,     0,     0,     0,   121,   113,   114,   108,   107,
   109,   110,   116,   117,   118,   115,   111,   112,     0,   122,
    21,     0,    61,     0,   100,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    14,    42,     0,     0,     0,
    75,     0,    39,     0,    91,     0,     8,   104,   102,   103,
     0,     0,    24,     0,    61,     0,     0,     0,     0,     0,
   124,     0,   124,   124,    54,     0,     0,    45,    74,     0,
     0,   126,   125,   124,   106,     0,     0,     0,     0,     0,
     0,   124,     0,     0,     0,     0,     0,     0,     0,    73,
    40,     0,    61,     0,     0,   102,     0,     0,     0,   124,
     0,     0,     0,     0,     0,    44,   105,     0,    26,    76,
    53,    43,     0,     0,    50,    56,    55,    51,    43,     0,
     0,     0,    49,     0,     0,     0,    18,    46,    52,    48,
    26,     0,     0,     0,    66,    43,    22,    43,     0,     0,
     0,    47,    66,    19,    43,     0,    23,     0,     0,     0
};

static const short yydefgoto[] = {   328,
     1,     9,    54,   102,   119,    10,    22,    11,    14,    12,
   133,   312,    82,   232,   320,   104,    23,    45,    46,    47,
    48,    49,   170,   217,   218,    21,    60,   144,   182,   134,
   171,    61,    77,    78,    51,    63,    52,    53,    13,   128,
   129,   179,   130
};

static const short yypact[] = {-32768,
   146,-32768,-32768,    68,-32768,-32768,-32768,    28,-32768,-32768,
-32768,-32768,   102,   -36,    64,   123,-32768,-32768,   123,-32768,
   -48,    84,   467,    39,     1,   126,    73,-32768,   141,   130,
   152,   155,-32768,   162,-32768,-32768,   165,    94,   140,   143,
   174,   177,   184,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   200,   145,    -1,   148,-32768,   123,-32768,-32768,-32768,   -37,
-32768,-32768,   200,-32768,-32768,   156,   179,   180,   182,   234,
   237,   123,   185,   190,   193,   191,   -56,-32768,-32768,   200,
   248,   192,     8,   203,    73,-32768,-32768,-32768,-32768,-32768,
   195,   201,    20,-32768,   262,   123,    51,-32768,   200,    55,
   263,   207,    26,   -55,-32768,-32768,-32768,   123,    26,   208,
   206,    21,   213,   214,   215,-32768,-32768,-32768,   276,-32768,
    13,-32768,-32768,   225,    26,    26,    26,   660,    17,-32768,
   123,   216,   261,   498,    31,   147,-32768,    59,   224,-32768,
-32768,-32768,-32768,   505,    26,    26,    26,-32768,   582,-32768,
    26,    26,    26,    26,    26,    26,    26,    26,    26,    26,
    26,    26,    26,    26,-32768,    46,    26,   231,   285,   189,
-32768,   200,   228,    73,   230,   200,-32768,   660,    49,-32768,
   229,-32768,    56,   542,    72,-32768,   683,   673,   175,   175,
   693,   693,   171,-32768,-32768,   171,   175,   175,   646,   660,
-32768,    67,   123,   235,   -47,   242,   244,   299,   247,   249,
   250,   253,   254,   252,   259,-32768,-32768,   240,   500,   167,
-32768,   200,-32768,    76,-32768,    96,-32768,-32768,   260,-32768,
    26,   298,-32768,    42,   123,    26,    26,    26,   265,   320,
    26,    59,    26,    26,-32768,    26,    26,-32768,-32768,   172,
   264,-32768,   660,    26,   660,   266,   287,    80,   562,   598,
   614,    26,   267,   100,   109,   113,   118,   630,   521,-32768,
-32768,   121,   123,   271,   270,   -31,   278,   273,   131,    26,
   279,   281,   282,   283,   280,-32768,-32768,    82,   192,-32768,
-32768,-32768,   284,   132,-32768,-32768,-32768,-32768,-32768,   310,
   138,   269,-32768,   292,   309,   291,-32768,   348,-32768,-32768,
   192,   301,   303,   149,-32768,-32768,-32768,   505,   349,   304,
   389,-32768,-32768,-32768,   505,   429,-32768,   358,   366,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,  -285,-32768,-32768,-32768,-32768,
-32768,-32768,  -143,-32768,-32768,   -19,-32768,  -254,   345,-32768,
-32768,   286,   -78,   -29,     2,  -114,   238,   239,-32768,  -113,
   -93,   127,-32768
};


#define	YYLAST		748


static const short yytable[] = {    24,
   181,   100,   131,   301,    55,    25,    28,    98,    99,   132,
   145,   148,   149,   150,   236,   136,    26,    33,   -57,   172,
    35,    84,    36,    18,   178,   314,   254,    85,    62,   121,
   122,   123,   184,    86,   -58,    58,    83,   187,   188,   189,
   190,   191,   192,   193,   194,   195,   196,   197,   198,   199,
   200,   183,    93,   185,    80,   113,   219,   124,    56,   222,
   318,   177,   121,   122,   123,   114,   105,   219,   325,   116,
   145,    15,    26,   202,   146,   125,   112,   115,   110,   139,
    28,   164,    16,   126,    26,    26,    62,   165,   135,   175,
   124,    33,   127,   220,    35,    26,    36,   224,   252,   121,
   122,   123,   257,    26,   201,    17,    26,   225,   125,    58,
    26,   166,   253,   226,   228,    59,   126,   255,   117,    99,
   164,    19,   259,   260,   261,   127,    20,   124,   178,    57,
   230,   164,   268,   269,   251,    62,   164,   233,   275,    65,
    99,    27,   300,   250,    26,   125,    26,   264,   302,   266,
   267,    70,     2,   126,    64,   305,    66,     3,   281,    67,
   272,     4,   127,     5,   164,     6,    68,   282,   279,    69,
     7,   283,   319,   226,   321,    62,   284,   164,    73,   287,
    74,   326,   164,   234,     8,   164,   294,    75,   219,   293,
   304,   219,   205,   122,   123,   164,   164,    71,   307,   206,
    72,   207,   132,    76,   208,   219,    81,   219,    79,   317,
   176,   164,   219,   132,   209,   258,   210,   211,   212,    87,
   124,   158,   159,   213,   157,   158,   159,   160,   214,   215,
   249,    99,   205,   122,   123,   270,    99,    91,   125,   206,
    92,   207,    88,    89,   208,    90,   126,    95,    94,   216,
    96,   101,    97,   288,   209,   127,   210,   211,   212,   108,
   124,   103,   106,   213,   109,   111,   120,   118,   214,   215,
   138,   137,   205,   122,   123,   140,   141,   142,   125,   206,
   143,   207,   147,   168,   208,   167,   126,   180,   204,   227,
   203,   221,   235,   223,   209,   127,   210,   211,   212,   237,
   124,   238,   239,   213,   240,   247,   241,   242,   214,   215,
   243,   244,   205,   122,   123,   245,   246,   254,   125,   206,
   256,   207,   262,   263,   208,   273,   126,   271,   274,   308,
   289,   280,   292,   290,   209,   127,   210,   211,   212,   299,
   124,   291,   295,   213,   296,   297,   298,   303,   214,   215,
   311,   306,   205,   122,   123,   309,   313,   329,   125,   206,
   315,   207,   316,   323,   208,   330,   126,    50,   265,   310,
   107,   173,   174,     0,   209,   127,   210,   211,   212,     0,
   124,     0,     0,   213,     0,     0,     0,     0,   214,   215,
     0,     0,   205,   122,   123,     0,     0,     0,   125,   206,
     0,   207,     0,     0,   208,     0,   126,     0,     0,   322,
     0,     0,     0,     0,   209,   127,   210,   211,   212,     0,
   124,     0,     0,   213,     0,     0,     0,     0,   214,   215,
     0,     0,   205,   122,   123,     0,     0,     0,   125,   206,
     0,   207,     0,     0,   208,     0,   126,     0,     0,   324,
     0,     0,     0,     0,   209,   127,   210,   211,   212,     0,
   124,     0,     0,   213,     0,     0,     0,     0,   214,   215,
     0,     0,     0,     0,    28,     0,    29,     0,   125,     0,
    30,    31,     0,    32,     0,    33,   126,    34,    35,   327,
    36,     0,     0,    37,     0,   127,     0,    38,     0,    39,
    40,     0,    41,    42,    43,    28,     0,    29,     0,     0,
     0,    30,    28,     0,    29,     0,    33,     0,    30,    35,
     0,    36,     0,    33,     0,     0,    35,    44,    36,     0,
     0,     0,     0,     0,    42,   169,     0,     0,     0,     0,
    59,    42,    43,   151,   152,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,     0,     0,     0,     0,
     0,     0,     0,   248,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,     0,     0,     0,
     0,     0,     0,     0,   286,   151,   152,   153,   154,   155,
   156,   157,   158,   159,   160,   161,   162,   163,     0,     0,
     0,     0,     0,     0,   229,   151,   152,   153,   154,   155,
   156,   157,   158,   159,   160,   161,   162,   163,     0,     0,
     0,     0,     0,     0,   276,   151,   152,   153,   154,   155,
   156,   157,   158,   159,   160,   161,   162,   163,     0,     0,
   186,   151,   152,   153,   154,   155,   156,   157,   158,   159,
   160,   161,   162,   163,     0,     0,   277,   151,   152,   153,
   154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     0,     0,   278,   151,   152,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,     0,     0,   285,   151,
   152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
   162,   163,   231,   151,   152,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,   151,     0,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   153,   154,
     0,     0,   157,   158,   159,   160,   161,   162
};

static const short yycheck[] = {    19,
   144,    80,    58,   289,     4,    54,     8,    64,    65,    65,
    58,   125,   126,   127,    62,   109,    65,    19,    66,   134,
    22,    59,    24,    60,   138,   311,    58,    65,    27,     4,
     5,     6,   146,    63,    66,    37,    56,   151,   152,   153,
   154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
   164,   145,    72,   147,    53,     5,   170,    32,    58,   174,
   315,     3,     4,     5,     6,    15,    59,   181,   323,    99,
    58,     4,    65,   167,    62,    50,    96,    27,    59,    59,
     8,    65,    55,    58,    65,    65,    85,    71,   108,    59,
    32,    19,    67,   172,    22,    65,    24,   176,     3,     4,
     5,     6,    61,    65,    59,     4,    65,    59,    50,    37,
    65,   131,   226,    65,    59,    43,    58,   231,    64,    65,
    65,    58,   236,   237,   238,    67,     4,    32,   242,     4,
    59,    65,   246,   247,    59,   134,    65,    71,    59,    10,
    65,    58,    61,   222,    65,    50,    65,   241,   292,   243,
   244,    58,     7,    58,    14,   299,     5,    12,    59,     5,
   254,    16,    67,    18,    65,    20,     5,    59,   262,     5,
    25,    59,   316,    65,   318,   174,    59,    65,     5,    59,
     4,   325,    65,   203,    39,    65,   280,     4,   302,    59,
    59,   305,     4,     5,     6,    65,    65,    58,    61,    11,
    58,    13,    65,     4,    16,   319,    59,   321,    64,    61,
    64,    65,   326,    65,    26,   235,    28,    29,    30,    64,
    32,    51,    52,    35,    50,    51,    52,    53,    40,    41,
    64,    65,     4,     5,     6,    64,    65,     4,    50,    11,
     4,    13,    64,    64,    16,    64,    58,    58,    64,    61,
    58,     4,    62,   273,    26,    67,    28,    29,    30,    65,
    32,    70,    60,    35,    64,     4,    60,     5,    40,    41,
    65,    64,     4,     5,     6,    63,    63,    63,    50,    11,
     5,    13,    58,    23,    16,    70,    58,    64,     4,    61,
    60,    64,    58,    64,    26,    67,    28,    29,    30,    58,
    32,    58,     4,    35,    58,    66,    58,    58,    40,    41,
    58,    58,     4,     5,     6,    64,    58,    58,    50,    11,
    23,    13,    58,     4,    16,    60,    58,    64,    42,    61,
    60,    65,    60,    64,    26,    67,    28,    29,    30,    60,
    32,    64,    64,    35,    64,    64,    64,    64,    40,    41,
    60,    42,     4,     5,     6,    64,     9,     0,    50,    11,
    60,    13,    60,    60,    16,     0,    58,    23,   242,    61,
    85,   134,   134,    -1,    26,    67,    28,    29,    30,    -1,
    32,    -1,    -1,    35,    -1,    -1,    -1,    -1,    40,    41,
    -1,    -1,     4,     5,     6,    -1,    -1,    -1,    50,    11,
    -1,    13,    -1,    -1,    16,    -1,    58,    -1,    -1,    61,
    -1,    -1,    -1,    -1,    26,    67,    28,    29,    30,    -1,
    32,    -1,    -1,    35,    -1,    -1,    -1,    -1,    40,    41,
    -1,    -1,     4,     5,     6,    -1,    -1,    -1,    50,    11,
    -1,    13,    -1,    -1,    16,    -1,    58,    -1,    -1,    61,
    -1,    -1,    -1,    -1,    26,    67,    28,    29,    30,    -1,
    32,    -1,    -1,    35,    -1,    -1,    -1,    -1,    40,    41,
    -1,    -1,    -1,    -1,     8,    -1,    10,    -1,    50,    -1,
    14,    15,    -1,    17,    -1,    19,    58,    21,    22,    61,
    24,    -1,    -1,    27,    -1,    67,    -1,    31,    -1,    33,
    34,    -1,    36,    37,    38,     8,    -1,    10,    -1,    -1,
    -1,    14,     8,    -1,    10,    -1,    19,    -1,    14,    22,
    -1,    24,    -1,    19,    -1,    -1,    22,    61,    24,    -1,
    -1,    -1,    -1,    -1,    37,    38,    -1,    -1,    -1,    -1,
    43,    37,    38,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    64,    44,    45,    46,    47,    48,    49,
    50,    51,    52,    53,    54,    55,    56,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    64,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    -1,    -1,
    -1,    -1,    -1,    -1,    63,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    -1,    -1,
    -1,    -1,    -1,    -1,    63,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    -1,    -1,
    59,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    -1,    -1,    59,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    -1,    -1,    59,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    -1,    -1,    59,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    44,    -1,    46,    47,
    48,    49,    50,    51,    52,    53,    54,    55,    46,    47,
    48,    49,    50,    51,    52,    53,    54,    55,    46,    47,
    -1,    -1,    50,    51,    52,    53,    54,    55
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/bison.simple"
/* This file comes from bison-1.28.  */

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

#ifndef YYSTACK_USE_ALLOCA
#ifdef alloca
#define YYSTACK_USE_ALLOCA
#else /* alloca not defined */
#ifdef __GNUC__
#define YYSTACK_USE_ALLOCA
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi) || (defined (__sun) && defined (__i386))
#define YYSTACK_USE_ALLOCA
#include <alloca.h>
#else /* not sparc */
/* We think this test detects Watcom and Microsoft C.  */
/* This used to test MSDOS, but that is a bad idea
   since that symbol is in the user namespace.  */
#if (defined (_MSDOS) || defined (_MSDOS_)) && !defined (__TURBOC__)
#if 0 /* No need for malloc.h, which pollutes the namespace;
	 instead, just don't use alloca.  */
#include <malloc.h>
#endif
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
/* I don't know what this was needed for, but it pollutes the namespace.
   So I turned it off.   rms, 2 May 1997.  */
/* #include <malloc.h>  */
 #pragma alloca
#define YYSTACK_USE_ALLOCA
#else /* not MSDOS, or __TURBOC__, or _AIX */
#if 0
#ifdef __hpux /* haible@ilog.fr says this works for HPUX 9.05 and up,
		 and on HPUX 10.  Eventually we can turn this on.  */
#define YYSTACK_USE_ALLOCA
#define alloca __builtin_alloca
#endif /* __hpux */
#endif
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc */
#endif /* not GNU C */
#endif /* alloca not defined */
#endif /* YYSTACK_USE_ALLOCA not defined */

#ifdef YYSTACK_USE_ALLOCA
#define YYSTACK_ALLOC alloca
#else
#define YYSTACK_ALLOC malloc
#endif

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Define __yy_memcpy.  Note that the size argument
   should be passed with type unsigned int, because that is what the non-GCC
   definitions require.  With GCC, __builtin_memcpy takes an arg
   of type size_t, but it can handle unsigned int.  */

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     unsigned int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, unsigned int count)
{
  register char *t = to;
  register char *f = from;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 217 "/usr/share/bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
#ifdef YYPARSE_PARAM
int yyparse (void *);
#else
int yyparse (void);
#endif
#endif

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;
  int yyfree_stacks = 0;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  if (yyfree_stacks)
	    {
	      free (yyss);
	      free (yyvs);
#ifdef YYLSP_NEEDED
	      free (yyls);
#endif
	    }
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
#ifndef YYSTACK_USE_ALLOCA
      yyfree_stacks = 1;
#endif
      yyss = (short *) YYSTACK_ALLOC (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1,
		   size * (unsigned int) sizeof (*yyssp));
      yyvs = (YYSTYPE *) YYSTACK_ALLOC (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1,
		   size * (unsigned int) sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) YYSTACK_ALLOC (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1,
		   size * (unsigned int) sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 133 "parser.y"
{ troot = yyvsp[0];;
    break;}
case 2:
#line 136 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 3:
#line 137 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 4:
#line 138 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 5:
#line 139 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 6:
#line 140 "parser.y"
{yyval = NULL; ;
    break;}
case 7:
#line 143 "parser.y"
{make_instrpfields(yyvsp[0]);;
    break;}
case 8:
#line 145 "parser.y"
{yyval = make_instrdecl(yyvsp[-10],yyvsp[-9],yyvsp[-8],yyvsp[-7],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 9:
#line 148 "parser.y"
{yyval = make_miditag(yyvsp[-1],yyvsp[0]);;
    break;}
case 10:
#line 149 "parser.y"
{yyval = NULL;;
    break;}
case 11:
#line 152 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 13:
#line 157 "parser.y"
{make_opcodetype(yyvsp[-1],yyvsp[0]);;
    break;}
case 14:
#line 159 "parser.y"
{yyval = make_opcodedecl(yyvsp[-9],yyvsp[-8],yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 15:
#line 162 "parser.y"
{suspendvarchecks = 1;;
    break;}
case 16:
#line 163 "parser.y"
{yyval=make_globaldecl(yyvsp[-4],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 17:
#line 167 "parser.y"
{make_templatepfields(NULL,yyvsp[-1]);;
    break;}
case 18:
#line 170 "parser.y"
{templateopcodepatch();;
    break;}
case 19:
#line 172 "parser.y"
{yyval=make_templatedecl(yyvsp[-18],NULL,yyvsp[-15],yyvsp[-10],yyvsp[-6],yyvsp[-2],yyvsp[-1]);;
    break;}
case 20:
#line 174 "parser.y"
{suspendvarchecks = 1;;
    break;}
case 21:
#line 175 "parser.y"
{make_templatepfields(yyvsp[-5], yyvsp[-1]);;
    break;}
case 22:
#line 178 "parser.y"
{templateopcodepatch();;
    break;}
case 23:
#line 180 "parser.y"
{yyval=make_templatedecl(yyvsp[-21],yyvsp[-17],yyvsp[-15],yyvsp[-10],yyvsp[-6],yyvsp[-2],yyvsp[-1]);;
    break;}
case 24:
#line 184 "parser.y"
{yyval=make_mapblock(yyvsp[-4],yyvsp[-1]);;
    break;}
case 25:
#line 185 "parser.y"
{yyval=make_mapblock(NULL,yyvsp[-1]);;
    break;}
case 26:
#line 186 "parser.y"
{ yyval = NULL; ;
    break;}
case 27:
#line 189 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 28:
#line 190 "parser.y"
{ yyval = NULL; ;
    break;}
case 34:
#line 200 "parser.y"
{yyval = make_rtparam(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 35:
#line 201 "parser.y"
{yyval = make_rtparam(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 36:
#line 202 "parser.y"
{yyval = make_rtparam(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 37:
#line 203 "parser.y"
{yyval = make_rtparam(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 38:
#line 204 "parser.y"
{yyval = make_rtparam(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 39:
#line 208 "parser.y"
{yyval = make_routedef(yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 40:
#line 212 "parser.y"
{yyval = make_senddef(yyvsp[-8],yyvsp[-7],yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 41:
#line 216 "parser.y"
{yyval = make_seqdef(yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 42:
#line 219 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 43:
#line 220 "parser.y"
{yyval = NULL; ;
    break;}
case 44:
#line 224 "parser.y"
{yyval = make_statement(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 45:
#line 227 "parser.y"
{yyval = make_statement(yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 46:
#line 230 "parser.y"
{yyval = make_statement(yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],
                                       yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 47:
#line 233 "parser.y"
{yyval = make_statement(yyvsp[-10],yyvsp[-9],yyvsp[-8],yyvsp[-7],yyvsp[-6],yyvsp[-5],
                                       yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 48:
#line 236 "parser.y"
{yyval = make_statement(yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],
                                       yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 49:
#line 239 "parser.y"
{yyval = make_statement(yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 50:
#line 242 "parser.y"
{yyval = make_statement(yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 51:
#line 245 "parser.y"
{yyval = make_statement(yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 52:
#line 248 "parser.y"
{yyval = make_statement(yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],
                                       yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 53:
#line 251 "parser.y"
{yyval = make_statement(yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 54:
#line 254 "parser.y"
{yyval = make_statement(yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 55:
#line 257 "parser.y"
{yyval = make_statement(yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 56:
#line 260 "parser.y"
{yyval = make_statement(yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,
                                       NULL,NULL,NULL,NULL,NULL);;
    break;}
case 57:
#line 264 "parser.y"
{yyval = make_lval(yyvsp[0],NULL,NULL,NULL);;
    break;}
case 58:
#line 265 "parser.y"
{yyval = make_lval(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 59:
#line 268 "parser.y"
{yyval = leftsrecurse(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 61:
#line 270 "parser.y"
{yyval = NULL;;
    break;}
case 62:
#line 273 "parser.y"
{yyval = leftsrecurse(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 64:
#line 275 "parser.y"
{ yyval = NULL; ;
    break;}
case 65:
#line 278 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 66:
#line 279 "parser.y"
{yyval = NULL;;
    break;}
case 67:
#line 283 "parser.y"
{yyval=make_simplevar(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0], "<vardecl>" ,S_VARDECL);;
    break;}
case 68:
#line 285 "parser.y"
{yyval=make_simplevar(NULL,yyvsp[-2],yyvsp[-1],yyvsp[0], "<vardecl>", S_VARDECL);;
    break;}
case 69:
#line 287 "parser.y"
{yyval = yyvsp[-1];;
    break;}
case 70:
#line 289 "parser.y"
{yyval=make_tablemap(yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 71:
#line 292 "parser.y"
{yyval = leftrecurse(yyvsp[-1],yyvsp[0]);;
    break;}
case 72:
#line 293 "parser.y"
{yyval = NULL; ;
    break;}
case 73:
#line 297 "parser.y"
{yyval=make_simplevar(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0], "<opvardecl>" ,S_OPVARDECL);;
    break;}
case 74:
#line 299 "parser.y"
{yyval=make_simplevar(NULL,yyvsp[-2],yyvsp[-1],yyvsp[0], "<opvardecl>", S_OPVARDECL);;
    break;}
case 75:
#line 301 "parser.y"
{yyval = yyvsp[-1];;
    break;}
case 76:
#line 303 "parser.y"
{yyval=make_tablemap(yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 77:
#line 306 "parser.y"
{yyval = make_paramdecl(yyvsp[-1],yyvsp[0]);;
    break;}
case 78:
#line 309 "parser.y"
{yyval = leftsrecurse(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 80:
#line 313 "parser.y"
{yyval = make_name(yyvsp[0],NULL,NULL,NULL);;
    break;}
case 81:
#line 314 "parser.y"
{yyval = make_name(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 82:
#line 315 "parser.y"
{yyval = make_name(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 83:
#line 316 "parser.y"
{yyval = make_name(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 91:
#line 332 "parser.y"
{yyval = make_tabledecl(yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 92:
#line 336 "parser.y"
{yyval=make_stree(yyvsp[0],NULL,NULL,NULL,"<taglist>",S_TAGLIST);;
    break;}
case 93:
#line 338 "parser.y"
{yyval=make_stree(yyvsp[0],NULL,NULL,NULL,"<taglist>",S_TAGLIST);;
    break;}
case 94:
#line 340 "parser.y"
{yyval=make_stree(yyvsp[-1],yyvsp[0],NULL,NULL,"<taglist>",S_TAGLIST);;
    break;}
case 95:
#line 342 "parser.y"
{yyval=make_stree(yyvsp[-1],yyvsp[0],NULL,NULL,"<taglist>",S_TAGLIST);;
    break;}
case 100:
#line 352 "parser.y"
{yyval = make_expr(yyvsp[0],NULL,NULL,NULL,NULL,NULL,NULL);;
    break;}
case 101:
#line 354 "parser.y"
{yyval = make_expr(yyvsp[0],NULL,NULL,NULL,NULL,NULL,NULL);;
    break;}
case 102:
#line 356 "parser.y"
{yyval = make_expr(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL);;
    break;}
case 103:
#line 358 "parser.y"
{yyval = make_expr(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL);;
    break;}
case 104:
#line 360 "parser.y"
{yyval = make_expr(yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL);;
    break;}
case 105:
#line 362 "parser.y"
{yyval = make_expr(yyvsp[-6],yyvsp[-5],yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 106:
#line 364 "parser.y"
{yyval = make_expr(yyvsp[-4],yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL);;
    break;}
case 107:
#line 366 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 108:
#line 368 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 109:
#line 370 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 110:
#line 372 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 111:
#line 374 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 112:
#line 376 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 113:
#line 378 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 114:
#line 380 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 115:
#line 382 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 116:
#line 384 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 117:
#line 386 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 118:
#line 388 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 119:
#line 390 "parser.y"
{yyval = make_expr(yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL,NULL);;
    break;}
case 120:
#line 392 "parser.y"
{yyval = make_expr(yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL,NULL);;
    break;}
case 121:
#line 394 "parser.y"
{yyval = make_expr(yyvsp[-2],yyvsp[-1],yyvsp[0],NULL,NULL,NULL,NULL);;
    break;}
case 122:
#line 397 "parser.y"
{yyval = leftsrecurse(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 124:
#line 399 "parser.y"
{ yyval = NULL; ;
    break;}
case 125:
#line 402 "parser.y"
{yyval = leftsrecurse(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 126:
#line 403 "parser.y"
{yyval = leftsrecurse(yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 543 "/usr/share/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;

 yyacceptlab:
  /* YYACCEPT comes here.  */
  if (yyfree_stacks)
    {
      free (yyss);
      free (yyvs);
#ifdef YYLSP_NEEDED
      free (yyls);
#endif
    }
  return 0;

 yyabortlab:
  /* YYABORT comes here.  */
  if (yyfree_stacks)
    {
      free (yyss);
      free (yyvs);
#ifdef YYLSP_NEEDED
      free (yyls);
#endif
    }
  return 1;
}
#line 413 "parser.y"
         


