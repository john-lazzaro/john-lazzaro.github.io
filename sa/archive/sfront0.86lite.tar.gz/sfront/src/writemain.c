

/*
#    Sfront, a SAOL to C translator    
#    This file: Code generation: main loops
#    Copyright (C) 1999  Regents of the University of California
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License (Version 2) as
#    published by the Free Software Foundation.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    Maintainer: John Lazzaro, lazzaro@cs.berkeley.edu
*/

#include "tree.h"
#include "parser.tab.h"


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*         void printmakeloops() and void makeloops(char)       */
/*                                                              */
/* The postscript() function in writeorc.c calls the top-level  */
/* function printmakeloops(), to print out the functions that   */
/* actually executes all instruments and instances. The real    */
/* top-level work is done by makeloops().                       */
/*                                                              */
/*______________________________________________________________*/


extern void makeloops(char);

/****************************************************************/
/*  top-level function for writemain.c -- called by writeorc.c  */
/****************************************************************/

void printmainloops(void)

{

  makeloops('a');
  makeloops('k');
  makeloops('i');
  makeloops('n');
}


extern void apassstartup(sigsym *);
extern void kpassstartup(sigsym *);
extern void ipassstartup(sigsym *);
extern void apasssasl(sigsym *, char, char *);
extern void kpasssasl(sigsym *, char, char *);
extern void ipasscounter(sigsym *, char, char *);
extern void ipasssasl(sigsym *, char, char *);
extern void apasscore(sigsym *, char, char *);
extern void kpasscore(sigsym *, char, char *);
extern void ipasscore(sigsym *, char, char *);
extern void midipass(sigsym *, char, int);
extern void apasseffects(sigsym *);
extern void kpasseffects(sigsym *);
extern void ipasseffects(sigsym *);
extern void ipassinitpass(sigsym *);
extern void makeinputbusread(void);
extern void makebufferinit(void);

/****************************************************************/
/*           wrapper code generator for main_ loops             */
/****************************************************************/

void makeloops(char c)

{

  sigsym * sptr = instrnametable;

  switch (c) {
  case 'a':
    fprintf(outfile,"void main_apass(void)\n");
    break;
  case 'k':
    fprintf(outfile,"int main_kpass(void)\n");
    break;
  case 'i':
    fprintf(outfile,"void main_ipass(void)\n");
    break;
  case 'n':
    fprintf(outfile,"void main_initpass(void)\n");
    break;
  default:
    internalerror("writemain.c","makeloops switch 1");
  }

  fprintf(outfile,"\n{\n\n");

  if (c == 'i')
    fprintf(outfile,"int i;\n\n");

  if ((c == 'i') && (cin || session))
    makecontrolsys();

  if (c == 'a')
    makeinputbusread();

  while (sptr != NULL)
    {      
      if (sptr->startup)  /* startup instanced at start of execution */
	{
	  switch (c) {
	  case 'a':
	    apassstartup(sptr);
	    break;
	  case 'k':
	    kpassstartup(sptr);
	    break;
	  case 'i':
	    ipassstartup(sptr);
	    break;
	  case 'n':
	    break;
	  default:
	    internalerror("writemain.c","makeloops switch startup");
	  }
	}
      if (sptr->score)
	{
	  switch (c) {
	  case 'a':
	    apasssasl(sptr,'s',"s");
	    break;
	  case 'k':
	    kpasssasl(sptr,'s',"s");
	    break;
	  case 'i':
	    if (sptr->score > 1)
	      ipasscounter(sptr,'s',"s");
	    ipasssasl(sptr,'s',"s");
	    break;
	  case 'n':
	    break;
	  default:
	    internalerror("writemain.c","makeloops switch 2");
	  }
	}
      if (sptr->ascore)
	{
	  switch (c) {
	  case 'a':
	    apasssasl(sptr,'a',"sa");
	    break;
	  case 'k':
	    kpasssasl(sptr,'a',"sa");
	    break;
	  case 'i':
	    if (sptr->ascore > 1)
	      ipasscounter(sptr,'a',"sa");
	    ipasssasl(sptr,'a',"sa");
	    break;
	  case 'n':
	    break;
	  default:
	    internalerror("writemain.c","makeloops switch 2");
	  }
	}
      if (sptr->dyn)
	{
	  switch (c) {
	  case 'a':
	    apasscore(sptr,'d',"d");
	    break;
	  case 'k':
	    kpasscore(sptr,'d', "d");
	    break;
	  case 'i':
	    ipasscore(sptr,'d', "d");
	    break;
	  case 'n':
	    break;
	  default:
	    internalerror("writemain.c","makeloops switch 3");
	  }
	}

      /* midi file events */

      if (sptr->midi)          
	midipass(sptr, c, RELTSTAMP);

      if (sptr->amidi)          
	midipass(sptr, c, ABSTSTAMP);

      /* midi control device events -- only if instr has miditag */

      if ((cmidi || session) && sptr->miditag)
	{
	  switch (c) {
	  case 'a':
	    apasscore(sptr,'c',"cm");
	    break;
	  case 'k':
	    kpasscore(sptr,'c', "cm");
	    break;
	  case 'i':
	    ipasscore(sptr,'c', "cm");
	    break;
	  case 'n':
	    break;
	  default:
	    internalerror("writemain.c","makeloops switch 4");
	  }
	}

      /* sasl control device events */

      if (csasl)
	{
	  switch (c) {
	  case 'a':
	    apasscore(sptr,'l',"cs");
	    break;
	  case 'k':
	    kpasscore(sptr,'l', "cs");
	    break;
	  case 'i':
	    ipasscore(sptr,'l', "cs");
	    break;
	  case 'n':
	    break;
	  default:
	    internalerror("writemain.c","makeloops switch 4");
	  }
	}

      if (sptr->effects)
	{
	  switch (c) {
	  case 'a':
	    apasseffects(sptr);
	    break;
	  case 'k':
	    kpasseffects(sptr);
	    break;
	  case 'i':
	    ipasseffects(sptr);
	    break;
	  case 'n':
	    ipassinitpass(sptr);
	    break;
	  default:
	    internalerror("writemain.c","makeloops switch 5");
	  }
	}
      sptr = sptr->next;
    }

  if ((c == 'i') && csasl)
    makesaslcontrolsys();

  if (c == 'k')
    fprintf(outfile, "\n  return graceful_exit;");
  if (c == 'n')
    makebufferinit();
      

  fprintf(outfile,"\n}\n\n");

}


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                                                              */
/*    Second level functions for startup function creation      */
/*                                                              */
/*______________________________________________________________*/

/****************************************************************/
/*           writes core ipass code for sstartup instr          */
/****************************************************************/

void ipassstartup(sigsym * sptr)

{
  if (sptr->cref->conlines)
    {
      fprintf(outfile,"  sysidx = &u_startup[0];\n");
      fprintf(outfile,"  if (sysidx->noteon == PLAYING) {\n");
      fprintf(outfile,"   if (sysidx->released)\n");
      fprintf(outfile,"    {\n");
      fprintf(outfile,"     if (sysidx->turnoff)\n");
      fprintf(outfile,"      {\n");
      fprintf(outfile,"        sysidx->noteon = ALLDONE;\n");
      fprintf(outfile,"        for (i = 0; i < %s_ENDTBL; i++)\n", sptr->val);
      fprintf(outfile,"         if (sysidx->nstate->t[i].llmem)\n");
      fprintf(outfile,"           free(sysidx->nstate->t[i].t);\n");
      fprintf(outfile,"        sysidx->nstate->iline = NULL;\n"); 
      fprintf(outfile,"      }\n");
      fprintf(outfile,"     else\n");
      fprintf(outfile,"      {\n");
      fprintf(outfile,"        sysidx->abstime -= KTIME;\n");
      fprintf(outfile,"        if (sysidx->abstime < 0.0F)\n");
      fprintf(outfile,"         {\n");
      fprintf(outfile,"           sysidx->noteon = ALLDONE;\n");
      fprintf(outfile,"           for (i = 0; i < %s_ENDTBL; i++)\n",
	    sptr->val);
      fprintf(outfile,"            if (sysidx->nstate->t[i].llmem)\n");
      fprintf(outfile,"              free(sysidx->nstate->t[i].t);\n"); 
      fprintf(outfile,"           sysidx->nstate->iline = NULL;\n"); 
      fprintf(outfile,"         }\n");
      fprintf(outfile,"        else\n");
      fprintf(outfile,"         sysidx->turnoff = sysidx->released = 0;\n");
      fprintf(outfile,"      }\n");
      fprintf(outfile,"    }\n");
      fprintf(outfile,"   else\n");
      fprintf(outfile,"    {\n");
      fprintf(outfile,"     if (sysidx->turnoff)\n");
      fprintf(outfile,"      {\n");
      fprintf(outfile,"       sysidx->released = 1;\n");
      fprintf(outfile,"      }\n");
      fprintf(outfile,"     else\n");
      fprintf(outfile,"      {\n");
      fprintf(outfile,"        if (sysidx->endtime <= scorebeats)\n");
      fprintf(outfile,"         {\n");
      fprintf(outfile,"           if (sysidx->abstime <= 0.0F)\n");
      fprintf(outfile,"             sysidx->turnoff = sysidx->released = 1;\n");
      fprintf(outfile,"           else\n");
      fprintf(outfile,"           {\n");
      fprintf(outfile,"             sysidx->abstime -= KTIME;\n");
      fprintf(outfile,"             if (sysidx->abstime < 0.0F)\n");
      fprintf(outfile,"               sysidx->turnoff = sysidx->released = 1;\n");
      fprintf(outfile,"           }\n");
      fprintf(outfile,"         }\n");
      fprintf(outfile,"        else\n");
      fprintf(outfile,"          if ((sysidx->abstime < 0.0F) &&\n");  
      fprintf(outfile,"           (1.666667e-2F*tempo*sysidx->abstime + \n");
      fprintf(outfile,"               sysidx->endtime <= scorebeats))\n");
      fprintf(outfile,"            sysidx->turnoff = sysidx->released = 1;\n");
      fprintf(outfile,"      }\n");
      fprintf(outfile,"    }\n");
      fprintf(outfile,"   }\n");
    }
}


/****************************************************************/
/*           writes kpass code for startup instrs               */
/****************************************************************/

void kpassstartup(sigsym * sptr)

{
  if (sptr->cref->conlines)
    fprintf(outfile,"  if (u_startup[0].noteon == PLAYING)\n");
  
  /* needs separate copy for u_startup to eliminate argument */
  
  fprintf(outfile,"   startup_kpass(&ninstr[0]);\n");
  
}


/****************************************************************/
/*           writes apass code for startup instrs               */
/****************************************************************/

void apassstartup(sigsym * sptr)

{
  if (sptr->cref->alines)
    {
      if (sptr->cref->conlines)
	fprintf(outfile,"  if (u_startup[0].noteon == PLAYING)\n");

      /* needs separate copy for u_startup to eliminate argument */

      fprintf(outfile,"   startup_apass(&ninstr[0]);\n");
    }
}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                                                              */
/*  Second level functions for absolute-numbered SASL instrs    */
/*                                                              */
/*______________________________________________________________*/

/****************************************************************/
/*           writes core ipass code for sasl instr              */
/****************************************************************/

void ipasssasl(sigsym * sptr, char c, char * prefix)

{  
  char * val;

  val = dupunderscore(sptr->val);

  if ( ((c == 's') && (sptr->score > 1)) ||
       ((c == 'a') && (sptr->ascore > 1)))
    {
      fprintf(outfile,"  beginflag = 0;\n");
      fprintf(outfile," for (sysidx=%s_%sfirst;sysidx<=%s_%slast;sysidx++)\n"
	      ,prefix,val,prefix,val);
      fprintf(outfile,"  {\n");
    }
  else
    fprintf(outfile,"  sysidx = &%s_%s[0];\n", prefix, sptr->val);

  fprintf(outfile,"  switch(sysidx->noteon) {\n");
  fprintf(outfile,"   case PLAYING:\n");
  fprintf(outfile,"   if (sysidx->released)\n");
  fprintf(outfile,"    {\n");
  fprintf(outfile,"     if (sysidx->turnoff)\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"        sysidx->noteon = ALLDONE;\n");
  fprintf(outfile,"        for (i = 0; i < %s_ENDTBL; i++)\n", sptr->val);
  fprintf(outfile,"         if (sysidx->nstate->t[i].llmem)\n");
  fprintf(outfile,"           free(sysidx->nstate->t[i].t);\n");
  fprintf(outfile,"        sysidx->nstate->iline = NULL;\n"); 
  fprintf(outfile,"      }\n");
  fprintf(outfile,"     else\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"        sysidx->abstime -= KTIME;\n");
  fprintf(outfile,"        if (sysidx->abstime < 0.0F)\n");
  fprintf(outfile,"         {\n");
  fprintf(outfile,"           sysidx->noteon = ALLDONE;\n");
  fprintf(outfile,"           for (i = 0; i < %s_ENDTBL; i++)\n", sptr->val);
  fprintf(outfile,"            if (sysidx->nstate->t[i].llmem)\n");
  fprintf(outfile,"             free(sysidx->nstate->t[i].t);\n");
  fprintf(outfile,"           sysidx->nstate->iline = NULL;\n"); 
  fprintf(outfile,"         }\n");
  fprintf(outfile,"        else\n");
  fprintf(outfile,"         sysidx->turnoff = sysidx->released = 0;\n");
  fprintf(outfile,"      }\n");
  fprintf(outfile,"    }\n");
  fprintf(outfile,"   else\n");
  fprintf(outfile,"    {\n");
  fprintf(outfile,"     if (sysidx->turnoff)\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"       sysidx->released = 1;\n");
  fprintf(outfile,"      }\n");
  fprintf(outfile,"     else\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"        if (sysidx->endtime <= scorebeats)\n");
  fprintf(outfile,"         {\n");
  fprintf(outfile,"           if (sysidx->abstime <= 0.0F)\n");
  fprintf(outfile,"             sysidx->turnoff = sysidx->released = 1;\n");
  fprintf(outfile,"           else\n");
  fprintf(outfile,"           {\n");
  fprintf(outfile,"             sysidx->abstime -= KTIME;\n");
  fprintf(outfile,"             if (sysidx->abstime < 0.0F)\n");
  fprintf(outfile,"               sysidx->turnoff = sysidx->released = 1;\n");
  fprintf(outfile,"           }\n");
  fprintf(outfile,"         }\n");
  fprintf(outfile,"        else\n");  
  fprintf(outfile,"          if ((sysidx->abstime < 0.0F) &&\n");  
  fprintf(outfile,"           (1.666667e-2F*tempo*sysidx->abstime + \n");
  fprintf(outfile,"               sysidx->endtime <= scorebeats))\n");
  fprintf(outfile,"            sysidx->turnoff = sysidx->released = 1;\n");
  fprintf(outfile,"      }\n");
  fprintf(outfile,"    }\n");
  fprintf(outfile,"   break;\n");
  fprintf(outfile,"   case TOBEPLAYED:\n");  
  if (c == 'a')
    fprintf(outfile,"    if (sysidx->startabs <= absolutetime)\n");
  else
    fprintf(outfile,"    if (sysidx->starttime <= scorebeats)\n");
  fprintf(outfile,"     {\n");
  fprintf(outfile,"      sysidx->noteon = PLAYING;\n");
  fprintf(outfile,"      sysidx->notestate = nextstate;\n");
  fprintf(outfile,"      sysidx->nstate = &ninstr[nextstate];\n");

  if (totmidichan)
    {  
      fprintf(outfile,"      sysidx->numchan = midimasterchannel;\n");
    }

  fprintf(outfile,"      if (sysidx->sdur >= 0.0F)\n");
  fprintf(outfile,"        sysidx->endtime = scorebeats + sysidx->sdur;\n");
  fprintf(outfile,"      sysidx->kbirth = kcycleidx;\n");
  fprintf(outfile,"      ninstr[nextstate].iline = sysidx;\n");
  fprintf(outfile,"      sysidx->time = (kcycleidx-1)*KTIME;\n");
  nextstateupdate(NULL);
  fprintf(outfile,"      %s_ipass(sysidx->nstate);\n",sptr->val);
  fprintf(outfile,"    }\n");
  fprintf(outfile,"   break;\n");
  fprintf(outfile,"   }\n");
  if ( ((c == 's') && (sptr->score > 1)) ||
       ((c == 'a') && (sptr->ascore > 1)))
    {
      fprintf(outfile,"   if ((!beginflag) && (sysidx->noteon == ALLDONE))\n");
      fprintf(outfile,"     %s_%sfirst = sysidx+1;\n",prefix,val);
      fprintf(outfile,"   else\n");
      fprintf(outfile,"     beginflag = 1;\n");
      fprintf(outfile," }\n");
    }

  free(val);
}

/****************************************************************/
/*           writes kpass code for sasl instrs                  */
/****************************************************************/

void kpasssasl(sigsym * sptr, char c, char * prefix)

{
  char * val;

  val = dupunderscore(sptr->val);

  if ( ((c == 's') && (sptr->score == 1)) ||
       ((c == 'a') && (sptr->ascore == 1)))
    {
      fprintf(outfile,"  if (%s_%s[0].noteon == PLAYING)\n", prefix, 
	      sptr->val);
      fprintf(outfile,"   %s_kpass(%s_%s[0].nstate);\n",sptr->val,
	      prefix, sptr->val);
    }
  else
    {
      fprintf(outfile," for (sysidx=%s_%sfirst;sysidx<=%s_%slast;sysidx++)\n"
	      ,prefix,val,prefix,val);
      fprintf(outfile,"  if (sysidx->noteon == PLAYING)\n");
      fprintf(outfile,"   %s_kpass(sysidx->nstate);\n",sptr->val);
    }
  
  free(val);

}

/****************************************************************/
/*           writes apass code for sasl instrs                  */
/****************************************************************/

void apasssasl(sigsym * sptr, char c, char * prefix)

{
  char * val;

  val = dupunderscore(sptr->val);

  if (sptr->cref->alines)
    {
      if ( ((c == 's') && (sptr->score == 1)) ||
	   ((c == 'a') && (sptr->ascore == 1)))
	{
	  fprintf(outfile,"  if (%s_%s[0].noteon == PLAYING)\n", 
		  prefix, sptr->val);
	  fprintf(outfile,"   %s_apass(%s_%s[0].nstate);\n",sptr->val,
		  prefix, sptr->val);
	}
      else
	{
	  fprintf(outfile,
		  " for (sysidx=%s_%sfirst;sysidx<=%s_%slast;sysidx++)\n"
		  ,prefix, val,prefix,val);
	  fprintf(outfile,"  if (sysidx->noteon == PLAYING)\n");
	  fprintf(outfile,"   %s_apass(sysidx->nstate);\n",sptr->val);
	}
    }
  free(val);

}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                                                              */
/*  Second level functions for scorebeats-numbered SASL instrs  */
/*                                                              */
/*______________________________________________________________*/

/****************************************************************/
/*           writes ipass counter update code                  */
/****************************************************************/

void ipasscounter(sigsym * sptr, char c, char * s)


{
  char * val;

  val = dupunderscore(sptr->val);

  fprintf(outfile,"    sysidx = %s_%slast;\n",s,val);
  fprintf(outfile,"    while ((sysidx <= %s_%send) && \n",s,val);
  if (c == 'a')
    fprintf(outfile,"      (sysidx->startabs <= absolutetime))\n");
  else
    fprintf(outfile,"      (sysidx->starttime <= scorebeats))\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"       %s_%slast = sysidx;\n",s,val);
  fprintf(outfile,"       sysidx++;\n");
  fprintf(outfile,"      }\n");

  free(val);
}

/****************************************************************/
/*           writes core ipass code for instrs                  */
/****************************************************************/

void ipasscore(sigsym * sptr, char c, char * s)

{
  char * val;

  val = dupunderscore(sptr->val);

  if ((c != 'd') && (c != 'c') && (c != 'l'))
    fprintf(outfile,"  beginflag = 0;\n");
  fprintf(outfile," for (sysidx=%s_%sfirst;sysidx<=%s_%slast;sysidx++)\n"
	  ,s,val,s,val);
  fprintf(outfile,"  {\n");
  fprintf(outfile,"  switch(sysidx->noteon) {\n");
  fprintf(outfile,"   case PLAYING:\n");
  fprintf(outfile,"   if (sysidx->released)\n");
  fprintf(outfile,"    {\n");
  fprintf(outfile,"     if (sysidx->turnoff)\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"        sysidx->noteon = ALLDONE;\n");
  fprintf(outfile,"        for (i = 0; i < %s_ENDTBL; i++)\n", sptr->val);
  fprintf(outfile,"         if (sysidx->nstate->t[i].llmem)\n");
  fprintf(outfile,"           free(sysidx->nstate->t[i].t);\n");
  fprintf(outfile,"        sysidx->nstate->iline = NULL;\n"); 
  fprintf(outfile,"      }\n");
  fprintf(outfile,"     else\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"        sysidx->abstime -= KTIME;\n");
  fprintf(outfile,"        if (sysidx->abstime < 0.0F)\n");
  fprintf(outfile,"         {\n");
  fprintf(outfile,"           sysidx->noteon = ALLDONE;\n"); 
  fprintf(outfile,"           for (i = 0; i < %s_ENDTBL; i++)\n", sptr->val);
  fprintf(outfile,"            if (sysidx->nstate->t[i].llmem)\n");
  fprintf(outfile,"             free(sysidx->nstate->t[i].t);\n");
  fprintf(outfile,"           sysidx->nstate->iline = NULL;\n"); 
  fprintf(outfile,"         }\n");
  fprintf(outfile,"        else\n");
  fprintf(outfile,"         sysidx->turnoff = sysidx->released = 0;\n");
  fprintf(outfile,"      }\n");
  fprintf(outfile,"    }\n");
  fprintf(outfile,"   else\n");
  fprintf(outfile,"    {\n");
  fprintf(outfile,"     if (sysidx->turnoff)\n");
  fprintf(outfile,"      {\n");
  fprintf(outfile,"       sysidx->released = 1;\n");
  fprintf(outfile,"      }\n");
  fprintf(outfile,"     else\n");
  fprintf(outfile,"      {\n");
  if ((c == 'a')||(c == 'm')||(c == 'c'))
    {
      if (c == 'a')
	fprintf(outfile,"        if ((sysidx->endabs <= absolutetime) &&\n");
      else
	fprintf(outfile,"        if ((sysidx->endtime <= scorebeats) &&\n");
      fprintf(outfile,"        ");

      if (((c == 'm')||(c == 'a')) && midiallsoundsoff)
	fprintf(outfile,"(sysidx->label || ");

      fprintf(outfile, "(NG(%i*sysidx->nstate->iline->numchan+%i) == 0.0F))",
	    MIDIFRAMELEN, MIDICTRLPOS + 64);

      if (((c == 'm')||(c == 'a')) && midiallsoundsoff)
	fprintf(outfile,")");

      fprintf(outfile,"\n");
    }
  else
    fprintf(outfile,"        if (sysidx->endtime <= scorebeats)\n");

  fprintf(outfile,"         {\n");
  fprintf(outfile,"           if (sysidx->abstime <= 0.0F)\n");
  fprintf(outfile,"             sysidx->turnoff = sysidx->released = 1;\n");
  fprintf(outfile,"           else\n");
  fprintf(outfile,"           {\n");
  fprintf(outfile,"             sysidx->abstime -= KTIME;\n");
  fprintf(outfile,"             if (sysidx->abstime < 0.0F)\n");
  fprintf(outfile,"               sysidx->turnoff = sysidx->released = 1;\n");
  fprintf(outfile,"           }\n");

  if (((c == 'm')||(c == 'a')) && midiallsoundsoff)
    {
      fprintf(outfile,"           if (sysidx->label)\n");
      fprintf(outfile,"           {\n");
      fprintf(outfile,"             sysidx->noteon = ALLDONE;\n");
      fprintf(outfile,"             for (i = 0; i < %s_ENDTBL; i++)\n", sptr->val);
      fprintf(outfile,"              if (sysidx->nstate->t[i].llmem)\n");
      fprintf(outfile,"                free(sysidx->nstate->t[i].t);\n");
      fprintf(outfile,"             sysidx->nstate->iline = NULL;\n"); 
      fprintf(outfile,"           }\n");
    }

  fprintf(outfile,"         }\n");
  fprintf(outfile,"        else\n");
  if (c == 'a')
    {
      fprintf(outfile,"          if ((sysidx->abstime < 0.0F) &&\n");  
      fprintf(outfile,"           (sysidx->abstime + sysidx->endabs\n");
      fprintf(outfile,"               <= absolutetime))\n");
    }
  else
    {
      fprintf(outfile,"          if ((sysidx->abstime < 0.0F) &&\n");  
      fprintf(outfile,"           (1.666667e-2F*tempo*sysidx->abstime + \n");
      fprintf(outfile,"               sysidx->endtime <= scorebeats))\n");
    }
  fprintf(outfile,"            sysidx->turnoff = sysidx->released = 1;\n");
  fprintf(outfile,"      }\n");
  fprintf(outfile,"    }\n");
  fprintf(outfile,"   break;\n");
  fprintf(outfile,"   case TOBEPLAYED:\n");
  if (c == 'a')
    fprintf(outfile,"    if (sysidx->startabs <= absolutetime)\n");
  else
    fprintf(outfile,"    if (sysidx->starttime <= scorebeats)\n");
  fprintf(outfile,"     {\n");
  fprintf(outfile,"      sysidx->noteon = PLAYING;\n");
  fprintf(outfile,"      sysidx->notestate = nextstate;\n");
  fprintf(outfile,"      sysidx->nstate = &ninstr[nextstate];\n");

  if (totmidichan && ((c == 'd') || (c == 'l')))
    fprintf(outfile,"      sysidx->numchan = midimasterchannel;\n");

  fprintf(outfile,"      if (sysidx->sdur >= 0.0F)\n");
  fprintf(outfile,"        sysidx->endtime = scorebeats + sysidx->sdur;\n");
  fprintf(outfile,"      sysidx->kbirth = kcycleidx;\n");
  fprintf(outfile,"      ninstr[nextstate].iline = sysidx;\n");
  fprintf(outfile,"      sysidx->time = (kcycleidx-1)*KTIME;\n");
  nextstateupdate(NULL);
  fprintf(outfile,"      %s_ipass(sysidx->nstate);\n",sptr->val);
  fprintf(outfile,"    }\n");
  fprintf(outfile,"   break;\n");
  if (c == 'd')
    {
      fprintf(outfile,"   case PAUSED:\n");
      fprintf(outfile,"      sysidx->noteon = PLAYING;\n");
      fprintf(outfile,"      sysidx->kbirth = kcycleidx;\n");
      fprintf(outfile,"   break;\n");
    }
  fprintf(outfile,"   default:\n");
  fprintf(outfile,"   break;\n");
  fprintf(outfile,"   }\n");
  if ((c != 'd')&&(c != 'c')&&(c != 'l'))
    {
      fprintf(outfile,"   if ((!beginflag) && (sysidx->noteon == ALLDONE))\n");
      fprintf(outfile,"     %s_%sfirst = sysidx+1;\n",s,val);
      fprintf(outfile,"   else\n");
      fprintf(outfile,"     beginflag = 1;\n");
    }
  fprintf(outfile," }\n");
  if ((c == 'd')||(c == 'c')||(c == 'l'))
    {
      fprintf(outfile,"  while (%s_%slast->noteon == ALLDONE)\n",s,val);
      fprintf(outfile,"   if (%s_%slast == %s_%sfirst)\n",s,val,s,val);
      fprintf(outfile,"    {\n");
      fprintf(outfile,"     %s_%sfirst = &%s_%s[1];\n",s,val,s,sptr->val);
      fprintf(outfile,"     %s_%slast =  &%s_%s[0];\n",s,val,s,sptr->val);
      fprintf(outfile,"     %s_%snext =  NULL;\n",s,val);
      fprintf(outfile,"     %s_%slast->noteon = TOBEPLAYED;\n",s,val);
      fprintf(outfile,"     break;\n");
      fprintf(outfile,"    }\n");
      fprintf(outfile,"   else\n");
      fprintf(outfile,"    %s_%slast--;\n",s,val);
    }

  free(val);
}

/****************************************************************/
/*           writes core kpass code for instrs                  */
/****************************************************************/

void kpasscore(sigsym * sptr, char c, char * s)

{
  char * val;

  val = dupunderscore(sptr->val);

  fprintf(outfile," for (sysidx=%s_%sfirst;sysidx<=%s_%slast;sysidx++)\n"
	  ,s,val,s,val);
  fprintf(outfile,"  if (sysidx->noteon == PLAYING)\n");
  fprintf(outfile,"  {\n");
  if (c == 'd')
    fprintf(outfile,"   sysidx->launch = LAUNCHED;\n");
  fprintf(outfile,"   %s_kpass(sysidx->nstate);\n",sptr->val);
  fprintf(outfile,"  }\n");
 
  free(val);
}

/****************************************************************/
/*           writes core apass code for instrs                  */
/****************************************************************/

void apasscore(sigsym * sptr, char c, char * s)

{
  char * val;

  val = dupunderscore(sptr->val);

  if (sptr->cref->alines)
    {

      fprintf(outfile," for (sysidx=%s_%sfirst;sysidx<=%s_%slast;sysidx++)\n"
	      ,s,val,s,val);
      if (c == 'd')
	{
	  fprintf(outfile,
       "  if ((sysidx->noteon == PLAYING) &&(sysidx->launch == LAUNCHED))\n");
	}
      else
	fprintf(outfile,"  if (sysidx->noteon == PLAYING)\n");

      fprintf(outfile,"   %s_apass(sysidx->nstate);\n",sptr->val);

    }
  free(val);
}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                                                              */
/*         Second level functions for MIDI instrs               */
/*                                                              */
/*______________________________________________________________*/

/****************************************************************/
/*       writes core routines for midi-triggered instrs         */
/****************************************************************/

void midipass(sigsym * sptr, char c, int type)

{
  char * prefix;
  tnode * tptr;
  int i;
  char iname[32];
  char ccode;

  if (type == RELTSTAMP)
    {
      tptr = confmidi->imidiroot;
      i = sptr->midi;
      prefix = "m";
      ccode = 'm';
    }
  else
    {
      tptr = sstrmidi->imidiroot;
      i = sptr->amidi;
      prefix = "ma";
      ccode = 'a';
    }

  while ((tptr != NULL)&&(i > 0))
    {
      if (tptr->sptr != sptr)
        {
          tptr = tptr->next;
          continue;
        }
      sprintf(iname,"%s%i",prefix,tptr->special);
      switch (c) {
      case 'a':
	apasscore(sptr, 'm',iname);
	break;
      case 'k':
	kpasscore(sptr,'m', iname);
	break;
      case 'i':
	ipasscounter(sptr,ccode, iname);
	ipasscore(sptr,ccode, iname);
	break;
      default:
	break;
      }
      i--;
      tptr = tptr->next;
    }
}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                                                              */
/*         Second level functions for effects instrs            */
/*                                                              */
/*______________________________________________________________*/

/****************************************************************/
/*           writes initpass code for effects instrs            */
/****************************************************************/

void ipassinitpass(sigsym * sptr)

{

  tnode * tptr = instances;
  int i = 0;
  
  while (tptr != NULL)
    {
      if (!strcmp(tptr->sptr->val, sptr->val))
	{
	  fprintf(outfile,"  e_%s[%i].noteon = PLAYING;\n", sptr->val,i);
	  fprintf(outfile,"  e_%s[%i].notestate = nextstate;\n", sptr->val,i);
	  fprintf(outfile,"  e_%s[%i].endtime = MAXENDTIME;\n", sptr->val,i);
	  fprintf(outfile,"  e_%s[%i].nstate = &ninstr[nextstate];\n",
		  sptr->val,i);
	  fprintf(outfile,"  ninstr[nextstate].iline = &e_%s[%i];\n",
		  sptr->val,i);
	  nextstateupdate(NULL);
	  fprintf(outfile,"   %s_ipass();\n", tptr->val);
	  fprintf(outfile,"\n");
	  i++;
	}
      tptr = tptr->next;
    }

}

/****************************************************************/
/*           writes core ipass code for effects instrs          */
/****************************************************************/

void ipasseffects(sigsym * sptr)
     
{
  
  tnode * tptr = instances;
  int i = 0;
  
  while (tptr != NULL)
    {
      if (!strcmp(tptr->sptr->val, sptr->val))
	{
	  if (tptr->sptr->cref->conlines)
	    {
	      fprintf(outfile,"  sysidx = &e_%s[%i];\n", sptr->val,i);
	      fprintf(outfile,"  if (sysidx->noteon == PLAYING) {\n");
	      fprintf(outfile,"   if (sysidx->released)\n");
	      fprintf(outfile,"    {\n");
	      fprintf(outfile,"     if (sysidx->turnoff)\n");
	      fprintf(outfile,"      {\n");
	      fprintf(outfile,"        sysidx->noteon = ALLDONE;\n");
	      fprintf(outfile,"        sysidx->nstate->iline = NULL;\n"); 
	      fprintf(outfile,"      }\n");
	      fprintf(outfile,"     else\n");
	      fprintf(outfile,"      {\n");
	      fprintf(outfile,"        sysidx->abstime -= KTIME;\n");
	      fprintf(outfile,"        if (sysidx->abstime < 0.0F)\n");
	      fprintf(outfile,"         {\n");
	      fprintf(outfile,"           sysidx->noteon = ALLDONE;\n"); 
	      fprintf(outfile,"           sysidx->nstate->iline = NULL;\n"); 
	      fprintf(outfile,"         }\n");
	      fprintf(outfile,"        else\n");
	      fprintf(outfile,"         sysidx->turnoff = sysidx->released = 0;\n");
	      fprintf(outfile,"      }\n");
	      fprintf(outfile,"    }\n");
	      fprintf(outfile,"   else\n");
	      fprintf(outfile,"    {\n");
	      fprintf(outfile,"     if (sysidx->turnoff)\n");
	      fprintf(outfile,"      {\n");
	      fprintf(outfile,"       sysidx->released = 1;\n");
	      fprintf(outfile,"      }\n");
	      fprintf(outfile,"     else\n");
	      fprintf(outfile,"      {\n");
	      fprintf(outfile,"        if (sysidx->endtime <= scorebeats)\n");
	      fprintf(outfile,"         {\n");
	      fprintf(outfile,"           if (sysidx->abstime <= 0.0F)\n");
	      fprintf(outfile,"             sysidx->turnoff = sysidx->released = 1;\n");
	      fprintf(outfile,"           else\n");
	      fprintf(outfile,"           {\n");
	      fprintf(outfile,"             sysidx->abstime -= KTIME;\n");
	      fprintf(outfile,"             if (sysidx->abstime < 0.0F)\n");
	      fprintf(outfile,"               sysidx->turnoff = sysidx->released = 1;\n");
	      fprintf(outfile,"           }\n");
	      fprintf(outfile,"         }\n");
	      fprintf(outfile,"        else\n");
	      fprintf(outfile,"          if ((sysidx->abstime < 0.0F) &&\n");  
	      fprintf(outfile,"           (1.666667e-2F*tempo*sysidx->abstime + \n");
	      fprintf(outfile,"               sysidx->endtime <= scorebeats))\n");
	      fprintf(outfile,"            sysidx->turnoff = sysidx->released = 1;\n");
	      fprintf(outfile,"      }\n");
	      fprintf(outfile,"    }\n");
	      fprintf(outfile,"   }\n");
	    }
	  i++;
	}
      tptr = tptr->next;
    }

}

/****************************************************************/
/*           writes core kpass code for effects instrs          */
/****************************************************************/

void kpasseffects(sigsym * sptr)

{

  tnode * tptr = instances;
  int i = 0;
  
  while (tptr != NULL)
    {
      if (!strcmp(tptr->sptr->val, sptr->val))
	{
	  if (tptr->sptr->cref->conlines)
	    fprintf(outfile,"  if (e_%s[%i].noteon == PLAYING)\n",
		    sptr->val,i);
	  fprintf(outfile,"   %s_kpass();\n", tptr->val);
	  i++;
	}
      tptr = tptr->next;
    }

}

/****************************************************************/
/*           writes core apass code for effects instrs          */
/****************************************************************/

void apasseffects(sigsym * sptr)

{

  tnode * tptr = instances;
  int i = 0;
  
  while (tptr != NULL)
    {
      if (!strcmp(tptr->sptr->val, sptr->val))
	{
	  if (tptr->sptr->cref->alines)
	    {
	      if (tptr->sptr->cref->conlines)
		fprintf(outfile,"  if (e_%s[%i].noteon == PLAYING)\n",
			sptr->val,i);
	      fprintf(outfile,"   %s_apass();\n", tptr->val);
	    }
	  i++;
	}
      tptr = tptr->next;
    }

}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                                                              */
/*            Miscellaneous Second level functions.             */
/*                                                              */
/*______________________________________________________________*/

/****************************************************************/
/*       reads stdin for latest input_bus data                  */
/****************************************************************/

void makeinputbusread(void)

{

  if ((getvsym(&busnametable,"input_bus") != NULL) && (inchannels > 0) && 
      (ainflow == PASSIVE_FLOW) && (aoutflow == PASSIVE_FLOW))
    {
      fprintf(outfile,"   if (ibusidx < asys_isize)\n");
      fprintf(outfile,
	      "    for(busidx=BUS_input_bus;busidx<BUS_input_bus+%i;busidx++)\n",
	      inchannels);
      switch (makeaudiotypein(ain)) {
      case SAMPLE_SHORT:
	fprintf(outfile,
		"      TB(busidx) = 3.051851e-5F*asys_ibuf[ibusidx++];\n");
	break;
      case SAMPLE_FLOAT:
	fprintf(outfile,
		"      TB(busidx) = asys_ibuf[ibusidx++];\n");
	break;
      }
      fprintf(outfile,"   else\n");
      fprintf(outfile,"   {\n");
      fprintf(outfile,"    ibusidx = 0;\n");
      fprintf(outfile,"    if (asys_getbuf(&asys_ibuf, &asys_isize)"
	                       "||(!asys_isize))\n");
      fprintf(outfile,"     {\n");
      fprintf(outfile,"       asys_isize = 0;\n");
      fprintf(outfile,
	      "       for(busidx=BUS_input_bus;busidx<BUS_input_bus+%i;busidx++)\n",
	      inchannels);
      fprintf(outfile,"       TB(busidx) = 0.0F;\n");
      fprintf(outfile,"       kcycleidx = endkcycle;\n");
      fprintf(outfile,"      }\n");
      fprintf(outfile,"    else\n");
      fprintf(outfile,
	      "      for(busidx=BUS_input_bus;busidx<BUS_input_bus+%i;busidx++)\n",
	      inchannels);
      switch (makeaudiotypein(ain)) {
      case SAMPLE_SHORT:
	fprintf(outfile,
		"      TB(busidx) = 3.051851e-5F*asys_ibuf[ibusidx++];\n");
	break;
      case SAMPLE_FLOAT:
	fprintf(outfile,
		"      TB(busidx) = asys_ibuf[ibusidx++];\n");
	break;
      }
      fprintf(outfile,"   }\n");
    }

}

/****************************************************************/
/*       does initialization for buffer and synchronication     */
/****************************************************************/

void makebufferinit(void)

{
  sigsym * iptr;

  fprintf(outfile, "\n");
  iptr = getvsym(&busnametable,"input_bus");

  if (session)
    {
      fprintf(outfile, "   if (nsys_setup(NSYS_NONBLOCK) == NSYS_ERROR)\n");
      gened(NULL,"network setup failure");
      fprintf(outfile, "\n");
    }

  if (cin)
    {
      fprintf(outfile, "   if (csys_setup() != CSYS_DONE)\n");
      gened(NULL,"control input device unavailable");
      fprintf(outfile, "\n");
    }

  if ((ain == aout) && (iptr != NULL) && (inchannels > 0))
    {
      fprintf(outfile, "   if (asys_iosetup((int)ARATE, ASYS_ICHAN, ");
      fprintf(outfile, "ASYS_OCHAN, ASYS_ITYPENAME, ASYS_OTYPENAME,");
      fprintf(outfile, "\"%s\", \"%s\",", ainname, aoutname);
      fprintf(outfile, "ASYS_TIMEOPTION) != ASYS_DONE)\n");
      gened(NULL,"audio i/o device unavailable");
    }
  else
    {
      fprintf(outfile, "   if (asys_osetup((int)ARATE, ASYS_OCHAN, ");
      fprintf(outfile, "ASYS_OTYPENAME, ");
      fprintf(outfile, " \"%s\",\n", aoutname);
      fprintf(outfile, "ASYS_TIMEOPTION) != ASYS_DONE)\n");
      gened(NULL,"audio output device unavailable");
      if ((iptr != NULL) && (inchannels > 0))
	{
	  fprintf(outfile, "   if (asys_isetup((int)ARATE, ASYS_ICHAN, ");
	  fprintf(outfile, "ASYS_ITYPENAME, ");
	  fprintf(outfile, " \"%s\",", ainname);
	  fprintf(outfile, "ASYS_TIMEOPTION) != ASYS_DONE)\n");
	  gened(NULL,"audio input device unavailable");
	}
    }

  if (allsasl->endtimeval)
    {
      fprintf(outfile, "   endkcycle = kbase + (int) \n");
      fprintf(outfile, 
	      "      (KRATE*(endtime - scorebase)*(60.0F/tempo));\n\n");
      if (abssasl->endtimeval)
	{
	  fprintf(outfile, 
		  "   endkcycle = (endkinit > endkcycle) ?\n");
	  fprintf(outfile, 
		  "                endkinit : endkcycle;\n\n");
	}
    }
  else
    {
      fprintf(outfile, "   endkcycle = endkinit;\n\n");
    }

  if ((ainflow == PASSIVE_FLOW) && (aoutflow == PASSIVE_FLOW))
    {

      /* ordering tentative, pending testing */

      if ((iptr != NULL) && (inchannels > 0))
	{
	  fprintf(outfile, " if "
		  "((asys_getbuf(&asys_ibuf, &asys_isize) != ASYS_DONE)\n");
	  fprintf(outfile,
		  "     || (!asys_isize))\n");
	  gened(NULL,"audio input device unavailable");
	}

      fprintf(outfile, 
	      "   if (asys_preamble(&asys_obuf, &asys_osize) != ASYS_DONE)\n");
      gened(NULL,"audio output device unavailable");
    }

  fprintf(outfile, "   ksyncinit();\n\n");

}

