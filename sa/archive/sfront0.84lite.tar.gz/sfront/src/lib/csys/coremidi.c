
/*
#    Sfront, a SAOL to C translator    
#    This file: coremidi control driver for sfront
#    Copyright (C) 2002 Regents of the University of California
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License (Version 2) as
#    published by the Free Software Foundation.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    Maintainer: John Lazzaro, lazzaro@cs.berkeley.edu
*/

/****************************************************************/
/****************************************************************/
/*                coremidi control driver for sfront            */ 
/****************************************************************/

#include <sys/types.h>
#include <sys/socket.h>

#include <fcntl.h>

#if !(defined(ASYS_OUTDRIVER_COREAUDIO)||defined(ASYS_INDRIVER_COREAUDIO))
#include <CoreFoundation/CFString.h>
#endif

#include <CoreMIDI/CoreMIDI.h>

#define CSYSI_BUFFSIZE   1024  /* size of the holding buffer   */
#define CSYSI_SENDSIZE   256   /* maximum size of one packet[] */

/************************/
/* input port variables */
/************************/

MIDIClientRef csysi_inclient;  /* the input client  */
MIDIPortRef   csysi_inport;    /* it's port         */

/**********************************************/
/* read_proc pipe -- needs to be an array ... */
/**********************************************/

int csysi_readproc_pipepair[2];    /* csys_newdata <==> readproc */

/***********************/
/* buffer for commands */
/***********************/

unsigned char csysi_buffer[CSYSI_BUFFSIZE];
int csysi_len, csysi_cnt;

/*********************/
/* temporary -- redo */
/*********************/

int csysi_extchan = 0 ;        /* lots of assumptions ... */

/****************************************************************/
/*          generic error-checking wrappers                     */
/****************************************************************/

#define  CSYSI_ERROR_RETURN(x) do {\
      fprintf(stderr, "  Error: %s.\n", x);\
      fprintf(stderr, "  Errno Message: %s\n\n", strerror(errno));\
      return CSYS_ERROR; } while (0)

#define  CSYSI_ERROR_TERMINATE(x) do {\
      fprintf(stderr, "  Runtime Errno Message: %s\n", strerror(errno));\
      epr(0,NULL,NULL, "Soundcard error -- " x );}  while (0)

/*******************/
/* forward externs */
/*******************/

extern void csysi_read_proc(const MIDIPacketList * pktlist,
			    void * readProcRefCon, 
			    void * srcConnRefCon);


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*     high-level functions: called by sfront engine            */
/*______________________________________________________________*/

/****************************************************************/
/*             initialization routine for control               */
/****************************************************************/

int csys_setup(void)
     
{
  int connected, numsrc, flags;
  MIDIEndpointRef src;
  CFStringRef cf_name;
  char name[256];

  /********************************/
  /* create input client and port */
  /********************************/

  if (MIDIClientCreate(CFSTR("sfront_inclient"), NULL, 
		       (void *) NULL, &csysi_inclient))
    CSYSI_ERROR_RETURN("Error: Could not create CoreMIDI client");

  if (MIDIInputPortCreate(csysi_inclient, CFSTR("sfront_inport"),
			  csysi_read_proc, (void *) NULL, 
			  &csysi_inport))
    CSYSI_ERROR_RETURN("Error: Could not create CoreMIDI inport");

  /********************************************************/
  /* open pipes, since data may start flowing immediately */
  /********************************************************/

  if (socketpair(AF_UNIX, SOCK_DGRAM, 0, csysi_readproc_pipepair))
    CSYSI_ERROR_RETURN("Cannot open readproc pipe");

  if ((flags = fcntl(csysi_readproc_pipepair[0], F_GETFL, 0)) == -1)
    CSYSI_ERROR_RETURN("Unknown flags for read end of readproc pipe");

  if (fcntl(csysi_readproc_pipepair[0], F_SETFL, flags | O_NONBLOCK) == -1) 
    CSYSI_ERROR_RETURN("Cannot O_NONBLOCK read end of readproc pipe");

  /********************************************************/
  /* for now, connect only one source, exit if no sources */
  /********************************************************/

  connected = 0;
  numsrc = (int) MIDIGetNumberOfSources();

  while (numsrc--)
    if ((src = MIDIGetSource((ItemCount) numsrc)) &&
	!MIDIPortConnectSource(csysi_inport, src, &csysi_extchan))
      {
	connected = 1;
	break;
      }

  if (!connected)
    CSYSI_ERROR_RETURN("Could not connect to a CoreMIDI source");

  /*****************************/
  /* print out source identity */
  /*****************************/

  if (MIDIObjectGetStringProperty(src, kMIDIPropertyName, &cf_name))
    {
      printf("Connected to an unknown CoreMIDI source.\n");
      return CSYS_DONE;  /* return CSYS_ERROR; */      
    }

  if (CFStringGetCString(cf_name, name, 256, CFStringGetSystemEncoding()))
    {
      printf("Connected to an unknown CoreMIDI source.\n");
      CFRelease(cf_name);
      return CSYS_DONE;  /* return CSYS_ERROR; */      
    }

  CFRelease(cf_name);
  printf("Connected to CoreMIDI source %s.\n", name);

  return CSYS_DONE;  /* return CSYS_ERROR; */
}

/****************************************************************/
/*             polling routine for new data                     */
/****************************************************************/

int csys_newdata(void)
     
{
  int len;

  if ((csysi_len = read(csysi_readproc_pipepair[0], csysi_buffer, 
			CSYSI_SENDSIZE)) <= 0)
    return CSYS_NONE;

  do 
    {
      if ((len = read(csysi_readproc_pipepair[0], 
		      &(csysi_buffer[csysi_len]), CSYSI_SENDSIZE)) <= 0)
	break;
      csysi_len += len;
    } 
  while (csysi_len <= (CSYSI_BUFFSIZE - CSYSI_SENDSIZE));

  csysi_cnt = 0;
  return CSYS_MIDIEVENTS;
}

/****************************************************************/
/*                 processes a MIDI event                       */
/****************************************************************/

int csys_midievent(unsigned char * cmd,   unsigned char * ndata, 
	           unsigned char * vdata, unsigned short * extchan,
		   float * fval)

{
  /* assumes:
   *   1 - integral number of commands
   *   2 - all system commands filtered out
   *   3 - input stream is perfect MIDI
   */

  *cmd = 0xF0 & csysi_buffer[csysi_cnt];
  *extchan = 0x0F & csysi_buffer[csysi_cnt++];
  *ndata = csysi_buffer[csysi_cnt++];

  if ((*cmd != CSYS_MIDI_PROGRAM) && (*cmd != CSYS_MIDI_CTOUCH))
    *vdata = csysi_buffer[csysi_cnt++];
  
  if (csysi_cnt == csysi_len)
    return CSYS_NONE;
  else
    return CSYS_MIDIEVENTS;
}

/****************************************************************/
/*                  closing routine for control                 */
/****************************************************************/

void csys_shutdown(void)
     
{
  close(csysi_readproc_pipepair[0]);
  close(csysi_readproc_pipepair[1]);
  return;
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*       callback functions: called by coremidi directly        */
/*______________________________________________________________*/

/****************************************************************/
/*                  callback for MIDI input                     */
/****************************************************************/

void csysi_read_proc(const MIDIPacketList * pktlist,
		     void * readProcRefCon, void * srcConnRefCon)

{
  int num = pktlist->numPackets;
  MIDIPacket * p = (MIDIPacket *) &(pktlist->packet[0]);

  /* primitive in many ways ... */

  while (num--)
    {
      if (write(csysi_readproc_pipepair[1], p->data, p->length) < 0)
	{
	  printf("error with write() in read_proc()\n");
	  return;
	}
      p = MIDIPacketNext(p);
    }
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*   mid-level functions: called by top-level driver functions  */
/*______________________________________________________________*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                 low-level functions                          */
/*______________________________________________________________*/




