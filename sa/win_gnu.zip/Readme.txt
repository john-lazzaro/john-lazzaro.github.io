GCC / Make Win32 binary distribution for use with sfront
====================================================================
Distribution assembled by Ross Bencina <rossb@audiomulch.com>

Introduction
------------

This archive contains a minimal set of supporting binaries for 
compiling sfront generated C files on win32 platforms. It consists 
of a C compiler with support files (header files, standard libraries 
etc.) and the Make utility.

Note that this distribution does not include sfront.exe, which is
distributed as a separate file. When obtained, sfront.exe should
be placed in the \bin subdirectory of this distribution.

The binaries included in this distribution have been assembled from
the following sources:

1. GCC-2.95 binary release for Mingw distribution. 
http://www.xraylith.wisc.edu/~khan/software/gnu-win32/ 

2. GNU Make 3.78.1 source distribution.
http://www.fsf.org/software/make/make.html

These programs are distributed under the terms of the GNU Public 
License, see the file Copying for details.


Many of the files from the Mingw GCC distribution have been removed
from this distribution to reduce its size. No GCC documentation has
been included - thus severely limiting its utility for non-sfront
related applications. As a result, this distribution should not be 
considered a full compiler suite. Anyone intending to undertake 
development with the GCC compiler should download a full GCC binary 
distribution from http://www.fsf.org/software/gcc/gcc.html or 
the Mingw URL above.


Installing
----------

The following information is taken from the Install.txt file for
the mingw GCC distribution by Mumit Khan <khan@xraylith.wisc.edu>:

1. Pre-installation:

  a. Decide where to install it. I usually install in "C:\GCC-2.95", but
     you can install *anywhere* you want, including on a ZIP/JAZ drive.
     All you have to do is to set PATH and optionally GCC_EXEC_PREFIX 
     accordingly (see later). From here on, I'll use "C:\GCC-2.95" as 
     the installation root directory. Please replace with whatever you've 
     chosen. You can use the sample "MINGW32.BAT" I've provided in the 
     distribution to setup the variables. DO NOT install in a directory
     with spaces in it (eg., C:\Program Files\Mingw).
  
  b. Make sure you DO NOT install on top of an existing installation.
     Either install elsewhere, or delete the old directory structure first.
  
2. INSTALL:
   
   You must use an "unzip" program that understands both long file names
   and also maintains directory structure. Pkunzip and WinZIP work just
   fine, and I'm sure a host of others do as well. You might have to
   supply "-d" option when unzipping to maintain directory structure.

   First create the installation directory. 

     C:\> mkdir C:\GCC-2.95
     C:\> cd C:\GCC-2.95

     C:\> unzip -d C:\tmp\gcc-2.95-mingw32.zip

3. Setting up environment variables and such:
   
   Starting from EGCS-1.1.2 release, GCC does not require *any* environment
   variable to run properly. You can still set GCC_EXEC_PREFIX if you
   wish (useful for example to switch between multiple GCC distributions), 
   but it's completely optional. EGCS now looks for the system includes, 
   libraries, programs, etc relative to its installation directory. 

   You'll still need to add the GCC-2.95 bin directory,
   C:\GCC-2.95\bin, to your PATH for GCC to be able to find various 
   other tools such the linker, assembler, etc.

   The following is all you need for this release:
     
     C:\> PATH=C:\GCC-2.95\BIN;%PATH%
    
   Again, see the supplied MINGW32.BAT file. Those of you who use a Unix
   like SHELL such as bash, use "mingw32.sh" instead. 

   Make sure you do not have any other variables set from previous version
   or else GCC will search incorrect places for libraries and headers. The
   ones that you DO NOT need anymore are: LIBRARY_PATH, C_INCLUDE_PATH,
   CPLUS_INCLUDE_PATH, and OBJC_INCLUDE_PATH. If you *DO* have the variable
   GCC_EXEC_PREFIX in your environment, just make sure it's set correctly.
   
[ end mingw GCC install.txt quote ]


Known Issues
------------

The included version of GCC and supporting libraries will not 
currently compile sfront generated code that uses real-time MIDI input 
or DirectSound output.

The included version of GNU Make does not handle file paths with
spaces very well. You are advised to avoid using spaces in file 
paths passed to Make (in makefiles etc).

Some of the rules in Make files distributed as part of the sfront
examples package make use of the UNIX commands rm (remove), 
cp (copy), and mv (move) commands. Make will carry on regardless,
(but not perform the selected actions.) The best fix for this is
to obtain a set of unix commands for windows, such as the free
"Unix 95 Collection" available from http://www.itribe.net/virtunix
You could also try patching the Makefiles to use DEL COPY et al
instead.


Legal, Warranties etc.
----------------------

This software is provided as-is. Please read the file Copying for
full details of the conditions under which this software is 
distributed.


====================================================================